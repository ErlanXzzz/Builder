import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../dashboard/dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String balance;
  final String apiKeyQris;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listBugCh;
  final List<dynamic> news;
  final String? uid;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.balance,
    required this.apiKeyQris,
    required this.listBug,
    required this.listBugGroup,
    required this.listBugCh,
    required this.news,
    this.uid,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  VideoPlayerController? _videoController;
  late AnimationController _fadeController;
  late Animation<double> _textOpacityAnimation;
  bool _videoReady = false;
  bool _videoError = false;
  bool _skipPressed = false;
  bool _videoCompleted = false;

  Timer? _initTimeoutTimer;   // timeout kalau video gagal di-load
  Timer? _stuckCheckTimer;    // cek video stuck

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA ORANGE THEME
  // ═══════════════════════════════════════════════════════════════════
  final Color _primaryColor = const Color(0xFF050810);
  final Color _textColor = const Color(0xFFFF6600);
  final Color _accentColor = const Color(0xFFFF6600);

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _textOpacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) _fadeController.forward();
    });

    _initializeVideo();
  }

  // ═══════════════════════════════════════════════════════════════════
  // VIDEO INIT — durasi mengikuti video
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _initializeVideo() async {
    try {
      _videoController = VideoPlayerController.asset(
        "assets/videos/splash.mp4",
      );

      // Timeout HANYA untuk proses initialize (kalau video gagal dimuat)
      _initTimeoutTimer = Timer(const Duration(seconds: 8), () {
        if (mounted &&
            _videoController != null &&
            !_videoController!.value.isInitialized) {
          debugPrint("Video init timeout — fallback mode");
          _handleVideoError();
        }
      });

      await _videoController!.initialize();
      _initTimeoutTimer?.cancel();

      if (!mounted) return;

      setState(() {
        _videoReady = true;
      });

      // ⚙️ Setup video
      _videoController!.setLooping(false);   // ⭐ JANGAN loop — biar durasi sesuai
      _videoController!.setVolume(0.7);

      try {
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
      } catch (_) {}

      // ⭐ LISTENER: deteksi video selesai → langsung ke dashboard
      _videoController!.addListener(_onVideoPositionChanged);

      // ▶️ Play video
      await _videoController!.play().catchError((e) {
        debugPrint("Play error: $e");
        _handleVideoError();
      });

      // Cek video stuck (buat handle video corrupt / gak jalan)
      _startStuckCheckTimer();
    } catch (e) {
      debugPrint("Video init error: $e");
      _initTimeoutTimer?.cancel();
      _handleVideoError();
    }
  }

  // ⭐ Listener yang cek posisi video — kalau udah habis → ke dashboard
  void _onVideoPositionChanged() {
    if (!mounted || _skipPressed || _videoCompleted) return;
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return;
    }

    final position = _videoController!.value.position;
    final duration = _videoController!.value.duration;
    final isPlaying = _videoController!.value.isPlaying;

    // ⭐ Kalau video udah selesai (position >= duration)
    if (duration > Duration.zero &&
        position >= duration - const Duration(milliseconds: 100)) {
      _videoCompleted = true;
      debugPrint("Video selesai — durasi: ${duration.inSeconds}s");
      _navigateToDashboard();
    }

    // ⭐ Kalau video berhenti tapi belum selesai (edge case)
    if (!isPlaying &&
        position > Duration.zero &&
        position < duration &&
        !_videoCompleted) {
      // Cek apakah beneran berhenti atau cuma buffering
      Future.delayed(const Duration(milliseconds: 300), () {
        if (!mounted || _skipPressed || _videoCompleted) return;
        if (_videoController == null) return;

        final stillPaused = !_videoController!.value.isPlaying;
        final stillPosition = _videoController!.value.position;

        if (stillPaused &&
            stillPosition == position &&
            position < duration) {
          debugPrint("Video berhenti di ${position.inSeconds}s — lanjut");
          _videoCompleted = true;
          _navigateToDashboard();
        }
      });
    }
  }

  // ⭐ Cek video stuck (kalau posisi gak gerak selama 5 detik)
  void _startStuckCheckTimer() {
    Duration lastPos = Duration.zero;
    int stuckCount = 0;

    _stuckCheckTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _skipPressed || _videoCompleted) {
        timer.cancel();
        return;
      }

      if (_videoController == null ||
          !_videoController!.value.isInitialized) {
        return;
      }

      final currentPos = _videoController!.value.position;

      if (currentPos == lastPos &&
          _videoController!.value.isPlaying &&
          currentPos > Duration.zero) {
        stuckCount++;
        debugPrint("Video stuck count: $stuckCount");

        if (stuckCount >= 5) {
          timer.cancel();
          debugPrint("Video stuck 5 detik — fallback");
          _handleVideoError();
        }
      } else {
        lastPos = currentPos;
        stuckCount = 0;
      }
    });
  }

  void _handleVideoError() {
    if (!mounted || _skipPressed) return;

    setState(() {
      _videoError = true;
    });

    _initTimeoutTimer?.cancel();
    _stuckCheckTimer?.cancel();

    // Kalau video gagal → ke dashboard setelah 1.5 detik
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted && !_skipPressed) {
        _navigateToDashboard();
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // NAVIGASI KE DASHBOARD
  // ═══════════════════════════════════════════════════════════════════
  void _navigateToDashboard() {
    if (_skipPressed) return;
    _skipPressed = true;

    _initTimeoutTimer?.cancel();
    _stuckCheckTimer?.cancel();

    try {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    } catch (_) {}

    try {
      _videoController?.pause();
      _videoController?.removeListener(_onVideoPositionChanged);
      _videoController?.dispose();
    } catch (_) {}

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            balance: widget.balance,
            apiKeyQris: widget.apiKeyQris,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listBugGroup: widget.listBugGroup,
            listBugCh: widget.listBugCh,
            news: widget.news,
            uid: widget.uid,
          ),
        ),
      );
    }
  }

  void _skipVideo() {
    if (_skipPressed) return;

    _fadeController.reverse().then((_) {
      _navigateToDashboard();
    });
  }

  @override
  void dispose() {
    _initTimeoutTimer?.cancel();
    _stuckCheckTimer?.cancel();
    _fadeController.dispose();
    try {
      _videoController?.removeListener(_onVideoPositionChanged);
      _videoController?.dispose();
    } catch (_) {}
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _primaryColor,
      body: GestureDetector(
        onTap: _skipVideo,
        child: Stack(
          children: [
            // ─── LAYER 1: VIDEO / FALLBACK ───
            if (_videoReady && !_videoError && _videoController != null)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController!.value.size.width,
                    height: _videoController!.value.size.height,
                    child: VideoPlayer(_videoController!),
                  ),
                ),
              )
            else
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.2,
                      colors: [const Color(0xFF0D1B2A), _primaryColor],
                    ),
                  ),
                  child: Center(
                    child: Container(
                      width: 160,
                      height: 160,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _accentColor.withOpacity(0.2),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _accentColor.withOpacity(0.08),
                            blurRadius: 40,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            // ─── LAYER 2: GRADIENT OVERLAY ───
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.15),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withOpacity(0.55),
                    ],
                    stops: const [0.0, 0.25, 0.65, 1.0],
                  ),
                ),
              ),
            ),

            // ─── LAYER 3: TEXT UTAMA ───
            Center(
              child: FadeTransition(
                opacity: _textOpacityAnimation,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 1,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            _accentColor.withOpacity(0.7),
                          ],
                        ),
                      ),
                      margin: const EdgeInsets.only(bottom: 28),
                    ),
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [_textColor, _accentColor, _textColor],
                        stops: const [0.0, 0.5, 1.0],
                      ).createShader(bounds),
                      child: const Text(
                        "ATLAS",
                        style: TextStyle(
                          fontSize: 52,
                          fontWeight: FontWeight.w300,
                          color: Colors.white,
                          letterSpacing: 14,
                          height: 1.1,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Color(0x99FF6600),
                              blurRadius: 24,
                            ),
                            Shadow(
                              color: Color(0xCC000000),
                              blurRadius: 12,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 14),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 6,
                      ),
                      child: Text(
                        "ERLAN",
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w300,
                          color: _textColor.withOpacity(0.75),
                          letterSpacing: 2.5,
                          fontStyle: FontStyle.italic,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.9),
                              blurRadius: 6,
                              offset: const Offset(0, 1),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Container(
                      width: 80,
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            _accentColor.withOpacity(0.5),
                            Colors.transparent,
                          ],
                        ),
                      ),
                      margin: const EdgeInsets.only(top: 28),
                    ),
                  ],
                ),
              ),
            ),

            // ─── LAYER 4: NOTIFIKASI ERROR ───
            if (_videoError)
              Positioned(
                top: 90,
                left: 24,
                right: 24,
                child: AnimatedOpacity(
                  opacity: 1.0,
                  duration: const Duration(milliseconds: 500),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.65),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.orange.withOpacity(0.5),
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.info_outline,
                          color: Colors.orange,
                          size: 15,
                        ),
                        SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            "Video tidak tersedia, melanjutkan...",
                            style: TextStyle(
                              color: Colors.orange,
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            // ─── LAYER 5: STATUS BAWAH ───
            Positioned(
              bottom: 28,
              left: 0,
              right: 0,
              child: FadeTransition(
                opacity: _textOpacityAnimation,
                child: Column(
                  children: [
                    if (!_videoReady || _videoError)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              margin: const EdgeInsets.only(right: 7),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _videoError
                                    ? Colors.orange
                                    : _accentColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: (_videoError
                                            ? Colors.orange
                                            : _accentColor)
                                        .withOpacity(0.6),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              _videoError
                                  ? "Mode fallback aktif"
                                  : "Memuat...",
                              style: TextStyle(
                                fontSize: 10,
                                color: _textColor.withOpacity(0.55),
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    const SizedBox(height: 6),
                    Text(
                      "ATLAS IS HERE",
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w300,
                        color: _accentColor.withOpacity(0.3),
                        letterSpacing: 8,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: _accentColor.withOpacity(0.3),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}