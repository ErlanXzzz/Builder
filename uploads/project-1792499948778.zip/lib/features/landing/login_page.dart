import 'dart:async';
import 'dart:math';
import 'dart:ui';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:local_auth/local_auth.dart';

import 'splash_video_page.dart';    // ⭐ Sesuaikan nama file splash kamu
import '../../core/config/apiBaseUrl.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final LocalAuthentication auth = LocalAuthentication();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _slideAnim;

  late AnimationController _chargeController;
  late Animation<double> _chargeAnim;

  bool _loginSuccess = false;
  String _loginMessage = "";

  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color textDark     = Color(0xFF1A0A0A);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;
  static const Color accentGreen  = Color(0xFF4CAF50);

  String appVersion = "2.0.2";

  @override
  void initState() {
    super.initState();
    _initAnim();
    _initChargeAnim();
    _initAndLoad();
  }

  void _initChargeAnim() {
    _chargeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _chargeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _chargeController, curve: Curves.easeInOut),
    );
  }

  Future<void> _initAndLoad() async {
    androidId = await getAndroidId();
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) setState(() => appVersion = info.version);
    } catch (_) {}
    await initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideAnim = Tween<double>(begin: 50, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  Future<void> initLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$apiBaseUrl/api/accountDetails?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['expired'] != true) {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                balance: data['balance'],
                apiKeyQris: data['apiKeyQris'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listBugGroup: (data['listBugGroup'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listBugCh: (data['listBugCh'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                uid: data['uid'],
              ),
              transitionDuration: const Duration(milliseconds: 400),
              transitionsBuilder: (_, animation, __, child) =>
                  FadeTransition(opacity: animation, child: child),
            ),
          );
        } else if (data['reason'] == 'device') {
          if (!mounted) return;
          _showPopup(
            title: "Login Gagal",
            message: "Akun telah diloginkan di device lain",
            color: redMain,
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    if (kIsWeb) return "web_client";
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (_) {
      return "unknown_device";
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOGIN BIOMETRIK (SIDIK JARI)
  // ═══════════════════════════════════════════════════════════════════
Future<void> _loginWithBiometrics() async {
  final prefs = await SharedPreferences.getInstance();

  /*
   * Ambil akun yang memang menjadi pemilik fingerprint
   * pada perangkat ini.
   */
  final String? bioUser =
      prefs.getString('biometric_active_user');

  if (bioUser == null || bioUser.isEmpty) {
    _showPopup(
      title: "Fingerprint Belum Terdaftar",
      message:
          "Belum ada akun yang mendaftarkan fingerprint.\n"
          "Login menggunakan username dan password terlebih dahulu, "
          "kemudian aktifkan fingerprint di My Profile.",
      color: redMain,
    );

    return;
  }

  /*
   * Pastikan status akun tersebut masih aktif.
   */
  final bool isEnabled =
      prefs.getBool('biometric_enabled_$bioUser') ?? false;

  if (!isEnabled) {
    await prefs.remove('biometric_active_user');

    _showPopup(
      title: "Fingerprint Tidak Aktif",
      message:
          "Fingerprint untuk akun ini belum aktif.",
      color: redMain,
    );

    return;
  }

  final String? bioPass =
      prefs.getString('biometric_password_$bioUser');

  if (bioPass == null || bioPass.isEmpty) {
    _showPopup(
      title: "Data Tidak Lengkap",
      message:
          "Data fingerprint akun tidak lengkap.\n"
          "Silakan login manual dan daftarkan ulang fingerprint.",
      color: redMain,
    );

    return;
  }

  try {
    final bool canAuthenticateWithBiometrics =
        await auth.canCheckBiometrics;

    final bool canAuthenticate =
        canAuthenticateWithBiometrics ||
        await auth.isDeviceSupported();

    if (!canAuthenticate) {
      _showPopup(
        title: "Tidak Mendukung",
        message:
            "Perangkat ini tidak mendukung verifikasi sidik jari.",
        color: redMain,
      );

      return;
    }

    final bool didAuthenticate = await auth.authenticate(
      localizedReason:
          'Gunakan sidik jari untuk masuk ke akun $bioUser',
      options: const AuthenticationOptions(
        biometricOnly: true,
      ),
    );

    if (!didAuthenticate) {
      return;
    }

    /*
     * Fingerprint berhasil.
     *
     * Sekarang login menggunakan credential milik
     * akun yang memang terdaftar.
     */
    userController.text = bioUser;
    passController.text = bioPass;

    await login();
  } catch (e) {
    debugPrint('Fingerprint login error: $e');

    if (!mounted) return;

    _showPopup(
      title: "Error",
      message:
          "Gagal memproses autentikasi sidik jari.",
      color: redMain,
    );
  }
}

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      androidId ??= await getAndroidId();

      final validate = await http.post(
        Uri.parse("$apiBaseUrl/api/authenticateUser"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId!,
          "version": appVersion,
        },
      );

      final validData = jsonDecode(validate.body);

      if (!mounted) return;

      if (validData['expired'] == true) {
        _showPopup(
          title: "Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          color: gold,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        if (validData['reason'] == 'device') {
          _showPopup(
            title: "Login Gagal",
            message: "Akun telah diloginkan di device lain",
            color: redMain,
          );
        } else {
          _showPopup(
            title: "Login Gagal",
            message: "Username atau password salah.",
            color: redMain,
          );
        }
      } else {
        setState(() {
          _loginSuccess = true;
          _loginMessage = "Login Success";
        });
        _chargeController.forward();

        await Future.delayed(const Duration(milliseconds: 1800));

        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        if (validData['uid'] != null) {
          prefs.setString("uid", validData['uid']);
        }

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: validData['role'],
              sessionKey: validData['key'],
              expiredDate: validData['expiredDate'],
              balance: validData['balance'],
              apiKeyQris: validData['apiKeyQris'],
              listBug: (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listBugGroup: (validData['listBugGroup'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listBugCh: (validData['listBugCh'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              uid: validData['uid'],
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showPopup(
        title: "Connection Error",
        message: "Gagal terhubung ke server.\nPeriksa koneksi internet Anda.",
        color: redMain,
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    Color color = redMain,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [bgCreamLight, bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: borderDark, width: 3.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(6, 6),
              ),
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 24,
                offset: Offset(0, 12),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, Color.lerp(color, Colors.black, 0.4)!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: borderDark, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Icon(
                  showContact ? Icons.warning_amber_rounded : Icons.error_outline,
                  color: white,
                  size: 30,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  color: redDark,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  fontSize: 15,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: Color(0x33000000),
                      blurRadius: 3,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: bgCream,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                  ],
                ),
                child: Text(
                  message,
                  style: const TextStyle(
                    color: textDark,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (showContact)
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final uri = Uri.parse("https://t.me/bllackmatchaa");
                          await launchUrl(uri,
                              mode: LaunchMode.externalApplication);
                        },
                        child: Container(
                          height: 48,
                          margin: const EdgeInsets.only(right: 8),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [bgCreamLight, bgCream],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: borderDark, width: 2.5),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xAA000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              "CONTACT ADMIN",
                              style: TextStyle(
                                color: redDark,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                fontSize: 10,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderDark, width: 3),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(3, 3),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            "CLOSE",
                            style: TextStyle(
                              color: white,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              fontSize: 11,
                              letterSpacing: 2,
                              shadows: [
                                Shadow(
                                  color: Color(0x99000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _chargeController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brownDark,
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/xo_device_hero_poster.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [brownDark, redDeep, brownDark],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    brownDark.withOpacity(0.7),
                    redDeep.withOpacity(0.5),
                    brownDark.withOpacity(0.85),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: -120,
            left: 0,
            right: 0,
            child: Container(
              height: 400,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topCenter,
                  radius: 1.0,
                  colors: [
                    redMain.withOpacity(0.15),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(child: CustomPaint(painter: _DotsPatternPainter())),
          Positioned(
            top: -40,
            right: -40,
            child: Opacity(
              opacity: 0.1,
              child: CustomPaint(
                size: const Size(200, 200),
                painter: _HexOutlinePainter(),
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -40,
            child: Opacity(
              opacity: 0.08,
              child: CustomPaint(
                size: const Size(160, 160),
                painter: _HexOutlinePainter(),
              ),
            ),
          ),
          SafeArea(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _slideAnim.value),
                  child: Opacity(opacity: _fadeAnim.value, child: child),
                );
              },
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.all(20),
                    child: ConstrainedBox(
                      constraints:
                          BoxConstraints(minHeight: constraints.maxHeight - 40),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width * 0.92,
                              constraints: const BoxConstraints(maxWidth: 420),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [bgCreamLight, bgCream],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(24),
                                border:
                                    Border.all(color: borderDark, width: 3.5),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 0,
                                    offset: Offset(6, 6),
                                  ),
                                  BoxShadow(
                                    color: Color(0xAA000000),
                                    blurRadius: 24,
                                    offset: Offset(0, 12),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(21),
                                child: Column(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16, vertical: 12),
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [redMain, redDark],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 38,
                                            height: 38,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: white,
                                              border: Border.all(
                                                  color: borderDark, width: 2),
                                              boxShadow: const [
                                                BoxShadow(
                                                  color: Color(0x88000000),
                                                  blurRadius: 0,
                                                  offset: Offset(2, 2),
                                                ),
                                              ],
                                            ),
                                            child: ClipOval(
                                              child: Image.asset(
                                                'assets/images/logo.jpg',
                                                fit: BoxFit.cover,
                                                errorBuilder: (_, __, ___) =>
                                                    const Icon(
                                                  Icons.shield_outlined,
                                                  color: redDark,
                                                  size: 18,
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          const Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "atlas",
                                                  style: TextStyle(
                                                    color: white,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w900,
                                                    fontFamily: 'Orbitron',
                                                    letterSpacing: 1.2,
                                                    shadows: [
                                                      Shadow(
                                                        color:
                                                            Color(0xCC000000),
                                                        blurRadius: 3,
                                                        offset: Offset(1, 1),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Text(
                                                  "Secure Access System",
                                                  style: TextStyle(
                                                    color: Color(0xFFFFE0B2),
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: 'ShareTechMono',
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 36,
                                            height: 36,
                                            decoration: BoxDecoration(
                                              color:
                                                  Colors.black.withOpacity(0.3),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                              border: Border.all(
                                                  color: white, width: 2),
                                              boxShadow: const [
                                                BoxShadow(
                                                  color: Color(0x88000000),
                                                  blurRadius: 0,
                                                  offset: Offset(2, 2),
                                                ),
                                              ],
                                            ),
                                            child: const Icon(
                                              Icons.qr_code_2,
                                              color: white,
                                              size: 20,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    Padding(
                                      padding: const EdgeInsets.all(22),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Container(
                                                padding:
                                                    const EdgeInsets.all(3),
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  gradient: const LinearGradient(
                                                    colors: [
                                                      gold,
                                                      Color(0xFFB8923A)
                                                    ],
                                                    begin: Alignment.topLeft,
                                                    end: Alignment.bottomRight,
                                                  ),
                                                  border: Border.all(
                                                      color: borderDark,
                                                      width: 2),
                                                  boxShadow: const [
                                                    BoxShadow(
                                                      color: Color(0xCC000000),
                                                      blurRadius: 0,
                                                      offset: Offset(3, 3),
                                                    ),
                                                  ],
                                                ),
                                                child: Container(
                                                  width: 58,
                                                  height: 58,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: bgCream,
                                                    border: Border.all(
                                                        color: borderDark,
                                                        width: 2),
                                                  ),
                                                  child: ClipOval(
                                                    child: Image.asset(
                                                      'assets/images/logo.jpg',
                                                      fit: BoxFit.cover,
                                                      errorBuilder:
                                                          (_, __, ___) =>
                                                              const Icon(
                                                        Icons.shield_outlined,
                                                        color: redDark,
                                                        size: 26,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 14),
                                              const Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "ATLAS",
                                                      style: TextStyle(
                                                        color: redDark,
                                                        fontSize: 22,
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontFamily: 'Orbitron',
                                                        letterSpacing: 2,
                                                        shadows: [
                                                          Shadow(
                                                            color: Color(
                                                                0x33000000),
                                                            blurRadius: 3,
                                                            offset: Offset(2, 2),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(height: 4),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 8,
                                                          height: 8,
                                                          child: DecoratedBox(
                                                            decoration:
                                                                BoxDecoration(
                                                              shape: BoxShape
                                                                  .circle,
                                                              color:
                                                                  accentGreen,
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(width: 5),
                                                        Text(
                                                          "Online",
                                                          style: TextStyle(
                                                            color: accentGreen,
                                                            fontSize: 10,
                                                            fontWeight:
                                                                FontWeight.w800,
                                                          ),
                                                        ),
                                                        SizedBox(width: 10),
                                                        Icon(
                                                          Icons
                                                              .shield_outlined,
                                                          color: brownMid,
                                                          size: 11,
                                                        ),
                                                        SizedBox(width: 3),
                                                        Text(
                                                          "Secure Access",
                                                          style: TextStyle(
                                                            color: brownMid,
                                                            fontSize: 10,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 24),

                                          Form(
                                            key: _formKey,
                                            child: Column(
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    gradient: const LinearGradient(
                                                      colors: [
                                                        bgCreamLight,
                                                        bgCream
                                                      ],
                                                      begin: Alignment.topLeft,
                                                      end: Alignment
                                                          .bottomRight,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12),
                                                    border: Border.all(
                                                        color: borderDark,
                                                        width: 2.5),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color:
                                                            Color(0xAA000000),
                                                        blurRadius: 0,
                                                        offset: Offset(3, 3),
                                                      ),
                                                    ],
                                                  ),
                                                  child: TextFormField(
                                                    controller: userController,
                                                    style: const TextStyle(
                                                      color: textDark,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w800,
                                                      fontFamily:
                                                          'ShareTechMono',
                                                    ),
                                                    decoration:
                                                        const InputDecoration(
                                                      hintText: "Username",
                                                      hintStyle: TextStyle(
                                                        color: brownMid,
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                      prefixIcon: Icon(
                                                        Icons.person_outline,
                                                        color: redDark,
                                                        size: 20,
                                                      ),
                                                      border:
                                                          InputBorder.none,
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 16,
                                                              vertical: 16),
                                                    ),
                                                    validator: (v) =>
                                                        v == null || v.isEmpty
                                                            ? "Please enter username"
                                                            : null,
                                                  ),
                                                ),
                                                const SizedBox(height: 14),

                                                Container(
                                                  decoration: BoxDecoration(
                                                    gradient: const LinearGradient(
                                                      colors: [
                                                        bgCreamLight,
                                                        bgCream
                                                      ],
                                                      begin: Alignment.topLeft,
                                                      end: Alignment
                                                          .bottomRight,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12),
                                                    border: Border.all(
                                                        color: borderDark,
                                                        width: 2.5),
                                                    boxShadow: const [
                                                      BoxShadow(
                                                        color:
                                                            Color(0xAA000000),
                                                        blurRadius: 0,
                                                        offset: Offset(3, 3),
                                                      ),
                                                    ],
                                                  ),
                                                  child: TextFormField(
                                                    controller: passController,
                                                    obscureText:
                                                        _obscurePassword,
                                                    style: const TextStyle(
                                                      color: textDark,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w800,
                                                      fontFamily:
                                                          'ShareTechMono',
                                                    ),
                                                    decoration: InputDecoration(
                                                      hintText: "Password",
                                                      hintStyle: const TextStyle(
                                                        color: brownMid,
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                      prefixIcon:
                                                          const Icon(
                                                        Icons.lock_outline,
                                                        color: redDark,
                                                        size: 20,
                                                      ),
                                                      suffixIcon: IconButton(
                                                        icon: Icon(
                                                          _obscurePassword
                                                              ? Icons
                                                                  .visibility_off_outlined
                                                              : Icons
                                                                  .visibility_outlined,
                                                          color: redDark,
                                                          size: 20,
                                                        ),
                                                        onPressed: () =>
                                                            setState(() =>
                                                                _obscurePassword =
                                                                    !_obscurePassword),
                                                      ),
                                                      border:
                                                          InputBorder.none,
                                                      contentPadding:
                                                          const EdgeInsets
                                                              .symmetric(
                                                              horizontal: 16,
                                                              vertical: 16),
                                                    ),
                                                    validator: (v) =>
                                                        v == null || v.isEmpty
                                                            ? "Please enter password"
                                                            : null,
                                                  ),
                                                ),
                                                const SizedBox(height: 22),

                                                // ═══ TOMBOL SIGN IN 3D (RED) ═══
                                                GestureDetector(
                                                  onTap: isLoading
                                                      ? null
                                                      : login,
                                                  child: Container(
                                                    width: double.infinity,
                                                    height: 54,
                                                    decoration: BoxDecoration(
                                                      gradient:
                                                          const LinearGradient(
                                                        colors: [
                                                          redMain,
                                                          redDark
                                                        ],
                                                        begin:
                                                            Alignment.topLeft,
                                                        end: Alignment
                                                            .bottomRight,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12),
                                                      border: Border.all(
                                                          color: borderDark,
                                                          width: 3),
                                                      boxShadow: const [
                                                        BoxShadow(
                                                          color:
                                                              Color(0xCC000000),
                                                          blurRadius: 0,
                                                          offset: Offset(4, 4),
                                                        ),
                                                        BoxShadow(
                                                          color:
                                                              Color(0x88000000),
                                                          blurRadius: 14,
                                                          offset: Offset(0, 7),
                                                        ),
                                                      ],
                                                    ),
                                                    child: isLoading
                                                        ? const Center(
                                                            child: SizedBox(
                                                              width: 22,
                                                              height: 22,
                                                              child:
                                                                  CircularProgressIndicator(
                                                                strokeWidth:
                                                                    2.5,
                                                                color: white,
                                                              ),
                                                            ),
                                                          )
                                                        : const Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Icon(
                                                                  Icons.login,
                                                                  size: 18,
                                                                  color:
                                                                      white),
                                                              SizedBox(
                                                                  width: 10),
                                                              Text(
                                                                "SIGN IN",
                                                                style:
                                                                    TextStyle(
                                                                  color: white,
                                                                  fontSize:
                                                                      13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900,
                                                                  fontFamily:
                                                                      'Orbitron',
                                                                  letterSpacing:
                                                                      2,
                                                                  shadows: [
                                                                    Shadow(
                                                                      color: Color(
                                                                          0xCC000000),
                                                                      blurRadius:
                                                                          3,
                                                                      offset:
                                                                          Offset(
                                                                              1,
                                                                              1),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                  ),
                                                ),

                                                const SizedBox(height: 12),

                                                // ═══ TOMBOL FINGERPRINT / SIDIK JARI (PUTIH) ═══
                                                GestureDetector(
                                                  onTap: _loginWithBiometrics,
                                                  child: Container(
                                                    width: double.infinity,
                                                    height: 54,
                                                    decoration: BoxDecoration(
                                                      gradient:
                                                          const LinearGradient(
                                                        colors: [
                                                          bgCreamLight,
                                                          white,
                                                        ],
                                                        begin:
                                                            Alignment.topLeft,
                                                        end: Alignment
                                                            .bottomRight,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12),
                                                      border: Border.all(
                                                          color: borderDark,
                                                          width: 3),
                                                      boxShadow: const [
                                                        BoxShadow(
                                                          color:
                                                              Color(0xCC000000),
                                                          blurRadius: 0,
                                                          offset: Offset(4, 4),
                                                        ),
                                                        BoxShadow(
                                                          color:
                                                              Color(0x88000000),
                                                          blurRadius: 14,
                                                          offset: Offset(0, 7),
                                                        ),
                                                      ],
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Container(
                                                          padding: const EdgeInsets.all(4),
                                                          decoration: BoxDecoration(
                                                            color: bgCream,
                                                            shape: BoxShape.circle,
                                                            border: Border.all(color: borderDark, width: 1.5),
                                                          ),
                                                          child: const Icon(
                                                            Icons.fingerprint_rounded,
                                                            size: 20,
                                                            color: redDark,
                                                          ),
                                                        ),
                                                        const SizedBox(width: 10),
                                                        const Text(
                                                          "LOGIN SIDIK JARI",
                                                          style: TextStyle(
                                                            color: redDark,
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w900,
                                                            fontFamily:
                                                                'Orbitron',
                                                            letterSpacing: 2,
                                                            shadows: [
                                                              Shadow(
                                                                color: Color(
                                                                    0x22000000),
                                                                blurRadius: 3,
                                                                offset: Offset(
                                                                    1, 1),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: 18),

                                          AnimatedBuilder(
                                            animation: _chargeController,
                                            builder: (context, child) {
                                              return Column(
                                                children: [
                                                  Container(
                                                    width: double.infinity,
                                                    height: 50,
                                                    decoration: BoxDecoration(
                                                      gradient:
                                                          const LinearGradient(
                                                        colors: [
                                                          bgCreamLight,
                                                          bgCream
                                                        ],
                                                        begin:
                                                            Alignment.topLeft,
                                                        end: Alignment
                                                            .bottomRight,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      border: Border.all(
                                                          color: borderDark,
                                                          width: 2.5),
                                                      boxShadow: const [
                                                        BoxShadow(
                                                          color:
                                                              Color(0xAA000000),
                                                          blurRadius: 0,
                                                          offset: Offset(3, 3),
                                                        ),
                                                      ],
                                                    ),
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              7),
                                                      child: CustomPaint(
                                                        painter:
                                                            _BarcodeChargingPainter(
                                                          progress:
                                                              _chargeAnim.value,
                                                          isCharging:
                                                              _loginSuccess,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  if (_loginMessage.isNotEmpty)
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 10),
                                                      child: Text(
                                                        _loginMessage
                                                            .toUpperCase(),
                                                        style: const TextStyle(
                                                          color: accentGreen,
                                                          fontSize: 11,
                                                          fontWeight:
                                                              FontWeight.w900,
                                                          fontFamily: 'Orbitron',
                                                          letterSpacing: 1.5,
                                                          shadows: [
                                                            Shadow(
                                                              color: Color(
                                                                  0xCC000000),
                                                              blurRadius: 3,
                                                              offset:
                                                                  Offset(1, 1),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                ],
                                              );
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),

                            Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 40,
                                      height: 2,
                                      decoration: BoxDecoration(
                                        color: redMain.withOpacity(0.5),
                                        borderRadius: BorderRadius.circular(1),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    const Text(
                                      "ATLAS APLIKASI",
                                      style: TextStyle(
                                        color: gold,
                                        fontSize: 9,
                                        letterSpacing: 3,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron',
                                        shadows: [
                                          Shadow(
                                            color: Color(0xCC000000),
                                            blurRadius: 4,
                                            offset: Offset(1, 1),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Container(
                                      width: 40,
                                      height: 2,
                                      decoration: BoxDecoration(
                                        color: redMain.withOpacity(0.5),
                                        borderRadius: BorderRadius.circular(1),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "v$appVersion  ·  © 2026",
                                  style: TextStyle(
                                    color: gold.withOpacity(0.5),
                                    fontSize: 10,
                                    letterSpacing: 1,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BarcodeChargingPainter extends CustomPainter {
  final double progress;
  final bool isCharging;

  _BarcodeChargingPainter({
    required this.progress,
    required this.isCharging,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = const Color(0xFF5D2B1F)
      ..style = PaintingStyle.fill;

    final random = Random(42);
    double x = 8;
    while (x < size.width - 8) {
      final lineWidth = 2.0 + random.nextInt(4).toDouble();
      if (x + lineWidth > size.width - 8) break;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, 8, lineWidth, size.height - 16),
          const Radius.circular(1),
        ),
        linePaint,
      );
      x += lineWidth + 2 + random.nextInt(4);
    }

    if (isCharging && progress > 0) {
      final chargeWidth = size.width * progress;

      final gradient = const LinearGradient(
        colors: [
          Color(0xFFB71C1C),
          Color(0xFFD4A853),
          Color(0xFF7F0000),
        ],
        stops: [0.0, 0.5, 1.0],
      );

      final chargePaint = Paint()
        ..shader = gradient.createShader(
          Rect.fromLTWH(0, 0, chargeWidth, size.height),
        )
        ..style = PaintingStyle.fill;

      final clipPath = Path()
        ..addRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, chargeWidth, size.height),
            const Radius.circular(7),
          ),
        );

      canvas.save();
      canvas.clipPath(clipPath);

      final random2 = Random(42);
      double x2 = 8;
      while (x2 < size.width - 8) {
        final lineWidth = 2.0 + random2.nextInt(4).toDouble();
        if (x2 + lineWidth > chargeWidth - 8) {
          if (x2 < chargeWidth) {
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromLTWH(x2, 8, chargeWidth - x2, size.height - 16),
                const Radius.circular(1),
              ),
              chargePaint,
            );
          }
          break;
        }
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(x2, 8, lineWidth, size.height - 16),
            const Radius.circular(1),
          ),
          chargePaint,
        );
        x2 += lineWidth + 2 + random2.nextInt(4);
      }

      canvas.restore();

      if (progress < 1.0) {
        final glowPaint = Paint()
          ..color = const Color(0xFFB71C1C).withOpacity(0.8)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
        canvas.drawCircle(
          Offset(chargeWidth, size.height / 2),
          6,
          glowPaint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarcodeChargingPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.isCharging != isCharging;
  }
}

class _DotsPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF5D2B1F).withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _HexOutlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    for (final entry in [
      [1.0, 0.18],
      [0.6, 0.10],
      [0.3, 0.06],
    ]) {
      final scale = entry[0];
      final opacity = entry[1];
      final paint = Paint()
        ..color = const Color(0xFFB71C1C).withOpacity(opacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0;
      final r = (size.width / 2) * scale;
      final path = Path();
      for (int i = 0; i < 6; i++) {
        final angle = (pi / 3) * i - pi / 6;
        final x = cx + r * cos(angle);
        final y = cy + r * sin(angle);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
