import 'package:flutter/material.dart';
import 'dart:math' as math;

class MaintenancePage extends StatefulWidget {
  const MaintenancePage({super.key});

  @override
  State<MaintenancePage> createState() => _MaintancePageState();
}

class _MaintancePageState extends State<MaintenancePage>
    with TickerProviderStateMixin {
  late AnimationController _rotateController;
  late AnimationController _pulseController;
  late AnimationController _gradientController;

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 PALET WARNA — SAMA DENGAN LANDING & HALAMAN LAIN
  // ═══════════════════════════════════════════════════════════════════
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;

  @override
  void initState() {
    super.initState();
    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _gradientController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _rotateController.dispose();
    _pulseController.dispose();
    _gradientController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brownDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [brownDark, redDeep, brownDark],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Radial glow (bergerak seperti aslinya)
            AnimatedBuilder(
              animation: _gradientController,
              builder: (context, child) {
                final angle = _gradientController.value * 2 * math.pi;
                final dx = 0.5 + 0.5 * math.cos(angle);
                final dy = 0.5 + 0.5 * math.sin(angle);
                return Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(dx, dy),
                        radius: 1.2,
                        colors: [
                          redMain.withOpacity(0.15),
                          Colors.transparent,
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                );
              },
            ),
            // Grid titik coklat (khas landing)
            Positioned.fill(child: CustomPaint(painter: _GridPainter())),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 20,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── ANIMASI LINGKARAN 3D ───
                      SizedBox(
                        height: 200,
                        width: 200,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // Lingkaran luar berputar
                            RotationTransition(
                              turns: _rotateController,
                              child: Container(
                                width: 180,
                                height: 180,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: gold.withOpacity(0.4),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                            // Lingkaran dalam berputar terbalik
                            RotationTransition(
                              turns: Tween(begin: 0.0, end: -1.0)
                                  .animate(_rotateController),
                              child: Container(
                                width: 140,
                                height: 140,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: redMain.withOpacity(0.5),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                            // Inti pulse 3D
                            AnimatedBuilder(
                              animation: _pulseController,
                              builder: (context, child) {
                                final scale =
                                    1.0 + 0.06 * _pulseController.value;
                                return Transform.scale(
                                  scale: scale,
                                  child: Container(
                                    width: 110,
                                    height: 110,
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [redMain, redDark],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: borderDark, width: 3),
                                      boxShadow: [
                                        const BoxShadow(
                                          color: Color(0xCC000000),
                                          blurRadius: 0,
                                          offset: Offset(4, 4),
                                        ),
                                        BoxShadow(
                                          color: gold.withOpacity(
                                              0.3 + 0.3 * _pulseController.value),
                                          blurRadius:
                                              30 * (0.8 + 0.4 * _pulseController.value),
                                          spreadRadius: 8 *
                                              (0.5 + 0.5 * _pulseController.value),
                                        ),
                                      ],
                                    ),
                                    child: const Icon(
                                      Icons.build_circle_outlined,
                                      color: gold,
                                      size: 48,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 28),

                      // ─── JUDUL 3D ───
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [
                            bgCreamLight,
                            gold,
                            redMain,
                            gold,
                            bgCreamLight,
                          ],
                          stops: [0.0, 0.25, 0.5, 0.75, 1.0],
                        ).createShader(bounds),
                        child: const Text(
                          'ATLAS',
                          style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 8,
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            height: 0.9,
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 8,
                                offset: Offset(2, 2),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 14),

                      // ─── GARIS EMAS ───
                      Container(
                        width: 120,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              gold.withOpacity(0.9),
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: gold.withOpacity(0.5),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 14),

                      // ─── BADGE MAINTENANCE ───
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: redMain.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: gold, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xAA000000),
                              blurRadius: 0,
                              offset: Offset(3, 3),
                            ),
                          ],
                        ),
                        child: const Text(
                          'MAINTENANCE MODE',
                          style: TextStyle(
                            color: gold,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3,
                            fontFamily: 'Orbitron',
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 4,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),

                      // ─── KARTU INFO 3D ───
                      AnimatedBuilder(
                        animation: _pulseController,
                        builder: (context, child) {
                          return Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [bgCreamLight, bgCream],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(18),
                              border:
                                  Border.all(color: borderDark, width: 3.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(5, 5),
                                ),
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 18,
                                  offset: Offset(0, 9),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                // Icon gedung 3D memantul
                                Transform.translate(
                                  offset: Offset(
                                    0,
                                    4 *
                                        math.sin(
                                            _pulseController.value *
                                                2 *
                                                math.pi),
                                  ),
                                  child: Container(
                                    padding: const EdgeInsets.all(14),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [redMain, redDark],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(
                                          color: borderDark, width: 3),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color(0xAA000000),
                                          blurRadius: 0,
                                          offset: Offset(3, 3),
                                        ),
                                      ],
                                    ),
                                    child: const Icon(
                                      Icons.build_circle_outlined,
                                      color: gold,
                                      size: 36,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 20),
                                const Text(
                                  'Sistem Sedang Maintenance',
                                  style: TextStyle(
                                    color: redDark,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                    fontFamily: 'Orbitron',
                                    shadows: [
                                      Shadow(
                                        color: Color(0x33000000),
                                        blurRadius: 3,
                                        offset: Offset(2, 2),
                                      ),
                                    ],
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Sedang kami update.\nHarap tunggu beberapa saat.',
                                  style: TextStyle(
                                    color: brownMid,
                                    fontSize: 12,
                                    height: 1.6,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 22),
                                // Titik loading bergantian merah/gold
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: List.generate(
                                    3,
                                    (index) => AnimatedContainer(
                                      duration:
                                          const Duration(milliseconds: 600),
                                      margin: const EdgeInsets.symmetric(
                                        horizontal: 4,
                                      ),
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color.lerp(
                                          gold.withOpacity(0.3),
                                          redMain,
                                          (_pulseController.value +
                                                  index / 3) %
                                              1.0,
                                        ),
                                        border: Border.all(
                                            color: borderDark, width: 1.5),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 40),

                      // ─── FOOTER ───
                      Text(
                        '© 2026 ATLAS — All rights reserved',
                        style: TextStyle(
                          color: bgCreamLight.withOpacity(0.4),
                          fontSize: 10,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER — titik coklat seperti landing
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF5D2B1F).withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}