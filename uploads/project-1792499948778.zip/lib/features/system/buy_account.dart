import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';
import '../../core/config/apiBaseUrl.dart';

// ═══════════════════════════════════════════════════════════════════
// 🎨 PALET WARNA — SAMA DENGAN LANDING PAGE
// ═══════════════════════════════════════════════════════════════════
class _Palette {
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;
}

class BuyAccountPage extends StatefulWidget {
  const BuyAccountPage({super.key});

  @override
  State<BuyAccountPage> createState() => _BuyAccountPageState();
}

class _BuyAccountPageState extends State<BuyAccountPage>
    with SingleTickerProviderStateMixin {
  final String atlasApiKey = "atlas_0ff250e07243c63d";
  final String adminPw = "000419";

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _isLoading = false;

  int _selectedPackageIndex = 0;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  final List<Map<String, dynamic>> _packages = [
    {'title': 'Member 1 Hari',  'role': 'member',   'days': 1,    'desc': 'Akses harian · role member',      'price': 2000,  'originalPrice': 2500,   'discount': '-20%'},
    {'title': 'Member 2 Hari',  'role': 'member',   'days': 2,    'desc': 'Akses 2 hari · role member',      'price': 4000,  'originalPrice': 5000,   'discount': '-20%'},
    {'title': 'Member 3 Hari',  'role': 'member',   'days': 3,    'desc': 'Akses 3 hari · role member',      'price': 6000,  'originalPrice': 7500,   'discount': '-20%'},
    {'title': 'Member 4 Hari',  'role': 'member',   'days': 4,    'desc': 'Akses 4 hari · role member',      'price': 8000,  'originalPrice': 10000,  'discount': '-20%'},
    {'title': 'Member 7 Hari',  'role': 'member',   'days': 7,    'desc': 'Akses 7 hari · role member',      'price': 15000, 'originalPrice': 17000,  'discount': '-12%'},
    {'title': 'Member 1 Bulan', 'role': 'member',   'days': 30,   'desc': 'Akses 30 hari · role member',     'price': 25000, 'originalPrice': 35000,  'discount': '-20%'},
    {'title': 'Member Permanen','role': 'member',   'days': 9999, 'desc': 'Akses permanen · role member',    'price': 40000, 'originalPrice': 50000,  'discount': '-20%'},
    {'title': 'Reseller Permanen','role': 'reseller','days': 9999,'desc': 'Akses reseller · slot unlimited', 'price': 55000, 'originalPrice': 65000,  'discount': '-18%'},
    {'title': 'Partner Permanen','role': 'partner', 'days': 9999, 'desc': 'Akses partner · slot unlimited',  'price': 80000, 'originalPrice': 105000, 'discount': '-24%'},
  ];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _controller.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _processPayment() async {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showPopup(title: "⚠️ Data Belum Lengkap", message: "Harap isi Username dan Password terlebih dahulu.");
      return;
    }

    setState(() => _isLoading = true);
    final selectedPkg = _packages[_selectedPackageIndex];
    final int nominal = selectedPkg['price'];
    final String reference = "BUY-$username-${DateTime.now().millisecondsSinceEpoch}";

    try {
      final response = await http.get(Uri.parse(
          'https://qris.atlas-by-erlan.com/topup?nominal=$nominal&apikey=$atlasApiKey&reference=$reference'));
      final decoded = jsonDecode(response.body);
      setState(() => _isLoading = false);

      if (decoded['ok'] == true && decoded['data'] != null) {
        final data = decoded['data'];
        _showQrisDialog(
          orderId: data['id'],
          qrisString: data['qris'],
          total: data['pay_amount'] ?? nominal,
          role: selectedPkg['role'],
          days: selectedPkg['days'],
          username: username,
          password: password,
        );
      } else {
        _showPopup(title: "❌ Gagal Order", message: decoded['message'] ?? "Gagal membuat order QRIS.");
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showPopup(title: "⚠️ Koneksi Error", message: "Terjadi kesalahan koneksi QRIS Gateway.");
    }
  }

  void _showQrisDialog({
    required String orderId,
    required String qrisString,
    required int total,
    required String role,
    required int days,
    required String username,
    required String password,
  }) {
    Timer? timer;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        String paymentStatus = "Menunggu Pembayaran...";

        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            timer ??= Timer.periodic(const Duration(seconds: 4), (t) async {
              try {
                final res = await http.get(Uri.parse(
                    'https://qris.atlas-by-erlan.com/check-status?id=$orderId'));
                final statusDecoded = jsonDecode(res.body);
                if (statusDecoded['ok'] == true && statusDecoded['data'] != null) {
                  final String status = statusDecoded['data']['status'];
                  if (status == 'paid' || status == 'success') {
                    t.cancel();
                    Navigator.pop(dialogContext);
                    _executeCreateAccount(
                        username: username, password: password, role: role, days: days);
                  } else if (status == 'expired' || status == 'failed' || status == 'cancelled') {
                    t.cancel();
                    setDialogState(() => paymentStatus = "Pembayaran Kadaluarsa / Gagal!");
                  }
                }
              } catch (_) {}
            });

            return Dialog(
              backgroundColor: Colors.transparent,
              child: TweenAnimationBuilder(
                duration: const Duration(milliseconds: 300),
                tween: Tween<double>(begin: 0, end: 1),
                builder: (context, double scale, child) =>
                    Transform.scale(scale: scale, child: child),
                child: Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_Palette.bgCreamLight, _Palette.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: _Palette.borderDark, width: 3.5),
                    boxShadow: const [
                      BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(5, 5)),
                      BoxShadow(color: Color(0x88000000), blurRadius: 18, offset: Offset(0, 9)),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [_Palette.redMain, _Palette.redDark]),
                          shape: BoxShape.circle,
                          border: Border.all(color: _Palette.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                          ],
                        ),
                        child: const Icon(Icons.qr_code_2, color: _Palette.gold, size: 30),
                      ),
                      const SizedBox(height: 16),
                      const Text("Scan QRIS",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: _Palette.redDark,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron')),
                      const SizedBox(height: 4),
                      Text("ID: $orderId",
                          style: TextStyle(
                              fontSize: 11,
                              color: _Palette.brownMid.withOpacity(0.8),
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono'),
                          textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [_Palette.redMain, _Palette.redDark]),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _Palette.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                          ],
                        ),
                        child: Text(
                          "Rp ${total.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}",
                          style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: _Palette.white,
                              fontFamily: 'Orbitron'),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        width: 200,
                        height: 200,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _Palette.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _Palette.borderDark, width: 3),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(4, 4)),
                          ],
                        ),
                        child: Center(
                          child: QrImageView(
                            data: qrisString,
                            version: QrVersions.auto,
                            size: 180.0,
                            backgroundColor: _Palette.white,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text("Setelah bayar, akun otomatis aktif.\nStatus dicek tiap 4 detik.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: _Palette.brownMid,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono')),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: _Palette.redMain.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _Palette.redMain, width: 2),
                        ),
                        child: Text(paymentStatus,
                            style: const TextStyle(
                                color: _Palette.redDark,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8)),
                      ),
                      const SizedBox(height: 20),
                      GestureDetector(
                        onTap: () async {
                          timer?.cancel();
                          try {
                            await http.get(Uri.parse(
                                'https://qris.atlas-by-erlan.com/cancel-order?id=$orderId'));
                          } catch (_) {}
                          Navigator.pop(dialogContext);
                        },
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                                colors: [_Palette.redMain, _Palette.redDark]),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: _Palette.borderDark, width: 2.5),
                            boxShadow: const [
                              BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                            ],
                          ),
                          child: const Center(
                            child: Text("TUTUP / BATALKAN",
                                style: TextStyle(
                                    color: _Palette.white,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                    fontFamily: 'Orbitron',
                                    fontSize: 12)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    ).then((_) => timer?.cancel());
  }

  Future<void> _executeCreateAccount({
    required String username,
    required String password,
    required String role,
    required int days,
  }) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) =>
          const Center(child: CircularProgressIndicator(color: _Palette.gold)),
    );

    try {
      final uri = Uri.parse(
          '$apiBaseUrl/api/registerMember?pw=$adminPw&username=$username&password=$password&role=$role&day=$days');
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (mounted) Navigator.pop(context);

      if (data['valid'] == true && data['created'] == true) {
        final user = data['user'];
        if (mounted) {
          _showSuccessDialog(
            username: user['username'] ?? username,
            password: user['password'] ?? password,
            role: user['role'] ?? role,
            expired: user['expiredDate'] ?? '-',
          );
        }
      } else {
        if (mounted) {
          _showPopup(
              title: "❌ Pembuatan Gagal",
              message: data['message'] ?? "Gagal membuat akun.");
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) {
        _showPopup(
            title: "⚠️ Koneksi Error",
            message: "Gagal menghubungi server CreateAccount.");
      }
    }
  }

  void _showSuccessDialog({
    required String username,
    required String password,
    required String role,
    required String expired,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_Palette.bgCreamLight, _Palette.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _Palette.borderDark, width: 3.5),
            boxShadow: const [
              BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(5, 5)),
              BoxShadow(color: Color(0x88000000), blurRadius: 18, offset: Offset(0, 9)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [_Palette.redMain, _Palette.redDark]),
                      shape: BoxShape.circle,
                      border: Border.all(color: _Palette.borderDark, width: 2.5),
                      boxShadow: const [
                        BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                      ],
                    ),
                    child: const Icon(Icons.check, color: _Palette.gold, size: 22),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Text("PEMBAYARAN SUKSES",
                        style: TextStyle(
                            color: _Palette.redDark,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontFamily: 'Orbitron')),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text("Akun Anda berhasil dibuat & diaktifkan!",
                  style: TextStyle(
                      color: _Palette.brownMid,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono')),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _Palette.bgCreamLight,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _Palette.borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                  ],
                ),
                child: Column(
                  children: [
                    _buildDetailRow("Username", username),
                    const SizedBox(height: 8),
                    _buildDetailRow("Password", password),
                    const SizedBox(height: 8),
                    _buildDetailRow("Role", role.toUpperCase()),
                    const SizedBox(height: 8),
                    _buildDetailRow("Expired", expired),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [_Palette.redMain, _Palette.redDark]),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _Palette.borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                    ],
                  ),
                  child: const Center(
                    child: Text("SELESAI",
                        style: TextStyle(
                            color: _Palette.white,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron')),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text("$label:",
            style: TextStyle(
                color: _Palette.brownMid,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono')),
        Flexible(
          child: Text(value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                  color: _Palette.redDark,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontFamily: 'ShareTechMono')),
        ),
      ],
    );
  }

  void _showPopup({required String title, required String message}) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_Palette.bgCreamLight, _Palette.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _Palette.borderDark, width: 3.5),
            boxShadow: const [
              BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(5, 5)),
              BoxShadow(color: Color(0x88000000), blurRadius: 18, offset: Offset(0, 9)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [_Palette.redMain, _Palette.redDark]),
                  shape: BoxShape.circle,
                  border: Border.all(color: _Palette.borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                  ],
                ),
                child: const Icon(Icons.warning_rounded, color: _Palette.gold, size: 30),
              ),
              const SizedBox(height: 20),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _Palette.redDark,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                      fontFamily: 'Orbitron')),
              const SizedBox(height: 12),
              Text(message,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: _Palette.brownMid,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono')),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [_Palette.redMain, _Palette.redDark]),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _Palette.borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                    ],
                  ),
                  child: const Center(
                    child: Text("TUTUP",
                        style: TextStyle(
                            color: _Palette.white,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron')),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(TextEditingController controller, String label,
      IconData icon, bool isPassword) {
    return Container(
      decoration: BoxDecoration(
        color: _Palette.bgCreamLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(
            color: _Palette.redDeep,
            fontSize: 14,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
              color: _Palette.brownMid.withOpacity(0.7),
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w700),
          prefixIcon: Icon(icon, color: _Palette.redDark, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: _Palette.brownMid,
                    size: 20,
                  ),
                  onPressed: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedPkg = _packages[_selectedPackageIndex];

    return Scaffold(
      backgroundColor: _Palette.brownDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_Palette.brownDark, _Palette.redDeep, _Palette.brownDark],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -100,
              left: 0,
              right: 0,
              child: Container(
                height: 350,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 1.0,
                    colors: [_Palette.redMain.withOpacity(0.15), Colors.transparent],
                  ),
                ),
              ),
            ),
            Positioned.fill(child: CustomPaint(painter: _GridPainter())),
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: SlideTransition(
                  position: _slideAnim,
                  child: Column(
                    children: [
                      // ── Header ─────────────────────────────────
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                      colors: [_Palette.redMain, _Palette.redDark]),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: _Palette.borderDark, width: 2.5),
                                  boxShadow: const [
                                    BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                                  ],
                                ),
                                child: const Icon(Icons.arrow_back_ios_new_rounded,
                                    color: _Palette.gold, size: 16),
                              ),
                            ),
                            const Expanded(
                              child: Text(
                                "BELI AKSES",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: _Palette.bgCreamLight,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,
                                  fontFamily: 'Orbitron',
                                  shadows: [
                                    Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(2, 2)),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 42),
                          ],
                        ),
                      ),
                      Expanded(
                        child: SingleChildScrollView(
                          physics: const BouncingScrollPhysics(),
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // ── Info card ────────────────────────
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [_Palette.bgCreamLight, _Palette.bgCream],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: _Palette.borderDark, width: 3),
                                  boxShadow: const [
                                    BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
                                    BoxShadow(color: Color(0x77000000), blurRadius: 12, offset: Offset(0, 6)),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text("ERLAN STORE",
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: 2,
                                            color: _Palette.redDark,
                                            fontFamily: 'Orbitron',
                                            shadows: [
                                              Shadow(color: Color(0x33000000), blurRadius: 2, offset: Offset(1, 1)),
                                            ])),
                                    const SizedBox(height: 8),
                                    Text(
                                      "Pilih paket, isi akun, bayar QRIS – dan langsung gunakan.",
                                      style: TextStyle(
                                          color: _Palette.brownMid,
                                          fontSize: 12,
                                          height: 1.6,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'ShareTechMono'),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 24),

                              const Text("PILIH PAKET",
                                  style: TextStyle(
                                      color: _Palette.gold,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 2,
                                      fontFamily: 'Orbitron',
                                      shadows: [
                                        Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(1, 1)),
                                      ])),
                              const SizedBox(height: 12),

                              ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: _packages.length,
                                itemBuilder: (context, index) {
                                  final item = _packages[index];
                                  final bool isSelected = _selectedPackageIndex == index;

                                  return GestureDetector(
                                    onTap: () => setState(() => _selectedPackageIndex = index),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 250),
                                      margin: const EdgeInsets.only(bottom: 12),
                                      padding: const EdgeInsets.all(14),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: isSelected
                                              ? [_Palette.bgCreamLight, _Palette.bgCream]
                                              : [_Palette.bgCream.withOpacity(0.85), _Palette.bgCream.withOpacity(0.6)],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(14),
                                        border: Border.all(
                                          color: isSelected ? _Palette.redMain : _Palette.borderDark,
                                          width: isSelected ? 3.5 : 3,
                                        ),
                                        boxShadow: const [
                                          BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                                        ],
                                      ),
                                      child: Row(
                                        children: [
                                          Radio<int>(
                                            value: index,
                                            groupValue: _selectedPackageIndex,
                                            activeColor: _Palette.redMain,
                                            onChanged: (val) =>
                                                setState(() => _selectedPackageIndex = val!),
                                          ),
                                          const SizedBox(width: 4),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  children: [
                                                    Text(item['title'],
                                                        style: const TextStyle(
                                                            color: _Palette.redDark,
                                                            fontWeight: FontWeight.w900,
                                                            fontSize: 13,
                                                            fontFamily: 'Orbitron')),
                                                    const SizedBox(width: 8),
                                                    Container(
                                                      padding: const EdgeInsets.symmetric(
                                                          horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(
                                                        color: _Palette.redMain,
                                                        borderRadius: BorderRadius.circular(6),
                                                        border: Border.all(color: _Palette.borderDark, width: 1.5),
                                                      ),
                                                      child: Text(item['discount'],
                                                          style: const TextStyle(
                                                              color: _Palette.gold,
                                                              fontSize: 9,
                                                              fontWeight: FontWeight.w900)),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 4),
                                                Text(item['desc'],
                                                    style: TextStyle(
                                                        color: _Palette.brownMid,
                                                        fontSize: 10,
                                                        fontWeight: FontWeight.w700,
                                                        fontFamily: 'ShareTechMono')),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Text("Rp ${item['originalPrice']}",
                                                  style: TextStyle(
                                                      color: _Palette.brownMid.withOpacity(0.6),
                                                      fontSize: 10,
                                                      decoration: TextDecoration.lineThrough,
                                                      fontFamily: 'ShareTechMono')),
                                              Text("Rp ${item['price']}",
                                                  style: const TextStyle(
                                                      color: _Palette.redDark,
                                                      fontWeight: FontWeight.w900,
                                                      fontSize: 12,
                                                      fontFamily: 'Orbitron')),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),

                              const SizedBox(height: 24),

                              const Text("BUAT AKUN BARU",
                                  style: TextStyle(
                                      color: _Palette.gold,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 2,
                                      fontFamily: 'Orbitron',
                                      shadows: [
                                        Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(1, 1)),
                                      ])),
                              const SizedBox(height: 12),

                              _buildInput(_usernameController, "Username",
                                  Icons.person_outline_rounded, false),
                              const SizedBox(height: 16),
                              _buildInput(_passwordController, "Password",
                                  Icons.lock_outline_rounded, true),
                              const SizedBox(height: 24),
                            ],
                          ),
                        ),
                      ),

                      // ── Bottom bar ─────────────────────────────
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [_Palette.brownDark, _Palette.redDeep],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                          border: Border(
                            top: BorderSide(color: _Palette.gold, width: 2),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Text("TOTAL",
                                    style: TextStyle(
                                        color: _Palette.gold,
                                        fontSize: 10,
                                        letterSpacing: 2,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron')),
                                Text("Rp ${selectedPkg['price']}",
                                    style: const TextStyle(
                                        color: _Palette.bgCreamLight,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron',
                                        shadows: [
                                          Shadow(color: Color(0xCC000000), blurRadius: 3, offset: Offset(1, 1)),
                                        ])),
                              ],
                            ),
                            SizedBox(
                              height: 50,
                              child: GestureDetector(
                                onTap: _isLoading ? null : _processPayment,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 20),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [_Palette.redMain, _Palette.redDark, _Palette.redDeep],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: _Palette.borderDark, width: 3),
                                    boxShadow: const [
                                      BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
                                      BoxShadow(color: Color(0x88000000), blurRadius: 14, offset: Offset(0, 7)),
                                    ],
                                  ),
                                  child: Center(
                                    child: _isLoading
                                        ? const SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: CircularProgressIndicator(
                                                strokeWidth: 2, color: _Palette.gold),
                                          )
                                        : const Row(
                                            children: [
                                              Icon(Icons.qr_code_scanner_rounded,
                                                  color: _Palette.gold, size: 18),
                                              SizedBox(width: 8),
                                              Text("BAYAR QRIS",
                                                  style: TextStyle(
                                                      color: _Palette.white,
                                                      fontWeight: FontWeight.w900,
                                                      letterSpacing: 1.5,
                                                      fontSize: 12,
                                                      fontFamily: 'Orbitron')),
                                            ],
                                          ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER (sama seperti landing)
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _Palette.brownMid.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}