// lib/features/dashboard/home_page.dart
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import '../../core/widgets/custom_popup.dart';
import '../../core/config/apiBaseUrl.dart';
import '../../core/services/bug_sender.dart';
import '../system/upgrade_role.dart';
import 'xtheme.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listBugCh;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listBugCh,
    required this.listBugGroup,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final FocusNode _targetFocusNode = FocusNode();
  late AnimationController _pulseController;
  late PageController _bugPageController;
  int _selectedBugIndex = 0;
  int _bugCategoryTab = 0;
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;

  String? _detectedFlag;

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

  final Map<String, String> _countryDialCodes = {
    '62': 'ID', '1': 'US', '44': 'GB', '60': 'MY', '65': 'SG',
    '63': 'PH', '66': 'TH', '81': 'JP', '82': 'KR', '86': 'CN',
    '91': 'IN', '92': 'PK', '93': 'AF', '94': 'LK', '95': 'MM',
    '98': 'IR', '7': 'RU', '33': 'FR', '49': 'DE', '39': 'IT',
    '34': 'ES', '31': 'NL', '55': 'BR', '52': 'MX', '54': 'AR',
    '61': 'AU', '64': 'NZ', '20': 'EG', '27': 'ZA', '234': 'NG',
    '966': 'SA', '971': 'AE', '90': 'TR',
  };

  String _getFlagEmoji(String countryCode) {
    return countryCode.toUpperCase().replaceAllMapped(
          RegExp(r'[A-Z]'),
          (match) => String.fromCharCode(match.group(0)!.codeUnitAt(0) + 127397),
        );
  }

  void _onTargetNumberChanged() {
    if (_bugCategoryTab != 0) return;
    String text = targetController.text.trim().replaceAll('+', '');
    if (text.isEmpty) {
      if (_detectedFlag != null) {
        setState(() => _detectedFlag = null);
      }
      return;
    }

    String? foundFlag;
    for (int len = 3; len >= 1; len--) {
      if (text.length >= len) {
        String prefix = text.substring(0, len);
        if (_countryDialCodes.containsKey(prefix)) {
          foundFlag = _getFlagEmoji(_countryDialCodes[prefix]!);
          break;
        }
      }
    }

    if (_detectedFlag != foundFlag) {
      setState(() {
        _detectedFlag = foundFlag;
      });
    }
  }

  bool get _canUseGlobalSender =>
      widget.role == 'partner' || widget.role == 'pemula';

  List<Map<String, dynamic>> _getActiveBugList() {
    if (_bugCategoryTab == 1) return widget.listBugGroup;
    if (_bugCategoryTab == 2) return widget.listBugCh;
    return widget.listBug;
  }

  @override
  void initState() {
    super.initState();
    targetController.addListener(_onTargetNumberChanged);
    _bugPageController = PageController(viewportFraction: 0.72);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _initVideo();

    if (_getActiveBugList().isNotEmpty) {
      _selectedBugIndex = 0;
    }
    _fetchSenderStats();
  }

  Future<void> _initVideo() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');
      await _videoController!.initialize();
      await _videoController!.setLooping(true);
      await _videoController!.setPlaybackSpeed(1.0);
      await _videoController!.setVolume(1.0);
      await _videoController!.play();

      await Future.delayed(const Duration(milliseconds: 200));
      if (mounted && _videoController != null) {
        await _videoController!.setVolume(1.0);
      }

      if (!mounted) return;
      setState(() => _videoReady = true);
      debugPrint("✅ Video autoplay sound ON: ${_videoController!.value.duration}");
    } catch (e) {
      debugPrint("❌ Video error: $e");
      if (mounted) setState(() => _videoReady = false);
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "$apiBaseUrl/api/senderMetrics?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  @override
  void dispose() {
    targetController.removeListener(_onTargetNumberChanged);
    _targetFocusNode.dispose();
    _videoController?.dispose();
    _pulseController.dispose();
    _bugPageController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    if (_bugCategoryTab != 0) {
      return input.isEmpty ? null : input;
    }
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final effectiveSenderMode = _canUseGlobalSender ? _senderMode : 'private';
    final currentSenderCount = effectiveSenderMode == 'global'
        ? _globalSenderCount
        : _privateSenderCount;

    if (currentSenderCount <= 0) {
      CustomPopup.display(
        context,
        title: "Sender Tidak Ada",
        message:
            "Kamu belum memiliki sender yang aktif. Silakan tambahkan sender terlebih dahulu.",
        icon: Icons.warning_amber_rounded,
        iconColor: Colors.orangeAccent,
        confirmText: "Add Sender",
        cancelText: "Close",
        onConfirm: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BugSenderPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      );
      return;
    }

    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    final target = formatPhoneNumber(rawInput);
    if (target == null || key.isEmpty) {
      _showAlert(
        "Invalid Target",
        _bugCategoryTab == 0
            ? "Gunakan nomor internasional (misal: +62, 1, 44)."
            : "Target tidak boleh kosong.",
      );
      return;
    }

    final bugs = _getActiveBugList();
    if (bugs.isEmpty) {
      _showAlert("Error", "Tidak ada bug tersedia.");
      return;
    }
    final selectedBugId =
        bugs[_selectedBugIndex.clamp(0, bugs.length - 1)]['bug_id'];

    setState(() => _isSending = true);

    try {
      final url = "$apiBaseUrl/api/dispatchPayload"
          "?key=$key"
          "&target=$rawInput"
          "&bug=$selectedBugId"
          "&senderMode=$effectiveSenderMode";
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid",
            "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi nanti.");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, [String? msg]) {
    if (!mounted) return;
    CustomPopup.display(
      context,
      title: title,
      message: msg ?? title,
      icon: title.contains("✅")
          ? Icons.check_circle_outline
          : Icons.error_outline,
      iconColor: title.contains("✅") ? Colors.green : Colors.redAccent,
      confirmText: "Close",
    );
  }

  void _showRoleRestrictionPopup(XThemeData theme) {
    CustomPopup.display(
      context,
      title: "Akses Ditolak",
      message:
          "Fitur Bug Channel khusus untuk role partner. Silakan tingkatkan role Anda.",
      icon: Icons.lock_outline_rounded,
      iconColor: theme.gold,
      confirmText: "Up Role",
      cancelText: "Close",
      onConfirm: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => UpgradeRolePage(
              sessionKey: widget.sessionKey,
              role: widget.role,
              username: widget.username,
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;
        final bugs = _getActiveBugList();

        return Scaffold(
          backgroundColor: theme.brownDark,
          body: Column(
            children: [
              _build3DHeader(theme),

              Expanded(
                child: Container(
                  color: theme.bgCream,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _build3DVideoPlayer(theme),
                        _buildBugCategoryTabs(theme),

                        const SizedBox(height: 12),

                        // ─── PANEL MERAH 3D ───
                        Container(
                          margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                theme.accentRed,
                                theme.redMain,
                                theme.redDark,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: theme.borderDark, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(5, 5),
                              ),
                              BoxShadow(
                                color: Color(0x88000000),
                                blurRadius: 16,
                                offset: Offset(0, 8),
                              ),
                              BoxShadow(
                                color: Color(0x33FFFFFF),
                                blurRadius: 4,
                                offset: Offset(-2, -2),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(18),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildSectionTitle(
                                  theme,
                                  _bugCategoryTab == 0
                                      ? Icons.phone_android_rounded
                                      : (_bugCategoryTab == 1
                                          ? Icons.group_rounded
                                          : Icons.campaign_rounded),
                                  _bugCategoryTab == 0
                                      ? "NOMOR TARGET"
                                      : (_bugCategoryTab == 1
                                          ? "TARGET GROUP"
                                          : "TARGET CHANNEL"),
                                ),
                                const SizedBox(height: 10),
                                _build3DTextField(theme),
                                const SizedBox(height: 18),

                                _buildSectionTitle(
                                    theme, Icons.bug_report_rounded, "PILIH BUG"),
                                const SizedBox(height: 10),

                                _buildStatusBadges(theme),
                                const SizedBox(height: 14),

                                if (bugs.isNotEmpty) ...[
                                  SizedBox(
                                    height: 160,
                                    child: PageView.builder(
                                      controller: _bugPageController,
                                      onPageChanged: (i) => setState(
                                          () => _selectedBugIndex = i),
                                      itemCount: bugs.length,
                                      itemBuilder: (_, i) {
                                        final bug = bugs[i];
                                        final isSelected =
                                            i == _selectedBugIndex;
                                        return AnimatedScale(
                                          scale: isSelected ? 1.0 : 0.9,
                                          duration: const Duration(
                                              milliseconds: 250),
                                          child: GestureDetector(
                                            onTap: () {
                                              _bugPageController.animateToPage(
                                                i,
                                                duration: const Duration(
                                                    milliseconds: 300),
                                                curve: Curves.easeOut,
                                              );
                                              setState(() =>
                                                  _selectedBugIndex = i);
                                            },
                                            child: _build3DBugCard(
                                                theme, bug, isSelected),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  const SizedBox(height: 10),

                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      ...List.generate(
                                        bugs.length.clamp(0, 8),
                                        (i) => AnimatedContainer(
                                          duration: const Duration(
                                              milliseconds: 250),
                                          margin: const EdgeInsets.symmetric(
                                              horizontal: 3),
                                          width: i == _selectedBugIndex
                                              ? 18
                                              : 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            color: i == _selectedBugIndex
                                                ? theme.gold
                                                : Colors.white.withOpacity(0.4),
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            border: Border.all(
                                                color: theme.borderDark,
                                                width: 1),
                                            boxShadow:
                                                i == _selectedBugIndex
                                                    ? [
                                                        BoxShadow(
                                                          color: theme.gold
                                                              .withOpacity(0.8),
                                                          blurRadius: 8,
                                                          spreadRadius: 1,
                                                        ),
                                                      ]
                                                    : null,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ] else
                                  Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Text(
                                        "Tidak ada bug tersedia.",
                                        style: TextStyle(
                                            color: Colors.white
                                                .withOpacity(0.8)),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 16),

                        if (_canUseGlobalSender)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: _buildSenderModePanel(theme),
                          ),

                        const SizedBox(height: 20),

                        // ─── TOMBOL KIRIM 3D ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: AnimatedBuilder(
                            animation: _pulseController,
                            builder: (_, __) => GestureDetector(
                              onTap: _isSending ? null : _sendBug,
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      theme.redDeep,
                                      theme.redMain,
                                      Color.lerp(
                                        theme.redMain,
                                        theme.accentRed,
                                        _pulseController.value * 0.5,
                                      )!,
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                      color: theme.borderDark, width: 3),
                                  boxShadow: [
                                    BoxShadow(
                                      color: theme.redDeep.withOpacity(
                                          0.5 + 0.3 * _pulseController.value),
                                      blurRadius: 20,
                                      offset: const Offset(0, 6),
                                    ),
                                    const BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(4, 4),
                                    ),
                                    const BoxShadow(
                                      color: Color(0x33FFFFFF),
                                      blurRadius: 4,
                                      offset: Offset(-2, -2),
                                    ),
                                  ],
                                ),
                                child: _isSending
                                    ? const Center(
                                        child: SizedBox(
                                          width: 26,
                                          height: 26,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2.5,
                                          ),
                                        ),
                                      )
                                    : const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.send_rounded,
                                              color: Colors.white, size: 22),
                                          SizedBox(width: 12),
                                          Text(
                                            "KIRIM BUG",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontFamily: 'Orbitron',
                                              fontWeight: FontWeight.w900,
                                              fontSize: 16,
                                              letterSpacing: 3,
                                              shadows: [
                                                Shadow(
                                                  color: Color(0xCC000000),
                                                  blurRadius: 4,
                                                  offset: Offset(1, 1),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 32),

                        // ─── FOOTER ───
                        Center(
                          child: Column(
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) => LinearGradient(
                                  colors: [
                                    theme.gold,
                                    theme.goldLight,
                                    theme.goldDark
                                  ],
                                ).createShader(bounds),
                                child: const Text(
                                  "ATLAS TEAM",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13,
                                    letterSpacing: 3,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "We are team solid solid parah",
                                style: TextStyle(
                                  color: theme.redDark.withOpacity(0.6),
                                  fontSize: 10,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══ TAB KATEGORI BUG ═══
  Widget _buildBugCategoryTabs(XThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: _buildTabButton(theme,
                title: "Bug Number",
                icon: Icons.phone_android_rounded,
                index: 0),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildTabButton(theme,
                title: "Bug Group", icon: Icons.groups_rounded, index: 1),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildTabButton(theme,
                title: "Bug Channel", icon: Icons.campaign_rounded, index: 2),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(
    XThemeData theme, {
    required String title,
    required IconData icon,
    required int index,
  }) {
    final isSelected = _bugCategoryTab == index;
    return GestureDetector(
      onTap: () async {
        if (index == 2 &&
            widget.role.toLowerCase() != 'pemula' &&
            widget.role.toLowerCase() != 'partner') {
          _showRoleRestrictionPopup(theme);
          return;
        }

        if (_bugCategoryTab != index) {
          final wasFocused = _targetFocusNode.hasFocus;
          if (wasFocused) {
            _targetFocusNode.unfocus();
            await Future.delayed(const Duration(milliseconds: 100));
          }
          if (!mounted) return;
          setState(() {
            _bugCategoryTab = index;
            _selectedBugIndex = 0;
            targetController.clear();
            _detectedFlag = null;
          });
          if (_bugPageController.hasClients) {
            _bugPageController.jumpToPage(0);
          }
          if (wasFocused) {
            await Future.delayed(const Duration(milliseconds: 50));
            if (mounted) _targetFocusNode.requestFocus();
          }
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isSelected
                ? [theme.accentRed, theme.redMain, theme.redDark]
                : [theme.bgCreamLight, theme.bgCream, theme.bgCreamDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? theme.gold : theme.borderDark,
            width: isSelected ? 3 : 2,
          ),
          boxShadow: isSelected
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: theme.gold.withOpacity(0.55),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0x33FFFFFF),
                    blurRadius: 3,
                    offset: Offset(-1, -1),
                  ),
                ]
              : const [
                  BoxShadow(
                    color: Color(0x66000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                  BoxShadow(
                    color: Color(0x33000000),
                    blurRadius: 6,
                    offset: Offset(0, 3),
                  ),
                ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isSelected
                      ? [theme.goldLight, theme.gold, theme.goldDark]
                      : [theme.accentRed, theme.redMain, theme.redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: theme.borderDark, width: 2),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                  if (isSelected)
                    BoxShadow(
                      color: theme.gold.withOpacity(0.7),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                ],
              ),
              child: Icon(
                icon,
                color: isSelected ? theme.redDark : Colors.white,
                size: 22,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isSelected ? Colors.white : theme.brownDark,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 10.5,
                letterSpacing: 0.3,
                shadows: isSelected
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ 3D HEADER ═══
  Widget _build3DHeader(XThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.redDark, theme.redMain, theme.accentRed],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 6),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.goldLight, theme.gold, theme.goldDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 8,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(Icons.shield_rounded,
                    color: theme.redDark, size: 20),
              ),
              const SizedBox(width: 12),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.redDeep, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: theme.borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x33FFFFFF),
                      blurRadius: 4,
                      offset: Offset(-1, -1),
                    ),
                  ],
                ),
                child: ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [theme.goldLight, Colors.white, theme.gold],
                  ).createShader(bounds),
                  child: const Text(
                    "ATLAS BUG",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchSenderStats,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.accentRed, theme.redMain],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                      BoxShadow(
                        color: Color(0x33FFFFFF),
                        blurRadius: 4,
                        offset: Offset(-1, -1),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      color: Colors.white, size: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ 3D VIDEO PLAYER ═══
  Widget _build3DVideoPlayer(XThemeData theme) {
    return Container(
      color: theme.bgCream,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: theme.borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(5, 5),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 16,
              offset: Offset(0, 8),
            ),
            BoxShadow(
              color: Color(0x33FFFFFF),
              blurRadius: 4,
              offset: Offset(-2, -2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(17),
          child: AspectRatio(
            aspectRatio: 16 / 9,
            child: _videoReady && _videoController != null
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController!.value.size.width,
                      height: _videoController!.value.size.height,
                      child: VideoPlayer(_videoController!),
                    ),
                  )
                : Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [theme.redDark, theme.redMain],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 50),
                          SizedBox(height: 8),
                          Text(
                            "ATLAS BUG",
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  // ═══ SENDER MODE PANEL ═══
  Widget _buildSenderModePanel(XThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream, theme.bgCreamDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(5, 5),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
          BoxShadow(
            color: Color(0x55FFFFFF),
            blurRadius: 4,
            offset: Offset(-2, -2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.goldLight, theme.gold, theme.goldDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(Icons.swap_horiz_rounded,
                    color: theme.redDark, size: 14),
              ),
              const SizedBox(width: 10),
              Text(
                "PILIH SENDER",
                style: TextStyle(
                  color: theme.redDark,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  fontSize: 13,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: theme.accentGreen.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: theme.accentGreen.withOpacity(0.5), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: theme.accentGreen,
                        boxShadow: [
                          BoxShadow(
                            color: theme.accentGreen,
                            blurRadius: 6,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "${_globalSenderCount + _privateSenderCount} sender online",
                      style: TextStyle(
                        color: theme.accentGreen,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              Expanded(
                child: _buildSenderCard(
                  theme: theme,
                  icon: Icons.person_rounded,
                  label: "Pribadi",
                  subtitle: _privateSenderCount > 0
                      ? "$_privateSenderCount sender"
                      : "X Kosong",
                  isActive: _senderMode == 'private',
                  isDisabled: _privateSenderCount == 0,
                  subtitleColor: _privateSenderCount > 0
                      ? theme.accentGreen
                      : theme.redMain,
                  onTap: () {
                    if (_privateSenderCount == 0) {
                      _showAlert(
                        "⚠️ Sender Kosong",
                        "Belum ada sender pribadi online. "
                            "Tetap dipilih, tapi pengiriman mungkin gagal.",
                      );
                    }
                    setState(() => _senderMode = 'private');
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSenderCard(
                  theme: theme,
                  icon: Icons.public_rounded,
                  label: "Global",
                  subtitle: "$_globalSenderCount sender",
                  isActive: _senderMode == 'global',
                  isDisabled: _globalSenderCount == 0,
                  subtitleColor: theme.brownMid,
                  onTap: () {
                    if (_globalSenderCount == 0) {
                      _showAlert(
                        "⚠️ Sender Kosong",
                        "Belum ada sender global online. "
                            "Tetap dipilih, tapi pengiriman mungkin gagal.",
                      );
                    }
                    setState(() => _senderMode = 'global');
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSenderCard({
    required XThemeData theme,
    required IconData icon,
    required String label,
    required String subtitle,
    required bool isActive,
    required bool isDisabled,
    required Color subtitleColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isActive
                ? [theme.bgCreamLight, theme.bgCream, theme.bgCreamDark]
                : [theme.bgCream, theme.bgCreamDark, theme.bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? theme.redDark : theme.borderDark,
            width: isActive ? 3 : 2,
          ),
          boxShadow: isActive
              ? const [
                  BoxShadow(
                    color: Color(0xDD000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 12,
                    offset: Offset(0, 6),
                  ),
                  BoxShadow(
                    color: Color(0x55FFFFFF),
                    blurRadius: 4,
                    offset: Offset(-2, -2),
                  ),
                ]
              : const [
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x44000000),
                    blurRadius: 8,
                    offset: Offset(0, 4),
                  ),
                ],
        ),
        child: Opacity(
          opacity: isDisabled ? 0.6 : 1.0,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isActive
                        ? [theme.accentRed, theme.redMain, theme.redDark]
                        : [theme.redDark, theme.redDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x33FFFFFF),
                      blurRadius: 4,
                      offset: Offset(-1, -1),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(height: 10),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? theme.redDark : theme.brownMid,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(XThemeData theme, IconData icon, String text) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.goldLight, theme.gold, theme.goldDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: theme.borderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: theme.redDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
            fontSize: 14,
            letterSpacing: 2,
            shadows: [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _build3DTextField(XThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream, theme.bgCreamDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
          BoxShadow(
            color: Color(0x33FFFFFF),
            blurRadius: 2,
            offset: Offset(-1, -1),
          ),
        ],
      ),
      child: TextField(
        controller: targetController,
        focusNode: _targetFocusNode,
        style: TextStyle(
          color: theme.textDark,
          fontSize: 14,
          fontWeight: FontWeight.w700,
          fontFamily: 'ShareTechMono',
        ),
        keyboardType: _bugCategoryTab == 0
            ? TextInputType.phone
            : TextInputType.text,
        cursorColor: theme.redMain,
        decoration: InputDecoration(
          hintText: _bugCategoryTab == 0
              ? "62xxxxxxxxxx"
              : (_bugCategoryTab == 1
                  ? "linkgb / idgb"
                  : "linkch / idch"),
          hintStyle:
              TextStyle(color: theme.brownMid.withOpacity(0.5), fontSize: 13),
          prefixIcon: Padding(
            padding: const EdgeInsets.only(left: 10, right: 6),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_bugCategoryTab == 0 && _detectedFlag != null)
                  Text(
                    _detectedFlag!,
                    style: const TextStyle(fontSize: 20),
                  )
                else
                  Icon(
                    _bugCategoryTab == 0
                        ? Icons.language
                        : (_bugCategoryTab == 1
                            ? Icons.group
                            : Icons.campaign),
                    color: theme.redDark,
                    size: 18,
                  ),
              ],
            ),
          ),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 40,
            minHeight: 0,
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildStatusBadges(XThemeData theme) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCreamLight, theme.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: theme.borderDark, width: 1.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: theme.accentGreen,
                  boxShadow: [
                    BoxShadow(
                      color: theme.accentGreen,
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 5),
              Text(
                "Engine lokal aktif",
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white.withOpacity(0.4), width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.chat, color: Colors.white.withOpacity(0.9), size: 10),
              const SizedBox(width: 4),
              Text(
                "WA belum connect",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _build3DBugCard(
      XThemeData theme, Map<String, dynamic> bug, bool isSelected) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isSelected
              ? [theme.goldLight, theme.accentYellow, theme.gold]
              : [theme.bgCreamLight, theme.bgCream, theme.bgCreamDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isSelected ? theme.redDark : theme.borderDark,
          width: 3,
        ),
        boxShadow: isSelected
            ? [
                const BoxShadow(
                  color: Color(0xDD000000),
                  blurRadius: 0,
                  offset: Offset(4, 4),
                ),
                BoxShadow(
                  color: theme.gold.withOpacity(0.6),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 4,
                  offset: Offset(-2, -2),
                ),
              ]
            : const [
                BoxShadow(
                  color: Color(0x88000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Color(0x44000000),
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.accentRed, theme.redMain, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.shield_rounded,
                  color: Colors.white,
                  size: 14,
                ),
              ),
              if (isSelected)
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: theme.accentGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.borderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: theme.accentGreen.withOpacity(0.7),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: Colors.white, size: 14),
                ),
            ],
          ),
          const Spacer(),
          Text(
            bug['bug_name'] ?? 'Bug',
            style: TextStyle(
              color: theme.redDark,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              fontFamily: 'Orbitron',
              letterSpacing: 0.3,
              shadows: const [
                Shadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 1,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: theme.redDeep.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: theme.redDark.withOpacity(0.5),
                width: 1,
              ),
            ),
            child: Text(
              bug['bug_id'] ?? '',
              style: TextStyle(
                color: theme.redDark,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}