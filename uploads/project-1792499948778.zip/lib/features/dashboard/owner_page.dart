// lib/features/dashboard/owner_page.dart
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/widgets/custom_popup.dart';
import '../../core/config/apiBaseUrl.dart';
import 'xtheme.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['partner', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  XFile? _selectedImage;
  String _imageBase64 = '';

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/api/accountDirectory?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/api/removeAccount?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$apiBaseUrl/submitPending');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'username': u,
          'password': p,
          'day': d,
          'role': newUserRole,
          'imageBase64': _imageBase64,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert("Sukses",
            "Permintaan akun dikirim! Tunggu approval Owner di Telegram.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _imageBase64 = '';
        _selectedImage = null;
        newUserRole = 'member';
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengirim permintaan.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$apiBaseUrl/api/extendAccountExpiry?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.display(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses")
          ? Icons.check_circle_outline
          : Icons.info_outline,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT FIELD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInput({
    required XThemeData theme,
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(
          color: theme.textDark,
          fontWeight: FontWeight.w700,
          fontFamily: 'ShareTechMono',
        ),
        cursorColor: theme.redMain,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: theme.redDark,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 0.5,
          ),
          prefixIcon: Icon(icon, color: theme.redDark, size: 18),
          filled: true,
          fillColor: Colors.transparent,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await File(image.path).readAsBytes();
      setState(() {
        _selectedImage = image;
        _imageBase64 = base64Encode(bytes);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DIALOG WRAPPER 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _build3DDialog({
    required XThemeData theme,
    required Color accentColor,
    required IconData icon,
    required String title,
    required List<Widget> children,
    double iconSize = 30,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.bgCreamLight, theme.bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: theme.borderDark, width: 3.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(6, 6),
            ),
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 24,
              offset: Offset(0, 12),
            ),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accentColor,
                      Color.lerp(accentColor, Colors.black, 0.4)!,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: iconSize),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                  shadows: const [
                    Shadow(
                      color: Color(0x33000000),
                      blurRadius: 3,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  Widget _build3DButton({
    required XThemeData theme,
    required String label,
    required Color color,
    required VoidCallback onTap,
    IconData? icon,
    double height = 50,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: theme.borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(4, 4),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 12,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                fontFamily: 'Orbitron',
                fontSize: 12,
                shadows: [
                  Shadow(
                    color: Color(0x99000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: STORAGE QR
  // ═══════════════════════════════════════════════════════════════════
  void _showStorageQRPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          theme: theme,
          accentColor: theme.accentYellow,
          icon: Icons.qr_code_rounded,
          title: "STOR DISINI 5K",
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: theme.borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(8),
              child: Image.network(
                'https://files.atlas-by-erlan.com/yMrrMp3oRk.jpg',
                height: 200,
                width: 200,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Container(
                  height: 200,
                  width: 200,
                  color: theme.brownMid,
                  child: Icon(Icons.broken_image_rounded,
                      color: theme.bgCream, size: 40),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              "Scan QR untuk melakukan pembayaran",
              style: TextStyle(
                color: theme.brownMid,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            _build3DButton(
              theme: theme,
              label: "TUTUP",
              color: theme.redMain,
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: CREATE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showCreateAccountPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
            child: _build3DDialog(
              theme: theme,
              accentColor: theme.accentGreen,
              icon: FontAwesomeIcons.userPlus,
              title: "CREATE ACCOUNT",
              children: [
                // Tombol pilih foto 3D
                GestureDetector(
                  onTap: () async {
                    await _pickImage();
                    setModalState(() {});
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _selectedImage == null
                            ? [theme.brownMid, theme.redDeep]
                            : [
                                theme.accentGreen,
                                Color.lerp(theme.accentGreen,
                                    Colors.black, 0.5)!
                              ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: theme.borderDark, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xAA000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.photo_camera_rounded,
                            color: Colors.white, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          _selectedImage == null
                              ? "PILIH FOTO (OPSIONAL)"
                              : "FOTO TERPILIH ✓",
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            fontSize: 11,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                if (_selectedImage != null) ...[
                  Container(
                    height: 100,
                    width: 100,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      border: Border.all(color: theme.borderDark, width: 3),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xAA000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: Image.file(
                        File(_selectedImage!.path),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],

                _buildInput(
                  theme: theme,
                  label: "Username",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                ),
                _buildInput(
                  theme: theme,
                  label: "Password",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                ),
                _buildInput(
                  theme: theme,
                  label: "Durasi (Hari)",
                  controller: createDayController,
                  icon: FontAwesomeIcons.calendarDay,
                  type: TextInputType.number,
                ),

                // Dropdown Role 3D
                Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.bgCreamLight, theme.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: theme.borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                    ],
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: newUserRole,
                      dropdownColor: theme.bgCreamLight,
                      isExpanded: true,
                      style: TextStyle(
                        color: theme.textDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                      icon: Icon(Icons.keyboard_arrow_down,
                          color: theme.redDark),
                      items: roleOptions.map((role) {
                        return DropdownMenuItem(
                          value: role,
                          child: Text(role.toUpperCase()),
                        );
                      }).toList(),
                      onChanged: (val) =>
                          setModalState(() => newUserRole = val ?? 'member'),
                    ),
                  ),
                ),

                _build3DButton(
                  theme: theme,
                  label: "KIRIM REQUEST",
                  color: theme.accentGreen,
                  icon: Icons.send_rounded,
                  onTap: () {
                    Navigator.pop(context);
                    _createAccount();
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: EXTEND DURATION
  // ═══════════════════════════════════════════════════════════════════
  void _showExtendDurationPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          theme: theme,
          accentColor: theme.accentBlue,
          icon: FontAwesomeIcons.clock,
          title: "ADD DURATION",
          children: [
            _buildInput(
              theme: theme,
              label: "Username Target",
              controller: editUsernameController,
              icon: FontAwesomeIcons.userEdit,
            ),
            _buildInput(
              theme: theme,
              label: "Tambah Hari",
              controller: editDayController,
              icon: FontAwesomeIcons.calendarPlus,
              type: TextInputType.number,
            ),
            const SizedBox(height: 6),
            _build3DButton(
              theme: theme,
              label: "ADD DAYS",
              color: theme.accentBlue,
              icon: Icons.add_circle_outline_rounded,
              onTap: () {
                Navigator.pop(context);
                _editUser();
              },
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: DELETE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showDeleteAccountPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          theme: theme,
          accentColor: theme.redMain,
          icon: FontAwesomeIcons.userSlash,
          title: "DELETE ACCOUNT",
          children: [
            _buildInput(
              theme: theme,
              label: "Username Target",
              controller: deleteController,
              icon: FontAwesomeIcons.user,
            ),
            const SizedBox(height: 6),
            _build3DButton(
              theme: theme,
              label: "DELETE",
              color: theme.redMain,
              icon: Icons.delete_forever_rounded,
              onTap: () {
                Navigator.pop(context);
                _deleteUser();
              },
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TOMBOL BESAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTopButton({
    required XThemeData theme,
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCreamLight, theme.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.borderDark, width: 3),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 12,
                spreadRadius: -4,
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, Color.lerp(color, Colors.black, 0.4)!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // USER ITEM 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUserItem(Map user, XThemeData theme) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.redMain, theme.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: theme.borderDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: const Icon(Icons.person_rounded,
                color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'].toString(),
                  style: TextStyle(
                    color: theme.redDark,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    shadows: const [
                      Shadow(
                        color: Color(0x33000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()}  |  EXP: ${user['expiredDate']}",
                  style: TextStyle(
                    color: theme.brownMid,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup(theme);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    theme.accentRed,
                    Color.lerp(theme.accentRed, Colors.black, 0.4)!
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: theme.borderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.delete_outline_rounded,
                  color: Colors.white, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PAGINATION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPagination(XThemeData theme) {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: isSelected
                  ? LinearGradient(
                      colors: [theme.redMain, theme.redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : LinearGradient(
                      colors: [theme.bgCreamLight, theme.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? Colors.white : theme.redDark,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [theme.brownDark, theme.redDeep, theme.brownDark],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: isLoading && fullUserList.isEmpty
                  ? Center(
                      child: CircularProgressIndicator(color: theme.redMain))
                  : SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // ─── HEADER 3D ───
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      theme.gold,
                                      Color.lerp(
                                          theme.gold, Colors.black, 0.4)!
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: theme.borderDark, width: 2.5),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: Icon(
                                    Icons.workspace_premium_rounded,
                                    color: theme.redDark,
                                    size: 26),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "OWNER PANEL",
                                      style: TextStyle(
                                        color: theme.bgCreamLight,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1,
                                        shadows: const [
                                          Shadow(
                                            color: Color(0xCC000000),
                                            blurRadius: 4,
                                            offset: Offset(1, 1),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      "Management Dashboard",
                                      style: TextStyle(
                                        color: theme.gold,
                                        fontSize: 11,
                                        fontFamily: 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // ─── TOMBOL STOR DISINI 5K ───
                          _build3DButton(
                            theme: theme,
                            label: "STOR DISINI 5K",
                            color: theme.accentYellow,
                            icon: Icons.qr_code_rounded,
                            height: 50,
                            onTap: () => _showStorageQRPopup(theme),
                          ),
                          const SizedBox(height: 20),

                          // ─── 3 BUTTON ROW ───
                          Row(
                            children: [
                              _buildTopButton(
                                theme: theme,
                                title: "BUAT\nAKUN",
                                icon: FontAwesomeIcons.userPlus,
                                color: theme.accentGreen,
                                onTap: () => _showCreateAccountPopup(theme),
                              ),
                              const SizedBox(width: 12),
                              _buildTopButton(
                                theme: theme,
                                title: "ADD\nDURASI",
                                icon: FontAwesomeIcons.clock,
                                color: theme.accentBlue,
                                onTap: () => _showExtendDurationPopup(theme),
                              ),
                              const SizedBox(width: 12),
                              _buildTopButton(
                                theme: theme,
                                title: "HAPUS\nAKUN",
                                icon: FontAwesomeIcons.userSlash,
                                color: theme.redMain,
                                onTap: () => _showDeleteAccountPopup(theme),
                              ),
                            ],
                          ),
                          const SizedBox(height: 30),

                          // ─── USER DIRECTORY ───
                          Row(
                            children: [
                              Container(
                                width: 5,
                                height: 18,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [theme.redMain, theme.redDark],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                  borderRadius: BorderRadius.circular(3),
                                  border: Border.all(
                                      color: theme.borderDark, width: 1.5),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xAA000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "USER DIRECTORY",
                                style: TextStyle(
                                  color: theme.gold,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5,
                                  shadows: const [
                                    Shadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 4,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          // ─── ROLE FILTER DROPDOWN 3D ───
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.bgCreamLight, theme.bgCream],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: theme.borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                                BoxShadow(
                                  color: Color(0x77000000),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: selectedRole,
                                dropdownColor: theme.bgCreamLight,
                                isExpanded: true,
                                style: TextStyle(
                                  color: theme.redDark,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                ),
                                icon: Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: theme.redDark),
                                items: roleOptions.map((role) {
                                  return DropdownMenuItem(
                                    value: role,
                                    child: Text(role.toUpperCase()),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() {
                                      selectedRole = val;
                                      _filterAndPaginate();
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // ─── LOADING / EMPTY STATE ───
                          if (isLoading && fullUserList.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: Center(
                                child: CircularProgressIndicator(
                                    color: theme.redMain),
                              ),
                            ),

                          if (filteredList.isEmpty && !isLoading)
                            Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 40),
                                child: Column(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(20),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            theme.bgCreamLight,
                                            theme.bgCream
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                            color: theme.borderDark,
                                            width: 3),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xAA000000),
                                            blurRadius: 0,
                                            offset: Offset(3, 3),
                                          ),
                                        ],
                                      ),
                                      child: Icon(
                                        Icons.person_off_rounded,
                                        color: theme.redDark,
                                        size: 40,
                                      ),
                                    ),
                                    const SizedBox(height: 16),
                                    Text(
                                      "Belum ada user di kategori ini.",
                                      style: TextStyle(
                                        color: theme.gold,
                                        fontSize: 12,
                                        fontFamily: 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                          // ─── USER LIST ───
                          ..._getCurrentPageData()
                              .map((u) => _buildUserItem(u, theme))
                              .toList(),

                          const SizedBox(height: 20),
                          Center(child: _buildPagination(theme)),
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }
}