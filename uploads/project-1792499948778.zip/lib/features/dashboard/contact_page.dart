// lib/features/dashboard/contact_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/widgets/custom_popup.dart';
import 'xtheme.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.display(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: Colors.redAccent,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = XThemeController();

    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final theme = controller.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [theme.redMain, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: theme.redMain.withOpacity(0.3),
                      blurRadius: 14,
                      spreadRadius: -4,
                    ),
                  ],
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.white,
                    size: 18,
                  ),
                  onPressed: () {
                    if (Navigator.of(context).canPop()) {
                      Navigator.of(context).pop();
                    } else {
                      SystemNavigator.pop();
                    }
                  },
                ),
              ),
            ),
            title: Text(
              "Customer Service",
              style: TextStyle(
                color: theme.bgCreamLight,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 4,
                    offset: const Offset(1, 1),
                  ),
                ],
              ),
            ),
            centerTitle: true,
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  theme.brownDark,
                  Color.lerp(theme.brownDark, theme.redDeep, 0.6)!,
                  theme.brownDark,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: Stack(
              children: [
                // Radial glow atas
                Positioned(
                  top: -100,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 350,
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.topCenter,
                        radius: 1.0,
                        colors: [
                          theme.redMain.withOpacity(0.18),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
                Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ═══ HEADER ICON 3D ═══
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                theme.redMain,
                                theme.redDark,
                                theme.redDeep,
                              ],
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: theme.borderDark,
                              width: 3,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: theme.redMain.withOpacity(0.55),
                                blurRadius: 34,
                                spreadRadius: 4,
                                offset: const Offset(0, 14),
                              ),
                              BoxShadow(
                                color: theme.gold.withOpacity(0.4),
                                blurRadius: 18,
                                spreadRadius: 1,
                                offset: const Offset(0, 6),
                              ),
                              BoxShadow(
                                color: Colors.white.withOpacity(0.25),
                                blurRadius: 10,
                                offset: const Offset(-4, -4),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.support_agent_rounded,
                            size: 64,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 28),
                        Text(
                          "Need Help?",
                          style: TextStyle(
                            color: theme.bgCreamLight,
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                            fontFamily: 'Orbitron',
                            shadows: [
                              Shadow(
                                color: theme.gold.withOpacity(0.5),
                                offset: const Offset(0, 2),
                                blurRadius: 6,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Contact us through our social media platforms below.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: theme.gold.withOpacity(0.85),
                            fontSize: 14,
                            height: 1.4,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 40),

                        // ═══ GRID 2x2 ═══
                        Row(
                          children: [
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                theme: theme,
                                label: "Developer",
                                icon: FontAwesomeIcons.telegram,
                                accent: theme.redMain,
                                url: "https://t.me/itsmeerlan",
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                theme: theme,
                                label: "Tele Ch",
                                icon: FontAwesomeIcons.telegram,
                                accent: theme.redDark,
                                url: "https://t.me/justerlanforme",
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                theme: theme,
                                label: "WhatsApp",
                                icon: FontAwesomeIcons.whatsapp,
                                accent: theme.accentGreen,
                                url: "https://wa.me/6285196393366",
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                theme: theme,
                                label: "Channel WA",
                                icon: FontAwesomeIcons.whatsapp,
                                accent: theme.accentGreen,
                                url:
                                    "https://whatsapp.com/channel/0029Vb8ZqffFCCoPFZTtzs1Q",
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══ TOMBOL 3D HD — mengikuti tema ═══
  Widget _buildContactButton({
    required BuildContext context,
    required XThemeData theme,
    required String label,
    required IconData icon,
    required Color accent,
    required String url,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _launchUrl(context, url),
        borderRadius: BorderRadius.circular(20),
        splashColor: accent.withOpacity(0.18),
        highlightColor: accent.withOpacity(0.10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                theme.bgCreamLight,
                theme.bgCream,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: theme.borderDark,
              width: 2.5,
            ),
            boxShadow: [
              // Drop shadow utama
              BoxShadow(
                color: accent.withOpacity(0.45),
                blurRadius: 20,
                spreadRadius: 1,
                offset: const Offset(0, 12),
              ),
              // Secondary shadow
              BoxShadow(
                color: theme.redDeep.withOpacity(0.25),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              // Highlight glossy atas
              BoxShadow(
                color: Colors.white.withOpacity(0.55),
                blurRadius: 6,
                offset: const Offset(-3, -3),
              ),
              // Shadow halus bawah
              BoxShadow(
                color: theme.redDeep.withOpacity(0.10),
                blurRadius: 8,
                offset: const Offset(2, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Ikon dengan glow 3D
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      accent,
                      Color.lerp(accent, theme.redDeep, 0.5)!,
                      theme.redDeep,
                    ],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: theme.borderDark,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.65),
                      blurRadius: 16,
                      spreadRadius: 1,
                      offset: const Offset(0, 7),
                    ),
                    BoxShadow(
                      color: theme.redDeep.withOpacity(0.35),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.45),
                      blurRadius: 6,
                      offset: const Offset(-3, -3),
                    ),
                  ],
                ),
                child: FaIcon(
                  icon,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                label,
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.3,
                  fontFamily: 'Orbitron',
                  shadows: const [
                    Shadow(
                      color: Color(0x22B91C1C),
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}