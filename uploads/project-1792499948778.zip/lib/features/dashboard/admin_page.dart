// lib/features/dashboard/admin_page.dart
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/config/apiBaseUrl.dart';
import '../../core/widgets/custom_popup.dart';
import 'xtheme.dart';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  // Foto
  XFile? _selectedImage;
  String _imageBase64 = '';

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/api/accountDirectory?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/api/removeAccount?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$apiBaseUrl/submitPending');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'username': u,
          'password': p,
          'day': d,
          'role': newUserRole,
          'imageBase64': _imageBase64,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert("Sukses",
            "Permintaan akun dikirim! Tunggu approval Owner di Telegram.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _imageBase64 = '';
        _selectedImage = null;
        newUserRole = 'member';
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengirim permintaan.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$apiBaseUrl/api/extendAccountExpiry?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.display(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses")
          ? Icons.check_circle_outline
          : Icons.info_outline,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT FIELD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInput({
    required XThemeData theme,
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.bgCreamLight, theme.bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: theme.borderDark, width: 2.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(3, 3),
            ),
          ],
        ),
        child: TextField(
          controller: controller,
          keyboardType: type,
          style: TextStyle(
            color: theme.textDark,
            fontFamily: 'ShareTechMono',
            fontWeight: FontWeight.w700,
          ),
          cursorColor: theme.redMain,
          decoration: InputDecoration(
            labelText: label,
            labelStyle: TextStyle(
              color: theme.redDark,
              fontSize: 12,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
            ),
            prefixIcon: Icon(icon, color: theme.redDark, size: 18),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await File(image.path).readAsBytes();
      setState(() {
        _selectedImage = image;
        _imageBase64 = base64Encode(bytes);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DIALOG HELPERS
  // ═══════════════════════════════════════════════════════════════════
  Widget _dialogContainer({
    required XThemeData theme,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: theme.borderDark, width: 3.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(6, 6),
          ),
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _dialogIcon({
    required XThemeData theme,
    required IconData icon,
    required Color color,
    bool isFontAwesome = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, Color.lerp(color, Colors.black, 0.45)!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: isFontAwesome
          ? FaIcon(icon, color: Colors.white, size: 28)
          : Icon(icon, color: Colors.white, size: 28),
    );
  }

  Widget _dialogTitle({required XThemeData theme, required String title}) {
    return Text(
      title,
      style: TextStyle(
        color: theme.redDark,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        fontFamily: 'Orbitron',
        letterSpacing: 1.2,
        shadows: const [
          Shadow(
            color: Color(0x33000000),
            blurRadius: 3,
            offset: Offset(2, 2),
          ),
        ],
      ),
    );
  }

  Widget _dialogActionButton({
    required XThemeData theme,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, Color.lerp(color, Colors.black, 0.4)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: theme.borderDark, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
            ],
          ),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                fontFamily: 'Orbitron',
                fontSize: 12,
                shadows: [
                  Shadow(
                    color: Color(0x99000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP QR STOR
  // ═══════════════════════════════════════════════════════════════════
  void _showStorageQRPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _dialogContainer(
            theme: theme,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogIcon(
                  theme: theme,
                  icon: Icons.qr_code,
                  color: theme.gold,
                ),
                const SizedBox(height: 16),
                _dialogTitle(theme: theme, title: "STOR DISINI 5K"),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: theme.borderDark, width: 3),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: Image.network(
                      'https://files.atlas-by-erlan.com/yMrrMp3oRk.jpg',
                      height: 200,
                      width: 200,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Container(
                        height: 200,
                        width: 200,
                        color: theme.brownMid,
                        child: Icon(Icons.broken_image_rounded,
                            color: theme.bgCream, size: 40),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Scan QR untuk melakukan pembayaran",
                  style: TextStyle(
                    color: theme.brownMid,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                _dialogActionButton(
                  theme: theme,
                  label: "TUTUP",
                  color: theme.redMain,
                  onTap: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP CREATE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showCreateAccountPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Dialog(
              backgroundColor: Colors.transparent,
              elevation: 0,
              child: SingleChildScrollView(
                child: _dialogContainer(
                  theme: theme,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _dialogIcon(
                        theme: theme,
                        icon: FontAwesomeIcons.userPlus,
                        color: theme.redMain,
                        isFontAwesome: true,
                      ),
                      const SizedBox(height: 16),
                      _dialogTitle(theme: theme, title: "CREATE ACCOUNT"),
                      const SizedBox(height: 24),

                      // Tombol pilih foto
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 16),
                        child: GestureDetector(
                          onTap: () async {
                            await _pickImage();
                            setModalState(() {});
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: _selectedImage == null
                                    ? [theme.brownMid, theme.brownDark]
                                    : [
                                        theme.accentGreen,
                                        Color.lerp(theme.accentGreen,
                                            Colors.black, 0.4)!
                                      ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: theme.borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xAA000000),
                                  blurRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.photo,
                                    size: 20, color: Colors.white),
                                const SizedBox(width: 8),
                                Text(
                                  _selectedImage == null
                                      ? "PILIH FOTO (Opsional)"
                                      : "FOTO TERPILIH ✅",
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      if (_selectedImage != null)
                        Container(
                          margin: const EdgeInsets.only(bottom: 16),
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(
                                color: theme.borderDark, width: 3),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xAA000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(7),
                            child: Image.file(
                              File(_selectedImage!.path),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),

                      _buildInput(
                        theme: theme,
                        label: "Username",
                        controller: createUsernameController,
                        icon: FontAwesomeIcons.user,
                      ),
                      _buildInput(
                        theme: theme,
                        label: "Password",
                        controller: createPasswordController,
                        icon: FontAwesomeIcons.lock,
                      ),
                      _buildInput(
                        theme: theme,
                        label: "Durasi (Hari)",
                        controller: createDayController,
                        icon: FontAwesomeIcons.calendarDay,
                        type: TextInputType.number,
                      ),

                      // Dropdown role 3D
                      Container(
                        width: double.infinity,
                        padding:
                            const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        margin: const EdgeInsets.only(bottom: 24),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [theme.bgCreamLight, theme.bgCream],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: theme.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xAA000000),
                              blurRadius: 0,
                              offset: Offset(3, 3),
                            ),
                          ],
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: theme.bgCreamLight,
                            style: TextStyle(
                              color: theme.textDark,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                            icon: Icon(Icons.keyboard_arrow_down,
                                color: theme.redDark),
                            items: roleOptions.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Text(role.toUpperCase()),
                              );
                            }).toList(),
                            onChanged: (val) => setModalState(
                                () => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),

                      _dialogActionButton(
                        theme: theme,
                        label: "KIRIM REQUEST",
                        color: theme.redMain,
                        onTap: () {
                          Navigator.pop(context);
                          _createAccount();
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP EXTEND DURATION
  // ═══════════════════════════════════════════════════════════════════
  void _showExtendDurationPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _dialogContainer(
            theme: theme,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogIcon(
                  theme: theme,
                  icon: FontAwesomeIcons.clock,
                  color: theme.accentBlue,
                  isFontAwesome: true,
                ),
                const SizedBox(height: 16),
                _dialogTitle(theme: theme, title: "ADD DURATION"),
                const SizedBox(height: 24),
                _buildInput(
                  theme: theme,
                  label: "Username Target",
                  controller: editUsernameController,
                  icon: FontAwesomeIcons.userEdit,
                ),
                _buildInput(
                  theme: theme,
                  label: "Tambah Hari",
                  controller: editDayController,
                  icon: FontAwesomeIcons.calendarPlus,
                  type: TextInputType.number,
                ),
                const SizedBox(height: 8),
                _dialogActionButton(
                  theme: theme,
                  label: "ADD DAYS",
                  color: theme.accentBlue,
                  onTap: () {
                    Navigator.pop(context);
                    _editUser();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP DELETE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showDeleteAccountPopup(XThemeData theme) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _dialogContainer(
            theme: theme,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogIcon(
                  theme: theme,
                  icon: FontAwesomeIcons.userSlash,
                  color: theme.accentRed,
                  isFontAwesome: true,
                ),
                const SizedBox(height: 16),
                _dialogTitle(theme: theme, title: "DELETE ACCOUNT"),
                const SizedBox(height: 24),
                _buildInput(
                  theme: theme,
                  label: "Username Target",
                  controller: deleteController,
                  icon: FontAwesomeIcons.user,
                ),
                const SizedBox(height: 8),
                _dialogActionButton(
                  theme: theme,
                  label: "DELETE",
                  color: theme.accentRed,
                  onTap: () {
                    Navigator.pop(context);
                    _deleteUser();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TOP BUTTON 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTopButton({
    required XThemeData theme,
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCreamLight, theme.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.borderDark, width: 3),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              BoxShadow(
                color: color.withOpacity(0.35),
                blurRadius: 12,
                spreadRadius: -4,
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, Color.lerp(color, Colors.black, 0.4)!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 22),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // USER ITEM 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUserItem(Map user, XThemeData theme) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.redMain, theme.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: const Icon(Icons.person, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: theme.redDark,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                  style: TextStyle(
                    color: theme.brownMid,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup(theme);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    theme.accentRed,
                    Color.lerp(theme.accentRed, Colors.black, 0.4)!
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: theme.borderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.delete_outline,
                  color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PAGINATION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPagination(XThemeData theme) {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: isSelected
                  ? LinearGradient(
                      colors: [theme.redMain, theme.redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : LinearGradient(
                      colors: [theme.bgCreamLight, theme.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? Colors.white : theme.redDark,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [theme.brownDark, theme.redDeep, theme.brownDark],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: isLoading && fullUserList.isEmpty
                  ? Center(
                      child: CircularProgressIndicator(color: theme.redMain),
                    )
                  : SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // ─── HEADER ───
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [theme.redMain, theme.redDark],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: theme.borderDark, width: 2.5),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xAA000000),
                                      blurRadius: 0,
                                      offset: Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: Icon(Icons.admin_panel_settings,
                                    color: theme.gold, size: 24),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "ADMIN PANEL",
                                      style: TextStyle(
                                        color: theme.bgCreamLight,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1.5,
                                        shadows: const [
                                          Shadow(
                                            color: Color(0xCC000000),
                                            blurRadius: 4,
                                            offset: Offset(1, 1),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      "Management Dashboard",
                                      style: TextStyle(
                                        color: theme.gold,
                                        fontSize: 12,
                                        fontFamily: 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // ─── TOMBOL STOR 5K ───
                          GestureDetector(
                            onTap: () => _showStorageQRPopup(theme),
                            child: Container(
                              height: 50,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    theme.gold,
                                    Color.lerp(theme.gold, Colors.black, 0.4)!
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: theme.borderDark, width: 3),
                                boxShadow: [
                                  const BoxShadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 0,
                                    offset: Offset(4, 4),
                                  ),
                                  BoxShadow(
                                    color: theme.gold.withOpacity(0.35),
                                    blurRadius: 12,
                                    spreadRadius: -4,
                                  ),
                                ],
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.qr_code,
                                      size: 22, color: Colors.white),
                                  SizedBox(width: 8),
                                  Text(
                                    "STOR DISINI 5K",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.2,
                                      fontFamily: 'Orbitron',
                                      fontSize: 12,
                                      shadows: [
                                        Shadow(
                                          color: Color(0x99000000),
                                          blurRadius: 3,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // ─── 3 TOMBOL AKSI ───
                          Row(
                            children: [
                              _buildTopButton(
                                theme: theme,
                                title: "BUAT\nAKUN",
                                icon: FontAwesomeIcons.userPlus,
                                color: theme.redMain,
                                onTap: () => _showCreateAccountPopup(theme),
                              ),
                              const SizedBox(width: 12),
                              _buildTopButton(
                                theme: theme,
                                title: "ADD\nDURASI",
                                icon: FontAwesomeIcons.clock,
                                color: theme.accentBlue,
                                onTap: () => _showExtendDurationPopup(theme),
                              ),
                              const SizedBox(width: 12),
                              _buildTopButton(
                                theme: theme,
                                title: "HAPUS\nAKUN",
                                icon: FontAwesomeIcons.userSlash,
                                color: theme.accentRed,
                                onTap: () => _showDeleteAccountPopup(theme),
                              ),
                            ],
                          ),
                          const SizedBox(height: 30),

                          // ─── SECTION TITLE ───
                          Row(
                            children: [
                              Container(
                                width: 5,
                                height: 18,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [theme.redMain, theme.redDark],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                  borderRadius: BorderRadius.circular(3),
                                  border: Border.all(
                                      color: theme.borderDark, width: 1.5),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "USER DIRECTORY",
                                style: TextStyle(
                                  color: theme.gold,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 2,
                                  shadows: const [
                                    Shadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 4,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          // ─── ROLE FILTER DROPDOWN 3D ───
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.bgCreamLight, theme.bgCream],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                  color: theme.borderDark, width: 3),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(4, 4),
                                ),
                                BoxShadow(
                                  color: Color(0x66000000),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: selectedRole,
                                dropdownColor: theme.bgCreamLight,
                                isExpanded: true,
                                style: TextStyle(
                                  color: theme.redDark,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                ),
                                icon: Icon(Icons.keyboard_arrow_down,
                                    color: theme.redDark),
                                items: roleOptions.map((role) {
                                  return DropdownMenuItem(
                                    value: role,
                                    child: Text(role.toUpperCase()),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() {
                                      selectedRole = val;
                                      _filterAndPaginate();
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          if (isLoading && fullUserList.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: Center(
                                child: CircularProgressIndicator(
                                    color: theme.redMain),
                              ),
                            ),

                          if (filteredList.isEmpty && !isLoading)
                            Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 40),
                                child: Text(
                                  "Belum ada user di kategori ini.",
                                  style: TextStyle(
                                    color: theme.bgCream.withOpacity(0.7),
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),

                          ..._getCurrentPageData()
                              .map((u) => _buildUserItem(u, theme))
                              .toList(),

                          const SizedBox(height: 20),
                          Center(child: _buildPagination(theme)),
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }
}