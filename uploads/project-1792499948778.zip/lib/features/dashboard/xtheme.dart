// lib/xtheme.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════════
// XTHEME DATA — Palet warna lengkap per tema
// ═══════════════════════════════════════════════════════════════════
class XThemeData {
  final String name;

  // Background / Surface
  final Color bgCream;
  final Color bgCreamLight;
  final Color bgCreamDark;

  // Primary (dulu dinamai "red")
  final Color redMain;
  final Color redDark;
  final Color redDeep;

  // Neutral / Brown
  final Color brownDark;
  final Color brownMid;

  // Gold / Highlight
  final Color gold;
  final Color goldLight;
  final Color goldDark;

  // Text & Border
  final Color textDark;
  final Color borderDark;

  // Accents
  final Color accentGreen;
  final Color accentBlue;
  final Color accentYellow;
  final Color accentRed;

  const XThemeData({
    required this.name,
    required this.bgCream,
    required this.bgCreamLight,
    required this.bgCreamDark,
    required this.redMain,
    required this.redDark,
    required this.redDeep,
    required this.brownDark,
    required this.brownMid,
    required this.gold,
    required this.goldLight,
    required this.goldDark,
    required this.textDark,
    required this.borderDark,
    required this.accentGreen,
    required this.accentBlue,
    required this.accentYellow,
    required this.accentRed,
  });

  /// Daftar warna utama untuk ditampilkan sebagai swatch preview.
  List<Color> get swatches => <Color>[
        redMain,
        redDark,
        redDeep,
        gold,
        accentGreen,
        accentBlue,
        accentYellow,
        accentRed,
        brownMid,
        bgCream,
      ];
}

// ═══════════════════════════════════════════════════════════════════
// XTHEME CONTROLLER — Singleton + Persistence
// ═══════════════════════════════════════════════════════════════════
class XThemeController extends ChangeNotifier {
  static final XThemeController _instance = XThemeController._internal();
  factory XThemeController() => _instance;
  XThemeController._internal() {
    _loadFromPrefs();
  }

  static const String _prefsKey = 'xtheme_selected_name';

  static const List<XThemeData> availableThemes = [
    // ─────────── MERAH (DEFAULT) ───────────
    XThemeData(
      name: 'Merah (Default)',
      bgCream: Color(0xFFF5E6D3),
      bgCreamLight: Color(0xFFFFF8F0),
      bgCreamDark: Color(0xFFE8D5BC),
      redMain: Color(0xFFB71C1C),
      redDark: Color(0xFF7F0000),
      redDeep: Color(0xFF4A0000),
      brownDark: Color(0xFF2B0E0E),
      brownMid: Color(0xFF5D2B1F),
      gold: Color(0xFFD4A853),
      goldLight: Color(0xFFF0CC80),
      goldDark: Color(0xFFA17E38),
      textDark: Color(0xFF1A0A0A),
      borderDark: Color(0xFF1A0505),
      accentGreen: Color(0xFF4CAF50),
      accentBlue: Color(0xFF2196F3),
      accentYellow: Color(0xFFFFC107),
      accentRed: Color(0xFFE53935),
    ),

    // ─────────── BIRU OCEAN ───────────
    XThemeData(
      name: 'Biru Ocean',
      bgCream: Color(0xFFD0E1F9),
      bgCreamLight: Color(0xFFEBF2FA),
      bgCreamDark: Color(0xFFB8CEEB),
      redMain: Color(0xFF1E88E5),
      redDark: Color(0xFF1565C0),
      redDeep: Color(0xFF0D47A1),
      brownDark: Color(0xFF0A192F),
      brownMid: Color(0xFF1C3144),
      gold: Color(0xFF00E5FF),
      goldLight: Color(0xFF5FF0FF),
      goldDark: Color(0xFF00A0B8),
      textDark: Color(0xFF051329),
      borderDark: Color(0xFF020C1B),
      accentGreen: Color(0xFF00E676),
      accentBlue: Color(0xFF00BCD4),
      accentYellow: Color(0xFFFFC107),
      accentRed: Color(0xFFFF5252),
    ),

    // ─────────── UNGU PURPLE ───────────
    XThemeData(
      name: 'Ungu Purple',
      bgCream: Color(0xFFE1BEE7),
      bgCreamLight: Color(0xFFF3E5F5),
      bgCreamDark: Color(0xFFCFA0D8),
      redMain: Color(0xFF8E24AA),
      redDark: Color(0xFF6A1B9A),
      redDeep: Color(0xFF4A148C),
      brownDark: Color(0xFF1A002C),
      brownMid: Color(0xFF38004D),
      gold: Color(0xFFE040FB),
      goldLight: Color(0xFFEE80FF),
      goldDark: Color(0xFFA028B8),
      textDark: Color(0xFF120021),
      borderDark: Color(0xFF0A0014),
      accentGreen: Color(0xFF00E676),
      accentBlue: Color(0xFF40C4FF),
      accentYellow: Color(0xFFFFD54F),
      accentRed: Color(0xFFFF5252),
    ),

    // ─────────── HIJAU EMERALD ───────────
    XThemeData(
      name: 'Hijau Emerald',
      bgCream: Color(0xFFC8E6C9),
      bgCreamLight: Color(0xFFE8F5E9),
      bgCreamDark: Color(0xFFA8C9A9),
      redMain: Color(0xFF43A047),
      redDark: Color(0xFF2E7D32),
      redDeep: Color(0xFF1B5E20),
      brownDark: Color(0xFF09220D),
      brownMid: Color(0xFF143B1A),
      gold: Color(0xFF76FF03),
      goldLight: Color(0xFFA8FF50),
      goldDark: Color(0xFF4ABF00),
      textDark: Color(0xFF051808),
      borderDark: Color(0xFF020E04),
      accentGreen: Color(0xFF00E676),
      accentBlue: Color(0xFF40C4FF),
      accentYellow: Color(0xFFFFEA00),
      accentRed: Color(0xFFFF5252),
    ),

    // ─────────── ORANYE SUNSET ───────────
    XThemeData(
      name: 'Oranye Sunset',
      bgCream: Color(0xFFFFE0B2),
      bgCreamLight: Color(0xFFFFF3E0),
      bgCreamDark: Color(0xFFE8C888),
      redMain: Color(0xFFFB8C00),
      redDark: Color(0xFFEF6C00),
      redDeep: Color(0xFFE65100),
      brownDark: Color(0xFF2B1400),
      brownMid: Color(0xFF4E2600),
      gold: Color(0xFFFFD700),
      goldLight: Color(0xFFFFE84D),
      goldDark: Color(0xFFB09600),
      textDark: Color(0xFF1F0D00),
      borderDark: Color(0xFF140800),
      accentGreen: Color(0xFF00E676),
      accentBlue: Color(0xFF40C4FF),
      accentYellow: Color(0xFFFFD700),
      accentRed: Color(0xFFFF5252),
    ),

    // ─────────── PINK ROSE (BARU) ───────────
    XThemeData(
      name: 'Pink Rose',
      bgCream: Color(0xFFFFD9E2),
      bgCreamLight: Color(0xFFFFEEF3),
      bgCreamDark: Color(0xFFE8B8C8),
      redMain: Color(0xFFE91E63),
      redDark: Color(0xFFC2185B),
      redDeep: Color(0xFF880E4F),
      brownDark: Color(0xFF2B0616),
      brownMid: Color(0xFF5C1A38),
      gold: Color(0xFFFF6FA8),
      goldLight: Color(0xFFFFA8C8),
      goldDark: Color(0xFFB03868),
      textDark: Color(0xFF1A030C),
      borderDark: Color(0xFF0F0208),
      accentGreen: Color(0xFF00E676),
      accentBlue: Color(0xFF40C4FF),
      accentYellow: Color(0xFFFFD54F),
      accentRed: Color(0xFFFF5252),
    ),

    // ─────────── DARK NEON (BARU) ───────────
    XThemeData(
      name: 'Dark Neon',
      bgCream: Color(0xFF2A2A3E),
      bgCreamLight: Color(0xFF3A3A52),
      bgCreamDark: Color(0xFF1A1A2B),
      redMain: Color(0xFF7C4DFF),
      redDark: Color(0xFF5E35B1),
      redDeep: Color(0xFF3E1E8E),
      brownDark: Color(0xFF0A0A1A),
      brownMid: Color(0xFF16163A),
      gold: Color(0xFF00E5FF),
      goldLight: Color(0xFF80F0FF),
      goldDark: Color(0xFF00A8B8),
      textDark: Color(0xFFEDEDFF),
      borderDark: Color(0xFF000010),
      accentGreen: Color(0xFF00FF88),
      accentBlue: Color(0xFF40C4FF),
      accentYellow: Color(0xFFFFEA00),
      accentRed: Color(0xFFFF1744),
    ),
  ];

  XThemeData _currentTheme = availableThemes[0];
  XThemeData get currentTheme => _currentTheme;

  /// Muat tema tersimpan dari SharedPreferences.
  Future<void> _loadFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedName = prefs.getString(_prefsKey);
      if (savedName != null && savedName.isNotEmpty) {
        final found = availableThemes.firstWhere(
          (t) => t.name == savedName,
          orElse: () => availableThemes[0],
        );
        if (_currentTheme.name != found.name) {
          _currentTheme = found;
          notifyListeners();
        }
      }
    } catch (_) {
      // abaikan
    }
  }

  /// Ganti tema + simpan ke SharedPreferences.
  Future<void> changeTheme(XThemeData newTheme) async {
    if (_currentTheme.name == newTheme.name) return;
    _currentTheme = newTheme;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, newTheme.name);
    } catch (_) {
      // abaikan
    }
  }
}

// ═══════════════════════════════════════════════════════════════════
// XTHEME PAGE — UI Theme Picker yang lebih menarik
// ═══════════════════════════════════════════════════════════════════
class XThemePage extends StatelessWidget {
  const XThemePage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = XThemeController();

    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final theme = controller.currentTheme;

        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                theme.brownDark,
                Color.lerp(theme.brownDark, theme.brownMid, 0.55)!,
                theme.brownDark,
              ],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                _buildHeader(theme),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(14, 4, 14, 100),
                    itemCount: XThemeController.availableThemes.length,
                    itemBuilder: (context, index) {
                      final itemTheme =
                          XThemeController.availableThemes[index];
                      final isSelected = itemTheme.name == theme.name;
                      return _ThemeCard(
                        itemTheme: itemTheme,
                        isSelected: isSelected,
                        onTap: () => controller.changeTheme(itemTheme),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─────────── HEADER ───────────
  Widget _buildHeader(XThemeData theme) {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 14, 14, 6),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.redMain, theme.redDark, theme.redDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.55, 1.0],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [theme.goldLight, theme.gold, theme.goldDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: [
                BoxShadow(
                  color: theme.gold.withOpacity(0.55),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
              ],
            ),
            child: Icon(
              Icons.palette_rounded,
              color: theme.redDeep,
              size: 26,
              shadows: const [
                Shadow(
                  color: Colors.black45,
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [theme.goldLight, Colors.white, theme.goldLight],
                  ).createShader(bounds),
                  child: const Text(
                    'XTHEME STUDIO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.8,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Tema aktif: ${theme.name}',
                  style: TextStyle(
                    color: theme.bgCreamLight,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
          // Preview bulat tema aktif
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: SweepGradient(
                colors: [
                  theme.redMain,
                  theme.gold,
                  theme.accentGreen,
                  theme.accentBlue,
                  theme.redDeep,
                  theme.redMain,
                ],
              ),
              border: Border.all(color: Colors.white, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// THEME CARD
// ═══════════════════════════════════════════════════════════════════
class _ThemeCard extends StatefulWidget {
  final XThemeData itemTheme;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeCard({
    required this.itemTheme,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_ThemeCard> createState() => _ThemeCardState();
}

class _ThemeCardState extends State<_ThemeCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressCtrl;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 130),
      lowerBound: 0.95,
      upperBound: 1.0,
      value: 1.0,
    );
    _scaleAnim = _pressCtrl;
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.itemTheme;
    final selected = widget.isSelected;

    return ScaleTransition(
      scale: _scaleAnim,
      child: GestureDetector(
        onTapDown: (_) => _pressCtrl.reverse(),
        onTapUp: (_) => _pressCtrl.forward(),
        onTapCancel: () => _pressCtrl.forward(),
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOut,
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                t.bgCreamLight,
                t.bgCream,
                t.bgCreamDark,
              ],
              stops: const [0.0, 0.55, 1.0],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: selected ? t.gold : t.borderDark,
              width: selected ? 3.5 : 2.5,
            ),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              if (selected)
                BoxShadow(
                  color: t.gold.withOpacity(0.55),
                  blurRadius: 20,
                  spreadRadius: 1,
                ),
              const BoxShadow(
                color: Color(0x88000000),
                blurRadius: 14,
                offset: Offset(0, 7),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Preview circle (multi-stop gradient)
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: SweepGradient(
                          colors: [
                            t.redMain,
                            t.gold,
                            t.accentGreen,
                            t.accentBlue,
                            t.accentRed,
                            t.redDeep,
                            t.redMain,
                          ],
                        ),
                        border: Border.all(color: t.borderDark, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(3, 3),
                          ),
                          BoxShadow(
                            color: Color(0x66000000),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: t.bgCreamLight,
                            border:
                                Border.all(color: t.borderDark, width: 2),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),

                    // Nama + badge
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t.name,
                            style: TextStyle(
                              color: t.textDark,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 0.6,
                              shadows: const [
                                Shadow(
                                  color: Color(0x33000000),
                                  blurRadius: 2,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              _miniBadge(
                                label: 'BASE',
                                color: t.redMain,
                                textColor: Colors.white,
                              ),
                              const SizedBox(width: 5),
                              _miniBadge(
                                label: 'GOLD',
                                color: t.gold,
                                textColor: t.brownDark,
                              ),
                              const SizedBox(width: 5),
                              _miniBadge(
                                label: 'ACCENT',
                                color: t.accentGreen,
                                textColor: Colors.white,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Ikon check
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 260),
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: selected
                              ? [t.goldLight, t.gold, t.goldDark]
                              : [
                                  t.bgCreamLight,
                                  t.bgCream,
                                ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border:
                            Border.all(color: t.borderDark, width: 2.5),
                        boxShadow: [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                          if (selected)
                            BoxShadow(
                              color: t.gold.withOpacity(0.6),
                              blurRadius: 10,
                            ),
                        ],
                      ),
                      child: Icon(
                        selected
                            ? Icons.check_rounded
                            : Icons.circle_outlined,
                        color: selected ? t.brownDark : t.brownMid,
                        size: 20,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Color swatch bar — semua warna utama tema
                Row(
                  children: t.swatches
                      .map(
                        (c) => Expanded(
                          child: Container(
                            height: 22,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              color: c,
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: t.borderDark,
                                width: 1.8,
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 0,
                                  offset: Offset(1.5, 1.5),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),

                const SizedBox(height: 10),

                // Gradient bar preview
                Container(
                  height: 10,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(
                      colors: [
                        t.redDeep,
                        t.redMain,
                        t.gold,
                        t.accentGreen,
                        t.accentBlue,
                      ],
                    ),
                    border: Border.all(color: t.borderDark, width: 1.8),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x88000000),
                        blurRadius: 0,
                        offset: Offset(1.5, 1.5),
                      ),
                    ],
                  ),
                ),

                if (selected) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(
                        Icons.bolt_rounded,
                        color: t.gold,
                        size: 14,
                        shadows: [
                          Shadow(
                            color: t.gold.withOpacity(0.9),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'SEDANG DIGUNAKAN',
                        style: TextStyle(
                          color: t.redDark,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _miniBadge({
    required String label,
    required Color color,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: widget.itemTheme.borderDark, width: 1.4),
        boxShadow: const [
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 0,
            offset: Offset(1.5, 1.5),
          ),
        ],
      ),
      child: Text(
        label,
        style: TextStyle(
          color: textColor,
          fontSize: 8,
          fontWeight: FontWeight.w900,
          fontFamily: 'Orbitron',
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}