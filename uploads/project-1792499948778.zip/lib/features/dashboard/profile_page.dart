// lib/pages/profile_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import '../auth/change_password_page.dart';

// Sesuaikan path ini dengan lokasi xtheme.dart kamu
import 'xtheme.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  final LocalAuthentication auth = LocalAuthentication();

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  bool _isBiometricEnabled = false;

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadProfileImage();
    _loadBiometricStatus();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadBiometricStatus() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      _isBiometricEnabled =
          prefs.getBool('biometric_enabled_${widget.username}') ?? false;
    });
  }

  Future<void> _toggleBiometric() async {
    final theme = _themeController.currentTheme;
    try {
      final bool deviceSupported = await auth.isDeviceSupported();

      if (!deviceSupported) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text(
              '⚠️ Perangkat tidak mendukung autentikasi biometrik.',
            ),
            backgroundColor: theme.redMain,
          ),
        );
        return;
      }

      final List<BiometricType> availableBiometrics =
          await auth.getAvailableBiometrics();

      if (availableBiometrics.isEmpty) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text(
              '⚠️ Belum ada sidik jari yang terdaftar di perangkat.\n'
              'Silakan daftarkan sidik jari di Pengaturan Android terlebih dahulu.',
            ),
            backgroundColor: theme.redMain,
            duration: const Duration(seconds: 4),
          ),
        );
        return;
      }

      final bool authenticated = await auth.authenticate(
        localizedReason: _isBiometricEnabled
            ? 'Konfirmasi untuk menonaktifkan sidik jari'
            : 'Konfirmasi untuk mengaktifkan sidik jari untuk akun ${widget.username}',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );

      if (!authenticated) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('❌ Verifikasi sidik jari dibatalkan/gagal.'),
            backgroundColor: theme.redMain,
          ),
        );
        return;
      }

      final prefs = await SharedPreferences.getInstance();

      final String accountKey = 'biometric_enabled_${widget.username}';

      final bool newStatus = !_isBiometricEnabled;

      if (newStatus) {
        final String? currentBioUser =
            prefs.getString('biometric_active_user');

        if (currentBioUser != null &&
            currentBioUser.isNotEmpty &&
            currentBioUser != widget.username) {
          if (!mounted) return;

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Fingerprint sudah digunakan oleh akun $currentBioUser.\n'
                'Nonaktifkan fingerprint akun tersebut terlebih dahulu.',
              ),
              backgroundColor: theme.redMain,
              duration: const Duration(seconds: 4),
            ),
          );
          return;
        }

        await prefs.setBool(accountKey, true);
        await prefs.setString('biometric_active_user', widget.username);
        await prefs.setString(
          'biometric_password_${widget.username}',
          widget.password,
        );
      } else {
        await prefs.setBool(accountKey, false);

        final String? currentBioUser =
            prefs.getString('biometric_active_user');

        if (currentBioUser == widget.username) {
          await prefs.remove('biometric_active_user');
          await prefs.remove('biometric_password_${widget.username}');
        }
      }

      if (!mounted) return;

      setState(() {
        _isBiometricEnabled = newStatus;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            newStatus
                ? '✅ Fingerprint berhasil diaktifkan untuk ${widget.username}'
                : '❌ Fingerprint berhasil dinonaktifkan',
          ),
          backgroundColor: theme.redMain,
        ),
      );
    } on PlatformException catch (e) {
      debugPrint('Biometric PlatformException: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Fingerprint gagal: ${e.message ?? e.code}'),
          backgroundColor: theme.redMain,
          duration: const Duration(seconds: 4),
        ),
      );
    } catch (e) {
      debugPrint('Biometric error: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Terjadi error fingerprint: $e'),
          backgroundColor: theme.redMain,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog(XThemeData theme) {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: theme.bgCreamLight,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: theme.borderDark, width: 3),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: theme.brownMid.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "GANTI FOTO PROFIL",
                style: TextStyle(
                  color: theme.redDark,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 20),
              _buildSheetOption(
                theme: theme,
                icon: Icons.camera_alt_rounded,
                title: "KAMERA",
                subtitle: "Ambil foto sekarang",
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              const SizedBox(height: 10),
              _buildSheetOption(
                theme: theme,
                icon: Icons.photo_library_rounded,
                title: "GALERI",
                subtitle: "Pilih dari galeri",
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetOption({
    required XThemeData theme,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCream, theme.bgCreamLight],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: theme.borderDark, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.redMain, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: theme.redDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: theme.brownMid.withOpacity(0.9),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: theme.redDark,
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  Widget _buildRoleBadge(XThemeData theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.redMain, theme.redDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: theme.gold,
              shape: BoxShape.circle,
              border: Border.all(color: theme.borderDark, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: theme.gold.withOpacity(0.8),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
              shadows: [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required XThemeData theme,
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fullWidth ? 16 : 14,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.redMain, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 14),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: theme.redDark,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: theme.bgCream,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: theme.brownMid.withOpacity(0.3),
                width: 1.5,
              ),
            ),
            child: Text(
              value,
              style: TextStyle(
                color: theme.textDark,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 TOMBOL FITUR SIDIK JARI 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBiometricButton(XThemeData theme) {
    return Container(
      width: double.infinity,
      height: 58,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, Colors.white],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _toggleBiometric,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: theme.bgCream,
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.borderDark, width: 1.5),
                  ),
                  child: Icon(
                    Icons.fingerprint_rounded,
                    color: theme.redDark,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    _isBiometricEnabled
                        ? "SIDIK JARI (AKTIF)"
                        : "AKTIFKAN SIDIK JARI",
                    style: TextStyle(
                      color: theme.redDark,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: const [
                        Shadow(
                          color: Color(0x22000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
                Switch(
                  value: _isBiometricEnabled,
                  onChanged: (_) => _toggleBiometric(),
                  activeColor: theme.redMain,
                  activeTrackColor: theme.bgCream,
                  inactiveThumbColor: theme.brownMid,
                  inactiveTrackColor: theme.bgCream,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 TOMBOL CHANGE PASSWORD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildChangePasswordButton(XThemeData theme) {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          height: 58,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.redMain, theme.redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.borderDark, width: 3),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              BoxShadow(
                color: theme.redMain.withOpacity(_glowAnimation.value * 0.4),
                blurRadius: 25,
                spreadRadius: 2,
              ),
              const BoxShadow(
                color: Color(0x77000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(color: theme.borderDark, width: 1.5),
                    ),
                    child: Icon(
                      Icons.lock_reset_rounded,
                      color: theme.gold,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildUidCard(XThemeData theme) {
    final String uid = widget.uid ?? 'Tidak ada UID';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.redMain, theme.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: theme.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.badge_rounded,
                  color: Colors.white,
                  size: 14,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "UID / ID",
                  style: TextStyle(
                    color: theme.redDark,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('✅ UID berhasil disalin!'),
                      duration: const Duration(seconds: 2),
                      backgroundColor: theme.redMain,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(
                          color: theme.borderDark,
                          width: 2,
                        ),
                      ),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.redMain, theme.redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: theme.borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.copy_rounded, color: Colors.white, size: 12),
                      SizedBox(width: 4),
                      Text(
                        "SALIN",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: theme.bgCream,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: theme.brownMid.withOpacity(0.3),
                width: 1.5,
              ),
            ),
            child: Text(
              uid,
              style: TextStyle(
                color: theme.redDark,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          appBar: AppBar(
            backgroundColor: theme.brownDark,
            elevation: 0,
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.redMain, theme.redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: theme.borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              ),
            ),
            title: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.redMain, theme.redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: theme.borderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x66000000),
                    blurRadius: 8,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: const Text(
                "MY PROFILE",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 2,
                  shadows: [
                    Shadow(
                      color: Color(0xCC000000),
                      blurRadius: 3,
                      offset: Offset(1, 1),
                    ),
                  ],
                ),
              ),
            ),
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              children: [
                const SizedBox(height: 8),

                Center(
                  child: GestureDetector(
                    onTap: () => _showImageSourceDialog(theme),
                    child: Stack(
                      children: [
                        AnimatedBuilder(
                          animation: _glowAnimation,
                          builder: (context, _) {
                            return Container(
                              width: 120,
                              height: 120,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [theme.redMain, theme.redDark],
                                ),
                                border: Border.all(
                                    color: theme.borderDark, width: 3.5),
                                boxShadow: [
                                  const BoxShadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 0,
                                    offset: Offset(4, 4),
                                  ),
                                  BoxShadow(
                                    color: theme.redMain.withOpacity(
                                        _glowAnimation.value * 0.5),
                                    blurRadius: 30,
                                    spreadRadius: 4,
                                  ),
                                  const BoxShadow(
                                    color: Color(0x88000000),
                                    blurRadius: 18,
                                    offset: Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(4),
                                child: Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: theme.bgCream,
                                    border: Border.all(
                                      color: theme.borderDark,
                                      width: 2,
                                    ),
                                  ),
                                  child: ClipOval(
                                    child: _profileImage != null
                                        ? Image.file(
                                            _profileImage!,
                                            fit: BoxFit.cover,
                                          )
                                        : Center(
                                            child: Icon(
                                              FontAwesomeIcons.userAstronaut,
                                              size: 44,
                                              color: theme.redDark
                                                  .withOpacity(0.5),
                                            ),
                                          ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.gold, theme.goldDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: theme.borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(2, 2),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.camera_alt_rounded,
                              size: 16,
                              color: theme.textDark,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 22),

                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.bgCreamLight, theme.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: theme.borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                      BoxShadow(
                        color: Color(0x66000000),
                        blurRadius: 10,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Text(
                    widget.username,
                    style: TextStyle(
                      color: theme.redDark,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: const [
                        Shadow(
                          color: Color(0x33000000),
                          blurRadius: 3,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 14),

                _buildRoleBadge(theme),

                const SizedBox(height: 32),

                _buildSectionTitle("ACCOUNT DATA", theme),

                const SizedBox(height: 14),

                Row(
                  children: [
                    Expanded(
                      child: _buildInfoCard(
                        theme: theme,
                        icon: Icons.person_outline,
                        label: "USERNAME",
                        value: _censorText(widget.username),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildInfoCard(
                        theme: theme,
                        icon: Icons.lock_outline,
                        label: "PASSWORD",
                        value: _censorText(widget.password, isPassword: true),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: _buildInfoCard(
                        theme: theme,
                        icon: Icons.verified_user_outlined,
                        label: "ROLE",
                        value: widget.role.toUpperCase(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildInfoCard(
                        theme: theme,
                        icon: Icons.calendar_today_outlined,
                        label: "EXPIRED",
                        value: widget.expiredDate,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                _buildInfoCard(
                  theme: theme,
                  icon: Icons.vpn_key_rounded,
                  label: "SESSION KEY",
                  value: widget.sessionKey.length > 8
                      ? "${widget.sessionKey.substring(0, 8)}..."
                      : widget.sessionKey,
                  fullWidth: true,
                ),

                const SizedBox(height: 12),

                _buildUidCard(theme),

                const SizedBox(height: 40),

                _buildBiometricButton(theme),

                const SizedBox(height: 14),

                _buildChangePasswordButton(theme),

                const SizedBox(height: 32),

                _buildFooter(theme),

                const SizedBox(height: 20),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSectionTitle(String title, XThemeData theme) {
    return Row(
      children: [
        Container(
          width: 5,
          height: 18,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.redMain, theme.redDark],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(3),
            border: Border.all(color: theme.borderDark, width: 1.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: TextStyle(
            color: theme.gold,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            fontFamily: 'Orbitron',
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildFooter(XThemeData theme) {
    return Column(
      children: [
        Container(
          height: 2,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.transparent,
                theme.redMain.withOpacity(0.5),
                Colors.transparent,
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30,
              height: 2,
              decoration: BoxDecoration(
                color: theme.redMain.withOpacity(0.5),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: theme.gold,
                shape: BoxShape.circle,
                border: Border.all(color: theme.borderDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: theme.gold.withOpacity(0.6),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 30,
              height: 2,
              decoration: BoxDecoration(
                color: theme.redMain.withOpacity(0.5),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          "ERLAN SOFSPOKEN",
          style: TextStyle(
            color: theme.gold,
            fontSize: 10,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "vLatest  ·  © 2026",
          style: TextStyle(
            color: theme.bgCream.withOpacity(0.4),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            fontFamily: 'ShareTechMono',
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}