// lib/features/dashboard/music.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import '../../core/services/audio_service.dart';

// Sesuaikan path ini dengan lokasi xtheme.dart kamu
import 'xtheme.dart';

const String _font = "Rajdhani";

// ── ENDPOINT API ────────────────────────────────────────────────────────────
const String _kSearchEndpoint = "https://api.deezer.com/search";
const String _kTopChartEndpoint =
    "https://api.deezer.com/chart/0/tracks?limit=25";

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();
  final AudioService _audioService = AudioService();

  List<_Track> _searchResults = [];
  List<_Track> _topTracks = [];

  bool _isSearching = false;
  bool _hasSearched = false;
  bool _isLoadingTop = true;
  String? _topError;
  String? _searchError;

  String? _currentlyPlayingId;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _currentDuration = Duration.zero;
  _Track? _currentTrack;

  List<_Track> _currentPlaylist = [];

  Timer? _debounce;

  late AnimationController _entryAnim;
  late AnimationController _glowAnim;

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();

    _entryAnim = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();

    _glowAnim = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    _fetchTopTracks();

    _searchCtrl.addListener(() => _onSearchChanged(_searchCtrl.text));

    _audioService.player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      _playNextAuto();
    });
    _audioService.player.onDurationChanged.listen((d) {
      if (!mounted) return;
      setState(() => _currentDuration = d);
    });
    _audioService.player.onPositionChanged.listen((p) {
      if (!mounted) return;
      setState(() => _currentPosition = p);
    });
    _audioService.player.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() => _isPlaying = state == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _entryAnim.dispose();
    _glowAnim.dispose();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  // ─── API CALLS ──────────────────────────────────────────────────────────
  Future<void> _fetchTopTracks() async {
    setState(() {
      _isLoadingTop = true;
      _topError = null;
    });
    try {
      final res = await http
          .get(Uri.parse(_kTopChartEndpoint))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .where((t) => t.previewUrl.isNotEmpty)
            .toList();
        if (mounted) {
          setState(() {
            _topTracks = list;
            _isLoadingTop = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoadingTop = false;
            _topError = "Gagal memuat (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingTop = false;
          _topError = "Gagal memuat: $e";
        });
      }
    }
  }

  Future<void> _searchMusic(String query) async {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        _searchResults = [];
        _isSearching = false;
        _hasSearched = false;
        _searchError = null;
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _hasSearched = true;
      _searchError = null;
    });

    try {
      final uri = Uri.parse(
          "$_kSearchEndpoint?q=${Uri.encodeQueryComponent(q)}&limit=40");
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .toList();
        if (mounted) {
          setState(() {
            _searchResults = list;
            _isSearching = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isSearching = false;
            _searchError = "Gagal mencari (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Gagal mencari: $e";
        });
      }
    }
  }

  void _onSearchChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () => _searchMusic(q));
  }

  Future<void> _togglePlay(_Track track) async {
    if (track.previewUrl.isEmpty) {
      _showSnack("Preview audio tidak tersedia untuk lagu ini.");
      return;
    }
    try {
      if (_currentlyPlayingId == track.id && _audioService.isPlaying) {
        await _audioService.pause();
        if (mounted) setState(() => _isPlaying = false);
        return;
      }
      if (_currentlyPlayingId == track.id && !_audioService.isPlaying) {
        await _audioService.player.resume();
        if (mounted) setState(() => _isPlaying = true);
        return;
      }

      _currentPlaylist = _hasSearched && _searchResults.contains(track)
          ? List.from(_searchResults)
          : List.from(_topTracks);

      await _audioService.play(track.previewUrl, track.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = track.id;
          _currentTrack = track;
          _isPlaying = true;
        });
      }
    } catch (e) {
      _showSnack("Gagal memutar: $e");
    }
  }

  Future<void> _playNextAuto() async {
    if (_currentPlaylist.isEmpty || _currentTrack == null) {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _currentlyPlayingId = null;
          _currentTrack = null;
          _currentPosition = Duration.zero;
        });
      }
      return;
    }

    final idx = _currentPlaylist.indexWhere((t) => t.id == _currentTrack!.id);
    if (idx < 0) return;

    final nextIdx = (idx + 1) % _currentPlaylist.length;
    if (nextIdx == idx) return;

    final next = _currentPlaylist[nextIdx];

    if (next.previewUrl.isEmpty) {
      if (nextIdx == idx) return;
      _currentTrack = next;
      _playNextAuto();
      return;
    }

    try {
      await _audioService.play(next.previewUrl, next.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = next.id;
          _currentTrack = next;
          _isPlaying = true;
        });
      }
    } catch (e) {
      debugPrint('Auto-next error: $e');
    }
  }

  Future<void> _playPrevAuto() async {
    if (_currentPlaylist.isEmpty || _currentTrack == null) return;
    final idx = _currentPlaylist.indexWhere((t) => t.id == _currentTrack!.id);
    if (idx < 0) return;

    final prevIdx =
        (idx - 1 + _currentPlaylist.length) % _currentPlaylist.length;
    final prev = _currentPlaylist[prevIdx];

    if (prev.previewUrl.isEmpty) return;

    try {
      await _audioService.play(prev.previewUrl, prev.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = prev.id;
          _currentTrack = prev;
          _isPlaying = true;
        });
      }
    } catch (e) {
      debugPrint('Prev error: $e');
    }
  }

  Future<void> _stopPlayer() async {
    await _audioService.stop();
    if (mounted) {
      setState(() {
        _isPlaying = false;
        _currentlyPlayingId = null;
        _currentTrack = null;
        _currentPosition = Duration.zero;
      });
    }
  }

  void _showSnack(String msg) {
    final theme = _themeController.currentTheme;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: theme.bgCreamLight,
        content: Text(
          msg,
          style: TextStyle(
            color: theme.redDark,
            fontFamily: _font,
            fontWeight: FontWeight.w700,
          ),
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: theme.borderDark, width: 2.5),
        ),
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          body: Stack(
            children: [
              // Background gradient gelap
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      theme.brownDark,
                      theme.redDeep,
                      theme.brownDark,
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
              // Radial glow bergerak
              AnimatedBuilder(
                animation: _glowAnim,
                builder: (context, child) {
                  final angle = _glowAnim.value * 2 * math.pi;
                  final dx = 0.5 + 0.5 * math.cos(angle);
                  final dy = 0.5 + 0.5 * math.sin(angle);
                  return Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment(dx, dy),
                          radius: 1.2,
                          colors: [
                            theme.redMain.withOpacity(0.15),
                            Colors.transparent,
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.5, 1.0],
                        ),
                      ),
                    ),
                  );
                },
              ),
              // Grid titik
              Positioned.fill(
                child: CustomPaint(
                  painter: _GridPainter(color: theme.brownMid),
                ),
              ),

              SafeArea(
                child: Column(
                  children: [
                    _buildHeader(theme),
                    _buildSearchBar(theme),
                    Expanded(
                      child: FadeTransition(
                        opacity: CurvedAnimation(
                            parent: _entryAnim, curve: Curves.easeOut),
                        child: SingleChildScrollView(
                          physics: const BouncingScrollPhysics(),
                          padding: const EdgeInsets.only(bottom: 120),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (_hasSearched) ...[
                                _buildSectionHeader(
                                  theme: theme,
                                  icon: Icons.search_rounded,
                                  title: "HASIL PENCARIAN",
                                  count: _searchResults.length,
                                ),
                                const SizedBox(height: 8),
                                _buildResultsList(
                                  theme,
                                  _searchResults,
                                  isLoading: _isSearching,
                                  error: _searchError,
                                  emptyMsg:
                                      "Tidak ada hasil untuk \"${_searchCtrl.text}\"",
                                ),
                                const SizedBox(height: 24),
                              ],
                              _buildSectionHeader(
                                theme: theme,
                                icon: Icons.local_fire_department_rounded,
                                title: "MUSIK TERPOPULER",
                                count: _topTracks.length,
                                iconColor: theme.gold,
                              ),
                              const SizedBox(height: 8),
                              _buildResultsList(
                                theme,
                                _topTracks,
                                isLoading: _isLoadingTop,
                                error: _topError,
                                emptyMsg: "Belum ada data.",
                              ),
                              const SizedBox(height: 12),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              if (_currentTrack != null)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: _buildMiniPlayer(theme),
                ),
            ],
          ),
        );
      },
    );
  }

  // ─── HEADER ─────────────────────────────────────────────────────────────
  Widget _buildHeader(XThemeData theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      child: Row(
        children: [
          // Tombol kembali
          GestureDetector(
            onTap: () => Navigator.of(context).maybePop(),
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.bgCreamLight, theme.bgCream],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.arrow_back_rounded,
                  color: theme.redDark, size: 22),
            ),
          ),
          const SizedBox(width: 12),

          // Ikon musik
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.redMain, theme.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.borderDark, width: 3),
              boxShadow: [
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: theme.gold.withOpacity(0.55),
                  blurRadius: 14,
                ),
                BoxShadow(
                  color: theme.redMain.withOpacity(0.4),
                  blurRadius: 24,
                ),
              ],
            ),
            child: Icon(Icons.music_note_rounded,
                color: theme.gold, size: 22),
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "MUSIC",
                  style: TextStyle(
                    color: theme.bgCreamLight,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: _font,
                    letterSpacing: 2.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 4,
                        offset: Offset(1.5, 1.5),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "Cari & putar musik favoritmu",
                  style: TextStyle(
                    color: theme.gold,
                    fontSize: 11,
                    fontFamily: _font,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),

          // Tombol refresh
          GestureDetector(
            onTap: _fetchTopTracks,
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.bgCreamLight, theme.bgCream],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.refresh_rounded,
                  color: theme.redMain, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SEARCH BAR ─────────────────────────────────────────────────────────
  Widget _buildSearchBar(XThemeData theme) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 14),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.search_rounded, color: theme.redMain, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              focusNode: _searchFocus,
              style: TextStyle(
                color: theme.redDark,
                fontSize: 14.5,
                fontFamily: _font,
                fontWeight: FontWeight.w700,
              ),
              cursorColor: theme.redMain,
              decoration: InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText: "Cari judul lagu, artis, atau album...",
                hintStyle: TextStyle(
                  color: theme.brownMid,
                  fontSize: 13.5,
                  fontFamily: _font,
                ),
              ),
              onChanged: _onSearchChanged,
              onSubmitted: (value) {
                _debounce?.cancel();
                _searchMusic(value);
              },
              textInputAction: TextInputAction.search,
            ),
          ),
          if (_searchCtrl.text.isNotEmpty)
            GestureDetector(
              onTap: () {
                _searchCtrl.clear();
                _onSearchChanged('');
              },
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Icon(Icons.close_rounded,
                    color: theme.brownMid, size: 18),
              ),
            ),
        ],
      ),
    );
  }

  // ─── SECTION HEADER ─────────────────────────────────────────────────────
  Widget _buildSectionHeader({
    required XThemeData theme,
    required IconData icon,
    required String title,
    required int count,
    Color? iconColor,
  }) {
    final effectiveIconColor = iconColor ?? theme.redMain;
    final isGold = effectiveIconColor == theme.gold;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  isGold ? theme.gold : theme.redMain,
                  isGold ? theme.redMain : theme.redDark,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: [
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
                BoxShadow(
                  color: effectiveIconColor.withOpacity(0.5),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Icon(
              icon,
              color: isGold ? theme.redDark : theme.gold,
              size: 16,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: TextStyle(
              color: theme.bgCreamLight,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              fontFamily: _font,
              letterSpacing: 1.6,
              shadows: const [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          const Spacer(),
          if (count > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.redMain, theme.redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: theme.borderDark, width: 2),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                  BoxShadow(
                    color: theme.gold.withOpacity(0.5),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Text(
                "$count",
                style: TextStyle(
                  color: theme.gold,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: _font,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ─── LIST BUILDER ───────────────────────────────────────────────────────
  Widget _buildResultsList(
    XThemeData theme,
    List<_Track> tracks, {
    required bool isLoading,
    String? error,
    String emptyMsg = "Tidak ada data.",
  }) {
    if (isLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Column(
            children: [
              Container(
                width: 44,
                height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [theme.bgCreamLight, theme.bgCream],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: theme.borderDark, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                  ],
                ),
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation(theme.redMain),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "Memuat...",
                style: TextStyle(
                  color: theme.bgCreamLight,
                  fontSize: 12,
                  fontFamily: _font,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCreamLight, theme.bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: theme.borderDark, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(Icons.error_outline_rounded,
                  color: theme.redMain, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  error,
                  style: TextStyle(
                    color: theme.redDark,
                    fontSize: 12.5,
                    fontFamily: _font,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (tracks.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
        child: Center(
          child: Text(
            emptyMsg,
            style: TextStyle(
              color: theme.bgCream,
              fontSize: 13,
              fontFamily: _font,
            ),
          ),
        ),
      );
    }
    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      itemCount: tracks.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => _buildTrackCard(theme, tracks[i]),
    );
  }

  // ─── TRACK CARD ─────────────────────────────────────────────────────────
  Widget _buildTrackCard(XThemeData theme, _Track t) {
    final bool isActive = _currentlyPlayingId == t.id;
    final bool playing = isActive && _isPlaying;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isActive
              ? [theme.redMain, theme.redDark]
              : [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive ? theme.gold : theme.borderDark,
          width: isActive ? 3 : 3.5,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          if (isActive)
            BoxShadow(
              color: theme.gold.withOpacity(0.5),
              blurRadius: 18,
              spreadRadius: 1,
            ),
          const BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _togglePlay(t),
            splashColor:
                (isActive ? theme.gold : theme.redMain).withOpacity(0.2),
            highlightColor:
                (isActive ? theme.gold : theme.redMain).withOpacity(0.06),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  // Thumbnail
                  Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: theme.borderDark,
                            width: 3,
                          ),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(9),
                          child: t.thumbnail.isEmpty
                              ? Container(
                                  width: 64,
                                  height: 64,
                                  color: theme.brownMid,
                                  child: Icon(
                                      Icons.music_note_rounded,
                                      color: theme.bgCream,
                                      size: 28),
                                )
                              : Image.network(
                                  t.thumbnail,
                                  width: 64,
                                  height: 64,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    width: 64,
                                    height: 64,
                                    color: theme.brownMid,
                                    child: Icon(
                                        Icons.broken_image_rounded,
                                        color: theme.bgCream,
                                        size: 28),
                                  ),
                                ),
                        ),
                      ),
                      if (isActive)
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(9),
                              color: Colors.black.withOpacity(0.55),
                            ),
                            alignment: Alignment.center,
                            child: Icon(
                              playing
                                  ? Icons.equalizer_rounded
                                  : Icons.pause_rounded,
                              color: theme.gold,
                              size: 26,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 12),

                  // Info lagu
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isActive ? theme.gold : theme.redDark,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            fontFamily: _font,
                            letterSpacing: 0.4,
                            shadows: isActive
                                ? const [
                                    Shadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 3,
                                      offset: Offset(1, 1),
                                    ),
                                  ]
                                : const [
                                    Shadow(
                                      color: Color(0x22000000),
                                      blurRadius: 2,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          t.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isActive
                                ? theme.bgCream.withOpacity(0.9)
                                : theme.brownMid,
                            fontSize: 12,
                            fontFamily: _font,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Icon(Icons.access_time_rounded,
                                color: isActive
                                    ? theme.bgCream.withOpacity(0.75)
                                    : theme.brownMid.withOpacity(0.8),
                                size: 11),
                            const SizedBox(width: 3),
                            Text(
                              _fmtDuration(t.duration),
                              style: TextStyle(
                                color: isActive
                                    ? theme.bgCream.withOpacity(0.75)
                                    : theme.brownMid.withOpacity(0.9),
                                fontSize: 10.5,
                                fontFamily: _font,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            if (t.album.isNotEmpty) ...[
                              const SizedBox(width: 8),
                              Container(
                                width: 3,
                                height: 3,
                                decoration: BoxDecoration(
                                  color: isActive
                                      ? theme.bgCream.withOpacity(0.5)
                                      : theme.brownMid.withOpacity(0.5),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  t.album,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: isActive
                                        ? theme.bgCream.withOpacity(0.75)
                                        : theme.brownMid.withOpacity(0.9),
                                    fontSize: 10.5,
                                    fontFamily: _font,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Tombol play/pause
                  GestureDetector(
                    onTap: () => _togglePlay(t),
                    child: Container(
                      width: 46,
                      height: 46,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [theme.redMain, theme.redDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(
                          color: theme.borderDark,
                          width: 3,
                        ),
                        boxShadow: [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(3, 3),
                          ),
                          BoxShadow(
                            color: theme.gold.withOpacity(0.6),
                            blurRadius: 14,
                            spreadRadius: 1,
                          ),
                          BoxShadow(
                            color: theme.redMain.withOpacity(0.4),
                            blurRadius: 24,
                          ),
                        ],
                      ),
                      child: Icon(
                        playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        color: theme.gold,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── MINI PLAYER ────────────────────────────────────────────────────────
  Widget _buildMiniPlayer(XThemeData theme) {
    final t = _currentTrack!;
    final pos = _currentPosition.inMilliseconds.toDouble();
    final dur = _currentDuration.inMilliseconds <= 0
        ? 1.0
        : _currentDuration.inMilliseconds.toDouble();
    final progress = (pos / dur).clamp(0.0, 1.0);

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.bgCreamLight, theme.bgCream],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            border: Border(
              top: BorderSide(color: theme.gold, width: 3),
            ),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(0, -4),
              ),
              BoxShadow(color: theme.gold.withOpacity(0.35), blurRadius: 22),
              BoxShadow(color: Colors.black.withOpacity(0.7), blurRadius: 18),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  // Thumbnail
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: theme.borderDark,
                        width: 2.5,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: t.thumbnail.isEmpty
                          ? Container(
                              width: 44,
                              height: 44,
                              color: theme.brownMid,
                              child: Icon(Icons.music_note,
                                  color: theme.bgCream, size: 20))
                          : Image.network(t.thumbnail,
                              width: 44,
                              height: 44,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                  width: 44,
                                  height: 44,
                                  color: theme.brownMid,
                                  child: Icon(Icons.music_note,
                                      color: theme.bgCream, size: 20))),
                    ),
                  ),
                  const SizedBox(width: 10),

                  // Judul & artis
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: theme.redDark,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: _font,
                            letterSpacing: 0.4,
                            shadows: const [
                              Shadow(
                                color: Color(0x22000000),
                                blurRadius: 2,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 1),
                        Text(
                          t.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: theme.brownMid,
                            fontSize: 11,
                            fontFamily: _font,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Prev
                  IconButton(
                    icon: Icon(Icons.skip_previous_rounded,
                        color: theme.redDark, size: 28),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _playPrevAuto,
                  ),
                  const SizedBox(width: 4),

                  // Play / Pause
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [theme.redMain, theme.redDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: theme.borderDark, width: 2.5),
                      boxShadow: [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(2, 2),
                        ),
                        BoxShadow(
                          color: theme.gold.withOpacity(0.6),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: Icon(
                        _isPlaying
                            ? Icons.pause_circle_filled_rounded
                            : Icons.play_circle_filled_rounded,
                        color: theme.gold,
                        size: 34,
                      ),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () => _togglePlay(t),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // Next
                  IconButton(
                    icon: Icon(Icons.skip_next_rounded,
                        color: theme.redDark, size: 28),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _playNextAuto,
                  ),
                  const SizedBox(width: 6),

                  // Close
                  IconButton(
                    icon: Icon(Icons.close_rounded,
                        color: theme.brownMid, size: 22),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _stopPlayer,
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Progress bar
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: theme.borderDark,
                    width: 2,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x88000000),
                      blurRadius: 0,
                      offset: Offset(1.5, 1.5),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 6,
                    backgroundColor: theme.bgCream,
                    valueColor: AlwaysStoppedAnimation(theme.redMain),
                  ),
                ),
              ),
              const SizedBox(height: 5),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _fmtMs(_currentPosition),
                    style: TextStyle(
                      color: theme.brownMid,
                      fontSize: 10,
                      fontFamily: _font,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    _fmtMs(_currentDuration),
                    style: TextStyle(
                      color: theme.brownMid,
                      fontSize: 10,
                      fontFamily: _font,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HELPERS ────────────────────────────────────────────────────────────
  String _fmtDuration(int seconds) {
    if (seconds <= 0) return "--:--";
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }

  String _fmtMs(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MODEL TRACK
// ═══════════════════════════════════════════════════════════════════════════
class _Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String thumbnail;
  final String previewUrl;
  final int duration;
  final int rank;

  _Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.thumbnail,
    required this.previewUrl,
    required this.duration,
    required this.rank,
  });

  factory _Track.fromDeezer(Map<String, dynamic> json) {
    final artistMap = json['artist'];
    final albumMap = json['album'];
    String thumb = '';
    if (albumMap is Map) {
      thumb = (albumMap['cover_xl'] ??
              albumMap['cover_big'] ??
              albumMap['cover_medium'] ??
              albumMap['cover'] ??
              '')
          .toString();
    }
    return _Track(
      id: (json['id'] ?? '').toString(),
      title: (json['title_short'] ?? json['title'] ?? '').toString(),
      artist: (artistMap is Map ? (artistMap['name'] ?? '') : '').toString(),
      album: (albumMap is Map ? (albumMap['title'] ?? '') : '').toString(),
      thumbnail: thumb,
      previewUrl: (json['preview'] ?? '').toString(),
      duration: (json['duration'] is int)
          ? json['duration'] as int
          : int.tryParse((json['duration'] ?? '0').toString()) ?? 0,
      rank: (json['rank'] is int)
          ? json['rank'] as int
          : int.tryParse((json['rank'] ?? '0').toString()) ?? 0,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;

  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}