// lib/features/tools/islamic/alquran_page.dart
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS (mutable) ───────────────────────────────────
Color xBgMain = const Color(0xFF050002);
Color xBgSurface = const Color(0xFF0A0005);
Color xBgCard = const Color(0xFF1A0008);
Color xBgCardLight = const Color(0xFF0A0005);
Color xTextMain = Colors.white;
Color xTextSub = const Color(0xFFFF3366);
Color xAccent = const Color(0xFFFF0044);
Color xAccentDeep = const Color(0xFFCC0033);
Color xAccentDark = const Color(0xFF990033);
Color xBorderLight = const Color(0xFFFF0044);

void applyXTheme(XThemeData theme) {
  xBgMain       = theme.brownDark;
  xBgSurface    = theme.brownDark;
  xBgCard       = theme.brownMid;
  xBgCardLight  = Color.lerp(theme.brownMid, theme.brownDark, 0.5)!;
  xTextMain     = theme.bgCreamLight;
  xTextSub      = theme.gold;
  xAccent       = theme.redMain;
  xAccentDeep   = theme.redDark;
  xAccentDark   = theme.redDeep;
  xBorderLight  = theme.gold;
}

class AlquranPage extends StatefulWidget {
  const AlquranPage({super.key});

  @override
  State<AlquranPage> createState() => _AlquranPageState();
}

class _AlquranPageState extends State<AlquranPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _searchFocusNode = FocusNode();

  List<AyatModel> _allAyat = [];
  List<AyatModel> _filteredAyat = [];
  List<Map<String, dynamic>> _suratList = [];
  List<Map<String, dynamic>> _juzData = [];
  bool _isLoading = true;
  String _selectedFilter = 'Semua';
  String _searchQuery = '';
  int _searchResultCount = 0;
  String _errorMessage = '';
  bool _showSuratList = false;
  bool _showAsmaulHusna = false;

  Set<int> _bookmarkedAyatIds = {};
  bool _showBookmarksOnly = false;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  final XThemeController _themeController = XThemeController();

  List<String> _filterOptions = [
    'Asmaul Husna',
    'Semua',
  ];

  final List<Map<String, String>> _asmaulHusna = const [
    {'arab': 'الرَّحْمَنُ', 'latin': 'Ar-Rahman', 'arti': 'Yang Maha Pengasih'},
    {'arab': 'الرَّحِيمُ', 'latin': 'Ar-Rahim', 'arti': 'Yang Maha Penyayang'},
    {'arab': 'الْمَلِكُ', 'latin': 'Al-Malik', 'arti': 'Yang Maha Merajai'},
    {'arab': 'الْقُدُّوسُ', 'latin': 'Al-Quddus', 'arti': 'Yang Maha Suci'},
    {'arab': 'السَّلاَمُ', 'latin': 'As-Salam', 'arti': 'Yang Maha Memberi Kesejahteraan'},
    {'arab': 'الْمُؤْمِنُ', 'latin': 'Al-Mu\'min', 'arti': 'Yang Maha Memberi Keamanan'},
    {'arab': 'الْمُهَيْمِنُ', 'latin': 'Al-Muhaymin', 'arti': 'Yang Maha Memelihara'},
    {'arab': 'الْعَزِيزُ', 'latin': 'Al-Aziz', 'arti': 'Yang Maha Perkasa'},
    {'arab': 'الْجَبَّارُ', 'latin': 'Al-Jabbar', 'arti': 'Yang Maha Perkasa (Memaksa)'},
    {'arab': 'الْمُتَكَبِّرُ', 'latin': 'Al-Mutakabbir', 'arti': 'Yang Maha Megah'},
    {'arab': 'الْخَالِقُ', 'latin': 'Al-Khaliq', 'arti': 'Yang Maha Pencipta'},
    {'arab': 'الْبَارِئُ', 'latin': 'Al-Bari\'', 'arti': 'Yang Maha Mengadakan'},
    {'arab': 'الْمُصَوِّرُ', 'latin': 'Al-Musawwir', 'arti': 'Yang Maha Membentuk Rupa'},
    {'arab': 'الْغَفَّارُ', 'latin': 'Al-Ghaffar', 'arti': 'Yang Maha Pengampun'},
    {'arab': 'الْقَهَّارُ', 'latin': 'Al-Qahhar', 'arti': 'Yang Maha Menundukkan'},
    {'arab': 'الْوَهَّابُ', 'latin': 'Al-Wahhab', 'arti': 'Yang Maha Pemberi'},
    {'arab': 'الرَّزَّاقُ', 'latin': 'Ar-Razzaq', 'arti': 'Yang Maha Pemberi Rezeki'},
    {'arab': 'الْفَتَّاحُ', 'latin': 'Al-Fattah', 'arti': 'Yang Maha Pembuka'},
    {'arab': 'اَلْعَلِيمُ', 'latin': 'Al-Alim', 'arti': 'Yang Maha Mengetahui'},
    {'arab': 'الْقَابِضُ', 'latin': 'Al-Qabid', 'arti': 'Yang Maha Menyempitkan'},
    {'arab': 'الْبَاسِطُ', 'latin': 'Al-Basit', 'arti': 'Yang Maha Melapangkan'},
    {'arab': 'الْخَافِضُ', 'latin': 'Al-Khafid', 'arti': 'Yang Maha Merendahkan'},
    {'arab': 'الرَّافِعُ', 'latin': 'Ar-Rafi\'', 'arti': 'Yang Maha Meninggikan'},
    {'arab': 'الْمُعِزُّ', 'latin': 'Al-Mu\'izz', 'arti': 'Yang Maha Memuliakan'},
    {'arab': 'الْمُذِلُّ', 'latin': 'Al-Mudhill', 'arti': 'Yang Maha Menghinakan'},
    {'arab': 'السَّمِيعُ', 'latin': 'As-Sami\'', 'arti': 'Yang Maha Mendengar'},
    {'arab': 'الْبَصِيرُ', 'latin': 'Al-Basir', 'arti': 'Yang Maha Melihat'},
    {'arab': 'الْحَكَمُ', 'latin': 'Al-Hakam', 'arti': 'Yang Maha Menetapkan Hukum'},
    {'arab': 'الْعَدْلُ', 'latin': 'Al-\'Adl', 'arti': 'Yang Maha Adil'},
    {'arab': 'اللَّطِيفُ', 'latin': 'Al-Latif', 'arti': 'Yang Maha Halus'},
    {'arab': 'الْخَبِيرُ', 'latin': 'Al-Khabir', 'arti': 'Yang Maha Mengetahui Seluk-beluk'},
    {'arab': 'الْحَلِيمُ', 'latin': 'Al-Halim', 'arti': 'Yang Maha Penyantun'},
    {'arab': 'الْعَظِيمُ', 'latin': 'Al-Azim', 'arti': 'Yang Maha Agung'},
    {'arab': 'الْغَفُورُ', 'latin': 'Al-Ghafur', 'arti': 'Yang Maha Pengampun'},
    {'arab': 'الشَّكُورُ', 'latin': 'Asy-Syakur', 'arti': 'Yang Maha Pembalas Syukur'},
    {'arab': 'الْعَلِيُّ', 'latin': 'Al-Aliy', 'arti': 'Yang Maha Tinggi'},
    {'arab': 'الْكَبِيرُ', 'latin': 'Al-Kabir', 'arti': 'Yang Maha Besar'},
    {'arab': 'الْحَفِيظُ', 'latin': 'Al-Hafiz', 'arti': 'Yang Maha Memelihara'},
    {'arab': 'المُقِيتُ', 'latin': 'Al-Muqit', 'arti': 'Yang Maha Menjaga'},
    {'arab': 'الْحَسِيبُ', 'latin': 'Al-Hasib', 'arti': 'Yang Maha Membuat Perhitungan'},
    {'arab': 'الْجَلِيلُ', 'latin': 'Al-Jalil', 'arti': 'Yang Maha Luhur'},
    {'arab': 'الْكَرِيمُ', 'latin': 'Al-Karim', 'arti': 'Yang Maha Mulia'},
    {'arab': 'الرَّقِيبُ', 'latin': 'Ar-Raqib', 'arti': 'Yang Maha Mengawasi'},
    {'arab': 'الْمُجِيبُ', 'latin': 'Al-Mujib', 'arti': 'Yang Maha Mengabulkan'},
    {'arab': 'الْوَاسِعُ', 'latin': 'Al-Wasi\'', 'arti': 'Yang Maha Luas'},
    {'arab': 'الْحَكِيمُ', 'latin': 'Al-Hakim', 'arti': 'Yang Maha Bijaksana'},
    {'arab': 'الْوَدُودُ', 'latin': 'Al-Wadud', 'arti': 'Yang Maha Mencintai'},
    {'arab': 'الْمَجِيدُ', 'latin': 'Al-Majid', 'arti': 'Yang Maha Mulia'},
    {'arab': 'الْبَاعِثُ', 'latin': 'Al-Ba\'its', 'arti': 'Yang Maha Membangkitkan'},
    {'arab': 'الشَّهِيدُ', 'latin': 'Asy-Syahid', 'arti': 'Yang Maha Menyaksikan'},
    {'arab': 'الْحَقُّ', 'latin': 'Al-Haqq', 'arti': 'Yang Maha Benar'},
    {'arab': 'الْوَكِيلُ', 'latin': 'Al-Wakil', 'arti': 'Yang Maha Memelihara'},
    {'arab': 'الْقَوِيُّ', 'latin': 'Al-Qawiyy', 'arti': 'Yang Maha Kuat'},
    {'arab': 'الْمَتِينُ', 'latin': 'Al-Matin', 'arti': 'Yang Maha Kokoh'},
    {'arab': 'الْوَلِيُّ', 'latin': 'Al-Waliyy', 'arti': 'Yang Maha Melindungi'},
    {'arab': 'الْحَمِيدُ', 'latin': 'Al-Hamid', 'arti': 'Yang Maha Terpuji'},
    {'arab': 'الْمُحْصِي', 'latin': 'Al-Muhsi', 'arti': 'Yang Maha Menghitung'},
    {'arab': 'الْمُبْدِئُ', 'latin': 'Al-Mubdi\'', 'arti': 'Yang Maha Memulai'},
    {'arab': 'الْمُعِيدُ', 'latin': 'Al-Mu\'id', 'arti': 'Yang Maha Mengembalikan'},
    {'arab': 'الْمُحْيِي', 'latin': 'Al-Muhyi', 'arti': 'Yang Maha Menghidupkan'},
    {'arab': 'الْمُمِيتُ', 'latin': 'Al-Mumit', 'arti': 'Yang Maha Mematikan'},
    {'arab': 'الْحَيُّ', 'latin': 'Al-Hayy', 'arti': 'Yang Maha Hidup'},
    {'arab': 'الْقَيُّومُ', 'latin': 'Al-Qayyum', 'arti': 'Yang Maha Mandiri'},
    {'arab': 'الْوَاجِدُ', 'latin': 'Al-Wajid', 'arti': 'Yang Maha Penemu'},
    {'arab': 'الْمَاجِدُ', 'latin': 'Al-Majid', 'arti': 'Yang Maha Mulia'},
    {'arab': 'الْوَاحِدُ', 'latin': 'Al-Wahid', 'arti': 'Yang Maha Esa'},
    {'arab': 'اَلْأَحَدُ', 'latin': 'Al-Ahad', 'arti': 'Yang Maha Tunggal'},
    {'arab': 'الصَّمَدُ', 'latin': 'As-Samad', 'arti': 'Yang Maha Dibutuhkan'},
    {'arab': 'الْقَادِرُ', 'latin': 'Al-Qadir', 'arti': 'Yang Maha Kuasa'},
    {'arab': 'الْمُقْتَدِرُ', 'latin': 'Al-Muqtadir', 'arti': 'Yang Maha Berkuasa'},
    {'arab': 'الْمُقَدِّمُ', 'latin': 'Al-Muqaddim', 'arti': 'Yang Maha Mendahulukan'},
    {'arab': 'الْمُؤَخِّرُ', 'latin': 'Al-Mu\'akhkhir', 'arti': 'Yang Maha Mengakhirkan'},
    {'arab': 'الأَوَّلُ', 'latin': 'Al-Awwal', 'arti': 'Yang Maha Awal'},
    {'arab': 'الآخِرُ', 'latin': 'Al-Akhir', 'arti': 'Yang Maha Akhir'},
    {'arab': 'الظَّاهِرُ', 'latin': 'Az-Zahir', 'arti': 'Yang Maha Nyata'},
    {'arab': 'الْبَاطِنُ', 'latin': 'Al-Batin', 'arti': 'Yang Maha Tersembunyi'},
    {'arab': 'الْوَالِي', 'latin': 'Al-Wali', 'arti': 'Yang Maha Memerintah'},
    {'arab': 'الْمُتَعَالِي', 'latin': 'Al-Muta\'ali', 'arti': 'Yang Maha Tinggi'},
    {'arab': 'الْبَرُّ', 'latin': 'Al-Barr', 'arti': 'Yang Maha Penderma'},
    {'arab': 'التَّوَابُ', 'latin': 'At-Tawwab', 'arti': 'Yang Maha Menerima Taubat'},
    {'arab': 'الْمُنْتَقِمُ', 'latin': 'Al-Muntaqim', 'arti': 'Yang Maha Pembalas'},
    {'arab': 'العَفُوُ', 'latin': 'Al-\'Afuww', 'arti': 'Yang Maha Pemaaf'},
    {'arab': 'الرَّؤُوفُ', 'latin': 'Ar-Ra\'uf', 'arti': 'Yang Maha Belas Kasih'},
    {'arab': 'مَالِكُ الْمُلْكِ', 'latin': 'Malikul Mulk', 'arti': 'Yang Maha Penguasa Kerajaan'},
    {'arab': 'ذُو الْجَلَالِ وَالْإِكْرَامِ', 'latin': 'Zul Jalali wal Ikram', 'arti': 'Yang Maha Pemilik Keagungan dan Kemuliaan'},
    {'arab': 'الْمُقْسِطُ', 'latin': 'Al-Muqsit', 'arti': 'Yang Maha Adil'},
    {'arab': 'الْجَامِعُ', 'latin': 'Al-Jami\'', 'arti': 'Yang Maha Mengumpulkan'},
    {'arab': 'الْغَنِيُّ', 'latin': 'Al-Ghaniy', 'arti': 'Yang Maha Kaya'},
    {'arab': 'الْمُغْنِي', 'latin': 'Al-Mughni', 'arti': 'Yang Maha Memberi Kekayaan'},
    {'arab': 'اَلْمَانِعُ', 'latin': 'Al-Mani\'', 'arti': 'Yang Maha Mencegah'},
    {'arab': 'الضَّارُ', 'latin': 'Ad-Darr', 'arti': 'Yang Maha Memberi Mudharat'},
    {'arab': 'النَّافِعُ', 'latin': 'An-Nafi\'', 'arti': 'Yang Maha Memberi Manfaat'},
    {'arab': 'النُّورُ', 'latin': 'An-Nur', 'arti': 'Yang Maha Bercahaya'},
    {'arab': 'الْهَادِي', 'latin': 'Al-Hadi', 'arti': 'Yang Maha Pemberi Petunjuk'},
    {'arab': 'الْبَدِيعُ', 'latin': 'Al-Badi\'', 'arti': 'Yang Maha Pencipta'},
    {'arab': 'الْبَاقِي', 'latin': 'Al-Baqi', 'arti': 'Yang Maha Kekal'},
    {'arab': 'الْوَارِثُ', 'latin': 'Al-Waris', 'arti': 'Yang Maha Pewaris'},
    {'arab': 'الرَّشِيدُ', 'latin': 'Ar-Rasyid', 'arti': 'Yang Maha Pandai'},
    {'arab': 'الصَّبُورُ', 'latin': 'As-Sabur', 'arti': 'Yang Maha Sabar'},
  ];

  static final Map<int, List<dynamic>> _suratCache = {};

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadQuranData();
    _searchController.addListener(_onSearchChanged);
    _loadBookmarks();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _scrollController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  Future<void> _loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bookmarkList = prefs.getStringList('bookmarked_ayat') ?? [];
      setState(() {
        _bookmarkedAyatIds = bookmarkList.map((id) => int.parse(id)).toSet();
      });
    } catch (e) {
      debugPrint('Error loading bookmarks: $e');
    }
  }

  Future<void> _saveBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bookmarkList = _bookmarkedAyatIds.map((id) => id.toString()).toList();
      await prefs.setStringList('bookmarked_ayat', bookmarkList);
    } catch (e) {
      debugPrint('Error saving bookmarks: $e');
    }
  }

  void _toggleBookmark(int ayatId) {
    setState(() {
      if (_bookmarkedAyatIds.contains(ayatId)) {
        _bookmarkedAyatIds.remove(ayatId);
      } else {
        _bookmarkedAyatIds.add(ayatId);
      }
    });
    _saveBookmarks();
  }

  void _toggleBookmarkFilter() {
    setState(() {
      _showBookmarksOnly = !_showBookmarksOnly;
      if (_showBookmarksOnly) {
        _filteredAyat =
            _allAyat.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
        _selectedFilter = 'Bookmark';
        _searchController.clear();
        _searchQuery = '';
        _searchResultCount = _filteredAyat.length;
        _showSuratList = false;
        _showAsmaulHusna = false;
      } else {
        _filteredAyat = _allAyat;
        _selectedFilter = 'Semua';
        _searchResultCount = 0;
      }
    });
  }

  void _onSearchChanged() {
    _performSearch(_searchController.text);
  }

  void _performSearch(String query) {
    setState(() {
      _searchQuery = query;
      _searchResultCount = 0;

      if (query.isEmpty) {
        if (_showBookmarksOnly) {
          _filteredAyat =
              _allAyat.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
        } else {
          _filteredAyat = _allAyat;
        }
        return;
      }

      _filteredAyat = _smartSearch(query);
      _searchResultCount = _filteredAyat.length;
    });
  }

  List<AyatModel> _smartSearch(String query) {
    final lowerQuery = query.toLowerCase().trim();
    List<AyatModel> results = [];

    if (lowerQuery.startsWith('juz ')) {
      try {
        int juzNumber = int.parse(lowerQuery.replaceAll('juz ', '').trim());
        return _filterAyatByJuz(juzNumber);
      } catch (e) {}
    }

    if (lowerQuery.startsWith('hal') || lowerQuery.startsWith('halaman')) {
      try {
        String numStr = lowerQuery.replaceAll(RegExp(r'[a-z\s]'), '');
        if (numStr.isNotEmpty) {
          int pageNumber = int.parse(numStr);
          return _allAyat.where((a) => a.halaman == pageNumber).toList();
        }
      } catch (e) {}
    }

    if (lowerQuery.startsWith('surat ') || lowerQuery.startsWith('s ')) {
      String suratName = lowerQuery.replaceAll(RegExp(r'^surat\s+|^s\s+'), '');
      if (suratName.isNotEmpty) {
        return _allAyat
            .where((a) =>
                a.surat.toLowerCase().contains(suratName) ||
                a.suratArabic.toLowerCase().contains(suratName))
            .toList();
      }
    }

    if (lowerQuery.startsWith('ayat ') || lowerQuery.startsWith('a ')) {
      try {
        String numStr = lowerQuery.replaceAll(RegExp(r'[a-z\s]'), '');
        if (numStr.isNotEmpty) {
          int ayatNumber = int.parse(numStr);
          return _allAyat.where((a) => a.ayat == ayatNumber).toList();
        }
      } catch (e) {}
    }

    results = _allAyat.where((ayat) {
      bool matchSurat = ayat.surat.toLowerCase().contains(lowerQuery);
      bool matchArab = ayat.arab.contains(query);
      bool matchLatin = ayat.latin.toLowerCase().contains(lowerQuery);
      bool matchArti = ayat.arti.toLowerCase().contains(lowerQuery);
      bool matchJuz = ayat.juz.toString().contains(query);
      bool matchHalaman = ayat.halaman.toString().contains(query);
      bool matchAyat = ayat.ayat.toString().contains(query);
      bool matchSuratArabic = ayat.suratArabic.toLowerCase().contains(lowerQuery);

      return matchSurat ||
          matchArab ||
          matchLatin ||
          matchArti ||
          matchJuz ||
          matchHalaman ||
          matchAyat ||
          matchSuratArabic;
    }).toList();

    if (_showBookmarksOnly) {
      results = results.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
    }

    return results;
  }

  List<AyatModel> _filterAyatByJuz(int juzNumber) {
    Map<String, dynamic>? juzInfo;
    for (var juz in _juzData) {
      if (juz['nomor'] == juzNumber) {
        juzInfo = juz;
        break;
      }
    }

    if (juzInfo == null) return [];

    final startSurat = juzInfo['surat_awal']?['nomor'] ?? 0;
    final startAyat = juzInfo['surat_awal']?['ayat'] ?? 1;
    final endSurat = juzInfo['surat_akhir']?['nomor'] ?? 0;
    final endAyat = juzInfo['surat_akhir']?['ayat'] ?? 1;

    if (startSurat == 0 || endSurat == 0) return [];

    List<AyatModel> results = _allAyat.where((ayat) {
      if (ayat.suratId == startSurat && ayat.suratId == endSurat) {
        return ayat.ayat >= startAyat && ayat.ayat <= endAyat;
      } else if (ayat.suratId == startSurat) {
        return ayat.ayat >= startAyat;
      } else if (ayat.suratId == endSurat) {
        return ayat.ayat <= endAyat;
      } else if (ayat.suratId > startSurat && ayat.suratId < endSurat) {
        return true;
      }
      return false;
    }).toList();

    if (_showBookmarksOnly) {
      results = results.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
    }

    return results;
  }

  Future<void> _loadQuranData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await http.get(
        Uri.parse('https://equran.id/api/surat'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final List<dynamic> suratList = jsonDecode(response.body);
        _suratList = suratList.cast<Map<String, dynamic>>();

        await _loadJuzData();
        await _processSuratDataParallel(suratList);
      } else {
        setState(() {
          _errorMessage = 'Gagal memuat data Al-Quran. Kode: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e\nPastikan koneksi internet aktif.';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadJuzData() async {
    try {
      final response = await http.get(
        Uri.parse('https://equran.id/api/juz'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> juzList = jsonDecode(response.body);
        _juzData = juzList.cast<Map<String, dynamic>>();
        _updateFilterOptions();
      }
    } catch (e) {
      debugPrint('Error loading juz data: $e');
      _setDefaultJuzFilterOptions();
    }
  }

  void _updateFilterOptions() {
    final List<String> newFilterOptions = ['Asmaul Husna', 'Semua'];
    for (var juz in _juzData) {
      final juzNumber = juz['nomor'] ?? 0;
      if (juzNumber > 0) {
        newFilterOptions.add('Juz $juzNumber');
      }
    }
    setState(() {
      _filterOptions.clear();
      _filterOptions.addAll(newFilterOptions);
    });
  }

  void _setDefaultJuzFilterOptions() {
    final List<String> defaultOptions = ['Asmaul Husna', 'Semua'];
    for (int i = 1; i <= 30; i++) {
      defaultOptions.add('Juz $i');
    }
    setState(() {
      _filterOptions.clear();
      _filterOptions.addAll(defaultOptions);
    });
  }

  Future<void> _processSuratDataParallel(List<dynamic> suratList) async {
    List<AyatModel> allAyat = [];
    int id = 1;

    List<Future<Map<int, List<AyatModel>>>> futures = [];

    for (var surat in suratList) {
      int suratId = surat['nomor'] ?? 0;
      String suratName = surat['nama'] ?? 'Unknown';
      String suratArabic = surat['nama_latin'] ?? 'Unknown';

      if (_suratCache.containsKey(suratId)) {
        final cachedData = _suratCache[suratId]!;
        for (var ayatData in cachedData) {
          allAyat.add(_parseAyatData(
              ayatData, suratId, suratName, suratArabic, id++));
        }
        continue;
      }

      futures.add(_fetchSuratData(suratId, suratName, suratArabic, id));
      id += 1000;
    }

    if (futures.isNotEmpty) {
      final results = await Future.wait(futures);

      for (var result in results) {
        final suratId = result.keys.first;
        final ayatList = result[suratId]!;

        if (!_suratCache.containsKey(suratId)) {
          _suratCache[suratId] = ayatList
              .map((a) => {
                    'nomor': a.ayat,
                    'ar': a.arab,
                    'tr': a.latin,
                    'idn': a.arti,
                    'juz': a.juz,
                    'halaman': a.halaman,
                  })
              .toList();
        }

        allAyat.addAll(ayatList);
      }
    }

    setState(() {
      _allAyat = allAyat;
      if (_showBookmarksOnly) {
        _filteredAyat =
            allAyat.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
        _searchResultCount = _filteredAyat.length;
      } else {
        _filteredAyat = allAyat;
      }
      _isLoading = false;
    });
  }

  Future<Map<int, List<AyatModel>>> _fetchSuratData(
    int suratId,
    String suratName,
    String suratArabic,
    int startId,
  ) async {
    try {
      final detailResponse = await http.get(
        Uri.parse('https://equran.id/api/surat/${suratId}'),
      ).timeout(const Duration(seconds: 10));

      if (detailResponse.statusCode == 200) {
        final detailData = jsonDecode(detailResponse.body);
        final List<dynamic> ayatList = detailData['ayat'] ?? [];

        List<AyatModel> ayatModels = [];
        int currentId = startId;

        for (var ayatData in ayatList) {
          ayatModels.add(_parseAyatData(
            ayatData,
            suratId,
            suratName,
            suratArabic,
            currentId++,
          ));
        }

        return {suratId: ayatModels};
      }
    } catch (e) {
      debugPrint('Error fetching surat $suratId: $e');
    }

    return {suratId: []};
  }

  AyatModel _parseAyatData(
    dynamic ayatData,
    int suratId,
    String suratName,
    String suratArabic,
    int id,
  ) {
    int ayatNumber = ayatData['nomor'] ?? 0;
    String arabText = ayatData['ar'] ?? '';
    String latinText = ayatData['tr'] ?? '';
    String artiText = ayatData['idn'] ?? '';
    int juz = ayatData['juz'] ?? 1;
    int halaman = ayatData['halaman'] ?? 1;

    return AyatModel(
      id: id,
      juz: juz,
      ayat: ayatNumber,
      halaman: halaman,
      surat: suratName,
      suratArabic: suratArabic,
      suratId: suratId,
      arab: arabText,
      latin: latinText,
      arti: artiText,
    );
  }

  void _filterByOption(String filter) {
    if (filter == 'Asmaul Husna') {
      setState(() {
        _showAsmaulHusna = !_showAsmaulHusna;
        _showSuratList = false;
        _showBookmarksOnly = false;
        _selectedFilter = filter;
        _searchController.clear();
        _searchQuery = '';
        _searchResultCount = 0;
        _filteredAyat = _allAyat;
      });
    } else if (filter == 'Semua') {
      setState(() {
        _showSuratList = !_showSuratList;
        _showAsmaulHusna = false;
        _showBookmarksOnly = false;
        _selectedFilter = filter;
        _searchController.clear();
        _searchQuery = '';
        _searchResultCount = 0;
        _filteredAyat = _allAyat;
      });
    } else {
      setState(() {
        _showSuratList = false;
        _showAsmaulHusna = false;
        _showBookmarksOnly = false;
        _selectedFilter = filter;
        _searchController.clear();
        _searchQuery = '';
        _searchResultCount = 0;
        final juzNumber = int.parse(filter.split(' ')[1]);
        _filteredAyat = _filterAyatByJuz(juzNumber);
      });
    }
  }

  void _filterBySurat(int suratId) {
    setState(() {
      _showSuratList = false;
      _showAsmaulHusna = false;
      _showBookmarksOnly = false;
      _selectedFilter =
          'Surat ${_suratList.firstWhere((s) => s['nomor'] == suratId)['nama']}';
      _searchController.clear();
      _searchQuery = '';
      _searchResultCount = 0;
      _filteredAyat = _allAyat.where((a) => a.suratId == suratId).toList();
    });
  }

  void _clearSearch() {
    setState(() {
      _searchController.clear();
      _searchQuery = '';
      if (_showBookmarksOnly) {
        _filteredAyat =
            _allAyat.where((a) => _bookmarkedAyatIds.contains(a.id)).toList();
        _searchResultCount = _filteredAyat.length;
      } else {
        _filteredAyat = _allAyat;
        _searchResultCount = 0;
      }
      FocusScope.of(context).unfocus();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: xBgMain,
          body: Stack(
            children: [
              // Background glow 3D
              AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: const Alignment(0.0, -0.4),
                        radius: 0.8,
                        colors: [
                          xAccent.withOpacity(0.20 * _glowAnimation.value),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  );
                },
              ),
              // Grid pattern
              Positioned.fill(
                child: CustomPaint(
                  painter: _GridPainter(color: xAccent),
                  child: const SizedBox.expand(),
                ),
              ),
              SafeArea(
                child: Column(
                  children: [
                    _buildHeader(),
                    _buildSearchBar(),
                    _buildFilterSection(),
                    _buildSearchInfo(),
                    Expanded(
                      child: _isLoading
                          ? _buildLoadingScreen()
                          : _errorMessage.isNotEmpty
                              ? _buildErrorScreen()
                              : _showAsmaulHusna
                                  ? _buildAsmaulHusnaView()
                                  : _showSuratList
                                      ? _buildSuratListView()
                                      : _buildAyatList(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── 3D BEVEL HELPERS ─────────────────────────────────────────────
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? fill,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: fill ??
          LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              xTextMain.withOpacity(0.20),
              xAccent.withOpacity(0.15),
              Colors.black.withOpacity(0.55),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? xAccent).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? innerFill,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.4),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: innerFill ??
              LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [xBgCard, xBgMain],
              ),
        ),
        child: child,
      ),
    );
  }

  // ─── HEADER 3D ─────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      decoration: _bevelDecoration(
        radius: 20,
        glow: xAccent,
        glowOpacity: 0.35,
      ),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [xBgCard, xBgMain],
          ),
          borderRadius: BorderRadius.circular(19),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                _buildLogo(),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'AL-QUR\'AN',
                      style: GoogleFonts.orbitron(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: xTextMain,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(
                            color: xAccent.withOpacity(0.7),
                            blurRadius: 14,
                          ),
                          const Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 4,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      'CYBER EDITION · V14.0',
                      style: GoogleFonts.orbitron(
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        color: xAccent,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            AnimatedBuilder(
              animation: _glowAnimation,
              builder: (context, child) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        xAccent.withOpacity(0.25 + 0.2 * _glowAnimation.value),
                        xAccentDeep.withOpacity(0.15 + 0.1 * _glowAnimation.value),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: xAccent.withOpacity(
                          0.4 + 0.3 * _glowAnimation.value),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: xAccent.withOpacity(
                            0.3 * _glowAnimation.value),
                        blurRadius: 18,
                        spreadRadius: 2,
                      ),
                      const BoxShadow(
                        color: Color(0x66000000),
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: xAccent,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: xAccent.withOpacity(0.9),
                              blurRadius: 12,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'LIVE',
                        style: GoogleFonts.orbitron(
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          color: xAccent,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [xAccent, xAccentDark],
        ),
        border: Border.all(color: xBorderLight.withOpacity(0.6), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: xAccent.withOpacity(0.55),
            blurRadius: 22,
            spreadRadius: 2,
            offset: const Offset(0, 6),
          ),
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.15),
            blurRadius: 4,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: Center(
        child: Text(
          'ق',
          style: GoogleFonts.scheherazadeNew(
            fontSize: 24,
            color: Colors.white,
            fontWeight: FontWeight.w700,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [xBgCard, xBgMain],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: xAccent.withOpacity(0.4),
          width: 2,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: xAccent.withOpacity(0.15),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Icon(Icons.search_rounded, color: xAccent, size: 22),
          ),
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: _performSearch,
              style: GoogleFonts.inter(
                color: xTextMain,
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.3,
              ),
              cursorColor: xAccent,
              decoration: InputDecoration(
                hintText: 'Cari surat, juz, halaman, atau kata...',
                hintStyle: GoogleFonts.inter(
                  color: xAccent.withOpacity(0.45),
                  fontSize: 13,
                  fontWeight: FontWeight.w300,
                ),
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.close_rounded,
                            color: xAccent, size: 20),
                        onPressed: _clearSearch,
                        splashRadius: 20,
                      )
                    : null,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchInfo() {
    if (_searchQuery.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            xAccent.withOpacity(0.15),
            xAccentDeep.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: xAccent.withOpacity(0.25),
          width: 1.2,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0x88000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(Icons.search_rounded, color: xAccent, size: 14),
              const SizedBox(width: 8),
              Text(
                '$_searchResultCount hasil untuk',
                style: GoogleFonts.inter(
                  color: xTextSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '"$_searchQuery"',
                style: GoogleFonts.inter(
                  color: xAccent,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          if (_searchResultCount > 0)
            Text(
              '${_filteredAyat.length} ayat',
              style: GoogleFonts.inter(
                color: xTextSub.withOpacity(0.7),
                fontSize: 10,
                fontWeight: FontWeight.w400,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFilterSection() {
    return SizedBox(
      height: 46,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _filterOptions.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return _buildFilterChip(
              label: 'Bookmark',
              icon: _bookmarkedAyatIds.isNotEmpty
                  ? Icons.bookmark_rounded
                  : Icons.bookmark_border_rounded,
              isActive: _showBookmarksOnly,
              count: _bookmarkedAyatIds.isNotEmpty
                  ? _bookmarkedAyatIds.length
                  : null,
              onTap: _toggleBookmarkFilter,
            );
          }

          final filter = _filterOptions[index - 1];
          final isSelected = _selectedFilter == filter;
          return _buildFilterChip(
            label: filter,
            isActive: isSelected,
            onTap: () => _filterByOption(filter),
          );
        },
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isActive,
    required VoidCallback onTap,
    IconData? icon,
    int? count,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8, top: 4, bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: isActive
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [xAccent, xAccentDeep],
                )
              : LinearGradient(
                  colors: [xBgCard, xBgMain],
                ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? xAccent : xAccent.withOpacity(0.35),
            width: isActive ? 2 : 1.5,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: xAccent.withOpacity(0.55),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ]
              : [
                  const BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                color: isActive ? Colors.white : xTextSub,
                size: 15,
              ),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 11,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w600,
                color: isActive ? Colors.white : xTextSub,
                letterSpacing: 0.3,
                shadows: isActive
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
            if (count != null) ...[
              const SizedBox(width: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: isActive
                      ? Colors.white.withOpacity(0.25)
                      : xAccent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '$count',
                  style: GoogleFonts.inter(
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    color: isActive ? Colors.white : xAccent,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [xAccent, xAccentDark],
                  ),
                  border: Border.all(
                      color: xBorderLight.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: xAccent.withOpacity(
                          0.4 + 0.3 * _glowAnimation.value),
                      blurRadius: 40,
                      spreadRadius: 8,
                    ),
                    const BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: const Center(
                  child: SizedBox(
                    width: 32,
                    height: 32,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      strokeWidth: 2.5,
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 32),
          Text(
            'LOADING',
            style: GoogleFonts.orbitron(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: xAccent,
              letterSpacing: 6,
              shadows: [
                Shadow(
                  color: xAccent.withOpacity(0.5),
                  blurRadius: 15,
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Memuat data Al-Qur\'an...',
            style: GoogleFonts.inter(
              color: xTextSub.withOpacity(0.7),
              fontSize: 12,
              fontWeight: FontWeight.w300,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _bevelBox(
              radius: 60,
              glow: xAccent,
              glowOpacity: 0.35,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(shape: BoxShape.circle),
                child: Icon(
                  Icons.error_outline_rounded,
                  color: xAccent,
                  size: 48,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'KONEKSI GAGAL',
              style: GoogleFonts.orbitron(
                color: xAccent,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _errorMessage,
              style: GoogleFonts.inter(
                color: xTextSub.withOpacity(0.8),
                fontSize: 13,
                height: 1.6,
                fontWeight: FontWeight.w400,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 28),
            _buildGlowingButton(
              onPressed: _loadQuranData,
              label: 'COBA LAGI',
              icon: Icons.refresh_rounded,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlowingButton({
    required VoidCallback onPressed,
    required String label,
    dynamic icon,
  }) {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: xAccent.withOpacity(
                    0.3 + 0.2 * _glowAnimation.value),
                blurRadius: 25,
                spreadRadius: 4,
              ),
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.white,
              padding:
                  const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              elevation: 0,
            ),
            child: Ink(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [xAccent, xAccentDeep],
                ),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: xBorderLight, width: 1.8),
              ),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      _DynamicIcon(icon, size: 18, color: Colors.white),
                      const SizedBox(width: 10),
                    ],
                    Text(
                      label,
                      style: GoogleFonts.orbitron(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2,
                        color: Colors.white,
                        shadows: const [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAsmaulHusnaView() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: _bevelDecoration(
        radius: 22,
        glow: xAccent,
        glowOpacity: 0.35,
      ),
      padding: const EdgeInsets.all(2),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [xBgCard, xBgMain],
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            _buildModalHeader(
              title: 'ASMAUL HUSNA',
              subtitle: '99 Nama-Nama Allah',
              icon: Icons.star_rounded,
              onClose: () {
                setState(() {
                  _showAsmaulHusna = false;
                  _selectedFilter = 'Semua';
                  _filteredAyat = _allAyat;
                });
              },
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1.5,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: _asmaulHusna.length,
                itemBuilder: (context, index) {
                  final asma = _asmaulHusna[index];
                  return _bevelBox(
                    radius: 14,
                    glow: xAccent,
                    glowOpacity: 0.15,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${index + 1}',
                            style: GoogleFonts.inter(
                              fontSize: 9,
                              color: xAccent.withOpacity(0.5),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            asma['arab']!,
                            style: TextStyle(
                              fontSize: 22,
                              color: xTextMain,
                              fontFamily: 'serif',
                              height: 1.4,
                              shadows: [
                                Shadow(
                                  color: xAccent.withOpacity(0.4),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            asma['latin']!,
                            style: GoogleFonts.inter(
                              fontSize: 12,
                              color: xTextSub,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            asma['arti']!,
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              color: xTextMain.withOpacity(0.55),
                              fontWeight: FontWeight.w300,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSuratListView() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: _bevelDecoration(
        radius: 22,
        glow: xAccent,
        glowOpacity: 0.35,
      ),
      padding: const EdgeInsets.all(2),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [xBgCard, xBgMain],
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            _buildModalHeader(
              title: 'DAFTAR SURAH',
              subtitle: '${_suratList.length} Surah dalam Al-Qur\'an',
              icon: Icons.menu_book_rounded,
              onClose: () {
                setState(() {
                  _showSuratList = false;
                  _selectedFilter = 'Semua';
                  _filteredAyat = _allAyat;
                });
              },
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(10),
                itemCount: _suratList.length,
                itemBuilder: (context, index) {
                  final surat = _suratList[index];
                  final suratId = surat['nomor'] ?? 0;
                  final suratName = surat['nama'] ?? 'Unknown';
                  final suratArabic = surat['nama_latin'] ?? 'Unknown';
                  final suratJuz = surat['juz'] ?? 1;
                  final suratType = surat['tempat_turun'] ?? 'Mekah';
                  final totalAyat =
                      _allAyat.where((a) => a.suratId == suratId).length;

                  return GestureDetector(
                    onTap: () => _filterBySurat(suratId),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: _bevelBox(
                        radius: 14,
                        glow: xAccent,
                        glowOpacity: 0.15,
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Container(
                                width: 42,
                                height: 42,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      xAccent.withOpacity(0.8),
                                      xAccentDeep,
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(11),
                                  border: Border.all(
                                    color: xBorderLight,
                                    width: 2,
                                  ),
                                  boxShadow: [
                                    const BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                    BoxShadow(
                                      color: xAccent.withOpacity(0.5),
                                      blurRadius: 10,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    '$suratId',
                                    style: GoogleFonts.inter(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      shadows: const [
                                        Shadow(
                                          color: Color(0xCC000000),
                                          blurRadius: 3,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          suratName,
                                          style: GoogleFonts.inter(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: xTextMain,
                                            letterSpacing: 0.3,
                                          ),
                                        ),
                                        Text(
                                          suratArabic,
                                          style: GoogleFonts.inter(
                                            fontSize: 12,
                                            color: xTextSub,
                                            fontWeight: FontWeight.w500,
                                            fontStyle: FontStyle.italic,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Juz $suratJuz • $suratType',
                                          style: GoogleFonts.inter(
                                            fontSize: 11,
                                            color: xTextSub
                                                .withOpacity(0.7),
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: xAccent.withOpacity(0.18),
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                              color:
                                                  xAccent.withOpacity(0.35),
                                              width: 1,
                                            ),
                                          ),
                                          child: Text(
                                            '$totalAyat Ayat',
                                            style: GoogleFonts.inter(
                                              fontSize: 10,
                                              color: xAccent,
                                              fontWeight: FontWeight.w700,
                                              letterSpacing: 0.3,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Icon(
                                Icons.chevron_right_rounded,
                                color: xAccent.withOpacity(0.5),
                                size: 24,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModalHeader({
    required String title,
    required String subtitle,
    required dynamic icon,
    required VoidCallback onClose,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            xAccent.withOpacity(0.25),
            xAccentDeep.withOpacity(0.1),
          ],
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(19),
          topRight: Radius.circular(19),
        ),
        border: Border(
          bottom: BorderSide(
            color: xAccent.withOpacity(0.3),
            width: 2,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: xAccent.withOpacity(0.2),
            blurRadius: 12,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [xAccent, xAccentDeep],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: xBorderLight, width: 2),
              boxShadow: [
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
                BoxShadow(
                  color: xAccent.withOpacity(0.55),
                  blurRadius: 12,
                ),
              ],
            ),
            child: _DynamicIcon(
              icon,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.orbitron(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: xTextMain,
                    letterSpacing: 2,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    color: xTextSub.withOpacity(0.8),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [xAccent, xAccentDeep],
              ),
              border: Border.all(color: xBorderLight, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: IconButton(
              icon: const Icon(Icons.close_rounded,
                  color: Colors.white, size: 20),
              onPressed: onClose,
              splashRadius: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAyatList() {
    if (_filteredAyat.isEmpty && _searchQuery.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off_rounded,
              color: xAccent.withOpacity(0.5),
              size: 56,
            ),
            const SizedBox(height: 20),
            Text(
              'TIDAK DITEMUKAN',
              style: GoogleFonts.orbitron(
                color: xAccent,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Coba dengan kata kunci lain',
              style: GoogleFonts.inter(
                color: xTextSub.withOpacity(0.7),
                fontSize: 13,
                fontWeight: FontWeight.w300,
              ),
            ),
            const SizedBox(height: 28),
            _buildGlowingButton(
              onPressed: _clearSearch,
              label: 'RESET',
              icon: Icons.refresh_rounded,
            ),
          ],
        ),
      );
    }

    if (_filteredAyat.isEmpty) {
      if (_showBookmarksOnly) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.bookmark_border_rounded,
                color: xAccent.withOpacity(0.5),
                size: 56,
              ),
              const SizedBox(height: 20),
              Text(
                'BELUM ADA BOOKMARK',
                style: GoogleFonts.orbitron(
                  color: xAccent,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Tambahkan bookmark pada ayat yang ingin disimpan',
                style: GoogleFonts.inter(
                  color: xTextSub.withOpacity(0.7),
                  fontSize: 13,
                  fontWeight: FontWeight.w300,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              _buildGlowingButton(
                onPressed: _toggleBookmarkFilter,
                label: 'TAMPILKAN SEMUA',
                icon: Icons.view_list_rounded,
              ),
            ],
          ),
        );
      }

      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.menu_book_rounded,
              color: xAccent.withOpacity(0.5),
              size: 56,
            ),
            const SizedBox(height: 20),
            Text(
              'BELUM ADA DATA',
              style: GoogleFonts.orbitron(
                color: xAccent,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Silakan muat ulang atau periksa koneksi',
              style: GoogleFonts.inter(
                color: xTextSub.withOpacity(0.7),
                fontSize: 13,
                fontWeight: FontWeight.w300,
              ),
            ),
            const SizedBox(height: 28),
            _buildGlowingButton(
              onPressed: _loadQuranData,
              label: 'MUAT ULANG',
              icon: Icons.refresh_rounded,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: _filteredAyat.length,
      itemBuilder: (context, index) {
        final ayat = _filteredAyat[index];
        return _buildAyatCard(ayat);
      },
    );
  }

  Widget _buildAyatCard(AyatModel ayat) {
    final isBookmarked = _bookmarkedAyatIds.contains(ayat.id);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.only(bottom: 16),
      decoration: _bevelDecoration(
        radius: 20,
        glow: isBookmarked ? xAccent : xAccentDeep,
        glowOpacity: isBookmarked ? 0.55 : 0.2,
      ),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isBookmarked
                ? [
                    Color.lerp(xBgCard, xAccent, 0.15)!,
                    xBgMain,
                  ]
                : [xBgCard, xBgMain],
          ),
          borderRadius: BorderRadius.circular(19),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    _buildChip('${ayat.suratId}. ${ayat.surat}', xAccent),
                    const SizedBox(width: 8),
                    _buildChip(ayat.suratArabic, xTextSub),
                  ],
                ),
                Row(
                  children: [
                    _buildChip('H ${ayat.halaman}', xTextSub),
                    const SizedBox(width: 6),
                    _buildChip('${ayat.ayat}', xTextSub),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => _toggleBookmark(ayat.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          gradient: isBookmarked
                              ? LinearGradient(
                                  colors: [xAccent, xAccentDeep],
                                )
                              : null,
                          color: isBookmarked ? null : Colors.transparent,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isBookmarked
                                ? xBorderLight
                                : xAccent.withOpacity(0.25),
                            width: isBookmarked ? 2 : 1,
                          ),
                          boxShadow: isBookmarked
                              ? [
                                  BoxShadow(
                                    color: xAccent.withOpacity(0.6),
                                    blurRadius: 12,
                                  ),
                                  const BoxShadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 0,
                                    offset: Offset(2, 2),
                                  ),
                                ]
                              : null,
                        ),
                        child: Icon(
                          isBookmarked
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          color: isBookmarked
                              ? Colors.white
                              : xTextSub.withOpacity(0.6),
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 18),
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  ayat.arab,
                  style: TextStyle(
                    fontSize: 30,
                    color: xTextMain,
                    fontFamily: 'serif',
                    height: 1.9,
                    shadows: [
                      Shadow(
                        color: xAccent.withOpacity(0.5),
                        blurRadius: 14,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text(
                ayat.latin,
                style: GoogleFonts.inter(
                  fontSize: 13,
                  color: xTextSub.withOpacity(0.85),
                  fontStyle: FontStyle.italic,
                  letterSpacing: 0.5,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 18),
            Container(
              height: 1.5,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    xAccent.withOpacity(0.3),
                    xAccent.withOpacity(0.6),
                    xAccent.withOpacity(0.3),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    xAccent.withOpacity(0.10),
                    xAccentDeep.withOpacity(0.04),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: xAccent.withOpacity(0.20),
                  width: 1.2,
                ),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.translate_rounded,
                    color: xAccent.withOpacity(0.7),
                    size: 18,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ARTI',
                          style: GoogleFonts.orbitron(
                            fontSize: 8,
                            color: xAccent.withOpacity(0.55),
                            fontWeight: FontWeight.w700,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          ayat.arti,
                          style: GoogleFonts.inter(
                            fontSize: 13,
                            color: xTextMain.withOpacity(0.85),
                            height: 1.6,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildChip(
                    'Juz ${ayat.juz}', xTextSub.withOpacity(0.75)),
                Row(
                  children: [
                    _buildChip(
                        'Surat ${ayat.suratId}', xTextSub.withOpacity(0.75)),
                    if (isBookmarked) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              xAccent.withOpacity(0.25),
                              xAccentDeep.withOpacity(0.15),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: xAccent.withOpacity(0.45),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: xAccent.withOpacity(0.35),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.bookmark_rounded,
                              color: xAccent,
                              size: 11,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Tersimpan',
                              style: GoogleFonts.inter(
                                fontSize: 9,
                                color: xAccent,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.15),
            blurRadius: 4,
          ),
        ],
      ),
      child: Text(
        label,
        style: GoogleFonts.inter(
          fontSize: 10,
          color: color,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}

class AyatModel {
  final int id;
  final int juz;
  final int ayat;
  final int halaman;
  final String surat;
  final String suratArabic;
  final int suratId;
  final String arab;
  final String latin;
  final String arti;

  const AyatModel({
    required this.id,
    required this.juz,
    required this.ayat,
    required this.halaman,
    required this.surat,
    required this.suratArabic,
    required this.suratId,
    required this.arab,
    required this.latin,
    required this.arti,
  });
}

class _GridPainter extends CustomPainter {
  final Color color;

  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.03)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;

  const _DynamicIcon(this.icon, {Key? key, this.size, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);
    bool isFontAwesome = false;
    try {
      if (icon.runtimeType.toString().contains('FaIcon') ||
          icon.toString().contains('FaIcon') ||
          icon.toString().contains('font_awesome_flutter') ||
          icon.fontPackage == 'font_awesome_flutter') {
        isFontAwesome = true;
      }
    } catch (_) {}
    return Center(
      widthFactor: 1.0,
      heightFactor: 1.0,
      child: isFontAwesome
          ? FaIcon(icon, size: size, color: color)
          : Icon(icon, size: size, color: color),
    );
  }
}