// lib/features/tools/islamic/jadwal_sholat_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// 🔔 NOTIFICATION SERVICE
// ═══════════════════════════════════════════════════════════════════
class NotificationServicee {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);

    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> showSholatNotification({
    required int id,
    required String title,
    required String body,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'sholat_channel',
      'Jadwal Sholat',
      channelDescription: 'Notifikasi waktu sholat',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _plugin.show(id, title, body, details);
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🌐 GLOBAL XTHEME COLORS (mutable)
// ═══════════════════════════════════════════════════════════════════
Color shBgDeep = const Color(0xFF0A0E1A);
Color shBgPanel = const Color(0xFF131829);
Color shBgCard = const Color(0xFF1A2036);
Color shTextMain = const Color(0xFFF5F5F7);
Color shTextSub = const Color(0xFF8A93B0);
Color shGoldAccent = const Color(0xFFD4A853);
Color shGreenAccent = const Color(0xFF4CAF50);
Color shRedMain = const Color(0xFFB71C1C);
Color shRedDark = const Color(0xFF7F0000);
Color shRedDeep = const Color(0xFF4A0000);
Color shBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  shBgDeep      = theme.brownDark;
  shBgPanel     = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  shBgCard      = theme.brownMid;
  shTextMain    = theme.bgCreamLight;
  shTextSub     = theme.gold;
  shGoldAccent  = theme.gold;
  shGreenAccent = theme.accentGreen;
  shRedMain     = theme.redMain;
  shRedDark     = theme.redDark;
  shRedDeep     = theme.redDeep;
  shBorderDark  = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// 🕌 JADWAL SHOLAT PAGE
// ═══════════════════════════════════════════════════════════════════
class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  Map<String, String> jadwal = {};
  String nextSholat = "";
  Duration countdown = Duration.zero;
  bool loading = true;
  String idKota = "1301";
  String namaKota = "Surabaya";

  Timer? _countdownTimer;
  Timer? _notifTimer;
  final Set<String> _notifiedToday = {};

  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await NotificationServicee.init();
    await _loadSavedKota();
    await loadJadwal();
    _startCountdown();
    _scheduleNotifications();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _notifTimer?.cancel();
    super.dispose();
  }

  // ─── PERSISTENCE ─────────────────────────────────────────────────
  Future<void> _loadSavedKota() async {
    final prefs = await SharedPreferences.getInstance();
    idKota = prefs.getString('sholat_idKota') ?? '1301';
    namaKota = prefs.getString('sholat_namaKota') ?? 'Surabaya';
  }

  Future<void> _saveKota() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sholat_idKota', idKota);
    await prefs.setString('sholat_namaKota', namaKota);
  }

  // ─── API ─────────────────────────────────────────────────────────
  Future<void> loadJadwal() async {
    setState(() => loading = true);
    final now = DateTime.now();

    try {
      final url = Uri.parse(
        "https://api.myquran.com/v2/sholat/jadwal/$idKota/${now.year}/${now.month}/${now.day}",
      );
      final response = await http.get(url);
      final data = jsonDecode(response.body);
      final j = data["data"]["jadwal"];

      setState(() {
        jadwal = {
          "Subuh": j["subuh"],
          "Dzuhur": j["dzuhur"],
          "Ashar": j["ashar"],
          "Maghrib": j["maghrib"],
          "Isya": j["isya"],
        };
        nextSholat = getNextPrayer(jadwal);
        loading = false;
        _notifiedToday.clear();
      });
      await _saveKota();
    } catch (e) {
      debugPrint("Error: $e");
      setState(() => loading = false);
    }
  }

  // ─── NEXT PRAYER ─────────────────────────────────────────────────
  String getNextPrayer(Map<String, String> jadwal) {
    final now = TimeOfDay.now();
    for (var entry in jadwal.entries) {
      final parts = entry.value.split(":");
      final prayerTime = TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
      if (prayerTime.hour > now.hour ||
          (prayerTime.hour == now.hour && prayerTime.minute > now.minute)) {
        return entry.key;
      }
    }
    return "Subuh";
  }

  // ─── COUNTDOWN ───────────────────────────────────────────────────
  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;

      final now = DateTime.now();
      if (now.hour == 0 && now.minute == 0 && now.second == 0) {
        loadJadwal();
        _notifiedToday.clear();
      }

      setState(() {
        countdown = _hitungCountdown();
      });
    });
  }

  Duration _hitungCountdown() {
    if (jadwal.isEmpty || nextSholat.isEmpty) return Duration.zero;

    final now = DateTime.now();
    final timeStr = jadwal[nextSholat] ?? '';
    if (timeStr.isEmpty) return Duration.zero;

    final parts = timeStr.split(":");
    final target = DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(parts[0]),
      int.parse(parts[1]),
    );

    if (target.isBefore(now)) {
      return target.add(const Duration(days: 1)).difference(now);
    }

    return target.difference(now);
  }

  // ─── NOTIFIKASI ──────────────────────────────────────────────────
  void _scheduleNotifications() {
    _notifTimer?.cancel();
    _notifTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      final now = TimeOfDay.now();

      for (final entry in jadwal.entries) {
        final parts = entry.value.split(":");
        final sholatTime = TimeOfDay(
          hour: int.parse(parts[0]),
          minute: int.parse(parts[1]),
        );

        final isTime =
            sholatTime.hour == now.hour && sholatTime.minute == now.minute;
        final key = "${entry.key}_${entry.value}";

        if (isTime && !_notifiedToday.contains(key)) {
          _notifiedToday.add(key);
          NotificationServicee.showSholatNotification(
            id: entry.key.hashCode,
            title: "🕌 Waktu ${entry.key}",
            body: "Sudah masuk waktu ${entry.key} untuk $namaKota",
          );
        }
      }
    });
  }

  // ─── MODAL CARI LOKASI ───────────────────────────────────────────
  void _showSearchLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        String query = "";
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [shBgPanel, shBgDeep],
                ),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(25)),
                border: Border(
                  top: BorderSide(color: shGoldAccent, width: 3),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 30,
                    offset: const Offset(0, -10),
                  ),
                  BoxShadow(
                    color: shGoldAccent.withOpacity(0.35),
                    blurRadius: 22,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: shGoldAccent.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: shGoldAccent.withOpacity(0.5),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [shBgCard, shBgDeep],
                      ),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: shGoldAccent.withOpacity(0.4),
                        width: 2,
                      ),
                      boxShadow: [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: TextField(
                      style: TextStyle(color: shTextMain),
                      cursorColor: shGoldAccent,
                      decoration: InputDecoration(
                        hintText: "Cari Kota/Kabupaten...",
                        hintStyle: TextStyle(color: shTextSub),
                        prefixIcon: Icon(Icons.search, color: shGoldAccent),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 16),
                      ),
                      onChanged: (val) => setModalState(() => query = val),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: FutureBuilder<List<dynamic>>(
                      future: _searchKota(query),
                      builder: (context, snapshot) {
                        if (query.length < 3) {
                          return Center(
                            child: Text(
                              "Ketik minimal 3 huruf",
                              style: TextStyle(color: shTextSub),
                            ),
                          );
                        }
                        if (!snapshot.hasData) {
                          return Center(
                            child: CircularProgressIndicator(
                                color: shGoldAccent),
                          );
                        }
                        if (snapshot.data!.isEmpty) {
                          return Center(
                            child: Text(
                              "Kota tidak ditemukan",
                              style: TextStyle(color: shTextSub),
                            ),
                          );
                        }
                        return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            final item = snapshot.data![index];
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  idKota = item['id'];
                                  namaKota = item['lokasi'];
                                });
                                loadJadwal();
                                Navigator.pop(context);
                              },
                              child: Container(
                                margin:
                                    const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [shBgCard, shBgDeep],
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: shGoldAccent.withOpacity(0.3),
                                    width: 1.5,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xAA000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.location_on,
                                        color: shGoldAccent, size: 20),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        item['lokasi'],
                                        style: TextStyle(
                                          color: shTextMain,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<List<dynamic>> _searchKota(String q) async {
    if (q.length < 3) return [];
    try {
      final res = await http.get(
        Uri.parse("https://api.myquran.com/v2/sholat/kota/cari/$q"),
      );
      return jsonDecode(res.body)['data'] ?? [];
    } catch (e) {
      return [];
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        if (loading) {
          return Container(
            color: shBgDeep,
            child: Center(
              child: CircularProgressIndicator(color: shGoldAccent),
            ),
          );
        }

        return Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.7),
              radius: 1.5,
              colors: [
                Color.lerp(shBgDeep, shRedMain, 0.25)!,
                shBgDeep,
                Colors.black,
              ],
              stops: const [0.0, 0.6, 1.0],
            ),
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 16),
                _buildCountdownCard(),
                const SizedBox(height: 16),
                _buildJadwalGrid(),
                const SizedBox(height: 16),
                _buildInfoCard(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎯 HEADER CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            shTextMain.withOpacity(0.20),
            shRedMain.withOpacity(0.15),
            Colors.black.withOpacity(0.55),
          ],
          stops: const [0.0, 0.5, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            blurRadius: 26,
            spreadRadius: -6,
            offset: const Offset(0, 14),
          ),
          BoxShadow(
            color: shGoldAccent.withOpacity(0.35),
            blurRadius: 30,
            spreadRadius: -8,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [shBgPanel, shBgCard, shBgDeep],
          ),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [shGoldAccent, Color.lerp(shGoldAccent, Colors.black, 0.4)!],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: shBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: shGoldAccent.withOpacity(0.55),
                    blurRadius: 16,
                  ),
                ],
              ),
              child: Icon(Icons.mosque, color: shBgDeep, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Jadwal Sholat",
                    style: TextStyle(
                      color: shTextMain,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                      shadows: const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: shGoldAccent, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        namaKota,
                        style: TextStyle(
                          color: shTextSub,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _showSearchLocation,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      shGoldAccent,
                      Color.lerp(shGoldAccent, Colors.black, 0.4)!,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: shBorderDark, width: 2),
                  boxShadow: [
                    const BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: shGoldAccent.withOpacity(0.55),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Icon(Icons.edit_location_alt,
                        color: shBgDeep, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      "GANTI",
                      style: TextStyle(
                        color: shBgDeep,
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ⏱️ COUNTDOWN CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCountdownCard() {
    final h = countdown.inHours;
    final m = countdown.inMinutes % 60;
    final s = countdown.inSeconds % 60;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            shTextMain.withOpacity(0.20),
            shGreenAccent.withOpacity(0.15),
            Colors.black.withOpacity(0.55),
          ],
          stops: const [0.0, 0.5, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            blurRadius: 26,
            spreadRadius: -6,
            offset: const Offset(0, 14),
          ),
          BoxShadow(
            color: shGreenAccent.withOpacity(0.35),
            blurRadius: 30,
            spreadRadius: -8,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [shBgPanel, shBgCard, shBgDeep],
          ),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: shGreenAccent,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: shGreenAccent,
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  "MENUJU ${nextSholat.toUpperCase()}",
                  style: TextStyle(
                    color: shTextSub,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildTimeBox(h.toString().padLeft(2, '0'), "JAM"),
                const SizedBox(width: 8),
                _buildTimeBox(m.toString().padLeft(2, '0'), "MENIT"),
                const SizedBox(width: 8),
                _buildTimeBox(s.toString().padLeft(2, '0'), "DETIK"),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              "Pukul ${jadwal[nextSholat] ?? '--:--'} WIB",
              style: TextStyle(
                color: shGoldAccent,
                fontSize: 14,
                fontWeight: FontWeight.w700,
                shadows: [
                  Shadow(
                    color: shGoldAccent.withOpacity(0.6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeBox(String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [shBgCard, shBgDeep],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: shGoldAccent, width: 2.5),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: shGoldAccent.withOpacity(0.35),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              color: shTextMain,
              fontSize: 32,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
              shadows: [
                Shadow(
                  color: shGoldAccent.withOpacity(0.7),
                  blurRadius: 14,
                ),
                const Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 4,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: shTextSub,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📅 JADWAL GRID 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildJadwalGrid() {
    final icons = {
      "Subuh": Icons.wb_twilight,
      "Dzuhur": Icons.wb_sunny,
      "Ashar": Icons.wb_sunny_outlined,
      "Maghrib": Icons.wb_twilight,
      "Isya": Icons.nights_stay,
    };

    return Column(
      children: jadwal.entries.map((entry) {
        final isNext = entry.key == nextSholat;
        final icon = icons[entry.key]!;

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isNext
                  ? [
                      shGoldAccent,
                      Color.lerp(shGoldAccent, Colors.black, 0.5)!,
                    ]
                  : [
                      shRedMain,
                      shRedDark,
                      shRedDeep,
                    ],
              stops: const [0.0, 0.55, 1.0],
            ),
            boxShadow: [
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              BoxShadow(
                color: (isNext ? shGoldAccent : shRedMain)
                    .withOpacity(isNext ? 0.55 : 0.35),
                blurRadius: 20,
                spreadRadius: -4,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          padding: const EdgeInsets.all(1.6),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isNext
                    ? [
                        Color.lerp(shGoldAccent, Colors.white, 0.15)!,
                        shGoldAccent,
                      ]
                    : [shBgCard, shBgDeep],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isNext
                          ? [shBgDeep, Color.lerp(shBgDeep, Colors.black, 0.4)!]
                          : [
                              shRedMain.withOpacity(0.5),
                              shRedDark.withOpacity(0.4),
                            ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isNext
                          ? shBgDeep
                          : shGoldAccent.withOpacity(0.5),
                      width: 2,
                    ),
                    boxShadow: [
                      const BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                      BoxShadow(
                        color: (isNext ? shBgDeep : shGoldAccent)
                            .withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: isNext ? shGoldAccent : shGoldAccent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            entry.key.toUpperCase(),
                            style: TextStyle(
                              color: isNext ? shBgDeep : shTextMain,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              shadows: isNext
                                  ? null
                                  : const [
                                      Shadow(
                                        color: Color(0xCC000000),
                                        blurRadius: 3,
                                        offset: Offset(1, 1),
                                      ),
                                    ],
                            ),
                          ),
                          if (isNext) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: shBgDeep,
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                  color: shGoldAccent,
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: shGoldAccent.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: Text(
                                "NEXT",
                                style: TextStyle(
                                  color: shGoldAccent,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isNext ? "Segera masuk waktu sholat" : "—",
                        style: TextStyle(
                          color: isNext
                              ? shBgDeep.withOpacity(0.75)
                              : shTextMain.withOpacity(0.55),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  entry.value,
                  style: TextStyle(
                    color: isNext ? shBgDeep : shTextMain,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                    shadows: isNext
                        ? null
                        : [
                            Shadow(
                              color: shGoldAccent.withOpacity(0.6),
                              blurRadius: 10,
                            ),
                            const Shadow(
                              color: Color(0xCC000000),
                              blurRadius: 4,
                              offset: Offset(1, 1),
                            ),
                          ],
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ℹ️ INFO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            shTextMain.withOpacity(0.20),
            shRedMain.withOpacity(0.15),
            Colors.black.withOpacity(0.55),
          ],
          stops: const [0.0, 0.5, 1.0],
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(1.4),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [shBgPanel, shBgDeep],
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: shGoldAccent, size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "Jadwal akan otomatis diperbarui setiap hari.\nNotifikasi aktif saat masuk waktu sholat.",
                style: TextStyle(
                  color: shTextSub,
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}