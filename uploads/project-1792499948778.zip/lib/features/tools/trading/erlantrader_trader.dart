// =============================================================================
// ATLAS TRADER — MT5-style paper trading (Flutter, 1 file)
// =============================================================================
// pubspec.yaml:
//   dependencies:
//     flutter: { sdk: flutter }
//     http: ^1.2.0
//     web_socket_channel: ^2.4.0
//     shared_preferences: ^2.2.2
// =============================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

// =============================================================================
// MODELS
// =============================================================================
class TradePosition {
  final String id;
  final String symbol;
  final String display;
  final bool isBuy;
  final double entryPrice;
  final double quantity;
  final DateTime openTime;
  double? closePrice;
  DateTime? closeTime;
  double? realizedPnl;

  TradePosition({
    required this.id,
    required this.symbol,
    required this.display,
    required this.isBuy,
    required this.entryPrice,
    required this.quantity,
    required this.openTime,
    this.closePrice,
    this.closeTime,
    this.realizedPnl,
  });

  bool get isOpen => closeTime == null;

  double floatingPnl(double currentPrice) {
    final diff = isBuy ? (currentPrice - entryPrice) : (entryPrice - currentPrice);
    return diff * quantity;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'symbol': symbol,
        'display': display,
        'isBuy': isBuy,
        'entryPrice': entryPrice,
        'quantity': quantity,
        'openTime': openTime.toIso8601String(),
        'closePrice': closePrice,
        'closeTime': closeTime?.toIso8601String(),
        'realizedPnl': realizedPnl,
      };

  factory TradePosition.fromJson(Map<String, dynamic> j) => TradePosition(
        id: j['id'],
        symbol: j['symbol'],
        display: j['display'] ?? j['symbol'],
        isBuy: j['isBuy'],
        entryPrice: (j['entryPrice'] as num).toDouble(),
        quantity: (j['quantity'] as num).toDouble(),
        openTime: DateTime.parse(j['openTime']),
        closePrice: j['closePrice'] != null ? (j['closePrice'] as num).toDouble() : null,
        closeTime: j['closeTime'] != null ? DateTime.parse(j['closeTime']) : null,
        realizedPnl: j['realizedPnl'] != null ? (j['realizedPnl'] as num).toDouble() : null,
      );
}

class MarketInfo {
  final String symbol;
  final String display;
  final String name;
  const MarketInfo(this.symbol, this.display, this.name);
}

class TimeframeInfo {
  final String label;
  final String interval;
  const TimeframeInfo(this.label, this.interval);
}

class Candle {
  final DateTime time;
  double open, high, low, close, volume;
  Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });
  bool get isBull => close >= open;
}

// =============================================================================
// CONSTANTS
// =============================================================================
const List<MarketInfo> kMarkets = [
  MarketInfo('BTCUSDT', 'BTC/USDT', 'Bitcoin vs Tether'),
  MarketInfo('ETHUSDT', 'ETH/USDT', 'Ethereum vs Tether'),
  MarketInfo('BNBUSDT', 'BNB/USDT', 'Binance Coin vs Tether'),
  MarketInfo('SOLUSDT', 'SOL/USDT', 'Solana vs Tether'),
  MarketInfo('XRPUSDT', 'XRP/USDT', 'Ripple vs Tether'),
  MarketInfo('DOGEUSDT', 'DOGE/USDT', 'Dogecoin vs Tether'),
  MarketInfo('ADAUSDT', 'ADA/USDT', 'Cardano vs Tether'),
  MarketInfo('LTCUSDT', 'LTC/USDT', 'Litecoin vs Tether'),
  MarketInfo('AVAXUSDT', 'AVAX/USDT', 'Avalanche vs Tether'),
  MarketInfo('LINKUSDT', 'LINK/USDT', 'Chainlink vs Tether'),
];

const List<TimeframeInfo> kTimeframes = [
  TimeframeInfo('M1', '1m'),
  TimeframeInfo('M5', '5m'),
  TimeframeInfo('M15', '15m'),
  TimeframeInfo('M30', '30m'),
  TimeframeInfo('H1', '1h'),
  TimeframeInfo('H4', '4h'),
  TimeframeInfo('D1', '1d'),
];

const double kInitialBalance = 10000000.0;
const Duration kResetPeriod = Duration(days: 7);

// =============================================================================
// FORMATTERS
// =============================================================================
String fmtPrice(double p) {
  if (p == 0) return '--';
  if (p >= 1000) return p.toStringAsFixed(2);
  if (p >= 1) return p.toStringAsFixed(4);
  return p.toStringAsFixed(6);
}

String fmtMoney(double v) {
  final neg = v < 0;
  v = v.abs();
  final s = v.toStringAsFixed(2);
  final parts = s.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    final posFromEnd = intPart.length - i;
    buf.write(intPart[i]);
    if (posFromEnd > 1 && posFromEnd % 3 == 1) buf.write('.');
  }
  return '${neg ? '-' : ''}${buf.toString()},${parts[1]}';
}

String fmtSigned(double v) => '${v >= 0 ? '+' : ''}${fmtMoney(v)}';

String fmtDuration(Duration d) {
  if (d.inHours >= 1) return '${d.inHours}j ${d.inMinutes % 60}m';
  if (d.inMinutes >= 1) return '${d.inMinutes}m ${d.inSeconds % 60}s';
  return '${d.inSeconds}s';
}

// =============================================================================
// ENTRY
// =============================================================================
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const AtlasTraderApp());
}

// =============================================================================
// COLORS
// =============================================================================
class C {
  static const bg = Color(0xFF0A0D10);
  static const panel = Color(0xFF13171C);
  static const panelLight = Color(0xFF1B2026);
  static const panelElev = Color(0xFF232932);
  static const border = Color(0xFF2A3038);
  static const green = Color(0xFF26A69A);
  static const greenGlow = Color(0xFF2DD4BF);
  static const red = Color(0xFFEF5350);
  static const redGlow = Color(0xFFFF6B6B);
  static const gold = Color(0xFFF0B90B);
  static const goldDark = Color(0xFFB28A00);
  static const textDim = Color(0xFF848E9C);
  static const textMed = Color(0xFFB7BFC9);
  static const white = Color(0xFFEAECEF);
}

// =============================================================================
// APP ROOT
// =============================================================================
class AtlasTraderApp extends StatelessWidget {
  const AtlasTraderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Atlas Trader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: C.bg,
        useMaterial3: true,
        colorScheme: const ColorScheme.dark(
          primary: C.gold,
          surface: C.panel,
          onSurface: C.white,
        ),
        splashFactory: InkSparkle.splashFactory,
      ),
      home: const TraderHomePage(),
    );
  }
}

// =============================================================================
// HOME PAGE
// =============================================================================
class TraderHomePage extends StatefulWidget {
  const TraderHomePage({super.key});
  @override
  State<TraderHomePage> createState() => _TraderHomePageState();
}

class _TraderHomePageState extends State<TraderHomePage> {
  MarketInfo market = kMarkets[0];
  TimeframeInfo timeframe = kTimeframes[1];

  List<Candle> candles = [];
  double currentPrice = 0;
  double prevClose = 0;
  bool loading = true;
  bool chartWsOk = false;

  // chart WS
  WebSocketChannel? _chartWs;
  StreamSubscription? _chartSub;

  // positions WS (miniTicker) untuk harga semua symbol yang ada posisi
  WebSocketChannel? _posWs;
  StreamSubscription? _posSub;

  // real-time price per symbol (untuk PnL posisi lintas market)
  final Map<String, double> livePrices = {};

  double balance = kInitialBalance;
  DateTime lastReset = DateTime.now();

  List<TradePosition> openPositions = [];
  List<TradePosition> closedPositions = [];

  double quantity = 0.01;
  int bottomTab = 1;

  final ScrollController _scrollCtrl = ScrollController();
  Timer? _tickTimer;
  Timer? _reconnectChartTimer;
  Timer? _reconnectPosTimer;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _loadState();
    await _loadMarket();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _chartSub?.cancel();
    _chartWs?.sink.close();
    _posSub?.cancel();
    _posWs?.sink.close();
    _tickTimer?.cancel();
    _reconnectChartTimer?.cancel();
    _reconnectPosTimer?.cancel();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // -----------------------------------------------------------------
  // PERSISTENCE
  // -----------------------------------------------------------------
  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final savedBalance = prefs.getDouble('balance');
    final savedResetMs = prefs.getInt('lastReset');
    final savedOpen = prefs.getString('openPositions');
    final savedClosed = prefs.getString('closedPositions');

    final now = DateTime.now();
    bool reset = false;

    if (savedResetMs == null) {
      balance = kInitialBalance;
      lastReset = now;
      reset = true;
    } else {
      lastReset = DateTime.fromMillisecondsSinceEpoch(savedResetMs);
      balance = savedBalance ?? kInitialBalance;
      if (now.difference(lastReset) >= kResetPeriod) {
        balance = kInitialBalance;
        lastReset = now;
        reset = true;
      }
    }

    if (!reset) {
      if (savedOpen != null) {
        try {
          openPositions = (jsonDecode(savedOpen) as List)
              .map((e) => TradePosition.fromJson(e as Map<String, dynamic>))
              .toList();
        } catch (_) {}
      }
      if (savedClosed != null) {
        try {
          closedPositions = (jsonDecode(savedClosed) as List)
              .map((e) => TradePosition.fromJson(e as Map<String, dynamic>))
              .toList();
        } catch (_) {}
      }
    } else {
      openPositions = [];
      closedPositions = [];
    }

    await _saveState();
    if (mounted) setState(() {});
    _updatePositionsSubscription();
  }

  Future<void> _saveState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('balance', balance);
    await prefs.setInt('lastReset', lastReset.millisecondsSinceEpoch);
    await prefs.setString('openPositions',
        jsonEncode(openPositions.map((e) => e.toJson()).toList()));
    await prefs.setString('closedPositions',
        jsonEncode(closedPositions.map((e) => e.toJson()).toList()));
  }

  // -----------------------------------------------------------------
  // MARKET DATA
  // -----------------------------------------------------------------
  Future<void> _loadMarket() async {
    final symbolAtStart = market.symbol;
    final tfAtStart = timeframe.interval;

    setState(() => loading = true);
    _chartSub?.cancel();
    _chartWs?.sink.close();

    await _fetchInitialCandles();

    if (!mounted) return;
    if (market.symbol != symbolAtStart || timeframe.interval != tfAtStart) return;

    _connectChartWs();
    setState(() => loading = false);
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpToEnd());
  }

  Future<void> _fetchInitialCandles() async {
    try {
      final uri = Uri.parse(
        'https://api.binance.com/api/v3/klines'
        '?symbol=${market.symbol}&interval=${timeframe.interval}&limit=200',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as List;
      final list = data.map((raw) {
        final row = raw as List;
        return Candle(
          time: DateTime.fromMillisecondsSinceEpoch(row[0] as int),
          open: double.parse(row[1].toString()),
          high: double.parse(row[2].toString()),
          low: double.parse(row[3].toString()),
          close: double.parse(row[4].toString()),
          volume: double.parse(row[5].toString()),
        );
      }).toList();
      if (!mounted) return;
      setState(() {
        candles = list;
        if (candles.isNotEmpty) {
          currentPrice = candles.last.close;
          prevClose = candles.length > 1
              ? candles[candles.length - 2].close
              : currentPrice;
        }
      });
    } catch (e) {
      debugPrint('Gagal ambil candle: $e');
    }
  }

  void _connectChartWs() {
    _chartSub?.cancel();
    _chartWs?.sink.close();
    chartWsOk = false;

    final stream = '${market.symbol.toLowerCase()}@kline_${timeframe.interval}';
    try {
      _chartWs =
          WebSocketChannel.connect(Uri.parse('wss://stream.binance.com:9443/ws/$stream'));
      _chartSub = _chartWs!.stream.listen(
        _onTick,
        onError: (e) {
          debugPrint('chart WS err: $e');
          _scheduleReconnectChart();
        },
        onDone: () {
          _scheduleReconnectChart();
        },
      );
      if (mounted) setState(() => chartWsOk = true);
    } catch (e) {
      debugPrint('chart WS connect fail: $e');
      _scheduleReconnectChart();
    }
  }

  void _scheduleReconnectChart() {
    if (!mounted) return;
    setState(() => chartWsOk = false);
    _reconnectChartTimer?.cancel();
    _reconnectChartTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) _connectChartWs();
    });
  }

  /// WS kedua: harga semua symbol yang sedang ada posisi + market aktif.
  /// Menggunakan `miniTicker` per symbol supaya hemat bandwidth.
  void _updatePositionsSubscription() {
    _posSub?.cancel();
    _posWs?.sink.close();

    final symbols = <String>{};
    for (final p in openPositions) {
      symbols.add(p.symbol.toLowerCase());
    }

    if (symbols.isEmpty) return;

    final streams = symbols.map((s) => '$s@miniTicker').join('/');
    final url = 'wss://stream.binance.com:9443/stream?streams=$streams';

    try {
      _posWs = WebSocketChannel.connect(Uri.parse(url));
      _posSub = _posWs!.stream.listen(
        (event) {
          try {
            final msg = jsonDecode(event as String);
            final data = msg['data'] ?? msg;
            final sym = (data['s'] ?? '') as String;
            final c = data['c'];
            if (sym.isEmpty || c == null) return;
            final price = double.parse(c.toString());
            if (!mounted) return;
            setState(() => livePrices[sym] = price);
          } catch (_) {}
        },
        onError: (_) => _scheduleReconnectPos(),
        onDone: _scheduleReconnectPos,
      );
    } catch (e) {
      debugPrint('pos WS connect fail: $e');
      _scheduleReconnectPos();
    }
  }

  void _scheduleReconnectPos() {
    _reconnectPosTimer?.cancel();
    _reconnectPosTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) _updatePositionsSubscription();
    });
  }

  void _onTick(dynamic raw) {
    try {
      final msg = jsonDecode(raw as String);
      final k = msg['k'];
      if (k == null) return;

      final openTime = DateTime.fromMillisecondsSinceEpoch(k['t'] as int);
      final o = double.parse(k['o'].toString());
      final h = double.parse(k['h'].toString());
      final l = double.parse(k['l'].toString());
      final c = double.parse(k['c'].toString());
      final v = double.tryParse(k['v']?.toString() ?? '0') ?? 0;

      bool newCandle = false;
      setState(() {
        if (candles.isNotEmpty && candles.last.time == openTime) {
          candles.last
            ..open = o
            ..high = h
            ..low = l
            ..close = c
            ..volume = v;
        } else {
          candles.add(Candle(
              time: openTime, open: o, high: h, low: l, close: c, volume: v));
          if (candles.length > 400) candles.removeAt(0);
          newCandle = true;
        }
        prevClose = currentPrice == 0 ? o : currentPrice;
        currentPrice = c;
      });

      // Hanya scroll saat candle baru dibuka biar chart tidak goyang.
      if (newCandle) _jumpToEnd();
    } catch (e) {
      debugPrint('tick parse err: $e');
    }
  }

  void _jumpToEnd() {
    if (!_scrollCtrl.hasClients) return;
    _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
  }

  void _switchMarket(MarketInfo m) {
    if (m.symbol == market.symbol) return;
    setState(() {
      market = m;
      currentPrice = 0;
      prevClose = 0;
      candles = [];
    });
    _loadMarket();
  }

  void _switchTimeframe(TimeframeInfo tf) {
    if (tf.interval == timeframe.interval) return;
    setState(() => timeframe = tf);
    _loadMarket();
  }

  // -----------------------------------------------------------------
  // TRADING
  // -----------------------------------------------------------------
  double get spread => currentPrice * 0.0006;
  double get bidPrice => currentPrice - spread / 2;
  double get askPrice => currentPrice + spread / 2;

  double priceFor(String symbol) {
    if (symbol == market.symbol) return currentPrice;
    return livePrices[symbol] ?? 0;
  }

  double floatingOf(TradePosition p) {
    final px = priceFor(p.symbol);
    if (px <= 0) return 0;
    return p.floatingPnl(px);
  }

  double get floatingTotal =>
      openPositions.fold(0.0, (sum, p) => sum + floatingOf(p));

  double get equity => balance + floatingTotal;

  void _openPosition(bool isBuy) {
    if (currentPrice <= 0) return;
    final entry = isBuy ? askPrice : bidPrice;

    // Cek saldo cukup (margin = harga * qty)
    final required = entry * quantity;
    if (required > equity) {
      _showSnack('Margin tidak cukup untuk membuka posisi', C.red);
      return;
    }

    final pos = TradePosition(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      symbol: market.symbol,
      display: market.display,
      isBuy: isBuy,
      entryPrice: entry,
      quantity: quantity,
      openTime: DateTime.now(),
    );
    setState(() => openPositions.insert(0, pos));
    _saveState();
    _updatePositionsSubscription();
    HapticFeedback.lightImpact();
    _showSnack(
      '${isBuy ? 'BUY' : 'SELL'} ${market.display} ${quantity.toStringAsFixed(2)} lot @ ${fmtPrice(entry)}',
      isBuy ? C.green : C.red,
    );
  }

  void _closePosition(TradePosition p) {
    final px = priceFor(p.symbol);
    if (px <= 0) {
      _showSnack('Harga ${p.display} belum tersedia', C.red);
      return;
    }
    final sp = px * 0.0006;
    final exit = p.isBuy ? px - sp / 2 : px + sp / 2;
    final pnl = p.floatingPnl(exit);

    setState(() {
      p.closePrice = exit;
      p.closeTime = DateTime.now();
      p.realizedPnl = pnl;
      openPositions.removeWhere((e) => e.id == p.id);
      closedPositions.insert(0, p);
      balance += pnl;
    });
    _saveState();
    _updatePositionsSubscription();

    _showSnack(
      '${p.isBuy ? 'BUY' : 'SELL'} ${p.display} ditutup ${fmtSigned(pnl)}',
      pnl >= 0 ? C.green : C.red,
    );
  }

  void _closeAll() {
    for (final p in List<TradePosition>.from(openPositions)) {
      _closePosition(p);
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
        backgroundColor: Color.lerp(color, Colors.black, 0.35),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // -----------------------------------------------------------------
  // BUILD
  // -----------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: Column(
          children: [
            _topBar(),
            _accountStrip(),
            _priceHeader(),
            _orderBar(),
            Expanded(child: _body()),
            _bottomNav(),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    switch (bottomTab) {
      case 0:
        return _quoteTab();
      case 2:
        return _historyTab();
      case 3:
        return _accountTab();
      default:
        return _chartArea();
    }
  }

  // ---- TOP BAR ----
  Widget _topBar() {
    return Container(
      decoration: const BoxDecoration(
        color: C.panel,
        border: Border(bottom: BorderSide(color: C.border)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [C.gold, C.goldDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Row(
              children: [
                Icon(Icons.bolt_rounded, color: Colors.black, size: 14),
                SizedBox(width: 2),
                Text('ATLAS',
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                        letterSpacing: 1.2)),
              ],
            ),
          ),
          const Spacer(),
          _iconBtn(Icons.search_rounded, () {}),
          _iconBtn(Icons.star_border_rounded, () {}),
          _iconBtn(Icons.notifications_none_rounded, () {}),
          const SizedBox(width: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: (chartWsOk ? C.green : C.red).withOpacity(0.15),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                  color: (chartWsOk ? C.green : C.red).withOpacity(0.4)),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: chartWsOk ? C.green : C.red,
                    boxShadow: [
                      BoxShadow(
                        color: (chartWsOk ? C.green : C.red).withOpacity(0.6),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                Text(chartWsOk ? 'LIVE' : 'WAIT',
                    style: TextStyle(
                        color: chartWsOk ? C.green : C.red,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback onTap) {
    return IconButton(
      onPressed: onTap,
      splashRadius: 18,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 34, minHeight: 34),
      icon: Icon(icon, color: C.textMed, size: 20),
    );
  }

  // ---- ACCOUNT STRIP ----
  Widget _accountStrip() {
    final fl = floatingTotal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      color: C.bg,
      child: Row(
        children: [
          const Icon(Icons.account_balance_wallet_rounded,
              color: C.gold, size: 12),
          const SizedBox(width: 6),
          Text(fmtMoney(balance),
              style: const TextStyle(
                  color: C.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFeatures: [FontFeature.tabularFigures()])),
          const SizedBox(width: 10),
          Container(width: 1, height: 10, color: C.border),
          const SizedBox(width: 10),
          Text('EQ ${fmtMoney(equity)}',
              style: const TextStyle(
                  color: C.textDim,
                  fontSize: 11,
                  fontFeatures: [FontFeature.tabularFigures()])),
          const Spacer(),
          if (openPositions.isNotEmpty) ...[
            Text('P/L ',
                style: const TextStyle(color: C.textDim, fontSize: 11)),
            Text(fmtSigned(fl),
                style: TextStyle(
                    color: fl >= 0 ? C.green : C.red,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    fontFeatures: const [FontFeature.tabularFigures()])),
          ],
        ],
      ),
    );
  }

  // ---- PRICE HEADER (symbol + change) ----
  Widget _priceHeader() {
    final isUp = currentPrice >= prevClose;
    final changePct = prevClose > 0
        ? ((currentPrice - prevClose) / prevClose * 100)
        : 0.0;
    return Container(
      color: C.bg,
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: _showMarketSheet,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: C.panelLight,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: C.border),
              ),
              child: Row(
                children: [
                  Text(market.display,
                      style: const TextStyle(
                          color: C.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14)),
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: C.textMed, size: 18),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(market.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: C.textDim, fontSize: 11)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                currentPrice > 0 ? fmtPrice(currentPrice) : '--',
                style: TextStyle(
                    color: isUp ? C.green : C.red,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    fontFeatures: const [FontFeature.tabularFigures()]),
              ),
              Text(
                '${changePct >= 0 ? '+' : ''}${changePct.toStringAsFixed(2)}%',
                style: TextStyle(
                    color: (isUp ? C.green : C.red).withOpacity(0.85),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    fontFeatures: const [FontFeature.tabularFigures()]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ---- ORDER BAR (SELL | qty | BUY) ----
  Widget _orderBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      height: 66,
      decoration: BoxDecoration(
        color: C.panel,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(9),
        child: Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => _confirmOrder(false),
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFFD84343), Color(0xFF8B1F1F)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('SELL',
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1)),
                      Text(
                        currentPrice > 0 ? fmtPrice(bidPrice) : '--',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            fontFeatures: [FontFeature.tabularFigures()]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              width: 110,
              color: C.panelLight,
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _qtyBtn(Icons.remove_rounded, () {
                    setState(() {
                      quantity = math.max(
                          0.01, double.parse((quantity - 0.01).toStringAsFixed(2)));
                    });
                  }),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(quantity.toStringAsFixed(2),
                          style: const TextStyle(
                              color: C.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 15,
                              fontFeatures: [FontFeature.tabularFigures()])),
                      const Text('LOT',
                          style: TextStyle(
                              color: C.textDim,
                              fontSize: 8,
                              letterSpacing: 1,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                  _qtyBtn(Icons.add_rounded, () {
                    setState(() {
                      quantity =
                          double.parse((quantity + 0.01).toStringAsFixed(2));
                    });
                  }),
                ],
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () => _confirmOrder(true),
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF2FB5A5), Color(0xFF136F65)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('BUY',
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1)),
                      Text(
                        currentPrice > 0 ? fmtPrice(askPrice) : '--',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            fontFeatures: [FontFeature.tabularFigures()]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _qtyBtn(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          color: C.panelElev,
          shape: BoxShape.circle,
          border: Border.all(color: C.border),
        ),
        child: Icon(icon, color: C.white, size: 14),
      ),
    );
  }

  // ---- CHART ----
  Widget _chartArea() {
    return Stack(
      children: [
        if (candles.isEmpty && !loading)
          const Center(
            child: Text('Tidak ada data',
                style: TextStyle(color: C.textDim)),
          ),
        if (candles.isNotEmpty)
          Positioned.fill(
            child: LayoutBuilder(builder: (context, constraints) {
              const candleW = 7.0;
              const candleGap = 4.0;
              final totalW =
                  candles.length * (candleW + candleGap) + 60;
              final width = math.max(constraints.maxWidth, totalW);
              return SingleChildScrollView(
                controller: _scrollCtrl,
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: width,
                  height: constraints.maxHeight,
                  child: CustomPaint(
                    painter: CandleChartPainter(
                      candles: candles,
                      currentPrice: currentPrice,
                      candleWidth: candleW,
                      candleGap: candleGap,
                    ),
                  ),
                ),
              );
            }),
          ),
        // TF chips di kanan atas chart
        Positioned(
          top: 8,
          right: 8,
          child: GestureDetector(
            onTap: _showTimeframeSheet,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: C.panel.withOpacity(0.9),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: C.border),
              ),
              child: Row(
                children: [
                  Text(timeframe.label,
                      style: const TextStyle(
                          color: C.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 12)),
                  const SizedBox(width: 2),
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: C.textMed, size: 16),
                ],
              ),
            ),
          ),
        ),
        if (loading)
          const Positioned.fill(
            child: ColoredBox(
              color: Color(0x99000000),
              child: Center(
                child: CircularProgressIndicator(color: C.gold, strokeWidth: 2.5),
              ),
            ),
          ),
      ],
    );
  }

  // ---- QUOTE TAB ----
  Widget _quoteTab() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        _quoteCard('Market', [
          _qr('Symbol', market.display),
          _qr('Nama', market.name),
          _qr('Timeframe', timeframe.label),
          _qr('Status', chartWsOk ? 'Live streaming' : 'Menghubungkan...',
              valueColor: chartWsOk ? C.green : C.red),
        ]),
        const SizedBox(height: 12),
        _quoteCard('Harga', [
          _qr('Last', currentPrice > 0 ? fmtPrice(currentPrice) : '--'),
          _qr('Bid', currentPrice > 0 ? fmtPrice(bidPrice) : '--',
              valueColor: C.red),
          _qr('Ask', currentPrice > 0 ? fmtPrice(askPrice) : '--',
              valueColor: C.green),
          _qr('Spread', currentPrice > 0 ? fmtPrice(spread) : '--'),
          _qr('High', candles.isNotEmpty
              ? fmtPrice(candles.map((c) => c.high).reduce(math.max))
              : '--'),
          _qr('Low', candles.isNotEmpty
              ? fmtPrice(candles.map((c) => c.low).reduce(math.min))
              : '--'),
        ]),
      ],
    );
  }

  Widget _quoteCard(String title, List<Widget> rows) {
    return Container(
      decoration: BoxDecoration(
        color: C.panel,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(title.toUpperCase(),
                style: const TextStyle(
                    color: C.gold,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2)),
          ),
          ...rows,
        ],
      ),
    );
  }

  Widget _qr(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: C.textDim, fontSize: 12)),
          Text(value,
              style: TextStyle(
                  color: valueColor ?? C.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                  fontFeatures: const [FontFeature.tabularFigures()])),
        ],
      ),
    );
  }

  // ---- HISTORY TAB ----
  Widget _historyTab() {
    return Column(
      children: [
        if (openPositions.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 8, 0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: C.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text('${openPositions.length}',
                      style: const TextStyle(
                          color: C.green,
                          fontWeight: FontWeight.w800,
                          fontSize: 11)),
                ),
                const SizedBox(width: 8),
                const Text('Posisi Terbuka',
                    style: TextStyle(
                        color: C.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14)),
                const Spacer(),
                TextButton(
                  onPressed: _closeAll,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    minimumSize: const Size(0, 30),
                    backgroundColor: C.red.withOpacity(0.12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6)),
                  ),
                  child: const Text('TUTUP SEMUA',
                      style: TextStyle(
                          color: C.red,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8)),
                ),
              ],
            ),
          ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
            children: [
              ...openPositions.map((p) => _positionCard(p, open: true)),
              if (closedPositions.isNotEmpty) ...[
                const Padding(
                  padding: EdgeInsets.fromLTRB(0, 16, 0, 8),
                  child: Text('RIWAYAT TRANSAKSI',
                      style: TextStyle(
                          color: C.gold,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2)),
                ),
                ...closedPositions.map((p) => _positionCard(p, open: false)),
              ],
              if (openPositions.isEmpty && closedPositions.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 80),
                  child: Column(
                    children: [
                      Icon(Icons.inbox_rounded, color: C.border, size: 48),
                      SizedBox(height: 12),
                      Text('Belum ada transaksi',
                          style: TextStyle(
                              color: C.textMed,
                              fontSize: 14,
                              fontWeight: FontWeight.w600)),
                      SizedBox(height: 4),
                      Text('Buka posisi BUY / SELL untuk mulai latihan',
                          style: TextStyle(color: C.textDim, fontSize: 12)),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _positionCard(TradePosition p, {required bool open}) {
    final px = priceFor(p.symbol);
    final pnl = open ? p.floatingPnl(px) : (p.realizedPnl ?? 0);
    final pnlColor = pnl >= 0 ? C.green : C.red;
    final pct = p.entryPrice > 0 ? (pnl / (p.entryPrice * p.quantity)) * 100 : 0.0;
    final dur = (p.closeTime ?? DateTime.now()).difference(p.openTime);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: C.panel,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: open ? (p.isBuy ? C.green : C.red).withOpacity(0.35) : C.border,
        ),
      ),
      child: Row(
        children: [
          // Side bar
          Container(
            width: 4,
            height: 68,
            decoration: BoxDecoration(
              color: p.isBuy ? C.green : C.red,
              borderRadius: const BorderRadius.horizontal(
                  left: Radius.circular(10)),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: (p.isBuy ? C.green : C.red).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        child: Text(p.isBuy ? 'BUY' : 'SELL',
                            style: TextStyle(
                                color: p.isBuy ? C.green : C.red,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5)),
                      ),
                      const SizedBox(width: 6),
                      Text(p.display,
                          style: const TextStyle(
                              color: C.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 13)),
                      const SizedBox(width: 6),
                      Text('${p.quantity.toStringAsFixed(2)} lot',
                          style: const TextStyle(
                              color: C.textDim,
                              fontSize: 10,
                              fontFeatures: [FontFeature.tabularFigures()])),
                      const Spacer(),
                      if (open)
                        Text(fmtDuration(dur),
                            style: const TextStyle(
                                color: C.textDim,
                                fontSize: 10,
                                fontFeatures: [FontFeature.tabularFigures()])),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      _miniStat('ENTRY', fmtPrice(p.entryPrice)),
                      const SizedBox(width: 12),
                      _miniStat(
                        open ? 'NOW' : 'EXIT',
                        fmtPrice(open ? (px > 0 ? px : p.entryPrice) : (p.closePrice ?? 0)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(fmtSigned(pnl),
                    style: TextStyle(
                        color: pnlColor,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFeatures: const [FontFeature.tabularFigures()])),
                Text('${pct >= 0 ? '+' : ''}${pct.toStringAsFixed(2)}%',
                    style: TextStyle(
                        color: pnlColor.withOpacity(0.85),
                        fontWeight: FontWeight.w600,
                        fontSize: 10,
                        fontFeatures: const [FontFeature.tabularFigures()])),
                if (open) ...[
                  const SizedBox(height: 4),
                  GestureDetector(
                    onTap: () => _closePosition(p),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: C.panelElev,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: C.border),
                      ),
                      child: const Text('TUTUP',
                          style: TextStyle(
                              color: C.textMed,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: C.textDim, fontSize: 8, letterSpacing: 0.5)),
        Text(value,
            style: const TextStyle(
                color: C.textMed,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                fontFeatures: [FontFeature.tabularFigures()])),
      ],
    );
  }

  // ---- ACCOUNT TAB ----
  Widget _accountTab() {
    final nextReset = lastReset.add(kResetPeriod);
    final remaining = nextReset.difference(DateTime.now());
    final hoursLeft = math.max(0.0, remaining.inMinutes / 60.0);
    final resetProgress = 1 -
        (remaining.inSeconds / kResetPeriod.inSeconds).clamp(0.0, 1.0);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Hero balance card
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF232932), Color(0xFF10141A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: C.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('SALDO VIRTUAL',
                      style: TextStyle(
                          color: C.textDim,
                          fontSize: 10,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: C.gold.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text('PAPER',
                        style: TextStyle(
                            color: C.gold,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1)),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text('Rp ${fmtMoney(balance)}',
                  style: const TextStyle(
                      color: C.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      fontFeatures: [FontFeature.tabularFigures()])),
              const SizedBox(height: 14),
              Container(height: 1, color: C.border),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                      child: _accStat('Equity', 'Rp ${fmtMoney(equity)}', C.gold)),
                  Container(width: 1, height: 32, color: C.border),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 14),
                      child: _accStat(
                        'Floating P/L',
                        fmtSigned(floatingTotal),
                        floatingTotal >= 0 ? C.green : C.red,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // Stat row
        Row(
          children: [
            Expanded(
              child: _statCard(
                icon: Icons.trending_up_rounded,
                iconColor: C.green,
                label: 'Total Trade',
                value: '${closedPositions.length}',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                icon: Icons.speed_rounded,
                iconColor: C.gold,
                label: 'Posisi Aktif',
                value: '${openPositions.length}',
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),

        // Reset info
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: C.panel,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: C.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.refresh_rounded, color: C.gold, size: 16),
                  const SizedBox(width: 8),
                  const Text('Reset Otomatis',
                      style: TextStyle(
                          color: C.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 13)),
                  const Spacer(),
                  Text('${hoursLeft.toStringAsFixed(1)} jam',
                      style: const TextStyle(
                          color: C.textDim,
                          fontSize: 11,
                          fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: LinearProgressIndicator(
                  value: resetProgress,
                  minHeight: 5,
                  backgroundColor: C.panelElev,
                  valueColor: const AlwaysStoppedAnimation(C.gold),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Saldo & riwayat akan di-reset ke Rp 10.000.000 setiap 7 hari.',
                style: TextStyle(color: C.textDim, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        ElevatedButton.icon(
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                backgroundColor: C.panel,
                title: const Text('Reset Saldo?',
                    style: TextStyle(color: C.white, fontWeight: FontWeight.w700)),
                content: const Text(
                  'Saldo akan dikembalikan ke Rp 10.000.000 dan semua posisi & riwayat akan dihapus.',
                  style: TextStyle(color: C.textMed),
                ),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('BATAL')),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: C.red),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('RESET'),
                  ),
                ],
              ),
            );
            if (ok != true) return;
            setState(() {
              balance = kInitialBalance;
              lastReset = DateTime.now();
              openPositions = [];
              closedPositions = [];
              livePrices.clear();
            });
            await _saveState();
            _updatePositionsSubscription();
            _showSnack('Saldo direset ke Rp 10.000.000', C.gold);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: C.panelElev,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: const BorderSide(color: C.border),
            ),
          ),
          icon: const Icon(Icons.restart_alt_rounded, color: C.red, size: 18),
          label: const Text('RESET SALDO SEKARANG',
              style: TextStyle(
                  color: C.white,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                  fontSize: 12)),
        ),
      ],
    );
  }

  Widget _statCard({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: C.panel,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: iconColor, size: 18),
          const SizedBox(height: 10),
          Text(value,
              style: const TextStyle(
                  color: C.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  fontFeatures: [FontFeature.tabularFigures()])),
          Text(label,
              style: const TextStyle(color: C.textDim, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _accStat(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: C.textDim, fontSize: 10, letterSpacing: 0.6)),
        const SizedBox(height: 4),
        Text(value,
            style: TextStyle(
                color: color,
                fontWeight: FontWeight.w800,
                fontSize: 15,
                fontFeatures: const [FontFeature.tabularFigures()])),
      ],
    );
  }

  // ---- BOTTOM NAV ----
  Widget _bottomNav() {
    final items = [
      ('Quote', Icons.swap_vert_rounded),
      ('Chart', Icons.candlestick_chart_rounded),
      ('Riwayat', Icons.receipt_long_rounded),
      ('Akun', Icons.account_balance_wallet_rounded),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: C.panel,
        border: Border(top: BorderSide(color: C.border)),
      ),
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: Row(
        children: List.generate(items.length, (i) {
          final selected = bottomTab == i;
          final badge = i == 2 && openPositions.isNotEmpty;
          return Expanded(
            child: InkWell(
              onTap: () => setState(() => bottomTab = i),
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        if (selected)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 2),
                            decoration: BoxDecoration(
                              color: C.gold.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        Icon(items[i].$2,
                            color: selected ? C.gold : C.textDim, size: 22),
                        if (badge)
                          Positioned(
                            right: -4,
                            top: -3,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: C.red,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              constraints: const BoxConstraints(minWidth: 14),
                              child: Text('${openPositions.length}',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w800)),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(items[i].$1,
                        style: TextStyle(
                            color: selected ? C.gold : C.textDim,
                            fontSize: 10,
                            fontWeight: selected
                                ? FontWeight.w700
                                : FontWeight.w500)),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ---- SHEETS & DIALOGS ----
  void _showTimeframeSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: C.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Timeframe',
                  style: TextStyle(
                      color: C.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15)),
            ),
            ...kTimeframes.map((tf) {
              final sel = tf.interval == timeframe.interval;
              return ListTile(
                dense: true,
                title: Text(tf.label,
                    style: TextStyle(
                        color: sel ? C.gold : C.white,
                        fontWeight: sel ? FontWeight.w700 : FontWeight.w500)),
                trailing: sel
                    ? const Icon(Icons.check_rounded, color: C.gold, size: 18)
                    : null,
                onTap: () {
                  Navigator.pop(ctx);
                  _switchTimeframe(tf);
                },
              );
            }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showMarketSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: C.panel,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 460,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Pilih Market',
                    style: TextStyle(
                        color: C.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15)),
              ),
              Container(height: 1, color: C.border),
              Expanded(
                child: ListView(
                  children: kMarkets.map((m) {
                    final sel = m.symbol == market.symbol;
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor:
                            sel ? C.gold : C.panelElev,
                        child: Text(m.display.substring(0, 1),
                            style: TextStyle(
                                color: sel ? Colors.black : C.gold,
                                fontWeight: FontWeight.w800)),
                      ),
                      title: Text(m.display,
                          style: TextStyle(
                              color: sel ? C.gold : C.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 14)),
                      subtitle: Text(m.name,
                          style: const TextStyle(
                              color: C.textDim, fontSize: 11)),
                      trailing: sel
                          ? const Icon(Icons.check_rounded,
                              color: C.gold, size: 18)
                          : null,
                      onTap: () {
                        Navigator.pop(ctx);
                        _switchMarket(m);
                      },
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmOrder(bool isBuy) {
    if (currentPrice <= 0) return;
    final price = isBuy ? askPrice : bidPrice;
    final margin = price * quantity;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.panel,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: (isBuy ? C.green : C.red).withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Icon(
                isBuy ? Icons.trending_up_rounded : Icons.trending_down_rounded,
                color: isBuy ? C.green : C.red,
                size: 16,
              ),
            ),
            const SizedBox(width: 10),
            Text(isBuy ? 'Konfirmasi BUY' : 'Konfirmasi SELL',
                style: TextStyle(
                    color: isBuy ? C.green : C.red,
                    fontWeight: FontWeight.w800,
                    fontSize: 15)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dialogRow('Symbol', market.display),
            _dialogRow('Volume', '${quantity.toStringAsFixed(2)} lot'),
            _dialogRow('Harga', fmtPrice(price)),
            _dialogRow('Margin', 'Rp ${fmtMoney(margin)}'),
            const Divider(color: C.border, height: 20),
            _dialogRow('Saldo', 'Rp ${fmtMoney(balance)}'),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('BATAL',
                  style: TextStyle(color: C.textMed))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isBuy ? C.green : C.red,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(ctx);
              _openPosition(isBuy);
            },
            child: Text(isBuy ? 'BUY' : 'SELL',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _dialogRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: C.textDim, fontSize: 12)),
          Text(value,
              style: const TextStyle(
                  color: C.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                  fontFeatures: [FontFeature.tabularFigures()])),
        ],
      ),
    );
  }
}

// =============================================================================
// CANDLE CHART PAINTER
// =============================================================================
class CandleChartPainter extends CustomPainter {
  final List<Candle> candles;
  final double currentPrice;
  final double candleWidth;
  final double candleGap;

  CandleChartPainter({
    required this.candles,
    required this.currentPrice,
    required this.candleWidth,
    required this.candleGap,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (candles.isEmpty) return;

    const rightAxis = 62.0;
    const bottomAxis = 22.0;
    const volumeRatio = 0.18;

    final chartW = size.width - rightAxis;
    final chartH = size.height - bottomAxis;
    final priceH = chartH * (1 - volumeRatio);
    final volH = chartH * volumeRatio;
    final volTop = priceH;

    // ---- price range ----
    double minP = candles.map((c) => c.low).reduce(math.min);
    double maxP = candles.map((c) => c.high).reduce(math.max);
    if (currentPrice > 0) {
      minP = math.min(minP, currentPrice);
      maxP = math.max(maxP, currentPrice);
    }
    final pad = (maxP - minP) * 0.08;
    minP -= pad;
    maxP += (maxP - minP) == 0 ? 1 : pad;
    if (maxP == minP) maxP += 1;

    double yFor(double price) =>
        priceH - ((price - minP) / (maxP - minP)) * priceH;

    // ---- grid + right price labels ----
    final gridPaint = Paint()
      ..color = C.border.withOpacity(0.4)
      ..strokeWidth = 0.5;
    const rows = 6;
    for (int i = 0; i <= rows; i++) {
      final y = priceH * i / rows;
      canvas.drawLine(Offset(0, y), Offset(chartW, y), gridPaint);
      final price = maxP - (maxP - minP) * i / rows;
      final tp = TextPainter(
        text: TextSpan(
            text: fmtPrice(price),
            style: const TextStyle(color: C.textDim, fontSize: 9.5)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(chartW + 6, y - tp.height / 2));
    }

    // separator volume area
    canvas.drawLine(
      Offset(0, volTop),
      Offset(chartW, volTop),
      Paint()
        ..color = C.border.withOpacity(0.6)
        ..strokeWidth = 0.8,
    );

    // ---- time labels ----
    final step = math.max(1, (candles.length / 6).round());
    for (int i = 0; i < candles.length; i += step) {
      final x = i * (candleWidth + candleGap) + candleWidth / 2;
      canvas.drawLine(
          Offset(x, 0),
          Offset(x, priceH),
          Paint()
            ..color = C.border.withOpacity(0.15)
            ..strokeWidth = 0.5);
      final t = candles[i].time;
      String label;
      if (t.hour == 0 && t.minute == 0) {
        label = '${t.day}/${t.month}';
      } else {
        label =
            '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
      }
      final tp = TextPainter(
        text: TextSpan(
            text: label,
            style: const TextStyle(color: C.textDim, fontSize: 9)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x - tp.width / 2, chartH + 4));
    }

    // ---- volume bars ----
    double maxVol = 0;
    for (final c in candles) {
      if (c.volume > maxVol) maxVol = c.volume;
    }
    if (maxVol > 0) {
      for (int i = 0; i < candles.length; i++) {
        final c = candles[i];
        final x = i * (candleWidth + candleGap);
        final h = (c.volume / maxVol) * (volH - 4);
        final color = c.isBull
            ? C.green.withOpacity(0.35)
            : C.red.withOpacity(0.35);
        canvas.drawRect(
          Rect.fromLTRB(x, chartH - h, x + candleWidth, chartH),
          Paint()..color = color,
        );
      }
    }

    // ---- candles ----
    for (int i = 0; i < candles.length; i++) {
      final c = candles[i];
      final x = i * (candleWidth + candleGap);
      final isBull = c.isBull;
      final bodyColor = isBull ? C.green : C.red;
      final xCenter = x + candleWidth / 2;

      // wick
      canvas.drawLine(
        Offset(xCenter, yFor(c.high)),
        Offset(xCenter, yFor(c.low)),
        Paint()
          ..color = bodyColor.withOpacity(0.9)
          ..strokeWidth = 1,
      );

      // body
      final openY = yFor(c.open);
      final closeY = yFor(c.close);
      final top = math.min(openY, closeY);
      var bottom = math.max(openY, closeY);
      if (bottom - top < 1.2) bottom = top + 1.2;
      final rect = Rect.fromLTRB(x, top, x + candleWidth, bottom);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(1)),
        Paint()..color = bodyColor,
      );
      // subtle glow
      canvas.drawRect(
        rect.inflate(0.5),
        Paint()
          ..color = bodyColor.withOpacity(0.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }

    // ---- current price line + tag ----
    if (currentPrice > 0) {
      final y = yFor(currentPrice);
      final isUp = candles.isNotEmpty && currentPrice >= candles.last.open;
      final lineColor = isUp ? C.green : C.red;
      final dashPaint = Paint()
        ..color = lineColor.withOpacity(0.9)
        ..strokeWidth = 1;
      double dx = 0;
      while (dx < chartW) {
        canvas.drawLine(Offset(dx, y), Offset(dx + 4, y), dashPaint);
        dx += 8;
      }
      // tag
      final tagRect = Rect.fromLTWH(chartW, y - 10, rightAxis, 20);
      canvas.drawRRect(
        RRect.fromRectAndRadius(tagRect, const Radius.circular(3)),
        Paint()..color = lineColor,
      );
      final tp = TextPainter(
        text: TextSpan(
          text: fmtPrice(currentPrice),
          style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w800),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: rightAxis);
      tp.paint(
          canvas, Offset(chartW + 5, y - tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant CandleChartPainter old) {
    if (old.candles.length != candles.length) return true;
    if (old.currentPrice != currentPrice) return true;
    if (candles.isEmpty) return false;
    if (old.candles.isEmpty) return true;
    return old.candles.last.close != candles.last.close ||
        old.candles.last.high != candles.last.high ||
        old.candles.last.low != candles.last.low;
  }
}