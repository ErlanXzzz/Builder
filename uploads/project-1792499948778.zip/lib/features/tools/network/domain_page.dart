// lib/features/tools/network/domain_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color doBgMain = const Color(0xFF160A07);
Color doBgSurface = const Color(0xFF2A140E);
Color doBgCard = const Color(0xFF3A1E15);
Color doTextMain = const Color(0xFFF3E6DD);
Color doTextSub = const Color(0xFFC9913F);
Color doGold = const Color(0xFFD4A853);
Color doRed = const Color(0xFFB71C1C);
Color doRedDark = const Color(0xFF7F0000);
Color doRedDeep = const Color(0xFF4A0000);
Color doGreen = const Color(0xFF4CAF50);
Color doBlue = const Color(0xFF2196F3);
Color doBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  doBgMain     = theme.brownDark;
  doBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  doBgCard     = theme.brownMid;
  doTextMain   = theme.bgCreamLight;
  doTextSub    = theme.gold;
  doGold       = theme.gold;
  doRed        = theme.redMain;
  doRedDark    = theme.redDark;
  doRedDeep    = theme.redDeep;
  doGreen      = theme.accentGreen;
  doBlue       = theme.accentBlue;
  doBorderDark = theme.borderDark;
}

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<dynamic>? _subdomainsData;
  Map<String, dynamic>? _whoisData;
  String? _errorMessage;

  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    _domainController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // FETCH DATA
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      setState(() {
        _errorMessage = "Domain tidak boleh kosong.";
        _dnsData = null;
        _subdomainsData = null;
        _whoisData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _subdomainsData = null;
      _whoisData = null;
    });

    try {
      final results = await Future.wait([
        _fetchDnsInfo(domain),
        _fetchSubdomains(domain),
        _fetchWhois(domain),
      ]);

      final dns = results[0] as Map<String, dynamic>?;
      final subs = results[1] as List<dynamic>?;
      final whois = results[2] as Map<String, dynamic>?;

      if (!mounted) return;
      setState(() {
        _dnsData = dns;
        _subdomainsData = subs;
        _whoisData = whois;
        if (dns == null && subs == null && whois == null) {
          _errorMessage = "Domain tidak valid atau tidak punya record DNS.";
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = "Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<Map<String, dynamic>?> _fetchDnsInfo(String domain) async {
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/osint/dns?domain=$domain'))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        return json['status'] == true ? json['data'] as Map<String, dynamic> : null;
      }
    } catch (_) {}
    return null;
  }

  Future<List<dynamic>?> _fetchSubdomains(String domain) async {
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/osint/subdomains?domain=$domain'))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        return json['status'] == true ? json['data'] as List<dynamic> : null;
      }
    } catch (_) {}
    return null;
  }

  Future<Map<String, dynamic>?> _fetchWhois(String domain) async {
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/osint/whois?domain=$domain'))
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        return json['status'] == true ? json['data'] as Map<String, dynamic> : null;
      }
    } catch (_) {}
    return null;
  }

  void _copyToClipboard(String text, String label) {
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    _showSnack("📋 $label disalin!", isError: false);
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: doTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? doRed : doGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: doBorderDark, width: 2),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          doTextMain.withOpacity(0.20),
          doRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? doGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [doBgCard, doBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: doBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(doBgMain, doRed, 0.25)!,
                  doBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          if (_dnsData != null ||
                              _subdomainsData != null ||
                              _whoisData != null) ...[
                            const SizedBox(height: 16),
                            _buildResults(),
                          ],
                          if (_dnsData == null &&
                              _subdomainsData == null &&
                              _whoisData == null &&
                              !_isLoading &&
                              _errorMessage == null)
                            _buildPlaceholder(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [doBgSurface, doBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: doGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: doGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [doRed, doRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: doBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [doRed, doRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: doBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: doGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.public_rounded, color: doGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'DOMAIN OSINT',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: doGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [doGold, Color.lerp(doGold, Colors.black, 0.4)!],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: doBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.domain_rounded,
                      color: doRedDark, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MASUKKAN DOMAIN',
                  style: TextStyle(
                    color: doTextMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [doBgSurface, doBgMain],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: doGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: doGold.withOpacity(0.3), blurRadius: 12),
                ],
              ),
              child: TextField(
                controller: _domainController,
                style: TextStyle(
                  color: doTextMain,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: doGold,
                autocorrect: false,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  hintText: 'contoh: google.com',
                  hintStyle: TextStyle(
                    color: doTextSub.withOpacity(0.5),
                    fontSize: 13,
                  ),
                  prefixIcon: Icon(Icons.link_rounded, color: doGold, size: 18),
                  suffixIcon: _domainController.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: doTextSub, size: 18),
                          onPressed: () {
                            _domainController.clear();
                            setState(() {});
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                ),
                onChanged: (_) => setState(() {}),
                onSubmitted: (_) => _checkDomain(),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [doRed, Color.lerp(doRed, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: doRed.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isLoading ? null : _checkDomain,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: doBorderDark, width: 2.5),
                  ),
                ),
                child: _isLoading
                    ? const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: Colors.white,
                          ),
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.search_rounded,
                              color: Colors.white, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'ANALISIS DOMAIN',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: doRed,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: doGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: doGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: doTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULTS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResults() {
    return Column(
      children: [
        if (_dnsData != null) _buildDnsSection(),
        if (_whoisData != null) _buildWhoisSection(),
        if (_subdomainsData != null && _subdomainsData!.isNotEmpty)
          _buildSubdomainsSection(),
      ],
    );
  }

  // ─── DNS Section ─────────────────────────────────────────────────
  Widget _buildDnsSection() {
    final records = _dnsData!['records'] as Map<String, dynamic>? ?? {};

    return _buildCategoryCard(
      title: 'DNS RECORDS',
      icon: Icons.dns_rounded,
      children: [
        // ── A Records ──
        if ((records['a'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('A Records (IPv4)', Icons.computer_rounded),
          ...((records['a'] as List).map((ip) => _buildInfoRow(
                label: 'IPv4',
                value: ip.toString(),
                showCopy: true,
              ))),
          const SizedBox(height: 8),
        ],

        // ── AAAA Records ──
        if ((records['aaaa'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('AAAA Records (IPv6)', Icons.computer_rounded),
          ...((records['aaaa'] as List).map((ip) => _buildInfoRow(
                label: 'IPv6',
                value: ip.toString(),
                showCopy: true,
              ))),
          const SizedBox(height: 8),
        ],

        // ── NS Records ──
        if ((records['ns'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('Name Servers', Icons.dns_rounded),
          ...((records['ns'] as List).map((ns) => _buildInfoRow(
                label: 'NS',
                value: ns.toString(),
                showCopy: true,
              ))),
          const SizedBox(height: 8),
        ],

        // ── MX Records ──
        if ((records['mx'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('Mail Exchange', Icons.email_rounded),
          ...((records['mx'] as List).map((mx) => _buildInfoRow(
                label: 'Priority ${mx['priority'] ?? '-'}',
                value: mx['exchange']?.toString() ?? '-',
                showCopy: true,
              ))),
          const SizedBox(height: 8),
        ],

        // ── TXT Records ──
        if ((records['txt'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('TXT Records', Icons.text_snippet_rounded),
          ...((records['txt'] as List).take(5).map((txt) => _buildInfoRow(
                label: 'TXT',
                value: txt.toString(),
                showCopy: true,
              ))),
          if ((records['txt'] as List).length > 5)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                '+ ${(records['txt'] as List).length - 5} more...',
                style: TextStyle(
                  color: doTextSub,
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          const SizedBox(height: 8),
        ],

        // ── CNAME ──
        if ((records['cname'] as List?)?.isNotEmpty == true) ...[
          _buildSubHeader('CNAME', Icons.link_rounded),
          ...((records['cname'] as List).map((c) => _buildInfoRow(
                label: 'CNAME',
                value: c.toString(),
                showCopy: true,
              ))),
          const SizedBox(height: 8),
        ],

        // ── SOA ──
        if (records['soa'] != null) ...[
          _buildSubHeader('SOA Record', Icons.settings_rounded),
          _buildInfoRow(
              label: 'Primary NS',
              value: records['soa']['nsname']?.toString(),
              showCopy: true),
          _buildInfoRow(
              label: 'Hostmaster',
              value: records['soa']['hostmaster']?.toString(),
              showCopy: true),
          _buildInfoRow(
              label: 'Serial',
              value: records['soa']['serial']?.toString()),
          _buildInfoRow(
              label: 'Refresh',
              value: '${records['soa']['refresh']} s'),
          _buildInfoRow(
              label: 'Retry', value: '${records['soa']['retry']} s'),
          _buildInfoRow(
              label: 'Expire', value: '${records['soa']['expire']} s'),
          _buildInfoRow(
              label: 'Minimum TTL',
              value: '${records['soa']['minttl']} s'),
        ],
      ],
    );
  }

  // ─── WHOIS / IP Info Section ─────────────────────────────────────
  Widget _buildWhoisSection() {
    final ipInfo = _whoisData!['ipInfo'] as Map<String, dynamic>?;
    final reverse = (_whoisData!['reverse'] as List?) ?? [];

    return _buildCategoryCard(
      title: 'SERVER & IP INFO',
      icon: Icons.location_on_rounded,
      children: [
        _buildInfoRow(
            label: 'IP Address',
            value: _whoisData!['ip']?.toString(),
            showCopy: true),
        if (reverse.isNotEmpty)
          _buildInfoRow(
              label: 'Reverse DNS',
              value: reverse.join(', '),
              showCopy: true),
        if (ipInfo != null) ...[
          _buildInfoRow(label: 'Negara', value: ipInfo['country']?.toString()),
          _buildInfoRow(label: 'Region', value: ipInfo['regionName']?.toString()),
          _buildInfoRow(label: 'Kota', value: ipInfo['city']?.toString()),
          _buildInfoRow(label: 'ISP', value: ipInfo['isp']?.toString()),
          _buildInfoRow(label: 'Organisasi', value: ipInfo['org']?.toString()),
          _buildInfoRow(label: 'AS', value: ipInfo['as']?.toString()),
        ],
      ],
    );
  }

  // ─── Subdomains Section ──────────────────────────────────────────
  Widget _buildSubdomainsSection() {
    // Clean & dedupe subdomains
    final cleanSubs = _subdomainsData!
        .map((e) => e.toString().trim())
        .where((e) => e.isNotEmpty && !e.startsWith('*'))
        .toSet()
        .toList()
      ..sort();

    return _buildCategoryCard(
      title: 'SUBDOMAINS (${cleanSubs.length})',
      icon: Icons.list_alt_rounded,
      children: [
        if (cleanSubs.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Text(
              'Tidak ada subdomain ditemukan',
              style: TextStyle(
                color: doTextSub,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          )
        else
          ...cleanSubs.take(50).map((sub) => _buildInfoRow(
                label: 'Subdomain',
                value: sub,
                showCopy: true,
              )),
        if (cleanSubs.length > 50)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              '+ ${cleanSubs.length - 50} subdomain lainnya...',
              style: TextStyle(
                color: doTextSub,
                fontSize: 11,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HELPERS: Category Card, SubHeader, InfoRow
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return _bevelBox(
      radius: 18,
      glow: doGold,
      glowOpacity: 0.25,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [doRed, doRedDark],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(17),
                  topRight: Radius.circular(17),
                ),
                border: Border(
                  bottom: BorderSide(color: doGold, width: 2),
                ),
                boxShadow: [
                  BoxShadow(
                    color: doGold.withOpacity(0.3),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(color: doGold, width: 1.5),
                    ),
                    child: Icon(icon, color: doGold, size: 14),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.2,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Content
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: children,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 10),
      child: Row(
        children: [
          Icon(icon, color: doGold, size: 12),
          const SizedBox(width: 6),
          Text(
            title,
            style: TextStyle(
              color: doGold,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required String label,
    required String? value,
    bool showCopy = false,
  }) {
    if (value == null || value.isEmpty || value == 'null') {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [doBgSurface, doBgMain],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: doGold.withOpacity(0.25), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: doTextSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                SelectableText(
                  value,
                  style: TextStyle(
                    color: doTextMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          if (showCopy)
            GestureDetector(
              onTap: () => _copyToClipboard(value, label),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [doGold, Color.lerp(doGold, Colors.black, 0.4)!],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: doBorderDark, width: 1.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(Icons.copy_rounded,
                    color: doRedDark, size: 12),
              ),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PLACEHOLDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPlaceholder() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          _bevelBox(
            radius: 100,
            glow: doGold,
            glowOpacity: 0.4,
            child: Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                Icons.public_rounded,
                size: 56,
                color: doGold,
                shadows: [
                  Shadow(
                    color: doGold.withOpacity(0.7),
                    blurRadius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Domain OSINT',
            style: TextStyle(
              color: doTextMain,
              fontSize: 20,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: doGold.withOpacity(0.6),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Analisis DNS records, subdomains, dan info server',
              style: TextStyle(
                color: doTextSub,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _buildFeatureChip(Icons.dns_rounded, 'DNS'),
              _buildFeatureChip(Icons.list_alt_rounded, 'Subdomain'),
              _buildFeatureChip(Icons.location_on_rounded, 'IP Info'),
              _buildFeatureChip(Icons.email_rounded, 'MX'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [doBgCard, doBgMain]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: doGold.withOpacity(0.4), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: doGold, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: doTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}