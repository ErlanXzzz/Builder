// lib/features/tools/network/wifi_external.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color weBgMain = const Color(0xFF160A07);
Color weBgSurface = const Color(0xFF2A140E);
Color weBgCard = const Color(0xFF3A1E15);
Color weTextMain = const Color(0xFFF3E6DD);
Color weTextSub = const Color(0xFFC9913F);
Color weGold = const Color(0xFFD4A853);
Color weRed = const Color(0xFFB71C1C);
Color weRedDark = const Color(0xFF7F0000);
Color weRedDeep = const Color(0xFF4A0000);
Color weGreen = const Color(0xFF4CAF50);
Color weBlue = const Color(0xFF2196F3);
Color weYellow = const Color(0xFFFFC107);
Color weBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  weBgMain     = theme.brownDark;
  weBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  weBgCard     = theme.brownMid;
  weTextMain   = theme.bgCreamLight;
  weTextSub    = theme.gold;
  weGold       = theme.gold;
  weRed        = theme.redMain;
  weRedDark    = theme.redDark;
  weRedDeep    = theme.redDeep;
  weGreen      = theme.accentGreen;
  weBlue       = theme.accentBlue;
  weYellow     = theme.accentYellow;
  weBorderDark = theme.borderDark;
}

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  int _duration = 120;
  int _port = 53;
  Duration _elapsed = Duration.zero;
  int _startTime = 0;
  bool _showStats = false;

  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOAD PUBLIC INFO
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadPublicInfo() async {
    setState(() => isLoading = true);

    try {
      final ipRes = await http
          .get(Uri.parse("https://api.ipify.org?format=json"))
          .timeout(const Duration(seconds: 10));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http
          .get(Uri.parse(
              "http://ip-api.com/json/$ip?fields=as,regionName,status,query"))
          .timeout(const Duration(seconds: 10));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String? ?? '').toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      if (!mounted) return;
      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // ATTACK TARGET
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _attackTarget() async {
    if (isAttacking) return;

    setState(() {
      isAttacking = true;
      _showStats = true;
      _elapsed = Duration.zero;
      _startTime = DateTime.now().millisecondsSinceEpoch;
    });

    HapticFeedback.heavyImpact();

    // Timer elapsed
    _tickElapsed();

    try {
      final url = Uri.parse(
          "$apiBaseUrl/api/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=$_duration&port=$_port");
      final res = await http.get(url).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          _showSnack("✅ ${data['message'] ?? 'Attack dikirim!'}", isError: false);

          // Tunggu durasi selesai, lalu reset
          Future.delayed(Duration(seconds: _duration), () {
            if (mounted) {
              setState(() {
                isAttacking = false;
                _showStats = false;
              });
            }
          });
        } else {
          // Cooldown atau error
          setState(() => isAttacking = false);
          _showSnack("❌ ${data['message'] ?? 'Gagal'}",
              isError: true);
        }
      } else {
        setState(() => isAttacking = false);
        _showSnack("❌ Server rejected (${res.statusCode})", isError: true);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isAttacking = false);
      _showSnack("❌ Network error: $e", isError: true);
    }
  }

  void _tickElapsed() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted || !isAttacking) return;
      setState(() {
        _elapsed = Duration(
          milliseconds: DateTime.now().millisecondsSinceEpoch - _startTime,
        );
      });
      _tickElapsed();
    });
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: weTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? weRed : weGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: weBorderDark, width: 2),
        ),
      ),
    );
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          weTextMain.withOpacity(0.20),
          weRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? weGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [weBgCard, weBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: weBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(weBgMain, weRed, 0.25)!,
                  weBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: isLoading
                        ? _buildLoading()
                        : SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                _buildHeroCard(),
                                const SizedBox(height: 14),
                                _buildInfoCard(),
                                const SizedBox(height: 14),
                                if (isVpn) ...[
                                  _buildVpnWarning(),
                                  const SizedBox(height: 14),
                                ],
                                if (!isVpn) ...[
                                  _buildConfigCard(),
                                  const SizedBox(height: 14),
                                  _buildAttackButton(),
                                  const SizedBox(height: 14),
                                  if (_showStats) _buildStatsCard(),
                                  if (_showStats) const SizedBox(height: 14),
                                ],
                                _buildWarningCard(),
                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOADING
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _bevelBox(
            radius: 100,
            glow: weGold,
            glowOpacity: 0.4,
            child: Container(
              width: 90,
              height: 90,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: weGold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'MEMUAT INFO...',
            style: TextStyle(
              color: weTextSub,
              fontSize: 11,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [weBgSurface, weBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: weGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: weGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [weRed, weRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: weBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [weRed, weRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: weBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: weGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.router_rounded, color: weGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'WiFi KILLER EXTERNAL',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                        letterSpacing: 1.2,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: isLoading ? null : _loadPublicInfo,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [weGold, Color.lerp(weGold, Colors.black, 0.4)!],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: weBorderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Icon(Icons.refresh_rounded, color: weRedDark, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HERO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: isAttacking ? weRed : weGold,
      glowOpacity: isAttacking ? 0.55 : 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: isAttacking
                    ? LinearGradient(
                        colors: [weRed, Color.lerp(weRed, Colors.black, 0.5)!],
                      )
                    : LinearGradient(
                        colors: [weGold, Color.lerp(weGold, Colors.black, 0.5)!],
                      ),
                shape: BoxShape.circle,
                border: Border.all(color: weBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: (isAttacking ? weRed : weGold).withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(
                isAttacking
                    ? Icons.wifi_off_rounded
                    : Icons.public_rounded,
                size: 28,
                color: Colors.white,
                shadows: const [
                  Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isAttacking ? '🔥 FLOODING...' : '⚡ READY',
                    style: TextStyle(
                      color: isAttacking ? weYellow : weTextMain,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: (isAttacking ? weRed : weGold).withOpacity(0.7),
                          blurRadius: 12,
                        ),
                        const Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isAttacking
                        ? 'Menyerang $publicIp:$_port'
                        : 'Public IP: $publicIp',
                    style: TextStyle(
                      color: weTextSub,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INFO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard() {
    return _bevelBox(
      radius: 20,
      glow: weGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('SYSTEM INFORMATION', Icons.info_outline_rounded),
            const SizedBox(height: 14),
            _buildInfoRow('IP Address', publicIp, Icons.language_rounded,
                highlight: true),
            _buildInfoRow('Region', region, Icons.map_rounded),
            _buildInfoRow('ASN', asn, Icons.storage_rounded),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [weGold, Color.lerp(weGold, Colors.black, 0.4)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: weBorderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: weRedDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: TextStyle(
            color: weTextMain,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 3,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon,
      {bool highlight = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: highlight
              ? [weGold.withOpacity(0.2), weGold.withOpacity(0.05)]
              : [weBgSurface, weBgMain],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: highlight
              ? weGold.withOpacity(0.6)
              : weGold.withOpacity(0.25),
          width: highlight ? 2 : 1.5,
        ),
        boxShadow: highlight
            ? [
                const BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
                BoxShadow(color: weGold.withOpacity(0.3), blurRadius: 10),
              ]
            : const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
      ),
      child: Row(
        children: [
          Icon(icon, color: weGold, size: 14),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: weTextSub,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                SelectableText(
                  value,
                  style: TextStyle(
                    color: highlight ? weGold : weTextMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // VPN WARNING CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildVpnWarning() {
    return _bevelBox(
      radius: 18,
      glow: weRed,
      glowOpacity: 0.5,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [weRed, Color.lerp(weRed, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: weBorderDark, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: weRed.withOpacity(0.6),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.shield_moon_rounded,
                  color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'VPN / HOSTING DETECTED',
                    style: TextStyle(
                      color: weRed,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Target berasal dari VPN/Cloud provider.\nAttack otomatis dibatalkan.',
                    style: TextStyle(
                      color: weTextSub,
                      fontSize: 11,
                      height: 1.5,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // CONFIG CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildConfigCard() {
    return _bevelBox(
      radius: 20,
      glow: weGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('ATTACK CONFIG', Icons.tune_rounded),
            const SizedBox(height: 14),

            // Duration slider
            Row(
              children: [
                Icon(Icons.timer_rounded, color: weGold, size: 14),
                const SizedBox(width: 8),
                Text(
                  'Duration',
                  style: TextStyle(
                    color: weTextSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [weGold, Color.lerp(weGold, Colors.black, 0.4)!],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: weBorderDark, width: 1.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    '${_duration}s',
                    style: TextStyle(
                      color: weRedDark,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: weGold,
                inactiveTrackColor: weGold.withOpacity(0.2),
                thumbColor: weGold,
                overlayColor: weGold.withOpacity(0.2),
                trackHeight: 6,
              ),
              child: Slider(
                value: _duration.toDouble(),
                min: 10,
                max: 300,
                divisions: 29,
                label: '${_duration}s',
                onChanged: isAttacking
                    ? null
                    : (v) => setState(() => _duration = v.round()),
              ),
            ),
            const SizedBox(height: 4),

            // Port selector
            Row(
              children: [
                Icon(Icons.settings_ethernet_rounded,
                    color: weGold, size: 14),
                const SizedBox(width: 8),
                Text(
                  'Port',
                  style: TextStyle(
                    color: weTextSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [53, 80, 443, 8080, 3000].map((p) {
                final isSelected = _port == p;
                return GestureDetector(
                  onTap: isAttacking
                      ? null
                      : () => setState(() => _port = p),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? LinearGradient(
                              colors: [
                                weRed,
                                Color.lerp(weRed, Colors.black, 0.5)!
                              ],
                            )
                          : LinearGradient(
                              colors: [weBgSurface, weBgMain],
                            ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected
                            ? weBorderDark
                            : weGold.withOpacity(0.3),
                        width: isSelected ? 2.5 : 1.5,
                      ),
                      boxShadow: isSelected
                          ? [
                              const BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                              BoxShadow(
                                color: weRed.withOpacity(0.5),
                                blurRadius: 10,
                              ),
                            ]
                          : const [
                              BoxShadow(
                                color: Color(0xAA000000),
                                blurRadius: 0,
                                offset: Offset(2, 2),
                              ),
                            ],
                    ),
                    child: Text(
                      '$p',
                      style: TextStyle(
                        color: isSelected ? Colors.white : weTextSub,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ATTACK BUTTON 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAttackButton() {
    final activeColor = isAttacking ? weRed : weGold;

    return GestureDetector(
      onTap: isAttacking ? null : _attackTarget,
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          gradient: !isAttacking
              ? LinearGradient(
                  colors: [
                    activeColor,
                    Color.lerp(activeColor, Colors.black, 0.5)!,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    weTextSub.withOpacity(0.3),
                    weTextSub.withOpacity(0.1),
                  ],
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: !isAttacking
                ? weBorderDark
                : weTextSub.withOpacity(0.3),
            width: 3,
          ),
          boxShadow: !isAttacking
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(5, 5),
                  ),
                  BoxShadow(
                    color: activeColor.withOpacity(0.6),
                    blurRadius: 22,
                    spreadRadius: -4,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isAttacking
                  ? Icons.hourglass_top_rounded
                  : Icons.wifi_off_rounded,
              color: !isAttacking
                  ? Colors.white
                  : weTextSub.withOpacity(0.5),
              size: 26,
              shadows: const [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 4,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Text(
              isAttacking ? 'ATTACKING...' : 'START KILL',
              style: TextStyle(
                fontSize: 15,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                color: !isAttacking
                    ? Colors.white
                    : weTextSub.withOpacity(0.5),
                shadows: !isAttacking
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATS CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatsCard() {
    return _bevelBox(
      radius: 18,
      glow: weRed,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('ATTACK STATUS', Icons.trending_up_rounded),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    icon: Icons.timer_rounded,
                    label: 'ELAPSED',
                    value: _formatDuration(_elapsed),
                    color: weGold,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    icon: Icons.speed_rounded,
                    label: 'TOTAL',
                    value: '${_duration}s',
                    color: weBlue,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    icon: Icons.gps_fixed_rounded,
                    label: 'TARGET',
                    value: ':$_port',
                    color: weRed,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            // Progress bar
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: _elapsed.inSeconds / _duration,
                minHeight: 8,
                backgroundColor: weBgMain,
                valueColor: AlwaysStoppedAnimation(weRed),
              ),
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                isAttacking
                    ? '${((_elapsed.inSeconds / _duration) * 100).toStringAsFixed(0)}% selesai'
                    : 'Attack selesai',
                style: TextStyle(
                  color: weTextSub,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            shape: BoxShape.circle,
            border: Border.all(color: color.withOpacity(0.4), width: 1.5),
          ),
          child: Icon(icon, color: color, size: 14),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(
                color: color.withOpacity(0.6),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: weTextSub,
            fontSize: 8,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // WARNING CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildWarningCard() {
    return _bevelBox(
      radius: 16,
      glow: weRed,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [weRed, Color.lerp(weRed, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: weBorderDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: weRed.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PERINGATAN',
                    style: TextStyle(
                      color: weRed,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Fitur ini hanya untuk testing pribadi. Menyerang jaringan tanpa izin adalah ilegal. Gunakan dengan tanggung jawab.',
                    style: TextStyle(
                      color: weTextSub,
                      fontSize: 11,
                      height: 1.5,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}