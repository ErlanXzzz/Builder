// lib/features/tools/network/manage_server.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color msBgMain = const Color(0xFF160A07);
Color msBgSurface = const Color(0xFF2A140E);
Color msBgCard = const Color(0xFF3A1E15);
Color msTextMain = const Color(0xFFF3E6DD);
Color msTextSub = const Color(0xFFC9913F);
Color msGold = const Color(0xFFD4A853);
Color msRed = const Color(0xFFB71C1C);
Color msRedDark = const Color(0xFF7F0000);
Color msRedDeep = const Color(0xFF4A0000);
Color msGreen = const Color(0xFF4CAF50);
Color msBlue = const Color(0xFF2196F3);
Color msBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  msBgMain     = theme.brownDark;
  msBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  msBgCard     = theme.brownMid;
  msTextMain   = theme.bgCreamLight;
  msTextSub    = theme.gold;
  msGold       = theme.gold;
  msRed        = theme.redMain;
  msRedDark    = theme.redDark;
  msRedDeep    = theme.redDeep;
  msGreen      = theme.accentGreen;
  msBlue       = theme.accentBlue;
  msBorderDark = theme.borderDark;
}

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _fetchVpsList();
  }

  @override
  void dispose() {
    _hostController.dispose();
    _userController.dispose();
    _passController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // API CALLS
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchVpsList() async {
    setState(() => isLoading = true);
    final uri = Uri.parse('$apiBaseUrl/api/serverList?key=${widget.keyToken}');
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (!mounted) return;
      setState(() {
        vpsList = List<Map<String, dynamic>>.from(data);
      });
    } catch (_) {
      _showError("Gagal mengambil data VPS.");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _addVps() async {
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _showError("Isi semua field terlebih dahulu.");
      return;
    }

    final uri = Uri.parse('$apiBaseUrl/api/registerServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear();
        _userController.clear();
        _passController.clear();
        _showSuccess("✅ VPS berhasil ditambahkan");
        _fetchVpsList();
      } else {
        _showError(data['error'] ?? 'Gagal menambah VPS');
      }
    } catch (_) {
      _showError("Gagal terhubung ke server.");
    }
  }

  Future<void> _deleteVps(String host) async {
    // Konfirmasi dulu
    final confirmed = await _showConfirmDialog(host);
    if (confirmed != true) return;

    final uri = Uri.parse('$apiBaseUrl/api/removeServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showSuccess("🗑️ VPS berhasil dihapus");
        _fetchVpsList();
      } else {
        _showError("Gagal menghapus VPS.");
      }
    } catch (_) {
      _showError("Gagal menghubungi server.");
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DIALOGS
  // ═══════════════════════════════════════════════════════════════════
  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: msTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: msRed,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: msBorderDark, width: 2),
        ),
      ),
    );
  }

  void _showSuccess(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: msTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: msGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: msBorderDark, width: 2),
        ),
      ),
    );
  }

  Future<bool?> _showConfirmDialog(String host) {
    return showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: _bevelBox(
          radius: 20,
          glow: msRed,
          glowOpacity: 0.4,
          child: Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [msRed, Color.lerp(msRed, Colors.black, 0.5)!],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: msBorderDark, width: 2.5),
                    boxShadow: [
                      BoxShadow(
                        color: msRed.withOpacity(0.6),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.delete_outline_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(height: 16),
                Text(
                  'HAPUS VPS?',
                  style: TextStyle(
                    color: msTextMain,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [msBgSurface, msBgMain],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: msGold.withOpacity(0.4), width: 1.5),
                  ),
                  child: Text(
                    host,
                    style: TextStyle(
                      color: msGold,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Tindakan ini tidak bisa dibatalkan.',
                  style: TextStyle(
                    color: msTextSub,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, false),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [msBgSurface, msBgMain],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: msGold.withOpacity(0.4), width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'BATAL',
                              style: TextStyle(
                                color: msTextSub,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context, true),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [msRed, msRedDark],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: msBorderDark, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              'HAPUS',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAddDialog() {
    // Reset controller
    _hostController.clear();
    _userController.clear();
    _passController.clear();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: _bevelBox(
          radius: 22,
          glow: msGold,
          glowOpacity: 0.4,
          child: Container(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [msGold, Color.lerp(msGold, Colors.black, 0.4)!],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: msBorderDark, width: 2.5),
                        boxShadow: [
                          BoxShadow(
                            color: msGold.withOpacity(0.6),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                      child: Icon(Icons.dns_rounded,
                          color: msRedDark, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'TAMBAH VPS',
                            style: TextStyle(
                              color: msTextMain,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1.2,
                              shadows: const [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            'Masukkan detail VPS',
                            style: TextStyle(
                              color: msTextSub,
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Input fields
                _buildInput(
                  label: 'IP / Host VPS',
                  controller: _hostController,
                  icon: Icons.dns_rounded,
                  hint: '192.168.1.1 atau domain.com',
                ),
                _buildInput(
                  label: 'Username SSH',
                  controller: _userController,
                  icon: Icons.person_rounded,
                  hint: 'root',
                ),
                _buildInput(
                  label: 'Password SSH',
                  controller: _passController,
                  icon: Icons.lock_rounded,
                  hint: '••••••••',
                  isPassword: true,
                ),

                const SizedBox(height: 20),

                // Actions
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [msBgSurface, msBgMain],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: msGold.withOpacity(0.4), width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'BATAL',
                              style: TextStyle(
                                color: msTextSub,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _addVps();
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [msRed, msRedDark],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: msBorderDark, width: 2),
                            boxShadow: [
                              const BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                              BoxShadow(
                                color: msRed.withOpacity(0.5),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              'TAMBAH',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    String hint = '',
    bool isPassword = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: msTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [msBgSurface, msBgMain],
              ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: msGold.withOpacity(0.5), width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: TextField(
              controller: controller,
              obscureText: isPassword,
              style: TextStyle(
                color: msTextMain,
                fontSize: 13,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w600,
              ),
              cursorColor: msGold,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: msTextSub.withOpacity(0.5),
                  fontSize: 12,
                ),
                prefixIcon: Icon(icon, color: msGold, size: 16),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          msTextMain.withOpacity(0.20),
          msRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? msGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [msBgCard, msBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: msBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(msBgMain, msRed, 0.25)!,
                  msBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: _fetchVpsList,
                      color: msGold,
                      backgroundColor: msBgCard,
                      child: isLoading && vpsList.isEmpty
                          ? _buildLoading()
                          : vpsList.isEmpty
                              ? _buildEmptyState()
                              : _buildVpsList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 12, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [msBgSurface, msBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: msGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: msGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [msRed, msRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: msBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [msRed, msRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: msBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: msGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.dns_rounded, color: msGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'MANAGE SERVER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Tombol refresh
          GestureDetector(
            onTap: _fetchVpsList,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [msGold, Color.lerp(msGold, Colors.black, 0.4)!],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: msBorderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Icon(Icons.refresh_rounded,
                  color: msRedDark, size: 18),
            ),
          ),
          const SizedBox(width: 8),
          // Tombol add
          GestureDetector(
            onTap: _showAddDialog,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [msRed, msRedDark],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: msBorderDark, width: 2),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                  BoxShadow(
                    color: msRed.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.add_rounded,
                  color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOADING
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _bevelBox(
            radius: 100,
            glow: msGold,
            glowOpacity: 0.4,
            child: Container(
              width: 90,
              height: 90,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: msGold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'MEMUAT DATA...',
            style: TextStyle(
              color: msTextSub,
              fontSize: 11,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildEmptyState() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SizedBox(height: 60),
        Column(
          children: [
            _bevelBox(
              radius: 100,
              glow: msGold,
              glowOpacity: 0.4,
              child: Container(
                width: 120,
                height: 120,
                alignment: Alignment.center,
                decoration: const BoxDecoration(shape: BoxShape.circle),
                child: Icon(
                  Icons.dns_rounded,
                  size: 56,
                  color: msGold,
                  shadows: [
                    Shadow(
                      color: msGold.withOpacity(0.7),
                      blurRadius: 20,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Belum Ada VPS',
              style: TextStyle(
                color: msTextMain,
                fontSize: 20,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                shadows: [
                  Shadow(
                    color: msGold.withOpacity(0.6),
                    blurRadius: 14,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                'Tambahkan VPS untuk mengaktifkan fitur remote command',
                style: TextStyle(
                  color: msTextSub,
                  fontSize: 13,
                  height: 1.6,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: _showAddDialog,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 30, vertical: 14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [msRed, msRedDark],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: msBorderDark, width: 2.5),
                  boxShadow: [
                    const BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(4, 4),
                    ),
                    BoxShadow(
                      color: msRed.withOpacity(0.5),
                      blurRadius: 16,
                      spreadRadius: -3,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.add_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'TAMBAH VPS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // VPS LIST
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildVpsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: vpsList.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) return _buildStatsCard();

        final vps = vpsList[index - 1];
        return _buildVpsCard(vps, index - 1);
      },
    );
  }

  Widget _buildStatsCard() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: _bevelBox(
        radius: 18,
        glow: msGold,
        glowOpacity: 0.35,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [msGold, Color.lerp(msGold, Colors.black, 0.4)!],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: msBorderDark, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: msGold.withOpacity(0.5),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Icon(Icons.cloud_done_rounded,
                    color: msRedDark, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'TOTAL SERVER',
                      style: TextStyle(
                        color: msTextSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${vpsList.length} VPS',
                      style: TextStyle(
                        color: msTextMain,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: msGold.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                          const Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      msGreen.withOpacity(0.3),
                      msGreen.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: msGreen.withOpacity(0.5), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: msGreen.withOpacity(0.3),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: msGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: msGreen,
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'ONLINE',
                      style: TextStyle(
                        color: msGreen,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVpsCard(Map<String, dynamic> vps, int index) {
    final host = vps['host']?.toString() ?? '-';
    final username = vps['username']?.toString() ?? '-';
    final number = (index + 1).toString().padLeft(2, '0');

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: _bevelBox(
        radius: 18,
        glow: msGold,
        glowOpacity: 0.2,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  // Index badge
                  Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [msRed, msRedDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: msBorderDark, width: 2),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      number,
                      style: TextStyle(
                        color: msGold,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: msGold.withOpacity(0.7),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.dns_rounded,
                                color: msGold, size: 12),
                            const SizedBox(width: 4),
                            Text(
                              'HOST',
                              style: TextStyle(
                                color: msTextSub,
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        SelectableText(
                          host,
                          style: TextStyle(
                            color: msTextMain,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Icon(Icons.person_rounded,
                                color: msGold, size: 12),
                            const SizedBox(width: 4),
                            Text(
                              username,
                              style: TextStyle(
                                color: msTextSub,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Delete button
                  GestureDetector(
                    onTap: () => _deleteVps(host),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [msRed, msRedDark],
                        ),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: msBorderDark, width: 2),
                        boxShadow: [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                          BoxShadow(
                            color: msRed.withOpacity(0.4),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.delete_outline_rounded,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}