// lib/features/tools/network/FreeFireLagServer.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color ffBgMain = const Color(0xFF160A07);
Color ffBgSurface = const Color(0xFF2A140E);
Color ffBgCard = const Color(0xFF3A1E15);
Color ffTextMain = const Color(0xFFF3E6DD);
Color ffTextSub = const Color(0xFFC9913F);
Color ffGold = const Color(0xFFD4A853);
Color ffRed = const Color(0xFFB71C1C);
Color ffRedDark = const Color(0xFF7F0000);
Color ffRedDeep = const Color(0xFF4A0000);
Color ffGreen = const Color(0xFF4CAF50);
Color ffBlue = const Color(0xFF2196F3);
Color ffCyan = const Color(0xFF00BCD4);
Color ffYellow = const Color(0xFFFFC107);
Color ffBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  ffBgMain     = theme.brownDark;
  ffBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  ffBgCard     = theme.brownMid;
  ffTextMain   = theme.bgCreamLight;
  ffTextSub    = theme.gold;
  ffGold       = theme.gold;
  ffRed        = theme.redMain;
  ffRedDark    = theme.redDark;
  ffRedDeep    = theme.redDeep;
  ffGreen      = theme.accentGreen;
  ffBlue       = theme.accentBlue;
  ffCyan       = theme.goldLight;
  ffYellow     = theme.accentYellow;
  ffBorderDark = theme.borderDark;
}

class FreeFireLagServerPage extends StatefulWidget {
  const FreeFireLagServerPage({super.key});

  @override
  State<FreeFireLagServerPage> createState() => _FreeFireLagServerPageState();
}

class _FreeFireLagServerPageState extends State<FreeFireLagServerPage> {
  bool _isAttacking = false;
  int _packetCount = 0;
  int _packetPerSecond = 0;
  int _peakPps = 0;
  Duration _elapsed = Duration.zero;
  Timer? _attackTimer;
  Timer? _statsTimer;
  Timer? _logTimer;
  Timer? _elapsedTimer;
  final List<String> _attackLogs = [];
  final ScrollController _scrollController = ScrollController();

  final XThemeController _themeController = XThemeController();

  final List<Map<String, dynamic>> _servers = [
    {'name': 'SG Server 1', 'ip': '203.116.115.10', 'flag': '🇸🇬'},
    {'name': 'SG Server 2', 'ip': '203.116.115.11', 'flag': '🇸🇬'},
    {'name': 'ID Server 1', 'ip': '47.246.0.10', 'flag': '🇮🇩'},
    {'name': 'ID Server 2', 'ip': '47.246.0.11', 'flag': '🇮🇩'},
    {'name': 'MY Server 1', 'ip': '103.219.76.10', 'flag': '🇲🇾'},
    {'name': 'MY Server 2', 'ip': '103.219.76.11', 'flag': '🇲🇾'},
  ];

  @override
  void dispose() {
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _elapsedTimer?.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // START / STOP
  // ═══════════════════════════════════════════════════════════════════
  void _startAttack() {
    if (_isAttacking) return;

    setState(() {
      _isAttacking = true;
      _packetCount = 0;
      _packetPerSecond = 0;
      _peakPps = 0;
      _elapsed = Duration.zero;
      _attackLogs.clear();
    });

    HapticFeedback.heavyImpact();

    // Simulasi packet
    _attackTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (!_isAttacking) {
        timer.cancel();
        return;
      }
      setState(() {
        _packetCount += Random().nextInt(150) + 50;
        _packetPerSecond += Random().nextInt(100) + 30;
        if (_packetPerSecond > _peakPps) _peakPps = _packetPerSecond;
      });
    });

    // Reset PPS setiap detik
    _statsTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isAttacking) {
        timer.cancel();
        return;
      }
      setState(() => _packetPerSecond = 0);
    });

    // Elapsed time
    _elapsedTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isAttacking) {
        timer.cancel();
        return;
      }
      setState(() => _elapsed += const Duration(seconds: 1));
    });

    // Log setiap 700ms
    _logTimer = Timer.periodic(const Duration(milliseconds: 700), (timer) {
      if (!_isAttacking) {
        timer.cancel();
        return;
      }
      final server = _servers[Random().nextInt(_servers.length)];
      _attackLogs.insert(
        0,
        '${DateTime.now().toLocal().toString().substring(11, 19)} → ${server['flag']} ${server['name']} (${server['ip']})',
      );
      if (_attackLogs.length > 25) _attackLogs.removeLast();
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _stopAttack() {
    if (!_isAttacking) return;
    setState(() => _isAttacking = false);
    HapticFeedback.lightImpact();
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _elapsedTimer?.cancel();
    _attackTimer = null;
    _statsTimer = null;
    _logTimer = null;
    _elapsedTimer = null;
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          ffTextMain.withOpacity(0.20),
          ffRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? ffGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [ffBgCard, ffBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: ffBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(ffBgMain, ffRed, 0.25)!,
                  ffBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: Column(
                      children: [
                        // Status card
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                          child: _buildStatusCard(),
                        ),

                        // Stats row
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                          child: _buildStatsRow(),
                        ),

                        const SizedBox(height: 16),

                        // Logs
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: _buildLogsSection(),
                          ),
                        ),

                        // Buttons
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: _buildButtons(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [ffBgSurface, ffBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: ffGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: ffGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [ffRed, ffRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ffBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [ffRed, ffRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: ffBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: ffGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_fire_department_rounded,
                      color: ffGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'FF LAG SERVER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Status indicator
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _isAttacking
                    ? [ffRed, ffRedDark]
                    : [ffGreen, Color.lerp(ffGreen, Colors.black, 0.4)!],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: ffBorderDark, width: 2),
              boxShadow: [
                BoxShadow(
                  color: (_isAttacking ? ffRed : ffGreen).withOpacity(0.6),
                  blurRadius: 12,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.8),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _isAttacking ? 'ON' : 'OFF',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATUS CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusCard() {
    return _bevelBox(
      radius: 20,
      glow: _isAttacking ? ffRed : ffGold,
      glowOpacity: _isAttacking ? 0.55 : 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            // Icon with pulse animation
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: _isAttacking
                    ? LinearGradient(
                        colors: [
                          ffRed,
                          Color.lerp(ffRed, Colors.black, 0.5)!,
                        ],
                      )
                    : LinearGradient(
                        colors: [
                          ffGold,
                          Color.lerp(ffGold, Colors.black, 0.5)!,
                        ],
                      ),
                shape: BoxShape.circle,
                border: Border.all(color: ffBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: (_isAttacking ? ffRed : ffGold)
                        .withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(
                _isAttacking
                    ? Icons.whatshot_rounded
                    : Icons.flash_on_rounded,
                size: 28,
                color: Colors.white,
                shadows: const [
                  Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _isAttacking ? '🔥 ATTACKING...' : '⚡ READY',
                    style: TextStyle(
                      color: _isAttacking ? ffYellow : ffTextMain,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: (_isAttacking ? ffRed : ffGold)
                              .withOpacity(0.7),
                          blurRadius: 12,
                        ),
                        const Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isAttacking
                        ? 'Targeting ${_servers.length} servers'
                        : 'Tekan START untuk memulai',
                    style: TextStyle(
                      color: ffTextSub,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (_isAttacking) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.timer_rounded,
                            color: ffGold, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _formatDuration(_elapsed),
                          style: TextStyle(
                            color: ffGold,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATS ROW 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.inventory_2_rounded,
            label: 'PACKETS',
            value: _formatNumber(_packetCount),
            color: ffCyan,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.bolt_rounded,
            label: 'PPS',
            value: '$_packetPerSecond',
            color: ffGreen,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.gps_fixed_rounded,
            label: 'TARGET',
            value: '${_servers.length}',
            color: ffYellow,
          ),
        ),
      ],
    );
  }

  String _formatNumber(int n) {
    if (n < 1000) return n.toString();
    if (n < 1000000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '${(n / 1000000).toStringAsFixed(2)}M';
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return _bevelBox(
      radius: 14,
      glow: color,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.4), width: 1.5),
              ),
              child: Icon(icon, color: color, size: 14),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                    color: color.withOpacity(0.6),
                    blurRadius: 10,
                  ),
                  const Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: ffTextSub,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOGS SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLogsSection() {
    return _bevelBox(
      radius: 18,
      glow: ffGold,
      glowOpacity: 0.25,
      child: Container(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        ffGold,
                        Color.lerp(ffGold, Colors.black, 0.4)!
                      ],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: ffBorderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: ffGold.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Icon(Icons.radar_rounded,
                      color: ffRedDark, size: 12),
                ),
                const SizedBox(width: 8),
                Text(
                  'LIVE LOGS',
                  style: TextStyle(
                    color: ffTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: ffGold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: ffGold.withOpacity(0.4), width: 1),
                  ),
                  child: Text(
                    '${_attackLogs.length}',
                    style: TextStyle(
                      color: ffGold,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _attackLogs.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: ffGold.withOpacity(0.1),
                              border: Border.all(
                                  color: ffGold.withOpacity(0.3),
                                  width: 2),
                            ),
                            child: Icon(
                              _isAttacking
                                  ? Icons.hourglass_top_rounded
                                  : Icons.hotel_rounded,
                              color: ffGold.withOpacity(0.7),
                              size: 28,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _isAttacking
                                ? '⏳ Menunggu packet...'
                                : '💤 Belum ada aktivitas',
                            style: TextStyle(
                              color: ffTextSub,
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      reverse: true,
                      itemCount: _attackLogs.length,
                      itemBuilder: (context, index) {
                        final log = _attackLogs[index];
                        final isNew = index == 0;
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.symmetric(vertical: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: isNew
                                ? LinearGradient(
                                    colors: [
                                      ffRed.withOpacity(0.25),
                                      ffRed.withOpacity(0.08),
                                    ],
                                  )
                                : null,
                            color: isNew ? null : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            border: isNew
                                ? Border.all(
                                    color: ffRed.withOpacity(0.5),
                                    width: 1)
                                : null,
                            boxShadow: isNew
                                ? [
                                    BoxShadow(
                                      color: ffRed.withOpacity(0.35),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Row(
                            children: [
                              if (isNew)
                                Container(
                                  width: 6,
                                  height: 6,
                                  margin: const EdgeInsets.only(right: 8),
                                  decoration: BoxDecoration(
                                    color: ffRed,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: ffRed,
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                )
                              else
                                Container(
                                  width: 6,
                                  height: 6,
                                  margin: const EdgeInsets.only(right: 8),
                                  decoration: BoxDecoration(
                                    color: ffTextSub.withOpacity(0.4),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              Expanded(
                                child: Text(
                                  log,
                                  style: TextStyle(
                                    color: isNew ? ffYellow : ffTextSub,
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight:
                                        isNew ? FontWeight.w700 : FontWeight.w500,
                                    shadows: isNew
                                        ? [
                                            Shadow(
                                              color: ffYellow
                                                  .withOpacity(0.6),
                                              blurRadius: 6,
                                            ),
                                          ]
                                        : null,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUTTONS 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildButtons() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: _isAttacking ? null : _startAttack,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                gradient: _isAttacking
                    ? LinearGradient(
                        colors: [
                          ffTextSub.withOpacity(0.3),
                          ffTextSub.withOpacity(0.1),
                        ],
                      )
                    : LinearGradient(
                        colors: [
                          ffRed,
                          Color.lerp(ffRed, Colors.black, 0.5)!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _isAttacking
                      ? ffTextSub.withOpacity(0.3)
                      : ffBorderDark,
                  width: 2.5,
                ),
                boxShadow: _isAttacking
                    ? null
                    : [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(4, 4),
                        ),
                        BoxShadow(
                          color: ffRed.withOpacity(0.5),
                          blurRadius: 16,
                          spreadRadius: -3,
                        ),
                      ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.play_arrow_rounded,
                      color: _isAttacking
                          ? ffTextSub.withOpacity(0.5)
                          : Colors.white,
                      size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'START',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      color: _isAttacking
                          ? ffTextSub.withOpacity(0.5)
                          : Colors.white,
                      shadows: _isAttacking
                          ? null
                          : const [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: _isAttacking ? _stopAttack : null,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                gradient: _isAttacking
                    ? LinearGradient(
                        colors: [
                          ffTextMain,
                          Color.lerp(ffTextMain, Colors.black, 0.5)!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : LinearGradient(
                        colors: [
                          ffTextSub.withOpacity(0.3),
                          ffTextSub.withOpacity(0.1),
                        ],
                      ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _isAttacking
                      ? ffBorderDark
                      : ffTextSub.withOpacity(0.3),
                  width: 2.5,
                ),
                boxShadow: _isAttacking
                    ? [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(4, 4),
                        ),
                        BoxShadow(
                          color: ffTextMain.withOpacity(0.3),
                          blurRadius: 16,
                          spreadRadius: -3,
                        ),
                      ]
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.stop_rounded,
                      color: _isAttacking
                          ? ffRedDark
                          : ffTextSub.withOpacity(0.5),
                      size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'STOP',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      color: _isAttacking
                          ? ffRedDark
                          : ffTextSub.withOpacity(0.5),
                      shadows: _isAttacking
                          ? const [
                              Shadow(
                                color: Color(0x44000000),
                                blurRadius: 2,
                                offset: Offset(1, 1),
                              ),
                            ]
                          : null,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}