// lib/features/tools/network/spam_ngl.dart
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color nglBgMain = const Color(0xFF160A07);
Color nglBgSurface = const Color(0xFF2A140E);
Color nglBgCard = const Color(0xFF3A1E15);
Color nglTextMain = const Color(0xFFF3E6DD);
Color nglTextSub = const Color(0xFFC9913F);
Color nglGold = const Color(0xFFD4A853);
Color nglRed = const Color(0xFFB71C1C);
Color nglRedDark = const Color(0xFF7F0000);
Color nglRedDeep = const Color(0xFF4A0000);
Color nglGreen = const Color(0xFF4CAF50);
Color nglBlue = const Color(0xFF2196F3);
Color nglYellow = const Color(0xFFFFC107);
Color nglBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  nglBgMain     = theme.brownDark;
  nglBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  nglBgCard     = theme.brownMid;
  nglTextMain   = theme.bgCreamLight;
  nglTextSub    = theme.gold;
  nglGold       = theme.gold;
  nglRed        = theme.redMain;
  nglRedDark    = theme.redDark;
  nglRedDeep    = theme.redDeep;
  nglGreen      = theme.accentGreen;
  nglBlue       = theme.accentBlue;
  nglYellow     = theme.accentYellow;
  nglBorderDark = theme.borderDark;
}

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();
  final TextEditingController intervalController =
      TextEditingController(text: '2');
  final TextEditingController limitController =
      TextEditingController(text: '0');

  bool isRunning = false;
  int counter = 0;
  int failCount = 0;
  int _startTime = 0;
  Duration _elapsed = Duration.zero;
  Timer? timer;
  Timer? elapsedTimer;
  final List<Map<String, dynamic>> _logHistory = [];
  final ScrollController _logScroll = ScrollController();

  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    timer?.cancel();
    elapsedTimer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    intervalController.dispose();
    limitController.dispose();
    _logScroll.dispose();
    super.dispose();
  }

  // ─── Random Device ID ─────────────────────────────────────────────
  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16)).join();
  }

  // ─── Send Message ─────────────────────────────────────────────────
  Future<bool> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http
          .post(url, headers: headers, body: body)
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        if (!mounted) return true;
        setState(() {
          counter++;
          _addLog("✅ [$counter] Terkirim", nglGreen);
        });
        return true;
      } else if (response.statusCode == 429) {
        if (!mounted) return false;
        setState(() {
          failCount++;
          _addLog(
              "❌ Ratelimit 429 — tunggu 5 detik", nglYellow);
        });
        await Future.delayed(const Duration(seconds: 5));
        return false;
      } else {
        if (!mounted) return false;
        setState(() {
          failCount++;
          _addLog(
              "❌ Error ${response.statusCode}", nglRed);
        });
        await Future.delayed(const Duration(seconds: 2));
        return false;
      }
    } catch (e) {
      if (!mounted) return false;
      setState(() {
        failCount++;
        _addLog("⚠️ Koneksi error: $e", nglYellow);
      });
      await Future.delayed(const Duration(seconds: 2));
      return false;
    }
  }

  // ─── Start Loop ───────────────────────────────────────────────────
  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();
    final interval = int.tryParse(intervalController.text) ?? 2;
    final limit = int.tryParse(limitController.text) ?? 0;

    if (username.isEmpty || message.isEmpty) {
      _showSnack("⚠️ Harap isi username & pesan!", isError: true);
      return;
    }

    if (interval < 1) {
      _showSnack("⚠️ Interval minimal 1 detik!", isError: true);
      return;
    }

    setState(() {
      isRunning = true;
      counter = 0;
      failCount = 0;
      _elapsed = Duration.zero;
      _startTime = DateTime.now().millisecondsSinceEpoch;
      _logHistory.clear();
      _addLog("▶️ Mulai mengirim ke @$username", nglGreen);
    });

    HapticFeedback.mediumImpact();

    // Loop
    timer = Timer.periodic(Duration(seconds: interval), (_) async {
      if (!isRunning) return;

      // Cek limit
      if (limit > 0 && counter >= limit) {
        _addLog("🎯 Target $limit pesan tercapai. Stop.", nglGold);
        stopLoop();
        return;
      }

      await sendMessage(username, message);
    });

    // Elapsed timer
    elapsedTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!isRunning) return;
      if (mounted) {
        setState(() {
          _elapsed = Duration(
            milliseconds:
                DateTime.now().millisecondsSinceEpoch - _startTime,
          );
        });
      }
    });
  }

  // ─── Stop Loop ────────────────────────────────────────────────────
  void stopLoop() {
    setState(() {
      isRunning = false;
      _addLog("⏹️ Dihentikan", nglYellow);
    });
    HapticFeedback.lightImpact();
    timer?.cancel();
    elapsedTimer?.cancel();
    timer = null;
    elapsedTimer = null;
  }

  void _addLog(String text, Color color) {
    _logHistory.insert(0, {
      'time': DateTime.now(),
      'text': text,
      'color': color,
    });
    if (_logHistory.length > 100) _logHistory.removeLast();
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: nglTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? nglRed : nglGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: nglBorderDark, width: 2),
        ),
      ),
    );
  }

  String _formatDuration(Duration d) {
    final h = d.inHours;
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    if (h > 0) return '${h.toString().padLeft(2, '0')}:$m:$s';
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          nglTextMain.withOpacity(0.20),
          nglRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? nglGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [nglBgCard, nglBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: nglBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(nglBgMain, nglRed, 0.25)!,
                  nglBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 14),
                          _buildControlSection(),
                          const SizedBox(height: 14),
                          _buildStatusSection(),
                          const SizedBox(height: 14),
                          _buildLogsSection(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [nglBgSurface, nglBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: nglGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: nglGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nglRed, nglRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: nglBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nglRed, nglRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: nglBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: nglGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.send_rounded, color: nglGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'NGL AUTO SENDER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Status badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isRunning
                    ? [nglGreen, Color.lerp(nglGreen, Colors.black, 0.4)!]
                    : [nglRed, nglRedDark],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: nglBorderDark, width: 2),
              boxShadow: [
                BoxShadow(
                  color: (isRunning ? nglGreen : nglRed).withOpacity(0.6),
                  blurRadius: 12,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.8),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  isRunning ? 'RUN' : 'IDLE',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: nglGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('KONFIGURASI', Icons.tune_rounded),
            const SizedBox(height: 16),

            // Username
            _buildInputField(
              label: 'Username NGL',
              controller: usernameController,
              icon: Icons.person_rounded,
              hint: 'contoh: username_ngl',
              enabled: !isRunning,
            ),
            const SizedBox(height: 12),

            // Pesan
            _buildInputField(
              label: 'Pesan',
              controller: messageController,
              icon: Icons.message_rounded,
              hint: 'Masukkan pesan yang ingin dikirim...',
              maxLines: 3,
              enabled: !isRunning,
            ),
            const SizedBox(height: 12),

            // Interval & Limit
            Row(
              children: [
                Expanded(
                  child: _buildInputField(
                    label: 'Interval (detik)',
                    controller: intervalController,
                    icon: Icons.timer_rounded,
                    hint: '2',
                    keyboardType: TextInputType.number,
                    enabled: !isRunning,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildInputField(
                    label: 'Limit (0=∞)',
                    controller: limitController,
                    icon: Icons.speed_rounded,
                    hint: '0',
                    keyboardType: TextInputType.number,
                    enabled: !isRunning,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [nglGold, Color.lerp(nglGold, Colors.black, 0.4)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: nglBorderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: nglRedDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: TextStyle(
            color: nglTextMain,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 3,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    String hint = '',
    int maxLines = 1,
    TextInputType? keyboardType,
    bool enabled = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: nglTextSub,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [nglBgSurface, nglBgMain],
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: nglGold.withOpacity(enabled ? 0.5 : 0.2),
              width: 2,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: TextField(
            controller: controller,
            enabled: enabled,
            keyboardType: keyboardType,
            maxLines: maxLines,
            style: TextStyle(
              color: enabled ? nglTextMain : nglTextSub,
              fontSize: 13,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w600,
            ),
            cursorColor: nglGold,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: nglTextSub.withOpacity(0.5),
                fontSize: 12,
              ),
              prefixIcon: Icon(icon, color: nglGold, size: 16),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // CONTROL SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildControlSection() {
    return _bevelBox(
      radius: 20,
      glow: nglGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Expanded(
              child: _buildControlButton(
                label: 'START',
                icon: Icons.play_arrow_rounded,
                color: nglGreen,
                enabled: !isRunning,
                onTap: startLoop,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildControlButton(
                label: 'STOP',
                icon: Icons.stop_rounded,
                color: nglRed,
                enabled: isRunning,
                onTap: stopLoop,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required String label,
    required IconData icon,
    required Color color,
    required bool enabled,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: enabled
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    nglTextSub.withOpacity(0.2),
                    nglTextSub.withOpacity(0.08),
                  ],
                ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: enabled
                ? nglBorderDark
                : nglTextSub.withOpacity(0.3),
            width: 2.5,
          ),
          boxShadow: enabled
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: enabled
                  ? Colors.white
                  : nglTextSub.withOpacity(0.5),
              size: 18,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: enabled
                    ? Colors.white
                    : nglTextSub.withOpacity(0.5),
                fontSize: 12,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1.2,
                shadows: enabled
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATUS SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusSection() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.check_circle_rounded,
            label: 'TERKIRIM',
            value: '$counter',
            color: nglGreen,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.error_rounded,
            label: 'GAGAL',
            value: '$failCount',
            color: nglRed,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: Icons.timer_rounded,
            label: 'ELAPSED',
            value: _formatDuration(_elapsed),
            color: nglGold,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return _bevelBox(
      radius: 14,
      glow: color,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.4), width: 1.5),
              ),
              child: Icon(icon, color: color, size: 14),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                    color: color.withOpacity(0.6),
                    blurRadius: 10,
                  ),
                  const Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: nglTextSub,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOGS SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLogsSection() {
    return _bevelBox(
      radius: 18,
      glow: nglGold,
      glowOpacity: 0.25,
      child: Container(
        padding: const EdgeInsets.all(12),
        height: 260,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        nglGold,
                        Color.lerp(nglGold, Colors.black, 0.4)!
                      ],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: nglBorderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: nglGold.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Icon(Icons.radar_rounded,
                      color: nglRedDark, size: 12),
                ),
                const SizedBox(width: 8),
                Text(
                  'STATUS LOG',
                  style: TextStyle(
                    color: nglTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: nglGold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: nglGold.withOpacity(0.4), width: 1),
                  ),
                  child: Text(
                    '${_logHistory.length}',
                    style: TextStyle(
                      color: nglGold,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _logHistory.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: nglGold.withOpacity(0.1),
                              border: Border.all(
                                  color: nglGold.withOpacity(0.3),
                                  width: 2),
                            ),
                            child: Icon(
                              isRunning
                                  ? Icons.hourglass_top_rounded
                                  : Icons.hourglass_empty_rounded,
                              color: nglGold.withOpacity(0.7),
                              size: 28,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            isRunning
                                ? '⏳ Menunggu log...'
                                : '💤 Belum ada aktivitas',
                            style: TextStyle(
                              color: nglTextSub,
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _logScroll,
                      reverse: true,
                      itemCount: _logHistory.length,
                      itemBuilder: (context, index) {
                        final log = _logHistory[index];
                        final isNew = index == 0;
                        final logColor = log['color'] as Color;
                        final logTime = log['time'] as DateTime;

                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.symmetric(vertical: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: isNew
                                ? LinearGradient(
                                    colors: [
                                      logColor.withOpacity(0.25),
                                      logColor.withOpacity(0.08),
                                    ],
                                  )
                                : null,
                            color: isNew ? null : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            border: isNew
                                ? Border.all(
                                    color: logColor.withOpacity(0.5),
                                    width: 1,
                                  )
                                : null,
                            boxShadow: isNew
                                ? [
                                    BoxShadow(
                                      color: logColor.withOpacity(0.35),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Row(
                            children: [
                              Text(
                                '${logTime.hour.toString().padLeft(2, '0')}:${logTime.minute.toString().padLeft(2, '0')}:${logTime.second.toString().padLeft(2, '0')}',
                                style: TextStyle(
                                  color: nglTextSub.withOpacity(0.7),
                                  fontSize: 10,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  log['text'].toString(),
                                  style: TextStyle(
                                    color: logColor,
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: isNew
                                        ? FontWeight.w700
                                        : FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}