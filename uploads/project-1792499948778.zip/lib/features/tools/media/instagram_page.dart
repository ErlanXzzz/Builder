// lib/features/tools/media/instagram_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../dashboard/xtheme.dart';
import '../../../core/config/apiBaseUrl.dart';

// ─── XTHEME-DRIVEN COLORS (mutable) ──────────────────────────────────
Color igBgMain = const Color(0xFF160A07);
Color igBgSurface = const Color(0xFF2A140E);
Color igBgCard = const Color(0xFF3A1E15);
Color igBgElevated = const Color(0xFF4A2818);
Color igTextMain = const Color(0xFFF3E6DD);
Color igTextSub = const Color(0xFFC9913F);
Color igAccent = const Color(0xFFE0763F);
Color igAccentDeep = const Color(0xFF9C3B22);
Color igRed = const Color(0xFFB71C1C);
Color igRedDark = const Color(0xFF7F0000);
Color igRedDeep = const Color(0xFF4A0000);
Color igGold = const Color(0xFFD4A853);
Color igGreen = const Color(0xFF4CAF50);
Color igBlue = const Color(0xFF2196F3);
Color igBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  igBgMain     = theme.brownDark;
  igBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  igBgCard     = theme.brownMid;
  igBgElevated = Color.lerp(theme.brownMid, theme.bgCreamLight, 0.15)!;
  igTextMain   = theme.bgCreamLight;
  igTextSub    = theme.gold;
  igAccent     = theme.gold;
  igAccentDeep = theme.goldDark;
  igRed        = theme.redMain;
  igRedDark    = theme.redDark;
  igRedDeep    = theme.redDeep;
  igGold       = theme.gold;
  igGreen      = theme.accentGreen;
  igBlue       = theme.accentBlue;
  igBorderDark = theme.borderDark;
}

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() =>
      _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isDownloading = false;
  List<dynamic>? _mediaData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  double _downloadProgress = 0.0;
  int _downloadingIndex = -1;

  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // API: FETCH INSTAGRAM MEDIA
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      _setError("URL Instagram tidak boleh kosong.");
      return;
    }

    if (!url.contains('instagram.com') && !url.contains('instagr.am')) {
      _setError("URL tidak valid. Pastikan dari Instagram.");
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _videoController?.dispose();
      _videoController = null;
      _chewieController?.dispose();
      _chewieController = null;
    });

    final encodedUrl = Uri.encodeComponent(url);
    final apiUrl = Uri.parse(
        "$apiBaseUrl/api/instagram/download?url=$encodedUrl");

    try {
      final response =
          await http.get(apiUrl).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _mediaData = json['data']);
        } else {
          _setError(json['message'] ?? "Gagal mengambil data Instagram.");
        }
      } else {
        _setError("Gagal terhubung ke server (${response.statusCode}).");
      }
    } catch (e) {
      _setError("Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _setError(String msg) {
    if (!mounted) return;
    setState(() => _errorMessage = msg);
  }

  // ═══════════════════════════════════════════════════════════════════
  // VIDEO PLAYER
  // ═══════════════════════════════════════════════════════════════════
  void _playVideo(String videoUrl) {
    _videoController?.dispose();
    _chewieController?.dispose();

    _videoController =
        VideoPlayerController.networkUrl(Uri.parse(videoUrl))
          ..initialize().then((_) {
            if (!mounted) return;
            setState(() {
              _chewieController = ChewieController(
                videoPlayerController: _videoController!,
                autoPlay: true,
                looping: false,
                showControls: true,
                aspectRatio: _videoController!.value.aspectRatio,
                materialProgressColors: ChewieProgressColors(
                  playedColor: igGold,
                  handleColor: igGold,
                  backgroundColor: igTextSub.withOpacity(0.3),
                  bufferedColor: igTextSub.withOpacity(0.2),
                ),
              );
            });
          }).catchError((e) {
            _setError("Gagal memuat video: $e");
          });
  }

  void _closePlayer() {
    _videoController?.dispose();
    _chewieController?.dispose();
    setState(() {
      _videoController = null;
      _chewieController = null;
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // SAVE MEDIA (video / image)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _saveMedia(int index, String url, bool isVideo) async {
    setState(() {
      _isDownloading = true;
      _downloadingIndex = index;
      _downloadProgress = 0.0;
    });

    try {
      final response = await http.get(Uri.parse(url));

      setState(() => _downloadProgress = 0.6);

      Directory? directory;
      if (Platform.isAndroid) {
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        directory = await getApplicationDocumentsDirectory();
      }

      final ext = isVideo ? 'mp4' : 'jpg';
      final fileName =
          'instagram_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final file = File('${directory!.path}/$fileName');
      await file.writeAsBytes(response.bodyBytes);

      setState(() => _downloadProgress = 1.0);

      _showSnack("✅ Disimpan di: ${file.path}", isError: false);
    } catch (e) {
      _showSnack("❌ Gagal menyimpan: $e", isError: true);
    } finally {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) {
            setState(() {
              _isDownloading = false;
              _downloadingIndex = -1;
              _downloadProgress = 0.0;
            });
          }
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SHARE MEDIA
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _shareMedia(String url, bool isVideo) async {
    try {
      _showSnack("⏳ Menyiapkan...", isError: false);

      final response = await http.get(Uri.parse(url));
      final tempDir = await getTemporaryDirectory();
      final ext = isVideo ? 'mp4' : 'jpg';
      final file = File(
          '${tempDir.path}/instagram_${DateTime.now().millisecondsSinceEpoch}.$ext');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Media dari Instagram',
      );
    } catch (e) {
      _showSnack("❌ Error sharing: $e", isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // COPY URL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _copyUrl(String url) async {
    if (url.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: url));
    _showSnack("📋 URL disalin!", isError: false);
  }

  // ═══════════════════════════════════════════════════════════════════
  // OPEN ORIGINAL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _openOriginal() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showSnack("❌ Tidak bisa membuka URL: $e", isError: true);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: igTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? igRed : igGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: igBorderDark, width: 2),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? fill,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: fill ??
          LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              igTextMain.withOpacity(0.20),
              igRed.withOpacity(0.15),
              Colors.black.withOpacity(0.55),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? igGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? innerFill,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: innerFill ??
              LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [igBgCard, igBgMain],
              ),
        ),
        child: child,
      ),
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          colors: [
            color,
            Color.lerp(color, Colors.black, 0.5)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: color.withOpacity(0.5),
            blurRadius: 16,
            spreadRadius: -3,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: igBorderDark, width: 2.5),
          ),
        ),
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 18, color: Colors.white),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: igBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(igBgMain, igRed, 0.25)!,
                  igBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          if (_chewieController != null) ...[
                            const SizedBox(height: 16),
                            _buildVideoPlayerCard(),
                          ],
                          if (_mediaData != null && _chewieController == null) ...[
                            const SizedBox(height: 16),
                            _buildMediaGallery(),
                          ],
                          if (_mediaData == null &&
                              !_isLoading &&
                              _errorMessage == null)
                            _buildPlaceholder(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [igBgSurface, igBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: igGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(
            color: igGold.withOpacity(0.25),
            blurRadius: 18,
          ),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [igRed, igRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: igBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [igRed, igRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: igBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: igGold.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.camera_alt_rounded,
                      color: igGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'INSTAGRAM DOWNLOADER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                        letterSpacing: 1.2,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: igGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [igGold, igAccentDeep],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: igBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.link_rounded,
                      color: igRedDark, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MASUKKAN URL',
                  style: TextStyle(
                    color: igTextMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [igBgSurface, igBgMain],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: igGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: igGold.withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: TextField(
                controller: _urlController,
                style: TextStyle(
                  color: igTextMain,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: igGold,
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'https://www.instagram.com/reel/xxx/',
                  hintStyle: TextStyle(
                    color: igTextSub.withOpacity(0.5),
                    fontSize: 13,
                  ),
                  prefixIcon: Icon(Icons.camera_alt,
                      color: igGold, size: 18),
                  suffixIcon: _urlController.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: igTextSub, size: 18),
                          onPressed: () {
                            _urlController.clear();
                            setState(() {});
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(height: 14),
            _build3DButton(
              label: _isLoading ? 'MENGAMBIL DATA...' : 'DOWNLOAD MEDIA',
              icon: _isLoading
                  ? Icons.hourglass_top_rounded
                  : Icons.download_rounded,
              onPressed: _isLoading ? null : _downloadInstagram,
              color: igRed,
              loading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: igRed,
      glowOpacity: 0.4,
      innerFill: LinearGradient(
        colors: [
          Color.lerp(igRed, Colors.black, 0.5)!,
          igBgMain,
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: igGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: igGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: igTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // VIDEO PLAYER CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildVideoPlayerCard() {
    return _bevelBox(
      radius: 20,
      glow: igGold,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            // Header label
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [igRed, igRedDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: igBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.play_arrow_rounded,
                          color: igGold, size: 14),
                      const SizedBox(width: 6),
                      const Text(
                        "VIDEO PLAYER",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _closePlayer,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [igRed, igRedDark],
                      ),
                      shape: BoxShape.circle,
                      border:
                          Border.all(color: igBorderDark, width: 2),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.close_rounded,
                        color: Colors.white, size: 16),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Video player
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: igGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: igGold.withOpacity(0.4),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AspectRatio(
                  aspectRatio: _videoController!.value.aspectRatio,
                  child: Chewie(controller: _chewieController!),
                ),
              ),
            ),

            const SizedBox(height: 14),

            // Actions
            Row(
              children: [
                Expanded(
                  child: _build3DButton(
                    label: 'SIMPAN',
                    icon: Icons.save_alt_rounded,
                    onPressed: () {
                      final url = _mediaData?[0]['url'] ?? '';
                      if (url.isNotEmpty) _saveMedia(0, url, true);
                    },
                    color: igGreen,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _build3DButton(
                    label: 'SHARE',
                    icon: Icons.share_rounded,
                    onPressed: () {
                      final url = _mediaData?[0]['url'] ?? '';
                      if (url.isNotEmpty) _shareMedia(url, true);
                    },
                    color: igRed,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // MEDIA GALLERY 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildMediaGallery() {
    return Column(
      children: [
        // Header
        Row(
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [igRed, igRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: igBorderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.photo_library_rounded,
                      color: igGold, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    "MEDIA GALLERY (${_mediaData!.length})",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),

        // Download progress
        if (_isDownloading)
          _bevelBox(
            radius: 14,
            glow: igGreen,
            glowOpacity: 0.4,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.downloading_rounded,
                          color: igGreen, size: 18),
                      const SizedBox(width: 10),
                      Text(
                        'Menyimpan media #${_downloadingIndex + 1}...',
                        style: TextStyle(
                          color: igTextMain,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${(_downloadProgress * 100).toStringAsFixed(0)}%',
                        style: TextStyle(
                          color: igGreen,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: _downloadProgress,
                      minHeight: 6,
                      backgroundColor: igBgMain,
                      valueColor: AlwaysStoppedAnimation(igGreen),
                    ),
                  ),
                ],
              ),
            ),
          ),

        if (_isDownloading) const SizedBox(height: 14),

        // Grid
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.72,
          ),
          itemCount: _mediaData!.length,
          itemBuilder: (context, index) {
            final media = _mediaData![index];
            final isVideo = media['type'] == 'video';
            final thumb = media['thumbnail'] ?? media['url'] ?? '';
            return _buildMediaCard(index, media, isVideo, thumb);
          },
        ),
      ],
    );
  }

  Widget _buildMediaCard(
      int index, dynamic media, bool isVideo, String thumb) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [igBgCard, igBgMain],
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: igGold.withOpacity(0.2),
            blurRadius: 14,
            spreadRadius: -4,
          ),
        ],
      ),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          gradient: LinearGradient(
            colors: [igBgCard, igBgMain],
          ),
        ),
        child: Column(
          children: [
            // Thumbnail
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (isVideo) _playVideo(media['url']);
                },
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(11),
                          topRight: Radius.circular(11),
                        ),
                        child: Image.network(
                          thumb,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [igBgSurface, igBgMain],
                              ),
                            ),
                            child: Center(
                              child: Icon(
                                isVideo
                                    ? Icons.videocam_rounded
                                    : Icons.photo_rounded,
                                color: igTextSub.withOpacity(0.6),
                                size: 40,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Type badge
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isVideo
                                ? [igRed, igRedDark]
                                : [igBlue, Color.lerp(igBlue, Colors.black, 0.4)!],
                          ),
                          borderRadius: BorderRadius.circular(6),
                          border:
                              Border.all(color: igBorderDark, width: 1.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              isVideo
                                  ? Icons.videocam_rounded
                                  : Icons.photo_rounded,
                              color: Colors.white,
                              size: 10,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              isVideo ? 'VIDEO' : 'PHOTO',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    // Play button overlay
                    if (isVideo)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(11),
                              topRight: Radius.circular(11),
                            ),
                            color: Colors.black.withOpacity(0.25),
                          ),
                          alignment: Alignment.center,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [igGold, igAccentDeep],
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: igBorderDark, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: igGold.withOpacity(0.6),
                                  blurRadius: 14,
                                ),
                                const BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(2, 2),
                                ),
                              ],
                            ),
                            child: const Icon(Icons.play_arrow_rounded,
                                color: Colors.white, size: 24),
                          ),
                        ),
                      ),
                    // Index badge
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                              color: igGold.withOpacity(0.6), width: 1.5),
                        ),
                        child: Text(
                          '#${index + 1}',
                          style: TextStyle(
                            color: igGold,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Action buttons
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: _buildSmallButton(
                      icon: Icons.save_alt_rounded,
                      color: igGreen,
                      onTap: _isDownloading
                          ? null
                          : () => _saveMedia(
                              index, media['url'], isVideo),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: _buildSmallButton(
                      icon: Icons.share_rounded,
                      color: igRed,
                      onTap: () =>
                          _shareMedia(media['url'], isVideo),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: _buildSmallButton(
                      icon: Icons.copy_rounded,
                      color: igBlue,
                      onTap: () => _copyUrl(media['url']),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSmallButton({
    required IconData icon,
    required Color color,
    required VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: igBorderDark, width: 1.8),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 14),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PLACEHOLDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPlaceholder() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          _bevelBox(
            radius: 100,
            glow: igGold,
            glowOpacity: 0.4,
            child: Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                Icons.camera_alt_rounded,
                size: 56,
                color: igGold,
                shadows: [
                  Shadow(
                    color: igGold.withOpacity(0.7),
                    blurRadius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Instagram Downloader',
            style: TextStyle(
              color: igTextMain,
              fontSize: 20,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: igGold.withOpacity(0.6),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Paste URL Reel, Post, atau Story untuk mendownload media',
              style: TextStyle(
                color: igTextSub,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _buildFeatureChip(Icons.replay_rounded, 'Reel'),
              _buildFeatureChip(Icons.grid_on_rounded, 'Post'),
              _buildFeatureChip(Icons.auto_stories_rounded, 'Story'),
              _buildFeatureChip(Icons.photo_library_rounded, 'Carousel'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [igBgCard, igBgMain],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: igGold.withOpacity(0.4), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: igGold, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: igTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}