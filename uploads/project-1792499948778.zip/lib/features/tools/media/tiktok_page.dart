// lib/features/tools/media/tiktok_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../dashboard/xtheme.dart';
import '../../../core/config/apiBaseUrl.dart';

// ─── XTHEME-DRIVEN COLORS (mutable) ──────────────────────────────────
Color tkBgMain = const Color(0xFF160A07);
Color tkBgSurface = const Color(0xFF2A140E);
Color tkBgCard = const Color(0xFF3A1E15);
Color tkBgElevated = const Color(0xFF4A2818);
Color tkTextMain = const Color(0xFFF3E6DD);
Color tkTextSub = const Color(0xFFC9913F);
Color tkAccent = const Color(0xFFE0763F);
Color tkAccentDeep = const Color(0xFF9C3B22);
Color tkRed = const Color(0xFFB71C1C);
Color tkRedDark = const Color(0xFF7F0000);
Color tkRedDeep = const Color(0xFF4A0000);
Color tkGold = const Color(0xFFD4A853);
Color tkGreen = const Color(0xFF4CAF50);
Color tkRed2 = const Color(0xFFE53935);
Color tkBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  tkBgMain     = theme.brownDark;
  tkBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  tkBgCard     = theme.brownMid;
  tkBgElevated = Color.lerp(theme.brownMid, theme.bgCreamLight, 0.15)!;
  tkTextMain   = theme.bgCreamLight;
  tkTextSub    = theme.gold;
  tkAccent     = theme.gold;
  tkAccentDeep = theme.goldDark;
  tkRed        = theme.redMain;
  tkRedDark    = theme.redDark;
  tkRedDeep    = theme.redDeep;
  tkGold       = theme.gold;
  tkGreen      = theme.accentGreen;
  tkRed2       = theme.accentRed;
  tkBorderDark = theme.borderDark;
}

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isDownloading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  double _downloadProgress = 0.0;
  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // API: FETCH VIDEO DATA
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      _setError("URL TikTok tidak boleh kosong.");
      return;
    }

    // Validasi format URL
    if (!url.contains('tiktok.com') && !url.contains('vt.tiktok')) {
      _setError("URL tidak valid. Pastikan dari TikTok.");
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _videoController = null;
      _chewieController?.dispose();
      _chewieController = null;
    });

    final apiUrl =
        Uri.parse("$apiBaseUrl/api/tiktok/download?url=$url");

    try {
      final response =
          await http.get(apiUrl).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _videoData = json['data']);
          _initializeVideoPlayer();
        } else {
          _setError(json['message'] ?? "Gagal mengambil data TikTok.");
        }
      } else {
        _setError("Gagal terhubung ke server (${response.statusCode}).");
      }
    } catch (e) {
      _setError("Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _setError(String msg) {
    if (!mounted) return;
    setState(() => _errorMessage = msg);
  }

  // ═══════════════════════════════════════════════════════════════════
  // VIDEO PLAYER
  // ═══════════════════════════════════════════════════════════════════
  void _initializeVideoPlayer() {
    if (_videoData?['urls'] != null && _videoData!['urls'].isNotEmpty) {
      final videoUrl = _videoData!['urls'][0];
      _videoController =
          VideoPlayerController.networkUrl(Uri.parse(videoUrl))
            ..initialize().then((_) {
              if (!mounted) return;
              setState(() {
                _chewieController = ChewieController(
                  videoPlayerController: _videoController!,
                  autoPlay: true,
                  looping: false,
                  showControls: true,
                  aspectRatio: _videoController!.value.aspectRatio,
                  materialProgressColors: ChewieProgressColors(
                    playedColor: tkGold,
                    handleColor: tkGold,
                    backgroundColor: tkTextSub.withOpacity(0.3),
                    bufferedColor: tkTextSub.withOpacity(0.2),
                  ),
                );
              });
            }).catchError((e) {
              _setError("Gagal memuat video: $e");
            });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DOWNLOAD: SAVE TO STORAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _saveVideo() async {
    if (_videoData?['urls'] == null || _videoData!['urls'].isEmpty) return;

    setState(() {
      _isDownloading = true;
      _downloadProgress = 0.0;
    });

    try {
      final videoUrl = _videoData!['urls'][0];
      final response = await http.get(Uri.parse(videoUrl));

      setState(() => _downloadProgress = 0.7);

      Directory? directory;
      if (Platform.isAndroid) {
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        directory = await getApplicationDocumentsDirectory();
      }

      final fileName =
          'tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final file = File('${directory!.path}/$fileName');
      await file.writeAsBytes(response.bodyBytes);

      setState(() => _downloadProgress = 1.0);

      _showSnack("✅ Video disimpan di: ${file.path}", isError: false);
    } catch (e) {
      _showSnack("❌ Gagal menyimpan: $e", isError: true);
    } finally {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) {
            setState(() {
              _isDownloading = false;
              _downloadProgress = 0.0;
            });
          }
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SHARE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _shareVideo() async {
    if (_videoData?['urls'] == null || _videoData!['urls'].isEmpty) return;

    try {
      _showSnack("⏳ Menyiapkan video...", isError: false);

      final videoUrl = _videoData!['urls'][0];
      final response = await http.get(Uri.parse(videoUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text:
            'Video TikTok dari: ${_videoData!['metadata']?['creator'] ?? 'Unknown'}',
      );
    } catch (e) {
      _showSnack("❌ Error sharing: $e", isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // COPY URL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _copyUrl() async {
    final url = _videoData?['urls']?[0] ?? '';
    if (url.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: url));
    _showSnack("📋 URL video disalin!", isError: false);
  }

  // ═══════════════════════════════════════════════════════════════════
  // OPEN IN TIKTOK / BROWSER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _openOriginal() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showSnack("❌ Tidak bisa membuka URL: $e", isError: true);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: tkTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? tkRed : tkGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: tkBorderDark, width: 2),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? fill,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: fill ??
          LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              tkTextMain.withOpacity(0.20),
              tkRed.withOpacity(0.15),
              Colors.black.withOpacity(0.55),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? tkGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
    Gradient? innerFill,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: innerFill ??
              LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [tkBgCard, tkBgMain],
              ),
        ),
        child: child,
      ),
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          colors: [
            color,
            Color.lerp(color, Colors.black, 0.5)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: color.withOpacity(0.5),
            blurRadius: 16,
            spreadRadius: -3,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: tkBorderDark, width: 2.5),
          ),
        ),
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 18, color: Colors.white),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: tkBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(tkBgMain, tkRed, 0.25)!,
                  tkBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          if (_videoData != null) _buildResultSection(),
                          if (_videoData == null &&
                              !_isLoading &&
                              _errorMessage == null)
                            _buildPlaceholder(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [tkBgSurface, tkBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: tkGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(
            color: tkGold.withOpacity(0.25),
            blurRadius: 18,
          ),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [tkRed, tkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tkBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [tkRed, tkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: tkBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: tkGold.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.music_video_rounded,
                      color: tkGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'TIKTOK DOWNLOADER',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: const [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: tkGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [tkGold, tkAccentDeep],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: tkBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.link_rounded,
                      color: tkRedDark, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MASUKKAN URL',
                  style: TextStyle(
                    color: tkTextMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [tkBgSurface, tkBgMain],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tkGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: tkGold.withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: TextField(
                controller: _urlController,
                style: TextStyle(
                  color: tkTextMain,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: tkGold,
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'https://vt.tiktok.com/xxx/',
                  hintStyle: TextStyle(
                    color: tkTextSub.withOpacity(0.5),
                    fontSize: 13,
                  ),
                  prefixIcon: Icon(Icons.link, color: tkGold, size: 18),
                  suffixIcon: _urlController.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: tkTextSub, size: 18),
                          onPressed: () {
                            _urlController.clear();
                            setState(() {});
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(height: 14),
            _build3DButton(
              label: _isLoading ? 'MENGAMBIL DATA...' : 'DOWNLOAD VIDEO',
              icon: _isLoading
                  ? Icons.hourglass_top_rounded
                  : Icons.download_rounded,
              onPressed: _isLoading ? null : _downloadTiktok,
              color: tkRed,
              loading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: tkRed,
      glowOpacity: 0.4,
      innerFill: LinearGradient(
        colors: [
          Color.lerp(tkRed, Colors.black, 0.5)!,
          tkBgMain,
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: tkGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: tkGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: tkTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULT SECTION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResultSection() {
    return Column(
      children: [
        // Video preview
        _bevelBox(
          radius: 20,
          glow: tkGold,
          glowOpacity: 0.4,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                // Header label
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [tkRed, tkRedDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: tkBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.videocam, color: tkGold, size: 14),
                      const SizedBox(width: 6),
                      const Text(
                        "VIDEO PREVIEW",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Video player
                if (_chewieController != null)
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: tkGold, width: 2.5),
                      boxShadow: [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                        BoxShadow(
                          color: tkGold.withOpacity(0.4),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: AspectRatio(
                        aspectRatio:
                            _videoController!.value.aspectRatio,
                        child: Chewie(controller: _chewieController!),
                      ),
                    ),
                  )
                else
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [tkBgSurface, tkBgMain],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: tkGold, width: 2),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(color: tkGold),
                          const SizedBox(height: 16),
                          Text(
                            'Loading video...',
                            style: TextStyle(
                              color: tkTextSub,
                              fontSize: 13,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 14),

        // Video info
        if (_videoData?['metadata'] != null)
          _bevelBox(
            radius: 16,
            glow: tkGold,
            glowOpacity: 0.25,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [tkGold, tkAccentDeep],
                          ),
                          shape: BoxShape.circle,
                          border:
                              Border.all(color: tkBorderDark, width: 2),
                        ),
                        child: Icon(Icons.info_outline_rounded,
                            color: tkRedDark, size: 12),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'VIDEO INFO',
                        style: TextStyle(
                          color: tkGold,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _videoData!['metadata']['title'] ?? 'No Title',
                    style: TextStyle(
                      color: tkTextMain,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.4,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.person_rounded,
                          color: tkGold, size: 16),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          _videoData!['metadata']['creator'] ?? 'Unknown',
                          style: TextStyle(
                            color: tkTextSub,
                            fontSize: 13,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w600,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

        const SizedBox(height: 14),

        // Download progress
        if (_isDownloading)
          _bevelBox(
            radius: 14,
            glow: tkGreen,
            glowOpacity: 0.4,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.downloading_rounded,
                          color: tkGreen, size: 18),
                      const SizedBox(width: 10),
                      Text(
                        'Menyimpan video...',
                        style: TextStyle(
                          color: tkTextMain,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${(_downloadProgress * 100).toStringAsFixed(0)}%',
                        style: TextStyle(
                          color: tkGreen,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: _downloadProgress,
                      minHeight: 6,
                      backgroundColor: tkBgMain,
                      valueColor: AlwaysStoppedAnimation(tkGreen),
                    ),
                  ),
                ],
              ),
            ),
          ),

        if (_isDownloading) const SizedBox(height: 14),

        // Actions Row 1: Save + Share
        Row(
          children: [
            Expanded(
              child: _build3DButton(
                label: 'SIMPAN',
                icon: Icons.save_alt_rounded,
                onPressed: _isDownloading ? null : _saveVideo,
                color: tkGreen,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _build3DButton(
                label: 'SHARE',
                icon: Icons.share_rounded,
                onPressed: _shareVideo,
                color: tkRed,
              ),
            ),
          ],
        ),

        const SizedBox(height: 10),

        // Actions Row 2: Copy URL + Open Original
        Row(
          children: [
            Expanded(
              child: _build3DButton(
                label: 'COPY URL',
                icon: Icons.copy_rounded,
                onPressed: _copyUrl,
                color: tkRedDark,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _build3DButton(
                label: 'BUKA ASLI',
                icon: Icons.open_in_new_rounded,
                onPressed: _openOriginal,
                color: tkRedDeep,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PLACEHOLDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPlaceholder() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          _bevelBox(
            radius: 100,
            glow: tkGold,
            glowOpacity: 0.4,
            child: Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                Icons.video_library_rounded,
                size: 56,
                color: tkGold,
                shadows: [
                  Shadow(
                    color: tkGold.withOpacity(0.7),
                    blurRadius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'TikTok Downloader',
            style: TextStyle(
              color: tkTextMain,
              fontSize: 20,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: tkGold.withOpacity(0.6),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Paste URL TikTok di atas untuk mendownload video, audio, dan info creator',
              style: TextStyle(
                color: tkTextSub,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildFeatureChip(Icons.download_rounded, 'Download'),
              const SizedBox(width: 8),
              _buildFeatureChip(Icons.share_rounded, 'Share'),
              const SizedBox(width: 8),
              _buildFeatureChip(Icons.info_outline, 'Info'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [tkBgCard, tkBgMain],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tkGold.withOpacity(0.4), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: tkGold, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: tkTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}