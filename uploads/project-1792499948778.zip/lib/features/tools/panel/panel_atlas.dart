import 'dart:async';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../dashboard/xtheme.dart';
import '../../../core/config/apiBaseUrl.dart';

// ─── Pterodactyl-inspired palette, XTheme-driven ───
class _TC {
  static Color bg0 = const Color(0xFF14181D);
  static Color bg1 = const Color(0xFF1B2026);
  static Color bg2 = const Color(0xFF232A31);
  static Color bg3 = const Color(0xFF2B333B);
  static Color border = const Color(0xFF2A3138);
  static Color borderLight = const Color(0xFF343C45);

  static Color primary = const Color(0xFFB71C1C);
  static Color primaryDark = const Color(0xFF7F0000);
  static Color killColor = const Color(0xFF6B0000);
  static Color green = const Color(0xFF4CAF50);
  static Color yellow = const Color(0xFFFFC107);
  static Color red = const Color(0xFFE53935);
  static Color blue = const Color(0xFF4A90D9);

  static Color gold = const Color(0xFFD4A853);
  static Color goldLight = const Color(0xFFF0CC80);      // ← FIX
  static Color textMain = const Color(0xFFF3E6DD);
  static Color textMed = const Color(0xFFB7BFC9);
  static Color textDim = const Color(0xFF8A6E4A);
  static Color termBg = const Color(0xFF0B0E11);
  static Color termText = const Color(0xFFCCCCCC);
  static Color termErr = const Color(0xFFFF6B6B);
  static Color termOk = const Color(0xFF6EE7B7);
}

void _applyTheme(XThemeData t) {
  _TC.bg0 = t.brownDark;
  _TC.bg1 = Color.lerp(t.brownDark, t.brownMid, 0.35)!;
  _TC.bg2 = Color.lerp(t.brownDark, t.brownMid, 0.55)!;
  _TC.bg3 = Color.lerp(t.brownMid, t.redMain, 0.20)!;
  _TC.border = t.gold.withOpacity(0.20);
  _TC.borderLight = t.gold.withOpacity(0.32);

  _TC.primary = t.redMain;
  _TC.primaryDark = t.redDark;
  _TC.killColor = Color.lerp(t.redDark, Colors.black, 0.35)!;
  _TC.green = t.accentGreen;
  _TC.yellow = t.accentYellow;
  _TC.red = t.accentRed;
  _TC.blue = t.accentBlue;
  _TC.gold = t.gold;
  _TC.goldLight = t.goldLight;
  _TC.textMain = t.bgCreamLight;
  _TC.textMed = Color.lerp(t.bgCreamLight, t.gold, 0.35)!;
  _TC.textDim = Color.lerp(t.gold, t.brownMid, 0.35)!;
}

// ─── Models ───
class Project {
  final String id;
  String name;
  String status;
  String? entry;
  Project({required this.id, required this.name, required this.status, this.entry});
  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'],
        name: j['name'] ?? '-',
        status: j['status'] ?? 'stopped',
        entry: j['entry'],
      );
}

class FileItem {
  final String name;
  final String rel;
  final bool isDir;
  final int size;
  final int mtime;
  FileItem({required this.name, required this.rel, required this.isDir,
      required this.size, required this.mtime});
  factory FileItem.fromJson(Map<String, dynamic> j) => FileItem(
        name: j['name'],
        rel: j['rel'] ?? j['name'],
        isDir: j['isDir'] ?? false,
        size: j['size'] ?? 0,
        mtime: (j['mtime'] ?? 0).toInt(),
      );
}

class LogLine {
  final int t;
  final String line;
  LogLine(this.t, this.line);
}

class ServerStats {
  double cpu = 0;
  double memMB = 0;
  double memLimitMB = 512;
  int uptimeSec = 0;
  ServerStats();
}

// ═══════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════
class ScriptPanelPage extends StatefulWidget {
  const ScriptPanelPage({super.key});
  @override
  State<ScriptPanelPage> createState() => _ScriptPanelPageState();
}

class _ScriptPanelPageState extends State<ScriptPanelPage> {
  final XThemeController _themeCtrl = XThemeController();
  static const int _maxLogsUi = 3000;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  List<Project> _projects = [];
  Project? _selected;
  bool _loading = true;

  // tabs: 0=Console 1=Files 2=Network 3=Startup 4=Settings
  int _tab = 0;

  // console
  final List<LogLine> _logs = [];
  final TextEditingController _cmdCtrl = TextEditingController();
  final FocusNode _cmdFocus = FocusNode();
  WebSocketChannel? _ws;
  StreamSubscription? _wsSub;
  final ScrollController _logScroll = ScrollController();
  bool _autoScroll = true;
  final ServerStats _stats = ServerStats();
  Timer? _statsTick;

  // files
  String _currentPath = '.';
  List<FileItem> _files = [];
  bool _filesLoading = false;

  // state
  bool _actionLoading = false;
  String _actionName = '';

  @override
  void initState() {
    super.initState();
    _loadProjects();
    _statsTick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _selected?.status == 'running') {
        setState(() => _stats.uptimeSec++);
      }
    });
  }

  @override
  void dispose() {
    _wsSub?.cancel();
    _ws?.sink.close();
    _logScroll.dispose();
    _cmdCtrl.dispose();
    _cmdFocus.dispose();
    _statsTick?.cancel();
    super.dispose();
  }

  Map<String, String> get _headers => {'x-api-key': '7206ed76ae7df9af68c951b63910bbad228aad7f4a28a06a9feb1bbb7b574184'};

  // ── API ────────────────────────────────────────────────
  Future<void> _loadProjects() async {
    setState(() => _loading = true);
    try {
      final r = await http
          .get(Uri.parse('$apiBaseUrl/api/projects'), headers: _headers)
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200) {
        final list = (jsonDecode(r.body) as List)
            .map((e) => Project.fromJson(e)).toList();
        if (mounted) setState(() => _projects = list);
      } else {
        _snack('Gagal load: ${r.statusCode}', true);
      }
    } catch (e) {
      _snack('$e', true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _selectProject(Project p) async {
    setState(() {
      _selected = p;
      _logs.clear();
      _currentPath = '.';
      _tab = 0;
      _stats.uptimeSec = 0;
    });
    _connectConsole(p.id);
    await _refreshStatus();
  }

  Future<void> _refreshStatus() async {
    if (_selected == null) return;
    try {
      final r = await http
          .get(Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/status'),
              headers: _headers)
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200 && mounted) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        setState(() {
          _selected!.status = j['status'];
          _selected!.entry = j['entry'];
          if (j['uptime'] != null) {
            _stats.uptimeSec = (j['uptime'] as num).toInt();
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _createProject() async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => _dlg(
        title: 'CREATE SERVER',
        child: _dlgInput(ctrl, 'Nama server'),
        actions: [
          _dlgBtn('Batal', _TC.textDim, () => Navigator.pop(ctx)),
          _dlgBtn('Create', _TC.green,
              () => Navigator.pop(ctx, ctrl.text.trim()),
              solid: true),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    try {
      final r = await http
          .post(Uri.parse('$apiBaseUrl/api/projects'),
              headers: {..._headers, 'content-type': 'application/json'},
              body: jsonEncode({'name': name}))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200) {
        _snack('Server dibuat', false);
        _loadProjects();
      } else {
        _snack('Gagal: ${r.body}', true);
      }
    } catch (e) {
      _snack('$e', true);
    }
  }

  Future<void> _deleteProject(Project p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => _dlg(
        title: 'DELETE SERVER',
        child: Text('Server "${p.name}" dan semua file akan dihapus permanen.',
            style: TextStyle(color: _TC.textMed, fontSize: 12.5)),
        actions: [
          _dlgBtn('Cancel', _TC.textDim, () => Navigator.pop(ctx, false)),
          _dlgBtn('Delete', _TC.red, () => Navigator.pop(ctx, true),
              solid: true),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await http
          .delete(Uri.parse('$apiBaseUrl/api/projects/${p.id}'),
              headers: _headers)
          .timeout(const Duration(seconds: 15));
      if (_selected?.id == p.id) {
        _selected = null;
        _logs.clear();
      }
      _loadProjects();
    } catch (e) {
      _snack('$e', true);
    }
  }

  Future<void> _action(String action) async {
    if (_selected == null) return;
    setState(() {
      _actionLoading = true;
      _actionName = action;
    });
    try {
      final r = await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/$action'),
            headers: _headers,
          )
          .timeout(const Duration(seconds: 60));
      if (r.statusCode >= 400) {
        try {
          final j = jsonDecode(r.body) as Map<String, dynamic>;
          if (j['error'] == 'port_listen_detected') {
            _snack('Script listen port - tidak diizinkan', true);
            _showListenWarning(j);
          } else {
            _snack(j['error']?.toString() ?? 'Gagal', true);
          }
        } catch (_) {
          _snack('Gagal: ${r.body}', true);
        }
      } else {
        _snack('${action.toUpperCase()} OK', false);
      }
      await _refreshStatus();
    } catch (e) {
      _snack('$e', true);
    } finally {
      if (mounted) setState(() {
        _actionLoading = false;
        _actionName = '';
      });
    }
  }

  void _showListenWarning(Map<String, dynamic> j) {
    final hits = (j['hits'] as List?) ?? [];
    showDialog(
      context: context,
      builder: (ctx) => _dlg(
        title: 'PORT LISTEN DETECTED',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Script mengandung pattern terlarang:',
                style: TextStyle(color: _TC.textMed, fontSize: 12)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: _TC.termBg, borderRadius: BorderRadius.circular(4)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final h in hits.take(10))
                    Text('• ${h['file']}  [${h['pattern']}]',
                        style: TextStyle(
                            color: _TC.termErr,
                            fontSize: 11,
                            fontFamily: 'monospace')),
                ],
              ),
            ),
          ],
        ),
        actions: [
          _dlgBtn('OK', _TC.blue, () => Navigator.pop(ctx), solid: true),
        ],
      ),
    );
  }

  // ── Console WebSocket ──────────────────────────────────
  void _connectConsole(String id) {
    _wsSub?.cancel();
    _ws?.sink.close();
    _logs.clear();

    final wsBase = '$apiBaseUrl'
        .replaceFirst('https://', 'wss://')
        .replaceFirst('http://', 'ws://');
    try {
      _ws = WebSocketChannel.connect(
          Uri.parse('$wsBase/api/projects/$id/console?api_key=7206ed76ae7df9af68c951b63910bbad228aad7f4a28a06a9feb1bbb7b574184'));
      _wsSub = _ws!.stream.listen(
        (ev) {
          try {
            final m = jsonDecode(ev as String) as Map<String, dynamic>;
            final t = m['type'];
            if (t == 'init') {
              final logs = (m['logs'] as List?) ?? [];
              if (!mounted) return;
              setState(() {
                _logs.clear();
                for (final l in logs) {
                  _logs.add(LogLine(
                      (l['t'] ?? 0), (l['line'] ?? '').toString()));
                }
                _capLogs();
                if (_selected != null) {
                  _selected!.status = m['status'] ?? 'stopped';
                }
              });
            } else if (t == 'log') {
              if (!mounted) return;
              setState(() {
                _logs.add(
                    LogLine((m['t'] ?? 0), (m['line'] ?? '').toString()));
                _capLogs();
              });
              if (_autoScroll) _scrollEnd();
            } else if (t == 'status') {
              if (!mounted) return;
              setState(() => _selected?.status = m['status'] ?? 'stopped');
            } else if (t == 'stats') {
              if (!mounted) return;
              setState(() {
                _stats.cpu = (m['cpu'] as num?)?.toDouble() ?? 0;
                _stats.memMB = (m['memory'] as num?)?.toDouble() ?? 0;
                if (m['uptime'] != null) {
                  _stats.uptimeSec = (m['uptime'] as num).toInt();
                }
              });
            }
          } catch (_) {}
        },
        onError: (_) {},
        onDone: () {},
      );
    } catch (_) {}
  }

  void _capLogs() {
    if (_logs.length > _maxLogsUi) {
      _logs.removeRange(0, _logs.length - _maxLogsUi);
    }
  }

  void _scrollEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScroll.hasClients) {
        _logScroll.animateTo(
          _logScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _clearLogs() async {
    if (_selected == null) return;
    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/logs/clear'),
            headers: _headers,
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
    if (mounted) setState(() => _logs.clear());
  }

  Future<void> _sendCommand() async {
    final text = _cmdCtrl.text.trim();
    if (text.isEmpty || _selected == null) return;
    _cmdCtrl.clear();
    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/input'),
            headers: {..._headers, 'content-type': 'application/json'},
            body: jsonEncode({'data': text}),
          )
          .timeout(const Duration(seconds: 10));
    } catch (_) {}
  }

  // ── Files API ──────────────────────────────────────────
  Future<void> _loadFiles() async {
    if (_selected == null) return;
    setState(() => _filesLoading = true);
    try {
      final r = await http
          .get(
            Uri.parse(
                '$apiBaseUrl/api/projects/${_selected!.id}/files?path=${Uri.encodeComponent(_currentPath)}'),
            headers: _headers,
          )
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200 && mounted) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        setState(() {
          _files =
              (j['items'] as List).map((e) => FileItem.fromJson(e)).toList();
        });
      }
    } catch (e) {
      _snack('$e', true);
    } finally {
      if (mounted) setState(() => _filesLoading = false);
    }
  }

  Future<void> _upload() async {
    if (_selected == null) return;
    final res =
        await FilePicker.platform.pickFiles(allowMultiple: true, withData: true);
    if (res == null || res.files.isEmpty) return;
    setState(() => _actionLoading = true);
    try {
      final req = http.MultipartRequest(
          'POST', Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/upload'));
      req.headers.addAll(_headers);
      req.fields['path'] = _currentPath;
      for (final f in res.files) {
        if (f.bytes != null) {
          req.files.add(
              http.MultipartFile.fromBytes('files', f.bytes!, filename: f.name));
        }
      }
      final s = await req.send().timeout(const Duration(minutes: 3));
      if (s.statusCode >= 400) {
        _snack('Upload gagal: ${s.statusCode}', true);
      } else {
        _snack('${res.files.length} file diupload', false);
        _loadFiles();
      }
    } catch (e) {
      _snack('$e', true);
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  Future<void> _unzip(FileItem f) async {
    if (_selected == null) return;
    try {
      final r = await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/unzip'),
            headers: {..._headers, 'content-type': 'application/json'},
            body: jsonEncode({'file': f.rel}),
          )
          .timeout(const Duration(seconds: 60));
      if (r.statusCode >= 400) {
        _snack('Gagal unzip', true);
      } else {
        _snack('Berhasil extract', false);
        _loadFiles();
      }
    } catch (e) {
      _snack('$e', true);
    }
  }

  Future<void> _deleteFile(FileItem f) async {
    if (_selected == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => _dlg(
        title: 'DELETE',
        child: Text(
          f.isDir
              ? 'Folder "${f.name}" dan isinya akan dihapus.'
              : 'File "${f.name}" akan dihapus.',
          style: TextStyle(color: _TC.textMed, fontSize: 12.5),
        ),
        actions: [
          _dlgBtn('Cancel', _TC.textDim, () => Navigator.pop(ctx, false)),
          _dlgBtn('Delete', _TC.red, () => Navigator.pop(ctx, true),
              solid: true),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/delete-file'),
            headers: {..._headers, 'content-type': 'application/json'},
            body: jsonEncode({'path': f.rel}),
          )
          .timeout(const Duration(seconds: 30));
      _loadFiles();
    } catch (e) {
      _snack('$e', true);
    }
  }

  Future<void> _mkdir() async {
    if (_selected == null) return;
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => _dlg(
        title: 'NEW FOLDER',
        child: _dlgInput(ctrl, 'nama-folder'),
        actions: [
          _dlgBtn('Cancel', _TC.textDim, () => Navigator.pop(ctx)),
          _dlgBtn('Create', _TC.green,
              () => Navigator.pop(ctx, ctrl.text.trim()),
              solid: true),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    final rel = _currentPath == '.' ? name : '$_currentPath/$name';
    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/mkdir'),
            headers: {..._headers, 'content-type': 'application/json'},
            body: jsonEncode({'path': rel}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
    _loadFiles();
  }

  Future<void> _renameProject(String newName) async {
    if (_selected == null) return;
    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/api/projects/${_selected!.id}/rename'),
            headers: {..._headers, 'content-type': 'application/json'},
            body: jsonEncode({'name': newName}),
          )
          .timeout(const Duration(seconds: 15));
      setState(() => _selected!.name = newName);
      _snack('Nama diubah', false);
    } catch (e) {
      _snack('$e', true);
    }
  }

  // ── UI Helpers ─────────────────────────────────────────
  void _snack(String msg, bool err) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 13)),
      backgroundColor: err ? _TC.red : _TC.green,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
    ));
  }

  Widget _dlg({
    required String title,
    required Widget child,
    required List<Widget> actions,
  }) {
    return AlertDialog(
      backgroundColor: _TC.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      title: Text(title,
          style: TextStyle(
              color: _TC.textMain,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              letterSpacing: 1.2)),
      content: child,
      actions: actions,
    );
  }

  Widget _dlgInput(TextEditingController ctrl, String hint) {
    return TextField(
      controller: ctrl,
      autofocus: true,
      style: TextStyle(color: _TC.textMain, fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: _TC.textDim, fontSize: 13),
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: _TC.border),
          borderRadius: BorderRadius.circular(4),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: _TC.blue, width: 1.5),
          borderRadius: BorderRadius.circular(4),
        ),
      ),
    );
  }

  Widget _dlgBtn(String label, Color c, VoidCallback onTap,
      {bool solid = false}) {
    return TextButton(
      onPressed: onTap,
      style: TextButton.styleFrom(
        backgroundColor: solid ? c : Colors.transparent,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      ),
      child: Text(label,
          style: TextStyle(
              color: solid ? Colors.white : c,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              letterSpacing: 0.6)),
    );
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'running':
        return _TC.green;
      case 'starting':
      case 'restarting':
        return _TC.yellow;
      case 'crashed':
        return _TC.red;
      case 'stopped':
        return _TC.textDim;
      default:
        return _TC.textDim;
    }
  }

  String _fmtSize(int bytes) {
    if (bytes < 1024) return '${bytes} B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KiB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MiB';
    }
    return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(2)} GiB';
  }

  String _fmtUptime(int sec) {
    if (sec < 60) return '${sec}s';
    if (sec < 3600) return '${sec ~/ 60}m ${sec % 60}s';
    final h = sec ~/ 3600;
    final m = (sec % 3600) ~/ 60;
    return '${h}h ${m}m';
  }

  String _fmtDate(int ms) {
    if (ms <= 0) return '-';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')} '
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  // ── Build ──────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeCtrl,
      builder: (_, __) {
        _applyTheme(_themeCtrl.currentTheme);
        return Scaffold(
          key: _scaffoldKey,
          backgroundColor: _TC.bg0,
          drawer: _serverDrawer(),
          body: SafeArea(
            child: Column(
              children: [
                _header(),
                Expanded(
                    child: _selected == null
                        ? _serverListView()
                        : _serverDetailView()),
              ],
            ),
          ),
          floatingActionButton: _selected == null
              ? FloatingActionButton.extended(
                  onPressed: _createProject,
                  backgroundColor: _TC.blue,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6)),
                  icon: const Icon(Icons.add_rounded,
                      color: Colors.white, size: 20),
                  label: const Text('NEW SERVER',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                          letterSpacing: 0.8)),
                )
              : null,
        );
      },
    );
  }

  // ── HEADER (Pterodactyl-style top bar) ────────────────
  Widget _header() {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: _TC.bg1,
        border: Border(bottom: BorderSide(color: _TC.border, width: 1)),
      ),
      child: Row(
        children: [
          // Menu / back
          GestureDetector(
            onTap: () => _selected == null
                ? _scaffoldKey.currentState?.openDrawer()
                : setState(() {
                    _selected = null;
                    _logs.clear();
                    _wsSub?.cancel();
                    _ws?.sink.close();
                  }),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: _TC.bg2,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: _TC.border, width: 1),
              ),
              child: Icon(
                _selected == null
                    ? Icons.menu_rounded
                    : Icons.arrow_back_ios_new,
                color: _TC.textMed,
                size: 16,
              ),
            ),
          ),
          const SizedBox(width: 10),

          // Server name + status
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _selected == null
                        ? _TC.gold
                        : _statusColor(_selected!.status),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: (_selected == null
                                  ? _TC.gold
                                  : _statusColor(_selected!.status))
                              .withOpacity(0.6),
                          blurRadius: 6),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _selected?.name ?? 'ATLAS PANEL',
                    style: TextStyle(
                      color: _TC.textMain,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      letterSpacing: 0.5,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),

          // Right actions
          if (_selected == null)
            GestureDetector(
              onTap: _loadProjects,
              child: Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: _TC.bg2,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: _TC.border, width: 1),
                ),
                child: Icon(Icons.refresh_rounded,
                    color: _TC.textMed, size: 18),
              ),
            )
          else ...[
            // Resource compact indicators
            _headerStat('CPU', '${_stats.cpu.toStringAsFixed(0)}%', _TC.blue),
            const SizedBox(width: 8),
            _headerStat(
                'RAM', '${_stats.memMB.toStringAsFixed(0)}MB', _TC.green),
            const SizedBox(width: 8),
            _headerStat('UP', _fmtUptime(_stats.uptimeSec), _TC.gold),
          ],
        ],
      ),
    );
  }

  Widget _headerStat(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: _TC.bg2,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _TC.border, width: 1),
      ),
      child: Row(
        children: [
          Text('$label ',
              style: TextStyle(
                  color: _TC.textDim,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.6)),
          Text(value,
              style: TextStyle(
                  color: color,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }

  // ── SERVER LIST (drawer content + main view) ──────────
  Widget _serverDrawer() {
    return Drawer(
      backgroundColor: _TC.bg1,
      width: 260,
      child: SafeArea(
        child: Column(
          children: [
            // Drawer header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _TC.bg2,
                border:
                    Border(bottom: BorderSide(color: _TC.border, width: 1)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: _TC.blue,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Icon(Icons.dns_rounded,
                        color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'ATLAS PANEL',
                      style: TextStyle(
                          color: _TC.textMain,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                          letterSpacing: 1),
                    ),
                  ),
                ],
              ),
            ),

            // Server list
            Expanded(
              child: _projects.isEmpty
                  ? Center(
                      child: Text('Belum ada server',
                          style:
                              TextStyle(color: _TC.textDim, fontSize: 12)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      itemCount: _projects.length,
                      itemBuilder: (_, i) {
                        final p = _projects[i];
                        final sc = _statusColor(p.status);
                        final sel = _selected?.id == p.id;
                        return GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                            _selectProject(p);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            color: sel
                                ? _TC.bg3
                                : Colors.transparent,
                            child: Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: sc,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    p.name,
                                    style: TextStyle(
                                        color: sel
                                            ? _TC.textMain
                                            : _TC.textMed,
                                        fontWeight: sel
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                        fontSize: 12.5),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Text(
                                  p.status,
                                  style: TextStyle(
                                      color: sc,
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.4),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),

            // Footer
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border:
                    Border(top: BorderSide(color: _TC.border, width: 1)),
              ),
              child: Text(
                'Copyright © Atlas Panel',
                style: TextStyle(color: _TC.textDim, fontSize: 10),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _serverListView() {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(color: _TC.blue, strokeWidth: 2));
    }
    if (_projects.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.dns_rounded, color: _TC.textDim, size: 56),
            const SizedBox(height: 12),
            Text('Belum ada server',
                style: TextStyle(
                    color: _TC.textMed,
                    fontSize: 14,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('Tap + NEW SERVER untuk buat',
                style: TextStyle(color: _TC.textDim, fontSize: 12)),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _projects.length,
      itemBuilder: (_, i) {
        final p = _projects[i];
        final sc = _statusColor(p.status);
        return GestureDetector(
          onTap: () => _selectProject(p),
          onLongPress: () => _deleteProject(p),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _TC.bg1,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: _TC.border, width: 1),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _TC.bg2,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: _TC.border, width: 1),
                  ),
                  child: Icon(Icons.smart_toy_rounded,
                      color: _TC.gold, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: TextStyle(
                              color: _TC.textMain,
                              fontWeight: FontWeight.w700,
                              fontSize: 13),
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: sc,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(p.status.toUpperCase(),
                              style: TextStyle(
                                  color: sc,
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.6)),
                          if (p.entry != null) ...[
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text('• ${p.entry}',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: _TC.textDim,
                                      fontSize: 10,
                                      fontFamily: 'monospace')),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: _TC.textDim, size: 20),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── SERVER DETAIL VIEW ─────────────────────────────────
  Widget _serverDetailView() {
    return Column(
      children: [
        _controlPanel(),
        _tabBar(),
        Expanded(child: _tabContent()),
      ],
    );
  }

  // Pterodactyl-like 4-button control bar
Widget _controlPanel() {
  final running = _selected!.status == 'running';
  final starting = _selected!.status == 'starting' ||
      _selected!.status == 'restarting';
  final stopped = _selected!.status == 'stopped' ||
      _selected!.status == 'crashed';

  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
    decoration: BoxDecoration(
      color: _TC.bg1,
      border: Border(bottom: BorderSide(color: _TC.border, width: 1)),
    ),
    child: Row(
      children: [
        // START: hanya enable kalau status stopped/crashed
        Expanded(
          child: _ctrlBtn(
            'START',
            Icons.play_arrow_rounded,
            _TC.green,
            () => _action('start'),
            enabled: stopped,
            loading: _actionLoading && _actionName == 'start',
          ),
        ),
        const SizedBox(width: 6),

        // RESTART: enable kalau running, atau kalau stopped (sama aja kayak start)
        Expanded(
          child: _ctrlBtn(
            'RESTART',
            Icons.refresh_rounded,
            _TC.yellow,
            () => _action('restart'),
            enabled: !starting && !_actionLoading,
            loading: _actionLoading && _actionName == 'restart',
          ),
        ),
        const SizedBox(width: 6),

        // STOP: enable kalau running
        Expanded(
          child: _ctrlBtn(
            'STOP',
            Icons.stop_rounded,
            _TC.primary,
            () => _action('stop'),
            enabled: running,
            loading: _actionLoading && _actionName == 'stop',
          ),
        ),
        const SizedBox(width: 6),

        // KILL: enable kalau running
        Expanded(
          child: _ctrlBtn(
            'KILL',
            Icons.power_settings_new_rounded,
            _TC.killColor,
            () => _action('kill'),
            enabled: running,
            loading: _actionLoading && _actionName == 'kill',
          ),
        ),
      ],
    ),
  );
}

Widget _ctrlBtn(
  String label,
  IconData icon,
  Color color,
  VoidCallback onTap, {
  bool enabled = true,
  bool loading = false,
}) {
  final canTap = enabled && !loading;
  return GestureDetector(
    onTap: canTap ? onTap : null,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: canTap ? color : _TC.bg2,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: canTap ? color.withOpacity(0.4) : _TC.border,
          width: 1,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (loading)
            const SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: Colors.white),
            )
          else
            Icon(icon,
                color: canTap ? Colors.white : _TC.textDim, size: 14),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: canTap ? Colors.white : _TC.textDim,
              fontWeight: FontWeight.w800,
              fontSize: 10,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    ),
  );
}

  // Pterodactyl tab bar: horizontal scrollable
  Widget _tabBar() {
    final tabs = [
      ('Console', Icons.terminal_rounded),
      ('Files', Icons.folder_rounded),
      ('Network', Icons.wifi_rounded),
      ('Startup', Icons.settings_power_rounded),
      ('Settings', Icons.tune_rounded),
    ];
    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: _TC.bg1,
        border: Border(bottom: BorderSide(color: _TC.border, width: 1)),
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        itemBuilder: (_, i) {
          final active = _tab == i;
          return GestureDetector(
            onTap: () {
              setState(() => _tab = i);
              if (i == 1 && _files.isEmpty) _loadFiles();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: active ? _TC.blue : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
              child: Row(
                children: [
                  Icon(tabs[i].$2,
                      color: active ? _TC.blue : _TC.textDim, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    tabs[i].$1,
                    style: TextStyle(
                      color: active ? _TC.textMain : _TC.textDim,
                      fontWeight:
                          active ? FontWeight.w700 : FontWeight.w500,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _tabContent() {
    switch (_tab) {
      case 1:
        return _filesView();
      case 2:
        return _networkView();
      case 3:
        return _startupView();
      case 4:
        return _settingsView();
      default:
        return _consoleView();
    }
  }

  // ── CONSOLE (Pterodactyl-style: black + input) ────────
  Widget _consoleView() {
    return Container(
      color: _TC.termBg,
      child: Column(
        children: [
          // Toolbar
          Container(
            height: 32,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: _TC.bg1,
              border:
                  Border(bottom: BorderSide(color: _TC.border, width: 1)),
            ),
            child: Row(
              children: [
                Icon(Icons.circle,
                    color: _TC.termOk, size: 8),
                const SizedBox(width: 6),
                Text(
                  _selected?.status.toUpperCase() ?? 'OFFLINE',
                  style: TextStyle(
                    color: _statusColor(_selected?.status ?? 'stopped'),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                    fontFamily: 'monospace',
                  ),
                ),
                const Spacer(),
                Text(
                  '${_logs.length} lines',
                  style: TextStyle(
                      color: _TC.textDim,
                      fontSize: 10,
                      fontFamily: 'monospace'),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => setState(() => _autoScroll = !_autoScroll),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _autoScroll
                          ? _TC.blue.withOpacity(0.2)
                          : _TC.bg2,
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(
                          color: _autoScroll ? _TC.blue : _TC.border,
                          width: 1),
                    ),
                    child: Text(
                      _autoScroll ? 'AUTO' : 'MANUAL',
                      style: TextStyle(
                          color: _autoScroll ? _TC.blue : _TC.textDim,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: _clearLogs,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _TC.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(
                          color: _TC.red.withOpacity(0.4), width: 1),
                    ),
                    child: Text('CLEAR',
                        style: TextStyle(
                            color: _TC.red,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5)),
                  ),
                ),
              ],
            ),
          ),

          // Terminal output
          Expanded(
            child: _logs.isEmpty
                ? Center(
                    child: Text(
                      r'$ container@pterodactyl~server: waiting...',
                      style: TextStyle(
                          color: _TC.termText.withOpacity(0.4),
                          fontFamily: 'monospace',
                          fontSize: 11),
                    ),
                  )
                : ListView.builder(
                    controller: _logScroll,
                    padding: const EdgeInsets.all(8),
                    itemCount: _logs.length,
                    itemBuilder: (_, i) {
                      final l = _logs[i];
                      final isErr = l.line.startsWith('[err]') ||
                          l.line.toLowerCase().contains('error') ||
                          l.line.contains('✗') ||
                          l.line.contains('Exception');
                      final isInfo = l.line.startsWith('▶') ||
                          l.line.startsWith('■') ||
                          l.line.startsWith('⏹') ||
                          l.line.startsWith('⛔') ||
                          l.line.startsWith('✓');
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 0.5),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '» ',
                              style: TextStyle(
                                color: _TC.textDim,
                                fontSize: 11,
                                fontFamily: 'monospace',
                                height: 1.4,
                              ),
                            ),
                            Expanded(
                              child: SelectableText(
                                l.line,
                                style: TextStyle(
                                  color: isErr
                                      ? _TC.termErr
                                      : isInfo
                                          ? _TC.blue
                                          : _TC.termText,
                                  fontSize: 11,
                                  fontFamily: 'monospace',
                                  height: 1.4,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          // Input line (Pterodactyl-style)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              color: _TC.bg1,
              border: Border(top: BorderSide(color: _TC.border, width: 1)),
            ),
            child: Row(
              children: [
                Text(
                  r'$ ',
                  style: TextStyle(
                      color: _TC.termOk,
                      fontSize: 13,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.w800),
                ),
                Expanded(
                  child: TextField(
                    controller: _cmdCtrl,
                    focusNode: _cmdFocus,
                    enabled: _selected?.status == 'running',
                    style: TextStyle(
                        color: _TC.termText,
                        fontSize: 12,
                        fontFamily: 'monospace'),
                    cursorColor: _TC.termOk,
                    cursorWidth: 6,
                    onSubmitted: (_) => _sendCommand(),
                    decoration: InputDecoration(
                      hintText: _selected?.status == 'running'
                          ? 'Type a command...'
                          : 'Server offline',
                      hintStyle: TextStyle(
                          color: _TC.textDim,
                          fontSize: 12,
                          fontFamily: 'monospace'),
                      isDense: true,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 8),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: _selected?.status == 'running'
                      ? _sendCommand
                      : null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: _selected?.status == 'running'
                          ? _TC.blue
                          : _TC.bg2,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: Icon(
                      Icons.send_rounded,
                      color: _selected?.status == 'running'
                          ? Colors.white
                          : _TC.textDim,
                      size: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── FILES (Pterodactyl table layout) ──────────────────
  Widget _filesView() {
    final crumbs = _currentPath == '.' ? <String>[] : _currentPath.split('/');
    return Container(
      color: _TC.bg0,
      child: Column(
        children: [
          // Toolbar: breadcrumb + actions
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: _TC.bg1,
              border:
                  Border(bottom: BorderSide(color: _TC.border, width: 1)),
            ),
            child: Column(
              children: [
                // Breadcrumb
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() => _currentPath = '.');
                        _loadFiles();
                      },
                      child: Text('/',
                          style: TextStyle(
                              color: _TC.blue,
                              fontFamily: 'monospace',
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ),
                    ...crumbs.asMap().entries.map((e) {
                      final path = crumbs.take(e.key + 1).join('/');
                      return Row(
                        children: [
                          Text(' / ',
                              style: TextStyle(
                                  color: _TC.textDim, fontSize: 12)),
                          GestureDetector(
                            onTap: () {
                              setState(() => _currentPath = path);
                              _loadFiles();
                            },
                            child: Text(e.value,
                                style: TextStyle(
                                    color: _TC.blue,
                                    fontFamily: 'monospace',
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      );
                    }),
                    const Spacer(),
                    IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        icon: Icon(Icons.refresh_rounded,
                            color: _TC.textMed, size: 18),
                        onPressed: _loadFiles),
                  ],
                ),
                const SizedBox(height: 8),
                // Actions
                Row(
                  children: [
                    Expanded(
                        child: _fileAction(
                            'UPLOAD', Icons.upload_rounded, _TC.blue, _upload)),
                    const SizedBox(width: 6),
                    Expanded(
                        child: _fileAction('NEW FOLDER',
                            Icons.create_new_folder_rounded, _TC.blue, _mkdir)),
                  ],
                ),
              ],
            ),
          ),

          // Column header
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _TC.bg2,
              border: Border(
                  bottom: BorderSide(color: _TC.border, width: 1)),
            ),
            child: Row(
              children: [
                Expanded(
                    flex: 5,
                    child: Text('NAME',
                        style: TextStyle(
                            color: _TC.textDim,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1))),
                Expanded(
                    flex: 2,
                    child: Text('SIZE',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            color: _TC.textDim,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1))),
                SizedBox(
                  width: 68,
                  child: Text('ACTION',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          color: _TC.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                ),
              ],
            ),
          ),

          // Files list
          Expanded(
            child: _filesLoading
                ? Center(
                    child: CircularProgressIndicator(
                        color: _TC.blue, strokeWidth: 2))
                : _files.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.folder_open_rounded,
                                color: _TC.textDim, size: 48),
                            const SizedBox(height: 8),
                            Text('Folder kosong',
                                style: TextStyle(
                                    color: _TC.textDim, fontSize: 12)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: EdgeInsets.zero,
                        itemCount: _files.length,
                        itemBuilder: (_, i) {
                          final f = _files[i];
                          final isZip =
                              f.name.toLowerCase().endsWith('.zip');
                          return _fileRow(f, isZip);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _fileRow(FileItem f, bool isZip) {
    return GestureDetector(
      onTap: f.isDir
          ? () {
              setState(() => _currentPath = f.rel);
              _loadFiles();
            }
          : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.transparent,
          border: Border(
              bottom: BorderSide(color: _TC.border.withOpacity(0.5))),
        ),
        child: Row(
          children: [
            Icon(
              f.isDir
                  ? Icons.folder_rounded
                  : isZip
                      ? Icons.folder_zip_rounded
                      : Icons.insert_drive_file_rounded,
              color: f.isDir
                  ? _TC.gold
                  : (isZip ? _TC.yellow : _TC.textMed),
              size: 16,
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(f.name,
                      style: TextStyle(
                          color: _TC.textMain,
                          fontSize: 12,
                          fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis),
                  if (f.mtime > 0)
                    Text(_fmtDate(f.mtime),
                        style: TextStyle(
                            color: _TC.textDim,
                            fontSize: 10,
                            fontFamily: 'monospace')),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                f.isDir ? '—' : _fmtSize(f.size),
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _TC.textMed,
                    fontSize: 11,
                    fontFamily: 'monospace'),
              ),
            ),
            SizedBox(
              width: 68,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (isZip)
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints:
                          const BoxConstraints(minWidth: 28, minHeight: 28),
                      icon: Icon(Icons.unarchive_rounded,
                          color: _TC.green, size: 16),
                      onPressed: () => _unzip(f),
                    ),
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints:
                        const BoxConstraints(minWidth: 28, minHeight: 28),
                    icon: Icon(Icons.delete_outline_rounded,
                        color: _TC.red, size: 16),
                    onPressed: () => _deleteFile(f),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fileAction(String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: color.withOpacity(0.4), width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 13),
            const SizedBox(width: 5),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                    letterSpacing: 0.6)),
          ],
        ),
      ),
    );
  }

  // ── NETWORK (placeholder with info) ───────────────────
  Widget _networkView() {
    return Container(
      color: _TC.bg0,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('NETWORK'),
          const SizedBox(height: 12),
          _infoCard(
              Icons.wifi_rounded,
              'Port listening disabled',
              'Panel ini tidak mengizinkan script untuk listen port'),
          const SizedBox(height: 8),
          _infoCard(
              Icons.lock_rounded,
              'Isolated runtime',
              'Setiap script berjalan di proses terpisah'),
          const SizedBox(height: 8),
          _infoCard(
              Icons.public_rounded,
              'Cloudflare Tunnel',
              'Script berjalan tanpa expose port ke publik'),
        ],
      ),
    );
  }

  // ── STARTUP (show entry + auto-restart info) ──────────
  Widget _startupView() {
    return Container(
      color: _TC.bg0,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('STARTUP CONFIGURATION'),
          const SizedBox(height: 12),
          _kvCard('Entry File', _selected?.entry ?? '—'),
          const SizedBox(height: 8),
          _kvCard('Auto-Restart', 'ON (crash -> restart otomatis)'),
          const SizedBox(height: 8),
          _kvCard('Status', _selected?.status ?? '—'),
          const SizedBox(height: 8),
          _kvCard('Uptime', _fmtUptime(_stats.uptimeSec)),
        ],
      ),
    );
  }

  // ── SETTINGS (rename + delete) ────────────────────────
  Widget _settingsView() {
    final p = _selected!;
    return Container(
      color: _TC.bg0,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('SERVER SETTINGS'),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _TC.bg1,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _TC.border, width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Server ID',
                    style: TextStyle(
                        color: _TC.textDim,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1)),
                const SizedBox(height: 4),
                Text(p.id,
                    style: TextStyle(
                        color: _TC.textMed,
                        fontSize: 11,
                        fontFamily: 'monospace')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () async {
              final ctrl = TextEditingController(text: p.name);
              final name = await showDialog<String>(
                context: context,
                builder: (ctx) => _dlg(
                  title: 'RENAME SERVER',
                  child: _dlgInput(ctrl, 'Nama baru'),
                  actions: [
                    _dlgBtn('Cancel', _TC.textDim,
                        () => Navigator.pop(ctx)),
                    _dlgBtn('Save', _TC.blue,
                        () => Navigator.pop(ctx, ctrl.text.trim()),
                        solid: true),
                  ],
                ),
              );
              if (name != null && name.isNotEmpty) {
                await _renameProject(name);
              }
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _TC.bg2,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: _TC.border, width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.edit_rounded, color: _TC.blue, size: 14),
                  const SizedBox(width: 6),
                  Text('RENAME SERVER',
                      style: TextStyle(
                          color: _TC.blue,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                          letterSpacing: 0.8)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () => _deleteProject(p),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _TC.red.withOpacity(0.15),
                borderRadius: BorderRadius.circular(4),
                border:
                    Border.all(color: _TC.red.withOpacity(0.4), width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.delete_forever_rounded,
                      color: _TC.red, size: 14),
                  const SizedBox(width: 6),
                  Text('DELETE SERVER',
                      style: TextStyle(
                          color: _TC.red,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                          letterSpacing: 0.8)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) {
    return Text(t,
        style: TextStyle(
            color: _TC.textDim,
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.5));
  }

  Widget _infoCard(IconData icon, String title, String desc) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _TC.bg1,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _TC.border, width: 1),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: _TC.blue, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(
                        color: _TC.textMain,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5)),
                const SizedBox(height: 3),
                Text(desc,
                    style:
                        TextStyle(color: _TC.textMed, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _kvCard(String k, String v) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _TC.bg1,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _TC.border, width: 1),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(k,
                style: TextStyle(
                    color: _TC.textDim,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5)),
          ),
          Flexible(
            child: Text(v,
                style: TextStyle(
                    color: _TC.textMain,
                    fontSize: 11.5,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w700),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }
}