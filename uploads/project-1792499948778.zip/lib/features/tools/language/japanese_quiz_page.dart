// lib/features/tools/language/japanese_quiz_page.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS (mutable) ──────────────────────────────────
Color jqBgMain = const Color(0xFF160A07);
Color jqBgSurface = const Color(0xFF2A140E);
Color jqBgCard = const Color(0xFF3A1E15);
Color jqBgOption = const Color(0xFF4A2818);
Color jqTextMain = const Color(0xFFF3E6DD);
Color jqTextSub = const Color(0xFFC9913F);
Color jqGold = const Color(0xFFD4A853);
Color jqRed = const Color(0xFFB71C1C);
Color jqRedDark = const Color(0xFF7F0000);
Color jqRedDeep = const Color(0xFF4A0000);
Color jqGreen = const Color(0xFF4CAF50);
Color jqBlue = const Color(0xFF2196F3);
Color jqPink = const Color(0xFFE91E63);
Color jqYellow = const Color(0xFFFFC107);
Color jqHeart = const Color(0xFFFF4D8D);
Color jqPurple = const Color(0xFFAB47BC);
Color jqBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  jqBgMain      = theme.brownDark;
  jqBgSurface   = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  jqBgCard      = theme.brownMid;
  jqBgOption    = Color.lerp(theme.brownMid, theme.bgCreamLight, 0.15)!;
  jqTextMain    = theme.bgCreamLight;
  jqTextSub     = theme.gold;
  jqGold        = theme.gold;
  jqRed         = theme.redMain;
  jqRedDark     = theme.redDark;
  jqRedDeep     = theme.redDeep;
  jqGreen       = theme.accentGreen;
  jqBlue        = theme.accentBlue;
  jqPink        = theme.accentRed;
  jqYellow      = theme.accentYellow;
  jqHeart       = theme.accentRed;
  jqPurple      = theme.accentBlue;
  jqBorderDark  = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// 📚 DATA MODEL
// ═══════════════════════════════════════════════════════════════════
class KanaItem {
  final String kana;
  final String romaji;
  final String type;
  const KanaItem(this.kana, this.romaji, this.type);
}

// ── HIRAGANA ──
const List<KanaItem> hiraganaList = [
  KanaItem('あ', 'a', 'hiragana'), KanaItem('い', 'i', 'hiragana'),
  KanaItem('う', 'u', 'hiragana'), KanaItem('え', 'e', 'hiragana'),
  KanaItem('お', 'o', 'hiragana'), KanaItem('か', 'ka', 'hiragana'),
  KanaItem('き', 'ki', 'hiragana'), KanaItem('く', 'ku', 'hiragana'),
  KanaItem('け', 'ke', 'hiragana'), KanaItem('こ', 'ko', 'hiragana'),
  KanaItem('さ', 'sa', 'hiragana'), KanaItem('し', 'shi', 'hiragana'),
  KanaItem('す', 'su', 'hiragana'), KanaItem('せ', 'se', 'hiragana'),
  KanaItem('そ', 'so', 'hiragana'), KanaItem('た', 'ta', 'hiragana'),
  KanaItem('ち', 'chi', 'hiragana'), KanaItem('つ', 'tsu', 'hiragana'),
  KanaItem('て', 'te', 'hiragana'), KanaItem('と', 'to', 'hiragana'),
  KanaItem('な', 'na', 'hiragana'), KanaItem('に', 'ni', 'hiragana'),
  KanaItem('ぬ', 'nu', 'hiragana'), KanaItem('ね', 'ne', 'hiragana'),
  KanaItem('の', 'no', 'hiragana'), KanaItem('は', 'ha', 'hiragana'),
  KanaItem('ひ', 'hi', 'hiragana'), KanaItem('ふ', 'fu', 'hiragana'),
  KanaItem('へ', 'he', 'hiragana'), KanaItem('ほ', 'ho', 'hiragana'),
  KanaItem('ま', 'ma', 'hiragana'), KanaItem('み', 'mi', 'hiragana'),
  KanaItem('む', 'mu', 'hiragana'), KanaItem('め', 'me', 'hiragana'),
  KanaItem('も', 'mo', 'hiragana'), KanaItem('や', 'ya', 'hiragana'),
  KanaItem('ゆ', 'yu', 'hiragana'), KanaItem('よ', 'yo', 'hiragana'),
  KanaItem('ら', 'ra', 'hiragana'), KanaItem('り', 'ri', 'hiragana'),
  KanaItem('る', 'ru', 'hiragana'), KanaItem('れ', 're', 'hiragana'),
  KanaItem('ろ', 'ro', 'hiragana'), KanaItem('わ', 'wa', 'hiragana'),
  KanaItem('を', 'wo', 'hiragana'), KanaItem('ん', 'n', 'hiragana'),
  KanaItem('が', 'ga', 'hiragana'), KanaItem('ぎ', 'gi', 'hiragana'),
  KanaItem('ぐ', 'gu', 'hiragana'), KanaItem('げ', 'ge', 'hiragana'),
  KanaItem('ご', 'go', 'hiragana'), KanaItem('ざ', 'za', 'hiragana'),
  KanaItem('じ', 'ji', 'hiragana'), KanaItem('ず', 'zu', 'hiragana'),
  KanaItem('ぜ', 'ze', 'hiragana'), KanaItem('ぞ', 'zo', 'hiragana'),
  KanaItem('だ', 'da', 'hiragana'), KanaItem('ぢ', 'ji', 'hiragana'),
  KanaItem('づ', 'zu', 'hiragana'), KanaItem('で', 'de', 'hiragana'),
  KanaItem('ど', 'do', 'hiragana'), KanaItem('ば', 'ba', 'hiragana'),
  KanaItem('び', 'bi', 'hiragana'), KanaItem('ぶ', 'bu', 'hiragana'),
  KanaItem('べ', 'be', 'hiragana'), KanaItem('ぼ', 'bo', 'hiragana'),
  KanaItem('ぱ', 'pa', 'hiragana'), KanaItem('ぴ', 'pi', 'hiragana'),
  KanaItem('ぷ', 'pu', 'hiragana'), KanaItem('ぺ', 'pe', 'hiragana'),
  KanaItem('ぽ', 'po', 'hiragana'), KanaItem('きゃ', 'kya', 'hiragana'),
  KanaItem('きゅ', 'kyu', 'hiragana'), KanaItem('きょ', 'kyo', 'hiragana'),
  KanaItem('しゃ', 'sha', 'hiragana'), KanaItem('しゅ', 'shu', 'hiragana'),
  KanaItem('しょ', 'sho', 'hiragana'), KanaItem('ちゃ', 'cha', 'hiragana'),
  KanaItem('ちゅ', 'chu', 'hiragana'), KanaItem('ちょ', 'cho', 'hiragana'),
  KanaItem('にゃ', 'nya', 'hiragana'), KanaItem('にゅ', 'nyu', 'hiragana'),
  KanaItem('にょ', 'nyo', 'hiragana'), KanaItem('ひゃ', 'hya', 'hiragana'),
  KanaItem('ひゅ', 'hyu', 'hiragana'), KanaItem('ひょ', 'hyo', 'hiragana'),
  KanaItem('みゃ', 'mya', 'hiragana'), KanaItem('みゅ', 'myu', 'hiragana'),
  KanaItem('みょ', 'myo', 'hiragana'), KanaItem('りゃ', 'rya', 'hiragana'),
  KanaItem('りゅ', 'ryu', 'hiragana'), KanaItem('りょ', 'ryo', 'hiragana'),
  KanaItem('ぎゃ', 'gya', 'hiragana'), KanaItem('ぎゅ', 'gyu', 'hiragana'),
  KanaItem('ぎょ', 'gyo', 'hiragana'), KanaItem('じゃ', 'ja', 'hiragana'),
  KanaItem('じゅ', 'ju', 'hiragana'), KanaItem('じょ', 'jo', 'hiragana'),
  KanaItem('びゃ', 'bya', 'hiragana'), KanaItem('びゅ', 'byu', 'hiragana'),
  KanaItem('びょ', 'byo', 'hiragana'), KanaItem('ぴゃ', 'pya', 'hiragana'),
  KanaItem('ぴゅ', 'pyu', 'hiragana'), KanaItem('ぴょ', 'pyo', 'hiragana'),
];

// ── KATAKANA ──
const List<KanaItem> katakanaList = [
  KanaItem('ア', 'a', 'katakana'), KanaItem('イ', 'i', 'katakana'),
  KanaItem('ウ', 'u', 'katakana'), KanaItem('エ', 'e', 'katakana'),
  KanaItem('オ', 'o', 'katakana'), KanaItem('カ', 'ka', 'katakana'),
  KanaItem('キ', 'ki', 'katakana'), KanaItem('ク', 'ku', 'katakana'),
  KanaItem('ケ', 'ke', 'katakana'), KanaItem('コ', 'ko', 'katakana'),
  KanaItem('サ', 'sa', 'katakana'), KanaItem('シ', 'shi', 'katakana'),
  KanaItem('ス', 'su', 'katakana'), KanaItem('セ', 'se', 'katakana'),
  KanaItem('ソ', 'so', 'katakana'), KanaItem('タ', 'ta', 'katakana'),
  KanaItem('チ', 'chi', 'katakana'), KanaItem('ツ', 'tsu', 'katakana'),
  KanaItem('テ', 'te', 'katakana'), KanaItem('ト', 'to', 'katakana'),
  KanaItem('ナ', 'na', 'katakana'), KanaItem('ニ', 'ni', 'katakana'),
  KanaItem('ヌ', 'nu', 'katakana'), KanaItem('ネ', 'ne', 'katakana'),
  KanaItem('ノ', 'no', 'katakana'), KanaItem('ハ', 'ha', 'katakana'),
  KanaItem('ヒ', 'hi', 'katakana'), KanaItem('フ', 'fu', 'katakana'),
  KanaItem('ヘ', 'he', 'katakana'), KanaItem('ホ', 'ho', 'katakana'),
  KanaItem('マ', 'ma', 'katakana'), KanaItem('ミ', 'mi', 'katakana'),
  KanaItem('ム', 'mu', 'katakana'), KanaItem('メ', 'me', 'katakana'),
  KanaItem('モ', 'mo', 'katakana'), KanaItem('ヤ', 'ya', 'katakana'),
  KanaItem('ユ', 'yu', 'katakana'), KanaItem('ヨ', 'yo', 'katakana'),
  KanaItem('ラ', 'ra', 'katakana'), KanaItem('リ', 'ri', 'katakana'),
  KanaItem('ル', 'ru', 'katakana'), KanaItem('レ', 're', 'katakana'),
  KanaItem('ロ', 'ro', 'katakana'), KanaItem('ワ', 'wa', 'katakana'),
  KanaItem('ヲ', 'wo', 'katakana'), KanaItem('ン', 'n', 'katakana'),
  KanaItem('ガ', 'ga', 'katakana'), KanaItem('ギ', 'gi', 'katakana'),
  KanaItem('グ', 'gu', 'katakana'), KanaItem('ゲ', 'ge', 'katakana'),
  KanaItem('ゴ', 'go', 'katakana'), KanaItem('ザ', 'za', 'katakana'),
  KanaItem('ジ', 'ji', 'katakana'), KanaItem('ズ', 'zu', 'katakana'),
  KanaItem('ゼ', 'ze', 'katakana'), KanaItem('ゾ', 'zo', 'katakana'),
  KanaItem('ダ', 'da', 'katakana'), KanaItem('ヂ', 'ji', 'katakana'),
  KanaItem('ヅ', 'zu', 'katakana'), KanaItem('デ', 'de', 'katakana'),
  KanaItem('ド', 'do', 'katakana'), KanaItem('バ', 'ba', 'katakana'),
  KanaItem('ビ', 'bi', 'katakana'), KanaItem('ブ', 'bu', 'katakana'),
  KanaItem('ベ', 'be', 'katakana'), KanaItem('ボ', 'bo', 'katakana'),
  KanaItem('パ', 'pa', 'katakana'), KanaItem('ピ', 'pi', 'katakana'),
  KanaItem('プ', 'pu', 'katakana'), KanaItem('ペ', 'pe', 'katakana'),
  KanaItem('ポ', 'po', 'katakana'), KanaItem('キャ', 'kya', 'katakana'),
  KanaItem('キュ', 'kyu', 'katakana'), KanaItem('キョ', 'kyo', 'katakana'),
  KanaItem('シャ', 'sha', 'katakana'), KanaItem('シュ', 'shu', 'katakana'),
  KanaItem('ショ', 'sho', 'katakana'), KanaItem('チャ', 'cha', 'katakana'),
  KanaItem('チュ', 'chu', 'katakana'), KanaItem('チョ', 'cho', 'katakana'),
  KanaItem('ニャ', 'nya', 'katakana'), KanaItem('ニュ', 'nyu', 'katakana'),
  KanaItem('ニョ', 'nyo', 'katakana'), KanaItem('ヒャ', 'hya', 'katakana'),
  KanaItem('ヒュ', 'hyu', 'katakana'), KanaItem('ヒョ', 'hyo', 'katakana'),
  KanaItem('ミャ', 'mya', 'katakana'), KanaItem('ミュ', 'myu', 'katakana'),
  KanaItem('ミョ', 'myo', 'katakana'), KanaItem('リャ', 'rya', 'katakana'),
  KanaItem('リュ', 'ryu', 'katakana'), KanaItem('リョ', 'ryo', 'katakana'),
  KanaItem('ギャ', 'gya', 'katakana'), KanaItem('ギュ', 'gyu', 'katakana'),
  KanaItem('ギョ', 'gyo', 'katakana'), KanaItem('ジャ', 'ja', 'katakana'),
  KanaItem('ジュ', 'ju', 'katakana'), KanaItem('ジョ', 'jo', 'katakana'),
  KanaItem('ビャ', 'bya', 'katakana'), KanaItem('ビュ', 'byu', 'katakana'),
  KanaItem('ビョ', 'byo', 'katakana'), KanaItem('ピャ', 'pya', 'katakana'),
  KanaItem('ピュ', 'pyu', 'katakana'), KanaItem('ピョ', 'pyo', 'katakana'),
];

// ═══════════════════════════════════════════════════════════════════
// 🎮 ENUM MODE
// ═══════════════════════════════════════════════════════════════════
enum QuizMode { hiragana, katakana, mixed }

// ═══════════════════════════════════════════════════════════════════
// 🧊 3D HELPERS
// ═══════════════════════════════════════════════════════════════════
BoxDecoration _bevelDecoration({
  double radius = 18,
  Color? glow,
  double glowOpacity = 0.25,
}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        jqTextMain.withOpacity(0.20),
        jqRed.withOpacity(0.15),
        Colors.black.withOpacity(0.55),
      ],
      stops: const [0.0, 0.5, 1.0],
    ),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.75),
        blurRadius: 22,
        spreadRadius: -6,
        offset: const Offset(0, 12),
      ),
      BoxShadow(
        color: Colors.black.withOpacity(0.5),
        blurRadius: 8,
        offset: const Offset(0, 4),
      ),
      BoxShadow(
        color: (glow ?? jqGold).withOpacity(glowOpacity),
        blurRadius: 26,
        spreadRadius: -8,
        offset: const Offset(0, 6),
      ),
    ],
  );
}

Widget _bevelBox({
  required Widget child,
  double radius = 18,
  Color? glow,
  double glowOpacity = 0.25,
}) {
  return Container(
    decoration: _bevelDecoration(
        radius: radius, glow: glow, glowOpacity: glowOpacity),
    padding: const EdgeInsets.all(1.6),
    child: Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius - 1),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [jqBgCard, jqBgMain],
        ),
      ),
      child: child,
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════
// 🚪 MODE SELECTION SCREEN
// ═══════════════════════════════════════════════════════════════════
class QuizMenuPage extends StatefulWidget {
  const QuizMenuPage({super.key});

  @override
  State<QuizMenuPage> createState() => _QuizMenuPageState();
}

class _QuizMenuPageState extends State<QuizMenuPage> {
  int _highScoreHiragana = 0;
  int _highScoreKatakana = 0;
  int _highScoreMixed = 0;
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    _loadHighScores();
  }

  Future<void> _loadHighScores() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _highScoreHiragana = prefs.getInt('hs_hiragana') ?? 0;
      _highScoreKatakana = prefs.getInt('hs_katakana') ?? 0;
      _highScoreMixed = prefs.getInt('hs_mixed') ?? 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: jqBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(jqBgMain, jqRed, 0.25)!,
                  jqBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          const SizedBox(height: 8),

                          // Title
                          Text(
                            "あ ア か カ",
                            style: TextStyle(
                              color: jqGold.withOpacity(0.9),
                              fontSize: 28,
                              fontWeight: FontWeight.w300,
                              letterSpacing: 8,
                              shadows: [
                                Shadow(
                                  color: jqGold.withOpacity(0.5),
                                  blurRadius: 14,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "KUIS JEPANG",
                            style: TextStyle(
                              color: jqTextMain,
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 3,
                              fontFamily: 'Orbitron',
                              shadows: const [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 4,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Hiragana • Katakana",
                            style: TextStyle(
                              color: jqTextSub,
                              fontSize: 13,
                              letterSpacing: 2,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),

                          const SizedBox(height: 40),

                          // Mode cards
                          _buildModeCard(
                            title: "HIRAGANA",
                            subtitle: "ひらがな",
                            description: "104 karakter dasar Jepang",
                            emoji: "🌸",
                            color: jqRed,
                            highScore: _highScoreHiragana,
                            onTap: () => _openQuiz(QuizMode.hiragana),
                          ),
                          const SizedBox(height: 16),
                          _buildModeCard(
                            title: "KATAKANA",
                            subtitle: "カタカナ",
                            description: "104 karakter untuk kata serapan",
                            emoji: "⚡",
                            color: jqBlue,
                            highScore: _highScoreKatakana,
                            onTap: () => _openQuiz(QuizMode.katakana),
                          ),
                          const SizedBox(height: 16),
                          _buildModeCard(
                            title: "CAMPURAN",
                            subtitle: "ミックス",
                            description: "Hiragana + Katakana sekaligus",
                            emoji: "🎯",
                            color: jqGold,
                            highScore: _highScoreMixed,
                            onTap: () => _openQuiz(QuizMode.mixed),
                          ),

                          const SizedBox(height: 32),

                          // Stats
                          _buildStatsCard(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [jqBgSurface, jqBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: jqGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: jqGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [jqRed, jqRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: jqBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [jqRed, jqRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: jqBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: jqGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.translate_rounded, color: jqGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'KUIS JEPANG',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openQuiz(QuizMode mode) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => JapaneseQuizPage(mode: mode),
      ),
    );
    _loadHighScores();
  }

  Widget _buildModeCard({
    required String title,
    required String subtitle,
    required String description,
    required String emoji,
    required Color color,
    required int highScore,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: _bevelBox(
        radius: 20,
        glow: color,
        glowOpacity: 0.3,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              // Emoji circle
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      color,
                      Color.lerp(color, Colors.black, 0.5)!,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: jqBorderDark, width: 2.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.6),
                      blurRadius: 16,
                      spreadRadius: -3,
                    ),
                    const BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(emoji, style: const TextStyle(fontSize: 28)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            title,
                            style: TextStyle(
                              color: jqTextMain,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                              fontFamily: 'Orbitron',
                              shadows: const [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: jqGold.withOpacity(0.8),
                            fontSize: 13,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: TextStyle(
                        color: jqTextSub,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    if (highScore > 0) ...[
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.emoji_events_rounded,
                              color: jqYellow, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            "High Score: $highScore",
                            style: TextStyle(
                              color: jqYellow,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'ShareTechMono',
                              shadows: [
                                Shadow(
                                  color: jqYellow.withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: jqGold.withOpacity(0.7), size: 28),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    final total = hiraganaList.length + katakanaList.length;

    return _bevelBox(
      radius: 16,
      glow: jqGold,
      glowOpacity: 0.25,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _statItem("📖", "${hiraganaList.length}", "Hiragana"),
            Container(
              width: 1,
              height: 30,
              color: jqGold.withOpacity(0.2),
            ),
            _statItem("📕", "${katakanaList.length}", "Katakana"),
            Container(
              width: 1,
              height: 30,
              color: jqGold.withOpacity(0.2),
            ),
            _statItem("📚", "$total", "Total"),
          ],
        ),
      ),
    );
  }

  Widget _statItem(String emoji, String value, String label) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: jqGold,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(color: jqGold.withOpacity(0.6), blurRadius: 8),
            ],
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: jqTextSub,
            fontSize: 10,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🎮 MAIN QUIZ PAGE
// ═══════════════════════════════════════════════════════════════════
class JapaneseQuizPage extends StatefulWidget {
  final QuizMode mode;
  final int totalQuestions;
  final int secondsPerQuestion;
  final int maxLives;

  const JapaneseQuizPage({
    super.key,
    required this.mode,
    this.totalQuestions = 10,
    this.secondsPerQuestion = 10,
    this.maxLives = 3,
  });

  @override
  State<JapaneseQuizPage> createState() => _JapaneseQuizPageState();
}

class _JapaneseQuizPageState extends State<JapaneseQuizPage> {
  late List<KanaItem> _quizPool;
  late List<List<String>> _options;
  late List<String> _correctAnswer;

  int _currentIndex = 0;
  int _score = 0;
  int _lives = 3;
  int _secondsLeft = 10;
  int _comboCount = 0;
  int _bestCombo = 0;

  Timer? _timer;

  int? _selectedIndex;
  bool _isAnswered = false;
  bool _isGameOver = false;
  bool _isWon = false;

  final XThemeController _themeController = XThemeController();

  List<KanaItem> get _sourceList {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return hiraganaList;
      case QuizMode.katakana:
        return katakanaList;
      case QuizMode.mixed:
        return [...hiraganaList, ...katakanaList];
    }
  }

  Color get _accentColor {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return jqRed;
      case QuizMode.katakana:
        return jqBlue;
      case QuizMode.mixed:
        return jqGold;
    }
  }

  String get _modeLabel {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return "HIRAGANA";
      case QuizMode.katakana:
        return "KATAKANA";
      case QuizMode.mixed:
        return "CAMPURAN";
    }
  }

  String get _modeSub {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return "ひらがな";
      case QuizMode.katakana:
        return "カタカナ";
      case QuizMode.mixed:
        return "ミックス";
    }
  }

  String get _prefsKey {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return 'hs_hiragana';
      case QuizMode.katakana:
        return 'hs_katakana';
      case QuizMode.mixed:
        return 'hs_mixed';
    }
  }

  @override
  void initState() {
    super.initState();
    _lives = widget.maxLives;
    _secondsLeft = widget.secondsPerQuestion;
    _startNewGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startNewGame() {
    final random = Random();
    final source = _sourceList;

    final shuffled = List<KanaItem>.from(source)..shuffle(random);
    _quizPool = shuffled.take(widget.totalQuestions).toList();

    _options = [];
    _correctAnswer = [];

    for (final item in _quizPool) {
      final wrongs = <String>{};
      int tries = 0;
      while (wrongs.length < 3 && tries < 100) {
        final candidate = source[random.nextInt(source.length)];
        if (candidate.romaji != item.romaji) {
          wrongs.add(candidate.romaji);
        }
        tries++;
      }

      final opts = [item.romaji, ...wrongs]..shuffle(random);
      _options.add(opts);
      _correctAnswer.add(item.romaji);
    }

    _currentIndex = 0;
    _score = 0;
    _comboCount = 0;
    _bestCombo = 0;
    _lives = widget.maxLives;
    _isGameOver = false;
    _isWon = false;
    _resetQuestionState();
    _startTimer();
  }

  void _resetQuestionState() {
    _selectedIndex = null;
    _isAnswered = false;
    _secondsLeft = widget.secondsPerQuestion;
  }

  void _startTimer() {
    _timer?.cancel();
    _secondsLeft = widget.secondsPerQuestion;
    if (mounted) setState(() {});

    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_isAnswered || _isGameOver) return;

      setState(() => _secondsLeft--);

      if (_secondsLeft <= 0) {
        t.cancel();
        _handleTimeout();
      }
    });
  }

  void _handleTimeout() {
    if (_isAnswered || _isGameOver) return;
    setState(() {
      _isAnswered = true;
      _selectedIndex = -1;
      _lives--;
      _comboCount = 0;
    });
    _checkGameState();
    Future.delayed(const Duration(milliseconds: 1200), _nextQuestion);
  }

  void _handleAnswer(int index) {
    if (_isAnswered || _isGameOver) return;

    _timer?.cancel();
    final isRight =
        _options[_currentIndex][index] == _correctAnswer[_currentIndex];

    setState(() {
      _selectedIndex = index;
      _isAnswered = true;

      if (isRight) {
        _comboCount++;
        if (_comboCount > _bestCombo) _bestCombo = _comboCount;
        final bonus = min(_comboCount * 2, 15);
        _score += 10 + bonus;
      } else {
        _lives--;
        _comboCount = 0;
      }
    });

    _checkGameState();
    Future.delayed(const Duration(milliseconds: 900), _nextQuestion);
  }

  void _checkGameState() {
    if (_lives <= 0) {
      _isGameOver = true;
      _timer?.cancel();
      Future.delayed(const Duration(milliseconds: 800), _showGameOver);
    }
  }

  void _nextQuestion() {
    if (!mounted || _isGameOver) return;

    if (_currentIndex >= widget.totalQuestions - 1) {
      _isWon = true;
      _isGameOver = true;
      _showGameOver();
      return;
    }

    setState(() {
      _currentIndex++;
      _resetQuestionState();
    });
    _startTimer();
  }

  Future<void> _saveHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getInt(_prefsKey) ?? 0;
    if (_score > current) {
      await prefs.setInt(_prefsKey, _score);
    }
  }

  void _showGameOver() async {
    if (!mounted) return;
    await _saveHighScore();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildGameOverDialog(),
    );
  }

  Widget _buildGameOverDialog() {
    final totalPossible = widget.totalQuestions * 10;
    final percentage =
        totalPossible > 0 ? (_score / totalPossible * 100).round() : 0;

    String title, emoji, message;
    Color color;

    if (!_isWon && _lives <= 0) {
      title = "GAME OVER";
      emoji = "💔";
      color = jqRed;
      message = "Nyawa kamu habis!";
    } else if (percentage >= 90) {
      title = "SUGOI! 🎌";
      emoji = "🏆";
      color = jqGreen;
      message = "Luar biasa! Master $_modeLabel!";
    } else if (percentage >= 70) {
      title = "YOKATTA! ✨";
      emoji = "🎉";
      color = jqBlue;
      message = "Bagus! Terus berlatih!";
    } else if (percentage >= 50) {
      title = "GANBATTE! 💪";
      emoji = "👍";
      color = jqGold;
      message = "Lumayan! Coba lagi ya!";
    } else {
      title = "TRY AGAIN";
      emoji = "📚";
      color = jqRed;
      message = "Belajar lagi $_modeLabel-nya!";
    }

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(24),
      child: _bevelBox(
        radius: 24,
        glow: color,
        glowOpacity: 0.5,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 64)),
              const SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                  color: color,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                  shadows: [
                    Shadow(color: color.withOpacity(0.6), blurRadius: 16),
                    const Shadow(
                      color: Color(0xCC000000),
                      blurRadius: 3,
                      offset: Offset(1, 1),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: jqTextSub,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 20),

              // Score box
              Container(
                padding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [jqBgSurface, jqBgMain],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: color.withOpacity(0.4),
                    width: 2,
                  ),
                  boxShadow: [
                    const BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 14,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      "TOTAL SCORE",
                      style: TextStyle(
                        color: jqTextSub,
                        fontSize: 11,
                        letterSpacing: 2,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "$_score",
                      style: TextStyle(
                        color: color,
                        fontSize: 44,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: color.withOpacity(0.8),
                            blurRadius: 20,
                          ),
                          const Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "dari $totalPossible poin ($percentage%)",
                      style: TextStyle(
                        color: jqTextSub,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _miniStat("🔥", "Best Combo", "$_bestCombo"),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _miniStat("✅", "Benar", "$_currentIndex"),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: _dialogBtn(
                      icon: Icons.home_rounded,
                      label: "MENU",
                      color: jqRed,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _dialogBtn(
                      icon: Icons.refresh_rounded,
                      label: "ULANG",
                      color: jqGreen,
                      onTap: () {
                        Navigator.pop(context);
                        setState(() => _startNewGame());
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniStat(String emoji, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [jqBgCard, jqBgMain],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: jqGold.withOpacity(0.3), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: jqTextSub,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: jqTextMain,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _dialogBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color,
              Color.lerp(color, Colors.black, 0.5)!,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: jqBorderDark, width: 2.5),
          boxShadow: [
            const BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(3, 3),
            ),
            BoxShadow(
              color: color.withOpacity(0.5),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                fontFamily: 'Orbitron',
                shadows: [
                  Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: jqBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(jqBgMain, jqRed, 0.25)!,
                  jqBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  _buildProgressBar(),
                  _buildTopBar(),
                  const SizedBox(height: 20),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          _buildQuestionCard(),
                          const SizedBox(height: 24),
                          _buildOptions(),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [jqRed, jqRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: jqBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: jqRed.withOpacity(0.5),
                    blurRadius: 12,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: const Icon(Icons.close, color: Colors.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Kuis $_modeLabel",
                  style: TextStyle(
                    color: jqTextMain,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                Text(
                  _modeSub,
                  style: TextStyle(
                    color: jqGold,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (_comboCount >= 3)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [jqRed, jqGold],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: jqBorderDark, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: jqRed.withOpacity(0.5),
                    blurRadius: 14,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Text("🔥", style: TextStyle(fontSize: 14)),
                  const SizedBox(width: 4),
                  Text(
                    "x$_comboCount",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    final progress = (_currentIndex + 1) / widget.totalQuestions;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Container(
        height: 8,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: jqGold.withOpacity(0.3), width: 1.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(1.5, 1.5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: Stack(
            children: [
              Container(color: jqBgMain),
              AnimatedContainer(
                duration: const Duration(milliseconds: 400),
                height: 8,
                width: MediaQuery.of(context).size.width * progress * 0.9,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _accentColor,
                      Color.lerp(_accentColor, Colors.black, 0.4)!,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _accentColor.withOpacity(0.6),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            children: List.generate(widget.maxLives, (i) {
              return Padding(
                padding: const EdgeInsets.only(right: 2),
                child: Icon(
                  i < _lives ? Icons.favorite : Icons.favorite_border,
                  color: i < _lives ? jqHeart : jqTextSub.withOpacity(0.3),
                  size: 22,
                  shadows: i < _lives
                      ? [
                          Shadow(
                            color: jqHeart.withOpacity(0.8),
                            blurRadius: 10,
                          )
                        ]
                      : null,
                ),
              );
            }),
          ),
          Expanded(
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [jqBgSurface, jqBgMain],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: _secondsLeft <= 3
                        ? jqRed
                        : jqGold.withOpacity(0.5),
                    width: 2,
                  ),
                  boxShadow: [
                    const BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                    BoxShadow(
                      color: (_secondsLeft <= 3 ? jqRed : jqGold)
                          .withOpacity(0.35),
                      blurRadius: 16,
                      spreadRadius: -3,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.hourglass_bottom,
                      color: _secondsLeft <= 3 ? jqRed : jqGold,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "${_secondsLeft}s",
                      style: TextStyle(
                        color: _secondsLeft <= 3 ? jqRed : jqTextMain,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "Skor:",
                style: TextStyle(
                  color: jqTextSub,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [jqGold, jqTextMain, jqGold],
                ).createShader(bounds),
                child: Text(
                  "$_score",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    shadows: [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionCard() {
    final item = _quizPool[_currentIndex];
    final isKatakana = item.type == 'katakana';

    return Column(
      children: [
        Text(
          "${_currentIndex + 1} / ${widget.totalQuestions}",
          style: TextStyle(
            color: jqTextSub,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            letterSpacing: 1,
            fontFamily: 'ShareTechMono',
          ),
        ),
        const SizedBox(height: 16),

        // Type badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                (isKatakana ? jqBlue : jqRed).withOpacity(0.8),
                (isKatakana ? jqBlue : jqRed).withOpacity(0.4),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: jqBorderDark, width: 2),
            boxShadow: [
              const BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
              BoxShadow(
                color: (isKatakana ? jqBlue : jqRed).withOpacity(0.5),
                blurRadius: 10,
              ),
            ],
          ),
          child: Text(
            isKatakana ? "カタカナ" : "ひらがな",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
        const SizedBox(height: 16),

        _bevelBox(
          radius: 24,
          glow: _accentColor,
          glowOpacity: 0.4,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
            child: Column(
              children: [
                Text(
                  "Romaji dari huruf/kata ini?",
                  style: TextStyle(
                    color: jqTextSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  item.kana,
                  style: TextStyle(
                    color: jqTextMain,
                    fontSize: 96,
                    fontWeight: FontWeight.w600,
                    height: 1.1,
                    shadows: [
                      Shadow(
                        color: _accentColor.withOpacity(0.6),
                        blurRadius: 20,
                      ),
                      const Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 6,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOptions() {
    final opts = _options[_currentIndex];
    final correct = _correctAnswer[_currentIndex];

    return Column(
      children: List.generate(opts.length, (index) {
        final option = opts[index];
        final isSelected = _selectedIndex == index;

        Color borderColor = jqGold.withOpacity(0.4);
        Color bgTop = jqBgOption;
        Color bgBottom = jqBgMain;
        Color textColor = jqTextMain;
        IconData? trailingIcon;
        double glowOpacity = 0.15;
        Color glowColor = jqGold;

        if (_isAnswered) {
          if (option == correct) {
            borderColor = jqGreen;
            bgTop = Color.lerp(jqBgOption, jqGreen, 0.25)!;
            bgBottom = jqBgMain;
            textColor = jqGreen;
            trailingIcon = Icons.check_circle;
            glowColor = jqGreen;
            glowOpacity = 0.5;
          } else if (isSelected) {
            borderColor = jqRed;
            bgTop = Color.lerp(jqBgOption, jqRed, 0.25)!;
            bgBottom = jqBgMain;
            textColor = jqRed;
            trailingIcon = Icons.cancel;
            glowColor = jqRed;
            glowOpacity = 0.5;
          }
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GestureDetector(
            onTap: _isAnswered ? null : () => _handleAnswer(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    textColor.withOpacity(0.10),
                    bgTop.withOpacity(0.15),
                    Colors.black.withOpacity(0.55),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: glowColor.withOpacity(glowOpacity),
                    blurRadius: 16,
                    spreadRadius: -4,
                  ),
                ],
              ),
              padding: const EdgeInsets.all(1.6),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    vertical: 18, horizontal: 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [bgTop, bgBottom],
                  ),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: borderColor, width: 2),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        option,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                          fontFamily: 'ShareTechMono',
                          shadows: const [
                            Shadow(
                              color: Color(0xAA000000),
                              blurRadius: 3,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (trailingIcon != null)
                      Icon(trailingIcon, color: textColor, size: 24),
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}