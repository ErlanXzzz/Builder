// lib/features/tools/language/kamus_jepang_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// ─── XTHEME-DRIVEN COLORS ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
Color kjBgMain = const Color(0xFF160A07);
Color kjBgSurface = const Color(0xFF2A140E);
Color kjBgCard = const Color(0xFF3A1E15);
Color kjBgElevated = const Color(0xFF4A2818);
Color kjTextMain = const Color(0xFFF3E6DD);
Color kjTextSub = const Color(0xFFC9913F);
Color kjGold = const Color(0xFFD4A853);
Color kjRed = const Color(0xFFB71C1C);
Color kjRedDark = const Color(0xFF7F0000);
Color kjRedDeep = const Color(0xFF4A0000);
Color kjGreen = const Color(0xFF4CAF50);
Color kjBlue = const Color(0xFF2196F3);
Color kjYellow = const Color(0xFFFFC107);
Color kjBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  kjBgMain     = theme.brownDark;
  kjBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  kjBgCard     = theme.brownMid;
  kjBgElevated = Color.lerp(theme.brownMid, theme.bgCreamLight, 0.15)!;
  kjTextMain   = theme.bgCreamLight;
  kjTextSub    = theme.gold;
  kjGold       = theme.gold;
  kjRed        = theme.redMain;
  kjRedDark    = theme.redDark;
  kjRedDeep    = theme.redDeep;
  kjGreen      = theme.accentGreen;
  kjBlue       = theme.accentBlue;
  kjYellow     = theme.accentYellow;
  kjBorderDark = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// ─── 3D HELPERS ───────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
BoxDecoration _bevelDecoration({
  double radius = 18,
  Color? glow,
  double glowOpacity = 0.25,
}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        kjTextMain.withOpacity(0.20),
        kjRed.withOpacity(0.15),
        Colors.black.withOpacity(0.55),
      ],
      stops: const [0.0, 0.5, 1.0],
    ),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.75),
        blurRadius: 22,
        spreadRadius: -6,
        offset: const Offset(0, 12),
      ),
      BoxShadow(
        color: Colors.black.withOpacity(0.5),
        blurRadius: 8,
        offset: const Offset(0, 4),
      ),
      BoxShadow(
        color: (glow ?? kjGold).withOpacity(glowOpacity),
        blurRadius: 26,
        spreadRadius: -8,
        offset: const Offset(0, 6),
      ),
    ],
  );
}

Widget _bevelBox({
  required Widget child,
  double radius = 18,
  Color? glow,
  double glowOpacity = 0.25,
}) {
  return Container(
    decoration: _bevelDecoration(
        radius: radius, glow: glow, glowOpacity: glowOpacity),
    padding: const EdgeInsets.all(1.6),
    child: Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius - 1),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [kjBgCard, kjBgMain],
        ),
      ),
      child: child,
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════
// ─── ENTRY POINT ──────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class KamusJepangPage extends StatelessWidget {
  const KamusJepangPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const KamusHomePage();
  }
}

// ═══════════════════════════════════════════════════════════════════
// ─── 1. MODEL DATA ────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class Kosakata {
  final String romaji;
  final String hiragana;
  final String katakana;
  final String kanji;
  final String arti;
  final String kategori;

  const Kosakata({
    required this.romaji,
    required this.hiragana,
    required this.katakana,
    required this.kanji,
    required this.arti,
    required this.kategori,
  });
}

// ═══════════════════════════════════════════════════════════════════
// ─── 2. DATA KAMUS (LOKAL) ────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
// ⚠️ PASTE dataKamus LAMA KAMU DI SINI (mulai dari:
//    const List<Kosakata> dataKamus = [ ... ];
//    sampai tutup bracket ]; )
//
// Data kamu ada ~200+ item, sama persis seperti file lama.
// Tidak perlu diubah sama sekali.
// ═══════════════════════════════════════════════════════════════════

// Contoh 3 item (GANTI dengan list lengkap dari file lama kamu):
const List<Kosakata> dataKamus = [
  Kosakata(
    romaji: "ohayou gozaimasu",
    hiragana: "おはようございます",
    katakana: "オハヨウゴザイマス",
    kanji: "お早うございます",
    arti: "Selamat pagi (formal)",
    kategori: "Salam",
  ),
  // ... PASTE SEMUA ITEM LAMA KAMU DI SINI
];

// ═══════════════════════════════════════════════════════════════════
// ─── 3. HALAMAN UTAMA KAMUS ───────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class KamusHomePage extends StatefulWidget {
  const KamusHomePage({super.key});

  @override
  State<KamusHomePage> createState() => _KamusHomePageState();
}

class _KamusHomePageState extends State<KamusHomePage> {
  final TextEditingController _searchController = TextEditingController();
  List<Kosakata> hasil = List.from(dataKamus);
  String kategoriTerpilih = "Semua";
  final Set<Kosakata> favorit = {};
  final XThemeController _themeController = XThemeController();

  final List<String> kategoriList = [
    "Semua", "Salam", "Angka", "Hari", "Keluarga",
    "Kata Kerja", "Benda", "Warna", "Sifat", "Tempat",
    "Alam", "JLPT N5", "JLPT N4",
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void cari(String query) {
    setState(() {
      hasil = dataKamus.where((k) {
        final cocokKategori =
            kategoriTerpilih == "Semua" || k.kategori == kategoriTerpilih;
        final q = query.toLowerCase().trim();
        final cocokQuery = q.isEmpty ||
            k.romaji.toLowerCase().contains(q) ||
            k.hiragana.contains(q) ||
            k.katakana.contains(q) ||
            k.kanji.contains(q) ||
            k.arti.toLowerCase().contains(q);
        return cocokKategori && cocokQuery;
      }).toList();
    });
  }

  void toggleFavorit(Kosakata k) {
    setState(() {
      if (favorit.contains(k)) {
        favorit.remove(k);
      } else {
        favorit.add(k);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: kjBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(kjBgMain, kjRed, 0.25)!,
                  kjBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  _buildSearchBar(),
                  _buildCategoryChips(),
                  _buildResultInfo(),
                  Expanded(
                    child: hasil.isEmpty
                        ? _buildEmptyState()
                        : ListView.builder(
                            itemCount: hasil.length,
                            padding: const EdgeInsets.only(bottom: 12),
                            itemBuilder: (context, i) {
                              return _buildKosakataCard(hasil[i]);
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── APP BAR 3D ─────────────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 12, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [kjBgSurface, kjBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: kjGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: kjGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [kjRed, kjRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kjBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [kjRed, kjRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: kjBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: kjGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.menu_book_rounded, color: kjGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'KAMUS JEPANG',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {
              if (favorit.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Belum ada kosakata favorit',
                      style: TextStyle(
                        color: kjTextMain,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    backgroundColor: kjRed,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: kjBorderDark, width: 2),
                    ),
                  ),
                );
                return;
              }
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => FavoritPage(
                    favorit: favorit.toList(),
                    onToggle: toggleFavorit,
                  ),
                ),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [kjRed, kjRedDark],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kjBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: kjRed.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Icon(Icons.favorite,
                  color: kjGold, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SEARCH BAR 3D ──────────────────────────────────────────
  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [kjBgSurface, kjBgMain],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kjGold, width: 2.5),
        boxShadow: [
          const BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: kjGold.withOpacity(0.3),
            blurRadius: 12,
          ),
        ],
      ),
      child: TextField(
        controller: _searchController,
        onChanged: cari,
        cursorColor: kjGold,
        style: TextStyle(
          color: kjTextMain,
          fontSize: 14,
          fontFamily: 'ShareTechMono',
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          hintText: 'Cari (romaji / hiragana / kanji / arti)...',
          hintStyle: TextStyle(
            color: kjTextSub.withOpacity(0.5),
            fontSize: 12,
          ),
          prefixIcon: Icon(Icons.search, color: kjGold, size: 20),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: Icon(Icons.clear, color: kjTextSub, size: 18),
                  onPressed: () {
                    _searchController.clear();
                    cari('');
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 14, vertical: 16),
        ),
      ),
    );
  }

  // ─── CATEGORY CHIPS 3D ──────────────────────────────────────
  Widget _buildCategoryChips() {
    return SizedBox(
      height: 48,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: kategoriList.length,
        itemBuilder: (context, i) {
          final kat = kategoriList[i];
          final aktif = kat == kategoriTerpilih;
          return Padding(
            padding: const EdgeInsets.only(right: 8, top: 4, bottom: 4),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  kategoriTerpilih = kat;
                  cari(_searchController.text);
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: aktif
                      ? LinearGradient(
                          colors: [kjRed, kjRedDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : LinearGradient(
                          colors: [kjBgSurface, kjBgMain],
                        ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: aktif ? kjGold : kjGold.withOpacity(0.3),
                    width: aktif ? 2.5 : 1.5,
                  ),
                  boxShadow: aktif
                      ? [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                          BoxShadow(
                            color: kjRed.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ]
                      : const [
                          BoxShadow(
                            color: Color(0x88000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                        ],
                ),
                child: Center(
                  child: Text(
                    kat,
                    style: TextStyle(
                      color: aktif ? Colors.white : kjTextSub,
                      fontWeight: aktif ? FontWeight.w900 : FontWeight.w600,
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      letterSpacing: 0.5,
                      shadows: aktif
                          ? const [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ]
                          : null,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── RESULT INFO ────────────────────────────────────────────
  Widget _buildResultInfo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [kjGold, Color.lerp(kjGold, Colors.black, 0.4)!],
              ),
              shape: BoxShape.circle,
              border: Border.all(color: kjBorderDark, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: kjGold.withOpacity(0.5),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Icon(Icons.list_alt_rounded, color: kjRedDark, size: 11),
          ),
          const SizedBox(width: 8),
          Text(
            '${hasil.length} kosakata ditemukan',
            style: TextStyle(
              color: kjTextSub,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ────────────────────────────────────────────
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: kjGold.withOpacity(0.1),
              border: Border.all(
                color: kjGold.withOpacity(0.3),
                width: 2,
              ),
            ),
            child: Icon(
              Icons.search_off_rounded,
              size: 60,
              color: kjGold.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Tidak ditemukan 😢',
            style: TextStyle(
              color: kjTextMain,
              fontSize: 16,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Coba kata kunci lain',
            style: TextStyle(
              color: kjTextSub,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // ─── KOSAKATA CARD 3D ───────────────────────────────────────
  Widget _buildKosakataCard(Kosakata k) {
    final isFav = favorit.contains(k);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: GestureDetector(
        onTap: () => _showDetail(context, k),
        child: _bevelBox(
          radius: 14,
          glow: isFav ? kjRed : kjGold,
          glowOpacity: isFav ? 0.4 : 0.2,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // Avatar kanji
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [kjRed, kjRedDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: kjBorderDark, width: 2.5),
                    boxShadow: [
                      const BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                      BoxShadow(
                        color: kjRed.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      k.kanji.isNotEmpty ? k.kanji[0] : '?',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        color: kjGold,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: kjGold.withOpacity(0.8),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${k.kanji} • ${k.hiragana}',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: kjTextMain,
                          fontFamily: 'Orbitron',
                          shadows: const [
                            Shadow(
                              color: Color(0xCC000000),
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${k.romaji} | ${k.katakana}',
                        style: TextStyle(
                          fontSize: 11,
                          color: kjTextSub,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        k.arti,
                        style: TextStyle(
                          color: kjGold,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                          shadows: [
                            Shadow(
                              color: kjGold.withOpacity(0.5),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),

                // Favorit + kategori
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () => toggleFavorit(k),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          gradient: isFav
                              ? LinearGradient(
                                  colors: [kjRed, kjRedDark],
                                )
                              : null,
                          color: isFav ? null : Colors.transparent,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isFav
                                ? kjGold
                                : kjGold.withOpacity(0.3),
                            width: 1.5,
                          ),
                          boxShadow: isFav
                              ? [
                                  BoxShadow(
                                    color: kjRed.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        ),
                        child: Icon(
                          isFav ? Icons.favorite : Icons.favorite_border,
                          color: isFav ? kjGold : kjTextSub,
                          size: 16,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      k.kategori,
                      style: TextStyle(
                        fontSize: 9,
                        color: kjTextSub.withOpacity(0.7),
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── DETAIL BOTTOM SHEET 3D ────────────────────────────────
  void _showDetail(BuildContext context, Kosakata k) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => AnimatedBuilder(
        animation: _themeController,
        builder: (context, _) {
          applyXTheme(_themeController.currentTheme);

          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [kjBgSurface, kjBgMain],
              ),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(
                top: BorderSide(color: kjGold, width: 3),
                left: BorderSide(color: kjBorderDark, width: 2),
                right: BorderSide(color: kjBorderDark, width: 2),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.7),
                  blurRadius: 30,
                  offset: const Offset(0, -10),
                ),
                BoxShadow(
                  color: kjGold.withOpacity(0.3),
                  blurRadius: 22,
                ),
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: kjGold.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [
                          BoxShadow(
                            color: kjGold.withOpacity(0.5),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Kanji besar
                  Center(
                    child: Text(
                      k.kanji,
                      style: TextStyle(
                        fontSize: 64,
                        fontWeight: FontWeight.bold,
                        color: kjGold,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: kjGold.withOpacity(0.7),
                            blurRadius: 20,
                          ),
                          const Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 4,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Hiragana
                  Center(
                    child: Text(
                      k.hiragana,
                      style: TextStyle(
                        fontSize: 22,
                        color: kjTextMain,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Divider gradient
                  Container(
                    height: 2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          kjGold.withOpacity(0.6),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  _rowDetail('Romaji', k.romaji),
                  _rowDetail('Hiragana', k.hiragana),
                  _rowDetail('Katakana', k.katakana),
                  _rowDetail('Kanji', k.kanji),
                  _rowDetail('Arti', k.arti),
                  _rowDetail('Kategori', k.kategori),
                  const SizedBox(height: 20),

                  // Copy button
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(
                        text:
                            '${k.kanji} (${k.hiragana}) - ${k.romaji} = ${k.arti}',
                      ));
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            '📋 Tersalin ke clipboard',
                            style: TextStyle(
                              color: kjTextMain,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          backgroundColor: kjGreen,
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(color: kjBorderDark, width: 2),
                          ),
                        ),
                      );
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [kjRed, kjRedDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kjBorderDark, width: 2.5),
                        boxShadow: [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(3, 3),
                          ),
                          BoxShadow(
                            color: kjRed.withOpacity(0.5),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.copy_rounded,
                              color: kjGold, size: 18),
                          const SizedBox(width: 8),
                          const Text(
                            'COPY KE CLIPBOARD',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1.5,
                              shadows: [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _rowDetail(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 90,
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.w900,
                color: kjGold,
                fontFamily: 'Orbitron',
                fontSize: 11,
                letterSpacing: 1,
              ),
            ),
          ),
          Text(':', style: TextStyle(color: kjGold)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 14,
                color: kjTextMain,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// ─── 4. HALAMAN FAVORIT ───────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class FavoritPage extends StatefulWidget {
  final List<Kosakata> favorit;
  final Function(Kosakata) onToggle;

  const FavoritPage({
    super.key,
    required this.favorit,
    required this.onToggle,
  });

  @override
  State<FavoritPage> createState() => _FavoritPageState();
}

class _FavoritPageState extends State<FavoritPage> {
  late List<Kosakata> items;
  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    items = List.from(widget.favorit);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: kjBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(kjBgMain, kjRed, 0.25)!,
                  kjBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  // App bar
                  Container(
                    padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [kjBgSurface, kjBgMain],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      border: Border(
                        bottom: BorderSide(
                            color: kjGold.withOpacity(0.4), width: 2),
                      ),
                      boxShadow: [
                        const BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(0, 4),
                        ),
                        BoxShadow(
                            color: kjGold.withOpacity(0.25),
                            blurRadius: 18),
                      ],
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [kjRed, kjRedDark],
                              ),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: kjBorderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                              ],
                            ),
                            child: const Icon(Icons.arrow_back_ios_new,
                                color: Colors.white, size: 16),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [kjRed, kjRedDark],
                              ),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: kjBorderDark, width: 2.5),
                              boxShadow: [
                                const BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                                BoxShadow(
                                  color: kjGold.withOpacity(0.5),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.favorite,
                                    color: kjGold, size: 16),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    'KOSAKATA FAVORIT',
                                    style: const TextStyle(
                                      fontFamily: 'Orbitron',
                                      fontWeight: FontWeight.w900,
                                      fontSize: 12,
                                      letterSpacing: 1.5,
                                      color: Colors.white,
                                      shadows: [
                                        Shadow(
                                          color: Color(0xCC000000),
                                          blurRadius: 3,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Content
                  Expanded(
                    child: items.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(24),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: kjGold.withOpacity(0.1),
                                    border: Border.all(
                                      color: kjGold.withOpacity(0.3),
                                      width: 2,
                                    ),
                                  ),
                                  child: Icon(
                                    Icons.favorite_border_rounded,
                                    size: 60,
                                    color: kjGold.withOpacity(0.6),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'Belum ada favorit',
                                  style: TextStyle(
                                    color: kjTextMain,
                                    fontSize: 16,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(12),
                            itemCount: items.length,
                            itemBuilder: (context, i) {
                              final k = items[i];
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: _bevelBox(
                                  radius: 12,
                                  glow: kjRed,
                                  glowOpacity: 0.3,
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 42,
                                          height: 42,
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              colors: [kjRed, kjRedDark],
                                            ),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                                color: kjBorderDark,
                                                width: 2),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color(0xCC000000),
                                                blurRadius: 0,
                                                offset: Offset(2, 2),
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              k.kanji.isNotEmpty
                                                  ? k.kanji[0]
                                                  : '?',
                                              style: TextStyle(
                                                color: kjGold,
                                                fontWeight: FontWeight.w900,
                                                fontSize: 18,
                                                fontFamily: 'Orbitron',
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                '${k.kanji} (${k.hiragana})',
                                                style: TextStyle(
                                                  color: kjTextMain,
                                                  fontWeight: FontWeight.w900,
                                                  fontSize: 13,
                                                  fontFamily: 'Orbitron',
                                                ),
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                '${k.romaji} - ${k.arti}',
                                                style: TextStyle(
                                                  color: kjTextSub,
                                                  fontSize: 11,
                                                  fontFamily: 'ShareTechMono',
                                                ),
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              widget.onToggle(k);
                                              items.removeAt(i);
                                            });
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              gradient: LinearGradient(
                                                colors: [kjRed, kjRedDark],
                                              ),
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                  color: kjBorderDark,
                                                  width: 2),
                                              boxShadow: [
                                                const BoxShadow(
                                                  color: Color(0xCC000000),
                                                  blurRadius: 0,
                                                  offset: Offset(2, 2),
                                                ),
                                                BoxShadow(
                                                  color: kjRed.withOpacity(0.5),
                                                  blurRadius: 8,
                                                ),
                                              ],
                                            ),
                                            child: Icon(
                                              Icons.delete_outline_rounded,
                                              color: kjGold,
                                              size: 16,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}