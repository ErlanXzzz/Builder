import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class DinoGameApp extends StatelessWidget {
  const DinoGameApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF2B0E0E), // brownDark
      ),
      home: const DinoGameScreen(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🎨 PALET WARNA ATLAS (SAMA DENGAN TAMPILAN A)
// ═══════════════════════════════════════════════════════════════════
class AtlasTheme {
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color borderDark   = Color(0xFF1A0505);
}

// Model Rintangan Dinamis
enum ObstacleType { cactus, bird }

class Obstacle {
  double x;
  double width;
  double height;
  double yOffset; // Y offset dari tanah (untuk burung melayang)
  ObstacleType type;

  Obstacle({
    required this.x,
    required this.width,
    required this.height,
    this.yOffset = 0,
    required this.type,
  });
}

class DinoGameScreen extends StatefulWidget {
  const DinoGameScreen({Key? key}) : super(key: key);

  @override
  State<DinoGameScreen> createState() => _DinoGameScreenState();
}

class _DinoGameScreenState extends State<DinoGameScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _gradientController;

  // Status Game
  bool isPlaying = false;
  bool isGameOver = false;
  int score = 0;
  int highScore = 0;

  // Fisika Dino
  double dinoY = 0;
  double dinoVelocity = 0;
  bool isGrounded = true;
  final double gravity = 1300;
  final double jumpForce = -540;

  // Rintangan
  List<Obstacle> obstacles = [];
  double obstacleSpeed = 340;
  double spawnTimer = 0;
  final Random _random = Random();

  // Animasi
  int legFrame = 0;
  double legTimer = 0;
  double groundOffset = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..addListener(_gameLoop);

    _gradientController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  void _startGame() {
    setState(() {
      isPlaying = true;
      isGameOver = false;
      score = 0;
      dinoY = 0;
      dinoVelocity = 0;
      isGrounded = true;
      obstacles.clear();
      obstacleSpeed = 340;
    });
    _controller.repeat();
  }

  void _jump() {
    if (!isPlaying) {
      _startGame();
    } else if (isGrounded) {
      setState(() {
        dinoVelocity = jumpForce;
        isGrounded = false;
      });
    }
  }

  void _gameLoop() {
    if (!isPlaying || isGameOver) return;

    final double dt = 0.016; // ~60 FPS

    setState(() {
      // 1. Fisika Dino
      dinoY += dinoVelocity * dt;
      dinoVelocity += gravity * dt;

      if (dinoY >= 0) {
        dinoY = 0;
        dinoVelocity = 0;
        isGrounded = true;
      }

      // 2. Skor & Kecepatan Berkelanjutan
      score += 1;
      if (score > highScore) highScore = score;
      
      // Peningkatan kecepatan bertahap sesuai skor
      obstacleSpeed = 340 + (score / 10);

      // 3. Animasi
      groundOffset = (groundOffset + obstacleSpeed * dt) % 36;
      legTimer += dt;
      if (legTimer > 0.08) {
        legFrame = (legFrame + 1) % 2;
        legTimer = 0;
      }

      // 4. Generator Rintangan Dinamis Berdasarkan Skor
      spawnTimer += dt;
      double minSpawnTime = max(0.7, 1.5 - (score / 2000));
      
      if (spawnTimer > (minSpawnTime + _random.nextDouble() * 1.0)) {
        double screenWidth = MediaQuery.of(context).size.width;
        
        // Pilih jenis rintangan berdasarkan Tingkat Skor
        bool canSpawnBird = score >= 500 && _random.nextBool();
        
        if (canSpawnBird) {
          // Burung Melayang
          double birdY = _random.nextBool() ? 35 : 65; // Tinggi burung bervariasi
          obstacles.add(
            Obstacle(
              x: screenWidth,
              width: 34,
              height: 24,
              yOffset: birdY,
              type: ObstacleType.bird,
            ),
          );
        } else {
          // Kaktus (Makin tinggi skor, ukuran makin bervariasi)
          double cactusWidth = 20.0 + _random.nextInt(3) * 14.0;
          double cactusHeight = 35.0 + (score > 200 ? _random.nextInt(2) * 12.0 : 0);
          
          obstacles.add(
            Obstacle(
              x: screenWidth,
              width: cactusWidth,
              height: cactusHeight,
              yOffset: 0,
              type: ObstacleType.cactus,
            ),
          );
        }
        spawnTimer = 0;
      }

      // 5. Deteksi Tabrakan (AABB Collision)
      final double dinoBoxLeft = 50;
      final double dinoBoxRight = 85;
      final double dinoBoxBottom = -dinoY;
      final double dinoBoxTop = dinoBoxBottom + 40;

      for (int i = 0; i < obstacles.length; i++) {
        obstacles[i].x -= obstacleSpeed * dt;

        double obsLeft = obstacles[i].x;
        double obsRight = obstacles[i].x + obstacles[i].width;
        double obsBottom = obstacles[i].yOffset;
        double obsTop = obsBottom + obstacles[i].height;

        if (dinoBoxRight > obsLeft &&
            dinoBoxLeft < obsRight &&
            dinoBoxTop > obsBottom &&
            dinoBoxBottom < obsTop) {
          _gameOver();
          break;
        }
      }

      obstacles.removeWhere((obs) => obs.x < -60);
    });
  }

  void _gameOver() {
    _controller.stop();
    setState(() {
      isGameOver = true;
      isPlaying = false;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _gradientController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AtlasTheme.brownDark,
      body: GestureDetector(
        onTapDown: (_) => _jump(),
        behavior: HitTestBehavior.opaque,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AtlasTheme.brownDark, AtlasTheme.redDeep, AtlasTheme.brownDark],
              stops: [0.0, 0.5, 1.0],
            ),
          ),
          child: Stack(
            children: [
              // Radial Glow Animasi
              AnimatedBuilder(
                animation: _gradientController,
                builder: (context, child) {
                  final angle = _gradientController.value * 2 * pi;
                  final dx = 0.5 + 0.5 * cos(angle);
                  final dy = 0.5 + 0.5 * sin(angle);
                  return Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment(dx, dy),
                          radius: 1.2,
                          colors: [
                            AtlasTheme.redMain.withOpacity(0.15),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              // Grid Titik khas ATLAS
              Positioned.fill(child: CustomPaint(painter: GridPainter())),

              SafeArea(
                child: Column(
                  children: [
                    const SizedBox(height: 16),
                    
                    // Header Status & Papan Skor
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AtlasTheme.redMain.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AtlasTheme.gold, width: 1.5),
                            ),
                            child: const Text(
                              'ATLAS RUNNER',
                              style: TextStyle(
                                color: AtlasTheme.gold,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                          Text(
                            'HI ${highScore.toString().padLeft(5, '0')}  ${score.toString().padLeft(5, '0')}',
                            style: const TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: AtlasTheme.bgCreamLight,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),

                    // Area Canvas Utama Game Dino 3D
                    SizedBox(
                      height: 180,
                      width: double.infinity,
                      child: CustomPaint(
                        painter: AtlasDinoPainter(
                          dinoY: dinoY,
                          legFrame: legFrame,
                          isGrounded: isGrounded,
                          obstacles: obstacles,
                          groundOffset: groundOffset,
                          isGameOver: isGameOver,
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Kartu Info / Panel Pesan Neobrutalism ATLAS
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [AtlasTheme.bgCreamLight, AtlasTheme.bgCream],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AtlasTheme.borderDark, width: 3.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(5, 5),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AtlasTheme.redMain,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: AtlasTheme.borderDark, width: 2),
                                  ),
                                  child: const Icon(Icons.videogame_asset, color: AtlasTheme.gold, size: 20),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  isGameOver ? 'GAME OVER' : (!isPlaying ? 'SIAP BERMAIN?' : 'SISTEM BERJALAN'),
                                  style: const TextStyle(
                                    color: AtlasTheme.redDark,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              isGameOver
                                  ? 'Ketuk layar untuk memulai ulang permainan.'
                                  : (!isPlaying
                                      ? 'Ketuk layar untuk melompat dan melintasi rintangan.'
                                      : 'Hindari kaktus & burung ATLAS! Tingkat kesulitan naik seiring tingginya skor.'),
                              style: const TextStyle(
                                color: AtlasTheme.brownMid,
                                fontSize: 12,
                                height: 1.5,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'STATUS: ERR_INTERNET_DISCONNECTED',
                              style: TextStyle(
                                fontSize: 10,
                                fontFamily: 'ShareTechMono',
                                color: AtlasTheme.redMain,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const Spacer(),

                    // Footer khas ATLAS
                    const Text(
                      '© 2026 ATLAS — All rights reserved',
                      style: TextStyle(
                        color: Color(0x66FFF8F0),
                        fontSize: 10,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// CUSTOM PAINTER DINO ATLAS & RINTANGAN DENGAN SHADOW 3D
// ═══════════════════════════════════════════════════════════════════
class AtlasDinoPainter extends CustomPainter {
  final double dinoY;
  final int legFrame;
  final bool isGrounded;
  final List<Obstacle> obstacles;
  final double groundOffset;
  final bool isGameOver;

  AtlasDinoPainter({
    required this.dinoY,
    required this.legFrame,
    required this.isGrounded,
    required this.obstacles,
    required this.groundOffset,
    required this.isGameOver,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double groundY = size.height - 24;

    // 1. Gambar Garis Tanah Tebal & Bintik Emas
    final groundPaint = Paint()
      ..color = AtlasTheme.gold
      ..strokeWidth = 3;

    canvas.drawLine(Offset(0, groundY), Offset(size.width, groundY), groundPaint);

    final dotPaint = Paint()..color = AtlasTheme.gold.withOpacity(0.5);
    for (double x = -groundOffset; x < size.width; x += 36) {
      canvas.drawCircle(Offset(x, groundY + 8), 2, dotPaint);
      canvas.drawCircle(Offset(x + 18, groundY + 16), 1.5, dotPaint);
    }

    // 2. Gambar Dino Gaya ATLAS (Kombinasi Merah, Emas & Border Hitam)
    final double dinoX = 50;
    final double currentDinoY = groundY - 40 + dinoY;

    final dinoBodyPaint = Paint()..color = AtlasTheme.redMain;
    final dinoAccentPaint = Paint()..color = AtlasTheme.gold;
    final borderPaint = Paint()
      ..color = AtlasTheme.borderDark
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    // Helper untuk menggambar kotak bergaris tepi
    void drawBorderRect(Rect rect, Paint fillPaint) {
      canvas.drawRect(rect, fillPaint);
      canvas.drawRect(rect, borderPaint);
    }

    // Kepala Dino
    drawBorderRect(Rect.fromLTWH(dinoX + 15, currentDinoY, 22, 14), dinoBodyPaint);
    // Mahkota / Aksen Emas Dino
    drawBorderRect(Rect.fromLTWH(dinoX + 18, currentDinoY - 4, 8, 4), dinoAccentPaint);
    // Badan Dino
    drawBorderRect(Rect.fromLTWH(dinoX + 10, currentDinoY + 14, 24, 18), dinoBodyPaint);
    // Ekor Dino
    drawBorderRect(Rect.fromLTWH(dinoX, currentDinoY + 18, 12, 10), dinoBodyPaint);

    // Mata Dino
    final eyePaint = Paint()..color = isGameOver ? AtlasTheme.borderDark : AtlasTheme.bgCreamLight;
    canvas.drawRect(Rect.fromLTWH(dinoX + 28, currentDinoY + 3, 4, 4), eyePaint);

    // Kaki Dino (Berjalan)
    if (!isGrounded || isGameOver) {
      drawBorderRect(Rect.fromLTWH(dinoX + 12, currentDinoY + 32, 5, 10), dinoAccentPaint);
      drawBorderRect(Rect.fromLTWH(dinoX + 24, currentDinoY + 32, 5, 10), dinoAccentPaint);
    } else if (legFrame == 0) {
      drawBorderRect(Rect.fromLTWH(dinoX + 12, currentDinoY + 32, 5, 10), dinoAccentPaint);
      drawBorderRect(Rect.fromLTWH(dinoX + 24, currentDinoY + 32, 5, 5), dinoAccentPaint);
    } else {
      drawBorderRect(Rect.fromLTWH(dinoX + 12, currentDinoY + 32, 5, 5), dinoAccentPaint);
      drawBorderRect(Rect.fromLTWH(dinoX + 24, currentDinoY + 32, 5, 10), dinoAccentPaint);
    }

    // 3. Gambar Rintangan Dinamis
    final obstaclePaint = Paint()..color = AtlasTheme.gold;
    final birdPaint = Paint()..color = AtlasTheme.redMain;

    for (var obs in obstacles) {
      if (obs.type == ObstacleType.cactus) {
        // Kaktus Emas Gaya 3D Neobrutalism
        double x = obs.x;
        double w = obs.width;
        double h = obs.height;
        
        Rect cactusRect = Rect.fromLTWH(x, groundY - h, w, h);
        drawBorderRect(cactusRect, obstaclePaint);

        // Cabang Kaktus
        if (w >= 20) {
          drawBorderRect(Rect.fromLTWH(x - 5, groundY - (h * 0.7), 5, 12), obstaclePaint);
          drawBorderRect(Rect.fromLTWH(x + w, groundY - (h * 0.5), 5, 10), obstaclePaint);
        }
      } else {
        // Burung Pterodactyl Terbang
        double x = obs.x;
        double y = groundY - obs.yOffset - obs.height;
        
        // Badan Burung
        drawBorderRect(Rect.fromLTWH(x + 6, y + 6, 20, 12), birdPaint);
        // Kepala / Paruh
        drawBorderRect(Rect.fromLTWH(x, y + 8, 8, 6), dinoAccentPaint);
        // Sayap Animasi
        double wingY = (legFrame == 0) ? y - 6 : y + 12;
        drawBorderRect(Rect.fromLTWH(x + 12, wingY, 10, 10), birdPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant AtlasDinoPainter oldDelegate) => true;
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER (TITIK COKLAT DARI TAMPILAN A)
// ═══════════════════════════════════════════════════════════════════
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF5D2B1F).withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
