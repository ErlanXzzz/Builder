// lib/features/dashboard/tools/qris/qris_atlas_page.dart

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../dashboard/xtheme.dart';
import '../../../core/config/apiBaseUrl.dart';

// ═══════════════════════════════════════════════════════════════════════
// XTHEME-DRIVEN COLOR PALETTE (mutable — diupdate dari XThemeController)
// ═══════════════════════════════════════════════════════════════════════
class _TC {
  // Background / Surface
  static Color bg0 = const Color(0xFF160A07);        // paling gelap
  static Color bg1 = const Color(0xFF2A140E);        // panel
  static Color bg2 = const Color(0xFF3A1E15);        // card
  static Color bg3 = const Color(0xFF4A2A1E);        // elevated

  // Border & overlay
  static Color border = const Color(0x33D4A853);
  static Color borderSoft = const Color(0x22FFFFFF);

  // Primary (dari redMain)
  static Color primary = const Color(0xFFB71C1C);
  static Color primaryDark = const Color(0xFF7F0000);
  static Color primaryDeep = const Color(0xFF4A0000);

  // Highlight (dari gold)
  static Color gold = const Color(0xFFD4A853);
  static Color goldLight = const Color(0xFFF0CC80);
  static Color goldDark = const Color(0xFFA17E38);

  // Accents
  static Color green = const Color(0xFF4CAF50);
  static Color blue = const Color(0xFF2196F3);
  static Color yellow = const Color(0xFFFFC107);
  static Color red = const Color(0xFFE53935);

  // Text
  static Color textMain = const Color(0xFFF3E6DD);
  static Color textMed = const Color(0xFFC9913F);
  static Color textDim = const Color(0xFF8A6E4A);
  static Color textFaint = const Color(0xFF5A4632);
}

void applyQrisTheme(XThemeData t) {
  _TC.bg0 = t.brownDark;
  _TC.bg1 = Color.lerp(t.brownDark, t.brownMid, 0.45)!;
  _TC.bg2 = t.brownMid;
  _TC.bg3 = Color.lerp(t.brownMid, t.redMain, 0.28)!;

  _TC.border = t.gold.withOpacity(0.35);
  _TC.borderSoft = Colors.white.withOpacity(0.10);

  _TC.primary = t.redMain;
  _TC.primaryDark = t.redDark;
  _TC.primaryDeep = t.redDeep;

  _TC.gold = t.gold;
  _TC.goldLight = t.goldLight;
  _TC.goldDark = t.goldDark;

  _TC.green = t.accentGreen;
  _TC.blue = t.accentBlue;
  _TC.yellow = t.accentYellow;
  _TC.red = t.accentRed;

  _TC.textMain = t.bgCreamLight;
  _TC.textMed = t.gold;
  _TC.textDim = Color.lerp(t.gold, t.brownMid, 0.35)!;
  _TC.textFaint = Color.lerp(t.brownMid, t.brownDark, 0.3)!;
}

// ═══════════════════════════════════════════════════════════════════════
// MODELS
// ═══════════════════════════════════════════════════════════════════════
class QrisOrder {
  final String id;
  final double baseAmount;
  final double feeAmount;
  final double payAmount;
  final int uniqueCode;
  final String status;
  final String qris;
  final String? checkoutUrl;
  final DateTime? createdAt;
  final DateTime? expiresAt;
  final DateTime? paidAt;

  QrisOrder({
    required this.id,
    required this.baseAmount,
    required this.feeAmount,
    required this.payAmount,
    required this.uniqueCode,
    required this.status,
    required this.qris,
    this.checkoutUrl,
    this.createdAt,
    this.expiresAt,
    this.paidAt,
  });

  factory QrisOrder.fromJson(Map<String, dynamic> j) {
    double d(dynamic v) => v == null ? 0 : double.tryParse(v.toString()) ?? 0;
    DateTime? t(dynamic v) =>
        v == null ? null : DateTime.tryParse(v.toString());
    return QrisOrder(
      id: j['id']?.toString() ?? '',
      baseAmount: d(j['base_amount']),
      feeAmount: d(j['fee_amount']),
      payAmount: d(j['pay_amount']),
      uniqueCode: (j['unique_code'] as num?)?.toInt() ?? 0,
      status: j['status']?.toString() ?? 'pending',
      qris: j['qris']?.toString() ?? '',
      checkoutUrl: j['checkout_url']?.toString(),
      createdAt: t(j['created_at']),
      expiresAt: t(j['expires_at']),
      paidAt: t(j['paid_at']),
    );
  }
}

class HistoryTx {
  final String id;
  final String type;
  final double amount;
  final String status;
  final DateTime? createdAt;

  HistoryTx({
    required this.id,
    required this.type,
    required this.amount,
    required this.status,
    this.createdAt,
  });

  factory HistoryTx.fromJson(Map<String, dynamic> j) => HistoryTx(
        id: j['id']?.toString() ?? '',
        type: j['type']?.toString() ?? '-',
        amount: double.tryParse(j['amount'].toString()) ?? 0,
        status: j['status']?.toString() ?? '-',
        createdAt: DateTime.tryParse(j['created_at']?.toString() ?? ''),
      );
}

// ═══════════════════════════════════════════════════════════════════════
// MAIN WIDGET
// ═══════════════════════════════════════════════════════════════════════
class QrisAtlas extends StatefulWidget {
  final String username;
  final double balance;
  final String apiKeyQris;
  final ValueChanged<double>? onBalanceChanged;

  const QrisAtlas({
    super.key,
    required this.username,
    required this.balance,
    required this.apiKeyQris,
    this.onBalanceChanged,
  });

  @override
  State<QrisAtlas> createState() => _QrisAtlasState();
}

class _QrisAtlasState extends State<QrisAtlas>
    with TickerProviderStateMixin {
  final XThemeController _themeCtrl = XThemeController();

  int _tab = 0; // 0 dashboard, 1 withdraw, 2 docs
  late String _apiKey;
  late double _balance;

  // dashboard
  bool _loadingHistory = true;
  List<HistoryTx> _history = [];

  // topup
  final _topupCtrl = TextEditingController();
  bool _topupLoading = false;
  String? _topupError;
  QrisOrder? _order;
  Timer? _pollTimer;
  bool _cancelLoading = false;

  // withdraw
  final _wdNominalCtrl = TextEditingController();
  final _wdNumberCtrl = TextEditingController();
  final _wdNameCtrl = TextEditingController();
  String _wdEwallet = '';
  bool _wdLoading = false;
  String? _wdMessage;
  bool _wdSuccess = false;

  // copy feedback
  final Set<String> _copiedKey = {};

  @override
  void initState() {
    super.initState();
    _balance = widget.balance;
    _apiKey = widget.apiKeyQris;
    _loadHistory();
  }

  @override
  void dispose() {
    _topupCtrl.dispose();
    _wdNominalCtrl.dispose();
    _wdNumberCtrl.dispose();
    _wdNameCtrl.dispose();
    _pollTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // API CALLS
  // ═══════════════════════════════════════════════════════════════════
  Uri _u(String path, [Map<String, String>? q]) =>
      Uri.parse('$apiBaseUrl$path').replace(queryParameters: q);

  Future<void> _loadHistory() async {
    if (!mounted) return;
    setState(() => _loadingHistory = true);
    try {
      final res = await http
          .get(_u('/api/user/history', {'apikey': _apiKey}))
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final list = (data['data'] as List?) ?? [];
        setState(() {
          _history = list
              .map((e) => HistoryTx.fromJson(e as Map<String, dynamic>))
              .toList();
        });
      }
    } catch (_) {
      // silent
    } finally {
      if (mounted) setState(() => _loadingHistory = false);
    }
  }

  Future<void> _submitTopup() async {
    FocusScope.of(context).unfocus();
    final nominal = int.tryParse(_topupCtrl.text.trim()) ?? 0;
    if (nominal < 1000) {
      setState(() => _topupError = 'Minimal topup Rp 1.000');
      return;
    }
    setState(() {
      _topupLoading = true;
      _topupError = null;
    });

    try {
      final res = await http
          .get(_u('/topup', {
            'nominal': nominal.toString(),
            'apikey': _apiKey,
          }))
          .timeout(const Duration(seconds: 20));
      final body = jsonDecode(res.body) as Map<String, dynamic>;

      final ok = body['ok'] == true || body['success'] == true;
      if (!ok) {
        throw body['error']?.toString() ?? 'Gagal membuat order';
      }

      final order = QrisOrder.fromJson(body['data'] as Map<String, dynamic>);
      if (!mounted) return;
      setState(() => _order = order);
      _startPolling();
    } catch (e) {
      if (!mounted) return;
      setState(
          () => _topupError = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _topupLoading = false);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_order == null || !mounted) return;
      try {
        final res = await http
            .get(_u('/check-status', {'id': _order!.id}))
            .timeout(const Duration(seconds: 10));
        if (res.statusCode != 200) return;
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final data = body['data'] as Map<String, dynamic>?;
        if (data == null) return;
        final status = data['status']?.toString() ?? 'pending';
        if (status == 'paid') {
          _pollTimer?.cancel();
          final newOrder = QrisOrder.fromJson(data);
          if (!mounted) return;
          setState(() {
            _order = newOrder;
            _balance += newOrder.baseAmount;
          });
          widget.onBalanceChanged?.call(_balance);
          _snack('Pembayaran berhasil! Saldo bertambah.',
              color: _TC.green);
          _loadHistory();
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) setState(() => _order = null);
          });
        } else if (status == 'cancelled' || status == 'failed') {
          _pollTimer?.cancel();
          if (!mounted) return;
          setState(() => _order = null);
          _snack('Order $status', color: _TC.red);
        }
      } catch (_) {}
    });
  }

  Future<void> _cancelOrder() async {
    if (_order == null) return;
    setState(() => _cancelLoading = true);
    try {
      await http
          .get(_u('/cancel-order', {'id': _order!.id}))
          .timeout(const Duration(seconds: 12));
      _pollTimer?.cancel();
      if (!mounted) return;
      setState(() => _order = null);
      _snack('Order dibatalkan', color: _TC.yellow);
      _loadHistory();
    } catch (e) {
      _snack('Gagal cancel: $e', color: _TC.red);
    } finally {
      if (mounted) setState(() => _cancelLoading = false);
    }
  }

  Future<void> _submitWithdraw() async {
    FocusScope.of(context).unfocus();
    final nominal = int.tryParse(_wdNominalCtrl.text.trim()) ?? 0;
    final number = _wdNumberCtrl.text.trim();
    final name = _wdNameCtrl.text.trim();

    if (nominal < 5000) {
      setState(() {
        _wdSuccess = false;
        _wdMessage = 'Minimal withdraw Rp 5.000';
      });
      return;
    }
    if (_wdEwallet.isEmpty) {
      setState(() {
        _wdSuccess = false;
        _wdMessage = 'Pilih e-wallet dulu';
      });
      return;
    }
    if (number.isEmpty || name.isEmpty) {
      setState(() {
        _wdSuccess = false;
        _wdMessage = 'Lengkapi nomor & nama';
      });
      return;
    }

    setState(() {
      _wdLoading = true;
      _wdMessage = null;
    });

    try {
      final res = await http
          .get(_u('/api/user/withdraw', {
            'nominal': nominal.toString(),
            'ewallet': _wdEwallet,
            'number': number,
            'account_name': name,
            'apikey': _apiKey,
          }))
          .timeout(const Duration(seconds: 20));
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      final ok = body['success'] == true || body['ok'] == true;
      setState(() {
        _wdSuccess = ok;
        _wdMessage = ok
            ? (body['message']?.toString() ?? 'Withdraw berhasil diproses')
            : (body['error']?.toString() ?? 'Withdraw gagal');
      });
      if (ok) {
        _wdNominalCtrl.clear();
        _wdNumberCtrl.clear();
        _wdNameCtrl.clear();
        setState(() => _wdEwallet = '');
        _loadHistory();
      }
    } catch (e) {
      setState(() {
        _wdSuccess = false;
        _wdMessage = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) setState(() => _wdLoading = false);
    }
  }

  Future<void> _generateKey() async {
    try {
      final res = await http
          .get(_u('/api/user/generate-key', {'apikey': _apiKey}))
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      if (body['success'] == true || body['ok'] == true) {
        final newKey = body['data']?['api_key']?.toString() ??
            body['api_key']?.toString();
        if (newKey != null && newKey.isNotEmpty) {
          setState(() => _apiKey = newKey);
          _snack('API key baru di-generate', color: _TC.gold);
          return;
        }
      }
      _snack('Gagal generate key', color: _TC.red);
    } catch (e) {
      _snack('Error: $e', color: _TC.red);
    }
  }

  void _snack(String msg, {Color? color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(
                fontWeight: FontWeight.w700, color: Colors.white)),
        backgroundColor: color ?? _TC.primary,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeCtrl,
      builder: (context, _) {
        applyQrisTheme(_themeCtrl.currentTheme);

        return Scaffold(
          backgroundColor: _TC.bg0,
          body: Stack(
            children: [
              _AnimatedBg(),
              SafeArea(
                child: Column(
                  children: [
                    _topBar(),
                    Expanded(
                      child: IndexedStack(
                        index: _tab,
                        children: [
                          _dashboardTab(),
                          _withdrawTab(),
                          _docsTab(),
                        ],
                      ),
                    ),
                    _bottomNav(),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TOP BAR (tanpa logout)
  // ═══════════════════════════════════════════════════════════════════
  Widget _topBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _TC.bg1.withOpacity(0.95),
            _TC.bg0.withOpacity(0.88),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: _TC.gold.withOpacity(0.35), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          // Logo
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_TC.primary, _TC.primaryDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: _TC.borderSoft, width: 1),
              boxShadow: [
                BoxShadow(
                  color: _TC.primary.withOpacity(0.5),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(Icons.bolt_rounded,
                color: Colors.white, size: 22),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => LinearGradient(
                    colors: [_TC.goldLight, _TC.textMain, _TC.goldLight],
                  ).createShader(b),
                  child: const Text(
                    'ATLAS GATEWAY',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                Text(
                  'Hi, ${widget.username}',
                  style: TextStyle(
                      color: _TC.textDim, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TAB: DASHBOARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _dashboardTab() {
    return RefreshIndicator(
      onRefresh: _loadHistory,
      color: _TC.gold,
      backgroundColor: _TC.bg1,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 24),
        children: [
          _balanceCard(),
          const SizedBox(height: 16),
          _topupCard(),
          const SizedBox(height: 16),
          _historyCard(),
        ],
      ),
    );
  }

  Widget _balanceCard() {
    return _GlassCard(
      glowColor: _TC.green,
      glowOpacity: 0.35,
      child: Stack(
        children: [
          Positioned(
            right: -40,
            bottom: -40,
            child: _glowDot(_TC.green, 160, 0.18),
          ),
          Positioned(
            left: -50,
            top: -50,
            child: _glowDot(_TC.primary, 140, 0.14),
          ),
          Padding(
            padding: const EdgeInsets.all(22),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'TOTAL SALDO KAMU',
                        style: TextStyle(
                          color: _TC.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ShaderMask(
                        shaderCallback: (b) => LinearGradient(
                          colors: [_TC.green, _TC.goldLight],
                        ).createShader(b),
                        child: Text(
                          'Rp ${_fmt(_balance)}',
                          style: const TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: -0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_TC.green, _TC.goldDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                        color: _TC.borderSoft, width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: _TC.green.withOpacity(0.5),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.account_balance_wallet_rounded,
                      color: Colors.white, size: 30),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _topupCard() {
    return _GlassCard(
      glowColor: _TC.gold,
      glowOpacity: 0.25,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _iconBadge(Icons.qr_code_2_rounded, _TC.gold),
                const SizedBox(width: 12),
                Text(
                  'Top Up Saldo QRIS',
                  style: TextStyle(
                    color: _TC.textMain,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            if (_topupError != null) ...[
              _alert(_topupError!, _TC.red),
              const SizedBox(height: 12),
            ],
            if (_order == null) ...[
              _label('Nominal Topup (Min Rp 1.000)'),
              const SizedBox(height: 8),
              _inputField(
                controller: _topupCtrl,
                hint: 'Contoh: 10000',
                keyboard: TextInputType.number,
              ),
              const SizedBox(height: 16),
              _primaryBtn(
                label: _topupLoading
                    ? 'Memproses...'
                    : 'Generate QRIS Pembayaran',
                icon: Icons.qr_code_scanner_rounded,
                color: _TC.primary,
                loading: _topupLoading,
                onTap: _topupLoading ? null : _submitTopup,
              ),
            ] else
              _qrisBox(_order!),
          ],
        ),
      ),
    );
  }

  Widget _qrisBox(QrisOrder o) {
    final isPaid = o.status == 'paid';
    final qrUrl =
        'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${Uri.encodeComponent(o.qris)}';

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: (isPaid ? _TC.green : _TC.yellow).withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: (isPaid ? _TC.green : _TC.yellow).withOpacity(0.5),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isPaid)
                SizedBox(
                  width: 10,
                  height: 10,
                  child: CircularProgressIndicator(
                    strokeWidth: 1.8,
                    color: _TC.yellow,
                  ),
                )
              else
                Icon(Icons.check_circle_rounded,
                    color: _TC.green, size: 12),
              const SizedBox(width: 6),
              Text(
                isPaid ? 'PEMBAYARAN BERHASIL' : 'MENUNGGU PEMBAYARAN',
                style: TextStyle(
                  color: isPaid ? _TC.green : _TC.yellow,
                  fontWeight: FontWeight.w900,
                  fontSize: 10,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        ShaderMask(
          shaderCallback: (b) => LinearGradient(
            colors: [_TC.green, _TC.goldLight],
          ).createShader(b),
          child: Text(
            'Rp ${_fmt(o.payAmount)}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Base: Rp ${_fmt(o.baseAmount)}  •  Fee: Rp ${_fmt(o.feeAmount)}  •  Kode unik: ${o.uniqueCode}',
          textAlign: TextAlign.center,
          style: TextStyle(color: _TC.textDim, fontSize: 10.5),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white, width: 4),
            boxShadow: [
              BoxShadow(
                color: _TC.green.withOpacity(0.35),
                blurRadius: 30,
                spreadRadius: -4,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              qrUrl,
              width: 220,
              height: 220,
              fit: BoxFit.cover,
              loadingBuilder: (_, child, p) {
                if (p == null) return child;
                return SizedBox(
                  width: 220,
                  height: 220,
                  child: Center(
                    child: CircularProgressIndicator(color: _TC.gold),
                  ),
                );
              },
              errorBuilder: (_, __, ___) => SizedBox(
                width: 220,
                height: 220,
                child: Center(
                  child: Icon(Icons.broken_image_rounded,
                      color: _TC.textDim, size: 40),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Selesaikan pembayaran sesuai nominal. Saldo otomatis bertambah saat pembayaran terdeteksi (polling tiap 3 detik).',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: _TC.textDim, fontSize: 11, height: 1.5),
          ),
        ),
        if (o.expiresAt != null) ...[
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.timer_outlined,
                  color: _TC.textFaint, size: 12),
              const SizedBox(width: 4),
              Text(
                'Kadaluarsa: ${_fmtDate(o.expiresAt!)}',
                style: TextStyle(
                    color: _TC.textFaint, fontSize: 10.5),
              ),
            ],
          ),
        ],
        const SizedBox(height: 16),
        GestureDetector(
          onTap: _cancelLoading ? null : _cancelOrder,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 18),
            decoration: BoxDecoration(
              color: _TC.red.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: _TC.red.withOpacity(0.4), width: 1),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_cancelLoading)
                  SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: _TC.red),
                  )
                else
                  Icon(Icons.close_rounded,
                      color: _TC.red, size: 16),
                const SizedBox(width: 6),
                Text(
                  'Batalkan Pembayaran',
                  style: TextStyle(
                    color: _TC.red,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _historyCard() {
    return _GlassCard(
      glowColor: _TC.gold,
      glowOpacity: 0.2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.history_rounded,
                    color: _TC.textMed, size: 18),
                const SizedBox(width: 8),
                Text(
                  'Riwayat Transaksi',
                  style: TextStyle(
                    color: _TC.textMain,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _loadHistory,
                  child: Row(
                    children: [
                      Icon(Icons.refresh_rounded,
                          color: _TC.gold, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        'Refresh',
                        style: TextStyle(
                          color: _TC.gold,
                          fontWeight: FontWeight.w700,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (_loadingHistory)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 30),
                child: Center(
                  child: CircularProgressIndicator(
                    color: _TC.gold,
                    strokeWidth: 2,
                  ),
                ),
              )
            else if (_history.isEmpty)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 40),
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Icon(Icons.inbox_rounded,
                        color: _TC.textFaint, size: 42),
                    const SizedBox(height: 8),
                    Text('Belum ada riwayat transaksi',
                        style: TextStyle(
                            color: _TC.textDim, fontSize: 12)),
                  ],
                ),
              )
            else
              ..._history.take(15).map((tx) => _historyRow(tx)),
          ],
        ),
      ),
    );
  }

  Widget _historyRow(HistoryTx tx) {
    Color statusColor;
    switch (tx.status.toLowerCase()) {
      case 'paid':
      case 'success':
        statusColor = _TC.green;
        break;
      case 'cancelled':
      case 'failed':
        statusColor = _TC.red;
        break;
      default:
        statusColor = _TC.yellow;
    }

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: Border(
            bottom: BorderSide(color: _TC.gold.withOpacity(0.15))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      tx.type.toUpperCase(),
                      style: TextStyle(
                        color: _TC.textMain,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: statusColor.withOpacity(0.4), width: 1),
                      ),
                      child: Text(
                        tx.status,
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  tx.id.length > 22 ? '${tx.id.substring(0, 22)}…' : tx.id,
                  style: TextStyle(
                    color: _TC.textFaint,
                    fontSize: 10,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'Rp ${_fmt(tx.amount)}',
                style: TextStyle(
                  color: _TC.green,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                ),
              ),
              if (tx.createdAt != null)
                Text(
                  _fmtDate(tx.createdAt!),
                  style: TextStyle(
                      color: _TC.textFaint, fontSize: 10),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TAB: WITHDRAW
  // ═══════════════════════════════════════════════════════════════════
  Widget _withdrawTab() {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 24),
      children: [
        _GlassCard(
          glowColor: _TC.green,
          glowOpacity: 0.25,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _iconBadge(
                        Icons.account_balance_rounded, _TC.green),
                    const SizedBox(width: 12),
                    Text(
                      'Penarikan Saldo',
                      style: TextStyle(
                        color: _TC.textMain,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                if (_wdMessage != null) ...[
                  _alert(_wdMessage!, _wdSuccess ? _TC.green : _TC.red),
                  const SizedBox(height: 14),
                ],
                _label('Nominal Withdraw (Min Rp 5.000)'),
                const SizedBox(height: 8),
                _inputField(
                  controller: _wdNominalCtrl,
                  hint: '5000',
                  keyboard: TextInputType.number,
                ),
                const SizedBox(height: 16),
                _label('Pilih E-Wallet Tujuan'),
                const SizedBox(height: 8),
                _ewalletPicker(),
                const SizedBox(height: 16),
                _label('Nomor HP E-Wallet'),
                const SizedBox(height: 8),
                _inputField(
                  controller: _wdNumberCtrl,
                  hint: '081234567890',
                  keyboard: TextInputType.phone,
                ),
                const SizedBox(height: 16),
                _label('Atas Nama Pemilik E-Wallet'),
                const SizedBox(height: 8),
                _inputField(
                  controller: _wdNameCtrl,
                  hint: 'Budi Santoso',
                ),
                const SizedBox(height: 22),
                _primaryBtn(
                  label:
                      _wdLoading ? 'Memproses...' : 'Tarik Saldo Sekarang',
                  icon: Icons.send_rounded,
                  color: _TC.green,
                  loading: _wdLoading,
                  onTap: _wdLoading ? null : _submitWithdraw,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _ewalletPicker() {
    const wallets = ['DANA', 'OVO', 'GOPAY', 'SHOPEEPAY', 'LINKAJA'];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: wallets.map((w) {
        final active = _wdEwallet == w;
        return GestureDetector(
          onTap: () => setState(() => _wdEwallet = w),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              gradient: active
                  ? LinearGradient(colors: [
                      _TC.green,
                      Color.lerp(_TC.green, Colors.black, 0.4)!,
                    ])
                  : LinearGradient(colors: [
                      _TC.bg2.withOpacity(0.5),
                      _TC.bg0.withOpacity(0.7),
                    ]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: active
                    ? _TC.green
                    : _TC.gold.withOpacity(0.3),
                width: active ? 2 : 1,
              ),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: _TC.green.withOpacity(0.4),
                        blurRadius: 14,
                        spreadRadius: -3,
                      ),
                    ]
                  : null,
            ),
            child: Text(
              w,
              style: TextStyle(
                color: active ? Colors.white : _TC.textMed,
                fontWeight: FontWeight.w800,
                fontSize: 11,
                letterSpacing: 0.8,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TAB: DOCS
  // ═══════════════════════════════════════════════════════════════════
  Widget _docsTab() {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 24),
      children: [
        _apiKeyCard(),
        const SizedBox(height: 16),
        _docsHeader(),
        const SizedBox(height: 16),
        _endpointCard(
          method: 'GET',
          path: '/topup',
          title: '1. Buat Order Topup / QRIS',
          color: _TC.green,
          code: '''const axios = require('axios');

const createOrder = async () => {
  try {
    const response = await axios.get(
      '$apiBaseUrl/topup',
      {
        params: {
          nominal: 10000,
          apikey: '$_apiKey',
          reference: 'INV-001'
        }
      }
    );
    console.log(response.data);
  } catch (error) {
    console.error(error.response?.data || error.message);
  }
};''',
          response: '''{
  "ok": true,
  "data": {
    "id": "pay_msiabc123def456",
    "base_amount": 10000,
    "fee_percent": 0.5,
    "fee_amount": 50,
    "unique_code": 37,
    "pay_amount": 10087,
    "status": "pending",
    "qris": "000201010212...",
    "checkout_url": "https://...",
    "created_at": "2026-08-07T10:00:00.000Z",
    "expires_at": "2026-08-07T10:10:00.000Z"
  }
}''',
        ),
        const SizedBox(height: 16),
        _endpointCard(
          method: 'GET',
          path: '/check-status',
          title: '2. Cek Status Order',
          color: _TC.gold,
          code: '''const checkStatus = async (orderId) => {
  try {
    const response = await axios.get(
      '$apiBaseUrl/check-status',
      { params: { id: orderId } }
    );
    console.log(response.data);
  } catch (error) {
    console.error(error.response?.data || error.message);
  }
};''',
          response: '''{
  "ok": true,
  "data": {
    "id": "pay_msiabc123def456",
    "status": "paid",
    "base_amount": 10000,
    "pay_amount": 10087,
    "paid_at": "2026-08-07T10:03:21.000Z"
  }
}''',
        ),
        const SizedBox(height: 16),
        _endpointCard(
          method: 'GET',
          path: '/cancel-order',
          title: '3. Batalkan Order',
          color: _TC.red,
          code: '''const cancelOrder = async (orderId) => {
  try {
    const response = await axios.get(
      '$apiBaseUrl/cancel-order',
      { params: { id: orderId } }
    );
    console.log(response.data);
  } catch (error) {
    console.error(error.response?.data || error.message);
  }
};''',
          response: '''{
  "ok": true,
  "message": "Order berhasil dibatalkan"
}''',
        ),
      ],
    );
  }

  Widget _apiKeyCard() {
    return _GlassCard(
      glowColor: _TC.gold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'API KEY UNIK ANDA',
              style: TextStyle(
                color: _TC.textDim,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.4,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: _TC.bg0.withOpacity(0.9),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: _TC.gold.withOpacity(0.3), width: 1),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: SelectableText(
                      _apiKey,
                      style: TextStyle(
                        color: _TC.goldLight,
                        fontFamily: 'monospace',
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: _apiKey));
                      _snack('API key disalin', color: _TC.gold);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Icon(Icons.copy_rounded,
                          color: _TC.textMed, size: 16),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _primaryBtn(
              label: 'Generate API Key Baru',
              icon: Icons.autorenew_rounded,
              color: _TC.gold,
              onTap: _generateKey,
            ),
          ],
        ),
      ),
    );
  }

  Widget _docsHeader() {
    return _GlassCard(
      glowColor: _TC.gold,
      glowOpacity: 0.2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            _iconBadge(Icons.code_rounded, _TC.gold),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Dokumentasi REST API',
                    style: TextStyle(
                      color: _TC.textMain,
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Gunakan SDK Axios pada Node.js untuk request API',
                    style: TextStyle(color: _TC.textDim, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _endpointCard({
    required String method,
    required String path,
    required String title,
    required Color color,
    required String code,
    required String response,
  }) {
    return _GlassCard(
      glowColor: color,
      glowOpacity: 0.2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border:
                    Border.all(color: color.withOpacity(0.4), width: 1),
              ),
              child: Text(
                '$method $path',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 0.5,
                  fontFamily: 'monospace',
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                color: _TC.textMain,
                fontWeight: FontWeight.w800,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'Request:',
              style: TextStyle(
                color: _TC.textDim,
                fontWeight: FontWeight.w700,
                fontSize: 11,
              ),
            ),
            const SizedBox(height: 6),
            _codeBlock(code, key: 'req-$path'),
            const SizedBox(height: 14),
            Text(
              'Response:',
              style: TextStyle(
                color: _TC.textDim,
                fontWeight: FontWeight.w700,
                fontSize: 11,
              ),
            ),
            const SizedBox(height: 6),
            _codeBlock(response, key: 'res-$path', green: true),
          ],
        ),
      ),
    );
  }

  Widget _codeBlock(String text, {required String key, bool green = false}) {
    final copied = _copiedKey.contains(key);
    final accent = green ? _TC.green : _TC.gold;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_TC.bg0, _TC.bg1],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: accent.withOpacity(0.25),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    accent.withOpacity(0.7),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 34),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SelectableText(
                text,
                style: TextStyle(
                  color: green ? _TC.green : _TC.goldLight,
                  fontFamily: 'monospace',
                  fontSize: 11,
                  height: 1.55,
                ),
              ),
            ),
          ),
          Positioned(
            right: 8,
            bottom: 8,
            child: GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: text));
                setState(() => _copiedKey.add(key));
                _snack('Disalin', color: _TC.gold);
                Future.delayed(const Duration(seconds: 2), () {
                  if (mounted) setState(() => _copiedKey.remove(key));
                });
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: copied
                      ? _TC.green.withOpacity(0.2)
                      : _TC.bg2.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: copied
                        ? _TC.green
                        : _TC.gold.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      copied ? Icons.check_rounded : Icons.copy_rounded,
                      color: copied ? _TC.green : _TC.textMed,
                      size: 11,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      copied ? 'Copied' : 'Copy',
                      style: TextStyle(
                        color: copied ? _TC.green : _TC.textMed,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BOTTOM NAV
  // ═══════════════════════════════════════════════════════════════════
  Widget _bottomNav() {
    final items = [
      (Icons.show_chart, 'Home', _TC.primary),
      (Icons.account_balance_wallet_rounded, 'Withdraw', _TC.green),
      (Icons.code_rounded, 'API Docs', _TC.gold),
    ];
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_TC.bg1.withOpacity(0.95), _TC.bg0.withOpacity(0.9)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          top: BorderSide(color: _TC.gold.withOpacity(0.3), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 24,
            offset: const Offset(0, -6),
          ),
          BoxShadow(
            color: _TC.gold.withOpacity(0.1),
            blurRadius: 40,
            offset: const Offset(0, -20),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      child: Row(
        children: List.generate(items.length, (i) {
          final active = _tab == i;
          final item = items[i];
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _tab = i),
              behavior: HitTestBehavior.opaque,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                padding: const EdgeInsets.symmetric(vertical: 8),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  gradient: active
                      ? LinearGradient(
                          colors: [
                            item.$3.withOpacity(0.22),
                            item.$3.withOpacity(0.06),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        )
                      : null,
                  borderRadius: BorderRadius.circular(14),
                  border: active
                      ? Border.all(
                          color: item.$3.withOpacity(0.4), width: 1)
                      : null,
                  boxShadow: active
                      ? [
                          BoxShadow(
                            color: item.$3.withOpacity(0.25),
                            blurRadius: 16,
                            spreadRadius: -4,
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      item.$1,
                      color: active ? item.$3 : _TC.textDim,
                      size: 22,
                    ),
                    const SizedBox(height: 3),
                    Text(
                      item.$2,
                      style: TextStyle(
                        color: active ? item.$3 : _TC.textDim,
                        fontWeight:
                            active ? FontWeight.w800 : FontWeight.w600,
                        fontSize: 10.5,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════
  Widget _iconBadge(IconData icon, Color color) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.25), color.withOpacity(0.08)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 12,
            spreadRadius: -4,
          ),
        ],
      ),
      child: Icon(icon, color: color, size: 20),
    );
  }

  Widget _glowDot(Color color, double size, double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(opacity), Colors.transparent],
        ),
      ),
    );
  }

  Widget _label(String text) {
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        color: _TC.textDim,
        fontSize: 10,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.2,
      ),
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    TextInputType? keyboard,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_TC.bg0.withOpacity(0.95), _TC.bg1.withOpacity(0.7)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: _TC.gold.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        style: TextStyle(
            color: _TC.textMain,
            fontSize: 13.5,
            fontWeight: FontWeight.w600),
        cursorColor: _TC.gold,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
              color: _TC.textFaint,
              fontSize: 13,
              fontWeight: FontWeight.w500),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _alert(String message, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
      ),
      child: Row(
        children: [
          Icon(
            color == _TC.green
                ? Icons.check_circle_rounded
                : (color == _TC.red
                    ? Icons.error_rounded
                    : Icons.info_rounded),
            color: color,
            size: 15,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: color,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _primaryBtn({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback? onTap,
    bool loading = false,
  }) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: enabled
              ? LinearGradient(
                  colors: [
                    color,
                    Color.lerp(color, Colors.black, 0.4)!,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                )
              : LinearGradient(colors: [
                  color.withOpacity(0.3),
                  color.withOpacity(0.1),
                ]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: _TC.borderSoft, width: 1),
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 20,
                    spreadRadius: -4,
                    offset: const Offset(0, 6),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (loading)
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2),
              )
            else
              Icon(icon, color: Colors.white, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 12.5,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static String _fmt(double v) {
    final neg = v < 0;
    final s = v.abs().toStringAsFixed(0);
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      buf.write(s[i]);
      final posFromEnd = s.length - i - 1;
      if (posFromEnd > 0 && posFromEnd % 3 == 0) buf.write('.');
    }
    return '${neg ? '-' : ''}$buf';
  }

  static String _fmtDate(DateTime dt) {
    final d = dt.day.toString().padLeft(2, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final y = dt.year;
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    return '$d/$m/$y $hh:$mm';
  }
}

// ═══════════════════════════════════════════════════════════════════════
// GLASS CARD (XTheme-driven)
// ═══════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final Color glowColor;
  final double glowOpacity;

  const _GlassCard({
    required this.child,
    this.glowColor = const Color(0xFFD4A853),
    this.glowOpacity = 0.25,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _TC.bg2.withOpacity(0.85),
            _TC.bg1.withOpacity(0.75),
            _TC.bg0.withOpacity(0.9),
          ],
          stops: const [0.0, 0.5, 1.0],
        ),
        border: Border.all(
          color: _TC.borderSoft,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: glowColor.withOpacity(glowOpacity),
            blurRadius: 32,
            spreadRadius: -8,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(23),
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: 60,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.white.withOpacity(0.06),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            child,
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
// ANIMATED BACKGROUND (XTheme-driven)
// ═══════════════════════════════════════════════════════════════════════
class _AnimatedBg extends StatefulWidget {
  const _AnimatedBg();

  @override
  State<_AnimatedBg> createState() => _AnimatedBgState();
}

class _AnimatedBgState extends State<_AnimatedBg>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final t = _ctrl.value;
        return Stack(
          children: [
            Container(color: _TC.bg0),
            Positioned(
              left: -120 + 30 * t,
              top: -120,
              child: _radialGlow(_TC.primary, 380, 0.22),
            ),
            Positioned(
              right: -100,
              bottom: -100 + 20 * (1 - t),
              child: _radialGlow(_TC.green, 340, 0.16),
            ),
            Positioned(
              left: 120,
              top: 260 + 40 * t,
              child: _radialGlow(_TC.gold, 260, 0.10),
            ),
            Positioned.fill(
              child: CustomPaint(painter: _GridPainter()),
            ),
          ],
        );
      },
    );
  }

  Widget _radialGlow(Color c, double size, double op) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [c.withOpacity(op), Colors.transparent],
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = _TC.gold.withOpacity(0.06)
      ..strokeWidth = 0.6;
    const step = 48.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
    final maskPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          _TC.bg0.withOpacity(0.85),
        ],
        stops: const [0.4, 1.0],
      ).createShader(
        Rect.fromLTWH(0, 0, size.width, size.height),
      );
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      maskPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => true;
}