// lib/features/tools/utility/vercel_deploy_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:http/http.dart' as http;
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// 🔑 ISI 3 NILAI INI — SEKALI AJA
// ═══════════════════════════════════════════════════════════════════

// Vercel token — https://vercel.com/account/tokens
const String VERCEL_TOKEN = 'vcp_2RUjgG0yVP1agzvOEeT06mzujrmlnP5fUy9v5UlAuLQljl53bN3Qyh13';

// Cloudflare API token — https://dash.cloudflare.com/profile/api-tokens
// Permission: Zone → DNS → Edit
const String CLOUDFLARE_TOKEN = 'cfut_FbCF2Ck8rkiBEtQ1BXoflya8UTgqVw4cDBkq5oRA5cd87887';

// Cloudflare Zone ID — https://dash.cloudflare.com → pilih domain → kanan bawah
const String CLOUDFLARE_ZONE_ID = '415f552054b4b4ce07cc8cedc66c5076';

// Domain suffix custom
const String DOMAIN_SUFFIX = 'atlas-by-erlan.com';

// CNAME target untuk Vercel (jangan diganti)
const String VERCEL_CNAME_TARGET = 'cname.vercel-dns.com';

// API bases
const String VERCEL_API = 'https://api.vercel.com';
const String CLOUDFLARE_API = 'https://api.cloudflare.com/client/v4';

// ═══════════════════════════════════════════════════════════════════
// ─── XTHEME-DRIVEN COLORS ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
Color vdBgMain = const Color(0xFF160A07);
Color vdBgSurface = const Color(0xFF2A140E);
Color vdBgCard = const Color(0xFF3A1E15);
Color vdTextMain = const Color(0xFFF3E6DD);
Color vdTextSub = const Color(0xFFC9913F);
Color vdGold = const Color(0xFFD4A853);
Color vdRed = const Color(0xFFB71C1C);
Color vdRedDark = const Color(0xFF7F0000);
Color vdGreen = const Color(0xFF4CAF50);
Color vdBlue = const Color(0xFF2196F3);
Color vdPurple = const Color(0xFFAB47BC);
Color vdBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  vdBgMain     = theme.brownDark;
  vdBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  vdBgCard     = theme.brownMid;
  vdTextMain   = theme.bgCreamLight;
  vdTextSub    = theme.gold;
  vdGold       = theme.gold;
  vdRed        = theme.redMain;
  vdRedDark    = theme.redDark;
  vdGreen      = theme.accentGreen;
  vdBlue       = theme.accentBlue;
  vdPurple     = theme.accentBlue;
  vdBorderDark = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// ─── MAIN PAGE ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class VercelDeployPage extends StatefulWidget {
  const VercelDeployPage({super.key});

  @override
  State<VercelDeployPage> createState() => _VercelDeployPageState();
}

class _VercelDeployPageState extends State<VercelDeployPage> {
  final XThemeController _themeController = XThemeController();

  final _nameController = TextEditingController();
  final _htmlController = TextEditingController();
  final _domainController = TextEditingController();

  bool _isDeploying = false;
  bool _isSettingDomain = false;
  bool _showHtmlEditor = false;
  double _progress = 0.0;
  String _statusText = '';
  String? _nameError;
  String? _htmlError;
  String? _htmlFileName;
  VercelDeployResult? _result;

  // Custom domain state
  final List<DomainStep> _domainSteps = [];
  String? _finalDomainUrl;

  @override
  void initState() {
    super.initState();
    _nameController.addListener(_validateName);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _htmlController.dispose();
    _domainController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // VALIDASI
  // ═══════════════════════════════════════════════════════════════════
  void _validateName() {
    final err = _validateProjectName(_nameController.text.trim());
    if (err != _nameError) setState(() => _nameError = err);
  }

  String? _validateProjectName(String name) {
    if (name.isEmpty) return 'Nama project tidak boleh kosong';
    if (name.length < 3) return 'Minimal 3 karakter';
    if (name.length > 100) return 'Maksimal 100 karakter';
    if (!RegExp(r'^[a-z0-9][a-z0-9-]*[a-z0-9]$').hasMatch(name)) {
      return 'Hanya huruf kecil (a-z), angka, dan minus (-)';
    }
    if (name.contains('--')) return 'Tidak boleh ada "--" berurutan';
    const reserved = [
      'www', 'api', 'app', 'admin', 'cdn', 'root',
      'vercel', 'now', 'zeit', 'localhost',
    ];
    if (reserved.contains(name)) {
      return 'Nama "$name" tidak boleh dipakai';
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════════════
  // PICK HTML
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _pickHtmlFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['html', 'htm'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      final bytes = file.bytes;
      if (bytes == null) {
        _snack('❌ Gagal baca file', isError: true);
        return;
      }

      final content = utf8.decode(bytes, allowMalformed: true);
      if (!mounted) return;
      setState(() {
        _htmlController.text = content;
        _htmlFileName = file.name;
        _htmlError = null;
        _showHtmlEditor = false;
      });
      _snack('✅ ${file.name} (${(bytes.length / 1024).toStringAsFixed(1)} KB)');
    } catch (e) {
      _snack('❌ Gagal pilih file: $e', isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DEPLOY KE VERCEL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _deploy() async {
    final name = _nameController.text.trim();
    final html = _htmlController.text;

    if (VERCEL_TOKEN.contains('GANTI_') || VERCEL_TOKEN.isEmpty) {
      _snack('❌ Token Vercel belum di-set di code', isError: true);
      return;
    }

    final nameErr = _validateProjectName(name);
    final htmlErr = html.trim().isEmpty
        ? 'HTML tidak boleh kosong'
        : (html.length > 500 * 1024
            ? 'HTML terlalu besar (max 500KB)'
            : null);

    setState(() {
      _nameError = nameErr;
      _htmlError = htmlErr;
    });

    if (nameErr != null) {
      _snack('❌ $nameErr', isError: true);
      return;
    }
    if (htmlErr != null) {
      _snack('❌ $htmlErr', isError: true);
      return;
    }

    setState(() {
      _isDeploying = true;
      _progress = 0.0;
      _statusText = 'Memulai...';
      _result = null;
      _domainSteps.clear();
      _finalDomainUrl = null;
    });

    try {
      final res = await _deployHtml(
        projectName: name,
        htmlContent: html,
        onProgress: (s, p) {
          if (mounted) {
            setState(() {
              _statusText = s;
              _progress = p;
            });
          }
        },
      );

      final ready = await _waitUntilReady(
        deployId: res.id,
        onProgress: (s, p) {
          if (mounted) {
            setState(() {
              _statusText = s;
              _progress = p;
            });
          }
        },
      );

      if (!mounted) return;
      setState(() {
        _result = ready;
        _isDeploying = false;
        _progress = 1.0;
      });

      _snack('🎉 Deploy berhasil!');
    } catch (e) {
      if (!mounted) return;
      setState(() => _isDeploying = false);
      _snack('❌ ${e.toString()}', isError: true);
    }
  }

  Future<VercelDeployResult> _deployHtml({
    required String projectName,
    required String htmlContent,
    void Function(String status, double progress)? onProgress,
  }) async {
    onProgress?.call('Menyiapkan deployment...', 0.1);

    final url = Uri.parse('$VERCEL_API/v13/deployments');
    final bytes = utf8.encode(htmlContent);
    final base64Content = base64Encode(bytes);

    final body = {
      'name': projectName,
      'files': [
        {
          'file': 'index.html',
          'data': base64Content,
          'encoding': 'base64',
        },
      ],
      'projectSettings': {
        'framework': null,
        'buildCommand': null,
        'outputDirectory': null,
        'rootDirectory': null,
      },
      'target': 'production',
      'regions': ['sin1'],
    };

    onProgress?.call('Mengirim ke Vercel...', 0.3);

    try {
      final res = await http
          .post(
            url,
            headers: {
              'Authorization': 'Bearer $VERCEL_TOKEN',
              'Content-Type': 'application/json',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));

      if (res.statusCode == 200 || res.statusCode == 201) {
        final data = jsonDecode(res.body);
        final deployId = data['id'] as String?;
        final deployUrl = data['url'] as String?;
        final readyState = data['readyState'] as String? ?? 'QUEUED';

        if (deployId == null || deployUrl == null) {
          throw 'Response Vercel tidak valid';
        }

        onProgress?.call('Menunggu deployment selesai...', 0.5);

        return VercelDeployResult(
          id: deployId,
          url: 'https://$deployUrl',
          rawUrl: deployUrl,
          readyState: readyState,
          projectName: projectName,
        );
      } else {
        throw 'Vercel error (${res.statusCode}): ${_parseVercelError(res.body)}';
      }
    } on TimeoutException {
      throw 'Koneksi timeout. Coba lagi.';
    } catch (e) {
      throw 'Deploy gagal: $e';
    }
  }

  Future<VercelDeployResult> _waitUntilReady({
    required String deployId,
    int maxAttempts = 30,
    Duration interval = const Duration(seconds: 3),
    void Function(String status, double progress)? onProgress,
  }) async {
    for (int i = 0; i < maxAttempts; i++) {
      await Future.delayed(interval);
      final progress = 0.5 + (i / maxAttempts) * 0.45;
      onProgress?.call('Building... (${i + 1}/$maxAttempts)', progress);

      try {
        final url = Uri.parse('$VERCEL_API/v13/deployments/$deployId');
        final res = await http.get(
          url,
          headers: {'Authorization': 'Bearer $VERCEL_TOKEN'},
        ).timeout(const Duration(seconds: 15));

        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final state = data['readyState'] as String? ?? 'QUEUED';
          final urlField = data['url'] as String? ?? '';
          final errMsg = data['errorMessage'] as String?;

          if (state == 'READY') {
            onProgress?.call('Deploy selesai!', 1.0);
            return VercelDeployResult(
              id: deployId,
              url: 'https://$urlField',
              rawUrl: urlField,
              readyState: state,
              projectName: data['name'] as String? ?? '',
            );
          } else if (state == 'ERROR' || state == 'CANCELED') {
            throw 'Deployment gagal: ${errMsg ?? state}';
          }
        }
      } catch (e) {
        if (i == maxAttempts - 1) rethrow;
      }
    }
    throw 'Timeout menunggu deployment.';
  }

  // ═══════════════════════════════════════════════════════════════════
  // CUSTOM DOMAIN — AUTO SETUP (Cloudflare DNS + Vercel)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _setupCustomDomain() async {
    if (_result == null) {
      _snack('❌ Deploy dulu sebelum custom domain', isError: true);
      return;
    }

    final subdomain = _domainController.text.trim().toLowerCase();
    if (subdomain.isEmpty) {
      _snack('❌ Subdomain tidak boleh kosong', isError: true);
      return;
    }
    if (!RegExp(r'^[a-z0-9]([a-z0-9-]*[a-z0-9])?$').hasMatch(subdomain)) {
      _snack('❌ Subdomain tidak valid (a-z, 0-9, minus)', isError: true);
      return;
    }
    if (CLOUDFLARE_TOKEN.contains('GANTI_') ||
        CLOUDFLARE_ZONE_ID.contains('GANTI_')) {
      _snack('❌ Cloudflare token / Zone ID belum di-set di code',
          isError: true);
      return;
    }

    final fullDomain = '$subdomain.$DOMAIN_SUFFIX';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: vdBgSurface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: vdBorderDark, width: 2.5),
        ),
        title: Text(
          'Auto Setup Domain',
          style: TextStyle(
            color: vdTextMain,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
            fontSize: 14,
          ),
        ),
        content: Text(
          'Setup otomatis:\n\n'
          '1. Create CNAME di Cloudflare\n'
          '   $subdomain → $VERCEL_CNAME_TARGET\n\n'
          '2. Add domain ke Vercel\n'
          '   $fullDomain\n\n'
          'Lanjutkan?',
          style: TextStyle(
            color: vdTextSub,
            fontFamily: 'ShareTechMono',
            fontSize: 12,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('BATAL', style: TextStyle(color: vdTextSub)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('SETUP', style: TextStyle(color: vdGold)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() {
      _isSettingDomain = true;
      _domainSteps.clear();
      _finalDomainUrl = null;
    });

    try {
      // ─── STEP 1: Create CNAME di Cloudflare ───
      _addStep('Membuat CNAME record di Cloudflare...', StepStatus.loading);

      // Hapus CNAME lama kalau ada (biar gak conflict)
      await _deleteExistingCname(subdomain);

      final dnsOk = await _createCloudflareCname(subdomain);

      if (!dnsOk) {
        _updateStep(0,
            status: StepStatus.error,
            detail: 'Gagal bikin CNAME di Cloudflare');
        throw 'Gagal bikin CNAME di Cloudflare';
      }
      _updateStep(0,
          status: StepStatus.success,
          detail: '$subdomain → $VERCEL_CNAME_TARGET');

      // ─── STEP 2: Add domain ke Vercel ───
      await Future.delayed(const Duration(seconds: 1));
      _addStep('Menambahkan domain ke Vercel...', StepStatus.loading);

      final vercelOk = await _addVercelDomain(fullDomain);

      if (!vercelOk) {
        _updateStep(1,
            status: StepStatus.error,
            detail: 'Gagal add domain ke Vercel');
        throw 'Gagal add domain ke Vercel';
      }
      _updateStep(1,
          status: StepStatus.success, detail: fullDomain);

      // ─── STEP 3: Tunggu Vercel verifikasi DNS ───
      await Future.delayed(const Duration(seconds: 2));
      _addStep('Menunggu Vercel verifikasi...', StepStatus.loading);

      final verified = await _waitForDomainVerification(fullDomain);

      if (verified) {
        _updateStep(2,
            status: StepStatus.success,
            detail: 'Verified! Aktif dalam ~1 menit');
      } else {
        _updateStep(2,
            status: StepStatus.warning,
            detail: 'Belum verified, tunggu ~5 menit');
      }

      if (!mounted) return;
      setState(() {
        _isSettingDomain = false;
        _finalDomainUrl = 'https://$fullDomain';
      });

      _snack('🎉 Domain setup selesai!');
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSettingDomain = false);
      _snack('❌ ${e.toString()}', isError: true);
    }
  }

  // ─── Cloudflare: Delete existing CNAME (cleanup) ───
  Future<void> _deleteExistingCname(String subdomain) async {
    try {
      final listUrl = Uri.parse(
        '$CLOUDFLARE_API/zones/$CLOUDFLARE_ZONE_ID/dns_records'
        '?type=CNAME&name=$subdomain.$DOMAIN_SUFFIX',
      );
      final res = await http.get(
        listUrl,
        headers: {'Authorization': 'Bearer $CLOUDFLARE_TOKEN'},
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final result = data['result'] as List? ?? [];
        for (final record in result) {
          final recordId = record['id'] as String?;
          if (recordId == null) continue;

          final delUrl = Uri.parse(
            '$CLOUDFLARE_API/zones/$CLOUDFLARE_ZONE_ID/dns_records/$recordId',
          );
          await http.delete(
            delUrl,
            headers: {'Authorization': 'Bearer $CLOUDFLARE_TOKEN'},
          ).timeout(const Duration(seconds: 10));
        }
      }
    } catch (e) {
      debugPrint('Cleanup error (skip): $e');
    }
  }

  // ─── Cloudflare: Create CNAME record ───
  Future<bool> _createCloudflareCname(String subdomain) async {
    try {
      final url = Uri.parse(
        '$CLOUDFLARE_API/zones/$CLOUDFLARE_ZONE_ID/dns_records',
      );

      final body = {
        'type': 'CNAME',
        'name': subdomain,
        'content': VERCEL_CNAME_TARGET,
        'ttl': 1, // 1 = Auto
        'proxied': false, // ⚠️ HARUS false — Vercel handle SSL sendiri
        'comment': 'Auto-created by ATLAS',
      };

      final res = await http
          .post(
            url,
            headers: {
              'Authorization': 'Bearer $CLOUDFLARE_TOKEN',
              'Content-Type': 'application/json',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 20));

      debugPrint('CF create CNAME: ${res.statusCode} → ${res.body}');

      if (res.statusCode == 200 || res.statusCode == 201) {
        final data = jsonDecode(res.body);
        return data['success'] == true;
      }
      return false;
    } catch (e) {
      debugPrint('CF create error: $e');
      return false;
    }
  }

  // ─── Vercel: Add domain to project ───
  Future<bool> _addVercelDomain(String fullDomain) async {
    try {
      final url = Uri.parse(
        '$VERCEL_API/v10/projects/${_result!.projectName}/domains',
      );

      final res = await http
          .post(
            url,
            headers: {
              'Authorization': 'Bearer $VERCEL_TOKEN',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({'name': fullDomain}),
          )
          .timeout(const Duration(seconds: 20));

      debugPrint('Vercel add domain: ${res.statusCode} → ${res.body}');

      // 200 = sukses, 409 = domain sudah ada (ok)
      return res.statusCode == 200 ||
          res.statusCode == 201 ||
          res.statusCode == 409;
    } catch (e) {
      debugPrint('Vercel add domain error: $e');
      return false;
    }
  }

  // ─── Vercel: Wait for domain verification ───
  Future<bool> _waitForDomainVerification(String fullDomain) async {
    for (int i = 0; i < 10; i++) {
      await Future.delayed(const Duration(seconds: 5));

      try {
        final url = Uri.parse(
          '$VERCEL_API/v9/projects/${_result!.projectName}/domains/$fullDomain',
        );
        final res = await http.get(
          url,
          headers: {'Authorization': 'Bearer $VERCEL_TOKEN'},
        ).timeout(const Duration(seconds: 15));

        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final verified = data['verified'] as bool? ?? false;
          if (verified) return true;
        }
      } catch (e) {
        debugPrint('Verify poll error: $e');
      }
    }
    return false;
  }

  // ─── Domain step helpers ───
  void _addStep(String title, StepStatus status) {
    if (!mounted) return;
    setState(() {
      _domainSteps.add(DomainStep(title: title, status: status));
    });
  }

  void _updateStep(int index,
      {required StepStatus status, String? detail}) {
    if (!mounted) return;
    if (index >= _domainSteps.length) return;
    setState(() {
      _domainSteps[index] = DomainStep(
        title: _domainSteps[index].title,
        status: status,
        detail: detail ?? _domainSteps[index].detail,
      );
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════
  String _parseVercelError(String body) {
    try {
      final data = jsonDecode(body);
      if (data['error'] != null) {
        final err = data['error'];
        return err['message'] ?? err.toString();
      }
      return data['message'] ?? body;
    } catch (_) {
      return body.length > 200 ? '${body.substring(0, 200)}...' : body;
    }
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: vdTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        backgroundColor: isError ? vdRed : vdGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: vdBorderDark, width: 2),
        ),
      ),
    );
  }

  Future<void> _copy(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _snack('📋 Disalin!');
  }

  Future<void> _open(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (_) {
      _snack('❌ Tidak bisa buka URL', isError: true);
    }
  }

  Future<void> _share(String url) async {
    try {
      await Share.share(url, subject: 'Website ATLAS');
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          vdTextMain.withOpacity(0.20),
          vdRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? vdGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [vdBgCard, vdBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  Widget _sectionHeader({
    required String title,
    required IconData icon,
    Widget? trailing,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [vdGold, Color.lerp(vdGold, Colors.black, 0.4)!],
            ),
            shape: BoxShape.circle,
            border: Border.all(color: vdBorderDark, width: 1.5),
            boxShadow: [
              BoxShadow(
                color: vdGold.withOpacity(0.5),
                blurRadius: 8,
              ),
            ],
          ),
          child: Icon(icon, color: vdRedDark, size: 12),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            color: vdTextMain,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        if (trailing != null) ...[
          const Spacer(),
          trailing,
        ],
      ],
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: onPressed != null
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    vdTextSub.withOpacity(0.2),
                    vdTextSub.withOpacity(0.08),
                  ],
                ),
          boxShadow: onPressed != null
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(
                color: onPressed != null
                    ? vdBorderDark
                    : vdTextSub.withOpacity(0.3),
                width: 2.5,
              ),
            ),
          ),
          child: loading
              ? const Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon,
                        size: 18,
                        color: onPressed != null
                            ? Colors.white
                            : vdTextSub.withOpacity(0.5)),
                    const SizedBox(width: 8),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        color: onPressed != null
                            ? Colors.white
                            : vdTextSub.withOpacity(0.5),
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildSmallBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: vdBorderDark, width: 2),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 13),
            const SizedBox(width: 5),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: vdBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(vdBgMain, vdRed, 0.25)!,
                  vdBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 14),
                          _buildProjectNameSection(),
                          const SizedBox(height: 14),
                          _buildHtmlSection(),
                          const SizedBox(height: 14),
                          if (_isDeploying) ...[
                            _buildProgressCard(),
                            const SizedBox(height: 14),
                          ],
                          _buildDeployButton(),
                          const SizedBox(height: 14),
                          if (_result != null) ...[
                            _buildResultCard(),
                            const SizedBox(height: 14),
                            _buildCustomDomainCard(),
                          ],
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [vdBgSurface, vdBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: vdGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: vdGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [vdRed, vdRedDark]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: vdBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [vdRed, vdRedDark]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: vdBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: vdGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.rocket_launch_rounded,
                      color: vdGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'VERCEL DEPLOY',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: vdGold,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [vdGold, Color.lerp(vdGold, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: vdBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: vdGold.withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.rocket_launch_rounded,
                  size: 28, color: vdRedDark),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'DEPLOY WEBSITE',
                    style: TextStyle(
                      color: vdTextMain,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'HTML → Vercel + Auto Custom Domain',
                    style: TextStyle(
                      color: vdTextSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProjectNameSection() {
    final name = _nameController.text.trim();
    final previewUrl = name.isEmpty ? 'contoh' : name;

    return _bevelBox(
      radius: 18,
      glow: _nameError != null ? vdRed : vdGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'NAMA PROJECT',
              icon: Icons.label_rounded,
            ),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [vdBgSurface, vdBgMain],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _nameError != null
                      ? vdRed
                      : vdGold.withOpacity(0.5),
                  width: 2,
                ),
              ),
              child: TextField(
                controller: _nameController,
                enabled: !_isDeploying,
                style: TextStyle(
                  color: vdTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: vdGold,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[a-z0-9-]')),
                  LengthLimitingTextInputFormatter(100),
                ],
                decoration: InputDecoration(
                  hintText: 'contoh: my-website',
                  hintStyle: TextStyle(
                    color: vdTextSub.withOpacity(0.5),
                    fontSize: 12,
                  ),
                  prefixIcon: Icon(Icons.abc_rounded,
                      color: vdGold, size: 16),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
            const SizedBox(height: 8),
            if (_nameError != null)
              Row(
                children: [
                  Icon(Icons.error_outline_rounded,
                      color: vdRed, size: 12),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      _nameError!,
                      style: TextStyle(
                        color: vdRed,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              )
            else if (name.isNotEmpty)
              Row(
                children: [
                  Icon(Icons.check_circle_rounded,
                      color: vdGreen, size: 12),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      '→ https://$previewUrl.vercel.app',
                      style: TextStyle(
                        color: vdGreen,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHtmlSection() {
    final htmlLen = _htmlController.text.length;

    return _bevelBox(
      radius: 18,
      glow: _htmlError != null ? vdRed : vdGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'HTML CONTENT',
              icon: Icons.html_rounded,
              trailing: htmlLen > 0
                  ? Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: vdGold.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                            color: vdGold.withOpacity(0.4), width: 1),
                      ),
                      child: Text(
                        '${(htmlLen / 1024).toStringAsFixed(1)} KB',
                        style: TextStyle(
                          color: vdGold,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    )
                  : null,
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: _isDeploying ? null : _pickHtmlFile,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            vdBlue,
                            Color.lerp(vdBlue, Colors.black, 0.5)!,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: vdBorderDark, width: 2),
                        boxShadow: [
                          const BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                          BoxShadow(
                            color: vdBlue.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.upload_file_rounded,
                              color: Colors.white, size: 14),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              _htmlFileName ?? 'PILIH FILE',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: _isDeploying
                        ? null
                        : () => setState(
                            () => _showHtmlEditor = !_showHtmlEditor),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            _showHtmlEditor ? vdGold : vdBgSurface,
                            _showHtmlEditor
                                ? Color.lerp(vdGold, Colors.black, 0.5)!
                                : vdBgMain,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: _showHtmlEditor
                              ? vdBorderDark
                              : vdGold.withOpacity(0.5),
                          width: 2,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.edit_note_rounded,
                            color: _showHtmlEditor
                                ? vdRedDark
                                : vdTextSub,
                            size: 14,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'PASTE TEXT',
                            style: TextStyle(
                              color: _showHtmlEditor
                                  ? vdRedDark
                                  : vdTextSub,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (_showHtmlEditor) ...[
              const SizedBox(height: 10),
              Container(
                constraints:
                    const BoxConstraints(minHeight: 180, maxHeight: 320),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [vdBgSurface, vdBgMain],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: vdGold.withOpacity(0.4), width: 2),
                ),
                child: TextField(
                  controller: _htmlController,
                  enabled: !_isDeploying,
                  maxLines: null,
                  style: TextStyle(
                    color: vdTextMain,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    height: 1.4,
                  ),
                  cursorColor: vdGold,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText:
                        '<!DOCTYPE html>\n<html>\n<head>\n  <title>My Website</title>\n</head>\n<body>\n  <h1>Hello World</h1>\n</body>\n</html>',
                    hintStyle: TextStyle(
                      color: vdTextSub.withOpacity(0.4),
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(12),
                  ),
                ),
              ),
            ],
            if (_htmlError != null) ...[
              const SizedBox(height: 6),
              Row(
                children: [
                  Icon(Icons.error_outline_rounded,
                      color: vdRed, size: 12),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      _htmlError!,
                      style: TextStyle(
                        color: vdRed,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCard() {
    return _bevelBox(
      radius: 16,
      glow: vdBlue,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: vdBlue.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: vdBlue.withOpacity(0.5), width: 1.5),
                  ),
                  child: Icon(Icons.rocket_launch_rounded,
                      color: vdBlue, size: 12),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _statusText,
                    style: TextStyle(
                      color: vdTextMain,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
                Text(
                  '${(_progress * 100).toStringAsFixed(0)}%',
                  style: TextStyle(
                    color: vdBlue,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: _progress,
                minHeight: 6,
                backgroundColor: vdBgMain,
                valueColor: AlwaysStoppedAnimation(vdBlue),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeployButton() {
    final canDeploy = !_isDeploying &&
        _nameError == null &&
        _htmlError == null &&
        _nameController.text.trim().isNotEmpty &&
        _htmlController.text.trim().isNotEmpty;

    return _build3DButton(
      label: _isDeploying ? 'DEPLOYING...' : 'DEPLOY SEKARANG',
      icon: _isDeploying
          ? Icons.hourglass_top_rounded
          : Icons.rocket_launch_rounded,
      onPressed: canDeploy ? _deploy : null,
      color: vdRed,
      loading: _isDeploying,
    );
  }

  Widget _buildResultCard() {
    final r = _result!;

    return _bevelBox(
      radius: 20,
      glow: vdGreen,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        vdGreen,
                        Color.lerp(vdGreen, Colors.black, 0.4)!,
                      ],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: vdBorderDark, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: vdGreen.withOpacity(0.6),
                        blurRadius: 14,
                      ),
                    ],
                  ),
                  child: Icon(Icons.check_rounded,
                      color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'DEPLOY BERHASIL',
                        style: TextStyle(
                          color: vdGreen,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Project: ${r.projectName}',
                        style: TextStyle(
                          color: vdTextSub,
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [vdBgSurface, vdBgMain],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: vdGreen.withOpacity(0.4), width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'URL VERCEL',
                    style: TextStyle(
                      color: vdTextSub,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  SelectableText(
                    r.url,
                    style: TextStyle(
                      color: vdGreen,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.copy_rounded,
                    label: 'COPY',
                    color: vdBlue,
                    onTap: () => _copy(r.url),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.open_in_new_rounded,
                    label: 'BUKA',
                    color: vdGold,
                    onTap: () => _open(r.url),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.share_rounded,
                    label: 'SHARE',
                    color: vdPurple,
                    onTap: () => _share(r.url),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomDomainCard() {
    return _bevelBox(
      radius: 18,
      glow: vdPurple,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'CUSTOM DOMAIN (AUTO)',
              icon: Icons.auto_awesome_rounded,
            ),
            const SizedBox(height: 8),
            Text(
              'Bikin CNAME di Cloudflare + add ke Vercel otomatis. '
              'Cukup isi subdomain, sisanya app yang handle.',
              style: TextStyle(
                color: vdTextSub,
                fontSize: 10,
                fontFamily: 'ShareTechMono',
                height: 1.4,
              ),
            ),
            const SizedBox(height: 12),

            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [vdBgSurface, vdBgMain],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: vdGold.withOpacity(0.5), width: 2),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _domainController,
                      enabled: !_isSettingDomain,
                      style: TextStyle(
                        color: vdTextMain,
                        fontSize: 13,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                      cursorColor: vdGold,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z0-9-]')),
                      ],
                      decoration: InputDecoration(
                        hintText: 'subdomain',
                        hintStyle: TextStyle(
                          color: vdTextSub.withOpacity(0.5),
                          fontSize: 12,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 14),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 14),
                    decoration: BoxDecoration(
                      color: vdGold.withOpacity(0.15),
                      border: Border(
                        left: BorderSide(
                            color: vdGold.withOpacity(0.4), width: 1.5),
                      ),
                    ),
                    child: Text(
                      '.$DOMAIN_SUFFIX',
                      style: TextStyle(
                        color: vdGold,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            if (_domainSteps.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [vdBgSurface, vdBgMain],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: vdGold.withOpacity(0.3), width: 1.5),
                ),
                child: Column(
                  children: _domainSteps
                      .asMap()
                      .entries
                      .map((e) => _buildStepRow(e.key, e.value))
                      .toList(),
                ),
              ),
            ],

            if (_finalDomainUrl != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [vdBgSurface, vdBgMain],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: vdGreen.withOpacity(0.5), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: vdGreen.withOpacity(0.3),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.public_rounded,
                            color: vdGreen, size: 14),
                        const SizedBox(width: 6),
                        Text(
                          'DOMAIN AKTIF',
                          style: TextStyle(
                            color: vdGreen,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    SelectableText(
                      _finalDomainUrl!,
                      style: TextStyle(
                        color: vdGreen,
                        fontSize: 13,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: _buildSmallBtn(
                            icon: Icons.copy_rounded,
                            label: 'COPY',
                            color: vdBlue,
                            onTap: () => _copy(_finalDomainUrl!),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _buildSmallBtn(
                            icon: Icons.open_in_new_rounded,
                            label: 'BUKA',
                            color: vdGreen,
                            onTap: () => _open(_finalDomainUrl!),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _buildSmallBtn(
                            icon: Icons.share_rounded,
                            label: 'SHARE',
                            color: vdPurple,
                            onTap: () => _share(_finalDomainUrl!),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 12),
            _build3DButton(
              label: _isSettingDomain
                  ? 'SETUP DOMAIN...'
                  : 'SETUP DOMAIN OTOMATIS',
              icon: _isSettingDomain
                  ? Icons.hourglass_top_rounded
                  : Icons.auto_fix_high_rounded,
              onPressed: _isSettingDomain ? null : _setupCustomDomain,
              color: vdPurple,
              loading: _isSettingDomain,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepRow(int index, DomainStep step) {
    Color color;
    IconData icon;
    switch (step.status) {
      case StepStatus.loading:
        color = vdBlue;
        icon = Icons.hourglass_top_rounded;
        break;
      case StepStatus.success:
        color = vdGreen;
        icon = Icons.check_circle_rounded;
        break;
      case StepStatus.warning:
        color = vdGold;
        icon = Icons.info_rounded;
        break;
      case StepStatus.error:
        color = vdRed;
        icon = Icons.error_rounded;
        break;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (step.status == StepStatus.loading)
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: color,
              ),
            )
          else
            Icon(icon, color: color, size: 14),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  step.title,
                  style: TextStyle(
                    color: vdTextMain,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (step.detail != null)
                  Text(
                    step.detail!,
                    style: TextStyle(
                      color: color,
                      fontSize: 9,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// ─── MODELS ───────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class VercelDeployResult {
  final String id;
  final String url;
  final String rawUrl;
  final String readyState;
  final String projectName;

  VercelDeployResult({
    required this.id,
    required this.url,
    required this.rawUrl,
    required this.readyState,
    required this.projectName,
  });
}

enum StepStatus { loading, success, warning, error }

class DomainStep {
  final String title;
  final StepStatus status;
  final String? detail;

  DomainStep({
    required this.title,
    required this.status,
    this.detail,
  });
}