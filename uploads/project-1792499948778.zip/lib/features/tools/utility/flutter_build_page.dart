// lib/features/tools/utility/flutter_build_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// 🔑 CONFIG
// ═══════════════════════════════════════════════════════════════════
const String GITHUB_TOKEN = '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';
const String GITHUB_OWNER = 'ErlanXzzz';
const String GITHUB_REPO = 'Builder';
const String WORKFLOW_FILE = 'build.yml';
const String WORKFLOW_REF = 'main';
const String GH_API = 'https://api.github.com';

const String CDN_UPLOAD = 'https://cdn.atlas-by-erlan.com/api/upload';

const int MAX_ZIP_SIZE = 100 * 1024 * 1024;

// ═══════════════════════════════════════════════════════════════════
// ─── XTHEME-DRIVEN COLORS ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
Color fbBgMain = const Color(0xFF160A07);
Color fbBgSurface = const Color(0xFF2A140E);
Color fbBgCard = const Color(0xFF3A1E15);
Color fbTextMain = const Color(0xFFF3E6DD);
Color fbTextSub = const Color(0xFFC9913F);
Color fbGold = const Color(0xFFD4A853);
Color fbRed = const Color(0xFFB71C1C);
Color fbRedDark = const Color(0xFF7F0000);
Color fbGreen = const Color(0xFF4CAF50);
Color fbBlue = const Color(0xFF2196F3);
Color fbPurple = const Color(0xFFAB47BC);
Color fbYellow = const Color(0xFFFFC107);
Color fbBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  fbBgMain     = theme.brownDark;
  fbBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  fbBgCard     = theme.brownMid;
  fbTextMain   = theme.bgCreamLight;
  fbTextSub    = theme.gold;
  fbGold       = theme.gold;
  fbRed        = theme.redMain;
  fbRedDark    = theme.redDark;
  fbGreen      = theme.accentGreen;
  fbBlue       = theme.accentBlue;
  fbPurple     = theme.accentBlue;
  fbYellow     = theme.accentYellow;
  fbBorderDark = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// ─── MAIN PAGE ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class FlutterBuildPage extends StatefulWidget {
  const FlutterBuildPage({super.key});

  @override
  State<FlutterBuildPage> createState() => _FlutterBuildPageState();
}

class _FlutterBuildPageState extends State<FlutterBuildPage> {
  final XThemeController _themeController = XThemeController();

  final _tagController = TextEditingController();
  final _logScrollController = ScrollController();

  File? _zipFile;
  String? _zipFileName;
  int? _zipFileSize;

  ZipAnalysis? _analysis;

  String _buildType = 'release';
  bool _onlyAnalyze = false;

  BuildStage _stage = BuildStage.idle;
  double _progress = 0.0;
  String _statusText = '';
  int? _runId;
  String? _runUrl;
  String? _zipPublicUrl;

  final List<String> _logs = [];
  Timer? _logPollTimer;
  int _logPollAttempts = 0;

  String? _artifactName;
  int? _artifactId;
  int? _artifactSize;
  String? _savedApkPath;
  double _downloadProgress = 0.0;

  final List<BuildHistoryItem> _history = [];
  static const String _historyKey = 'flutter_build_history_v1';

  @override
  void initState() {
    super.initState();
    _loadHistory();
    final now = DateTime.now();
    _tagController.text =
        'build-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _logPollTimer?.cancel();
    _tagController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // HELPER: BACA BYTES ENTRY ZIP (kompatibel archive v3 & v4)
  // ═══════════════════════════════════════════════════════════════════
  List<int> _readEntryBytes(dynamic entry) {
    try {
      final content = entry.content;
      if (content == null) return const <int>[];
      if (content is Uint8List) return content;
      if (content is List<int>) return content;
      try {
        final rb = entry.readBytes();
        if (rb is Uint8List) return rb;
        if (rb is List<int>) return rb;
      } catch (_) {}
      return const <int>[];
    } catch (_) {
      return const <int>[];
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // HISTORY
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_historyKey);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        if (!mounted) return;
        setState(() {
          _history.clear();
          _history.addAll(list
              .map((e) => BuildHistoryItem.fromJson(Map<String, dynamic>.from(e)))
              .toList());
        });
      }
    } catch (_) {}
  }

  Future<void> _saveHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
          _historyKey, jsonEncode(_history.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  void _addHistory(BuildHistoryItem item) {
    _history.insert(0, item);
    if (_history.length > 10) _history.removeLast();
    _saveHistory();
  }

  // ═══════════════════════════════════════════════════════════════════
  // LOG
  // ═══════════════════════════════════════════════════════════════════
  void _addLog(String line) {
    if (!mounted) return;
    final timestamp = DateTime.now().toIso8601String().substring(11, 19);
    setState(() => _logs.add('[$timestamp] $line'));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          _logScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _clearLogs() {
    setState(() => _logs.clear());
  }

  // ═══════════════════════════════════════════════════════════════════
  // PICK ZIP
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _pickZip() async {
    final allowed = _stage == BuildStage.idle ||
        _stage == BuildStage.ready ||
        _stage == BuildStage.success ||
        _stage == BuildStage.failed ||
        _stage == BuildStage.error;
    if (!allowed) {
      _snack('⏳ Tunggu proses selesai dulu', isError: true);
      return;
    }

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      if (file.path == null) {
        _snack('❌ Gagal baca file', isError: true);
        return;
      }

      final f = File(file.path!);
      final size = await f.length();

      if (size > MAX_ZIP_SIZE) {
        _snack(
            '❌ File terlalu besar (max ${(MAX_ZIP_SIZE / 1024 / 1024).toInt()}MB)',
            isError: true);
        return;
      }

      if (!mounted) return;
      setState(() {
        _zipFile = f;
        _zipFileName = file.name;
        _zipFileSize = size;
        _analysis = null;
        _logs.clear();
        _stage = BuildStage.analyzing;
        _statusText = 'Menganalisis ZIP...';
      });

      _addLog('📦 File dipilih: ${file.name} (${_formatBytes(size)})');
      _addLog('🔍 Mulai analisis isi ZIP...');

      await _analyzeZip();
    } catch (e) {
      _snack('❌ Gagal pilih file: $e', isError: true);
      if (mounted) {
        setState(() {
          _stage = BuildStage.idle;
          _statusText = '';
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // ANALYZE ZIP
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _analyzeZip() async {
    if (_zipFile == null) return;

    try {
      final bytes = await _zipFile!.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);

      _addLog('📂 Total entry: ${archive.length}');

      bool hasPubspec = false;
      bool hasMain = false;
      bool hasAndroid = false;
      bool hasLib = false;
      String? pubspecName;
      String? pubspecVersion;
      int fileCount = 0;
      int dirCount = 0;

      for (final entry in archive) {
        final path = entry.name;
        final basename = path.split('/').last;

        if (entry.isFile) {
          fileCount++;

          if (basename == 'pubspec.yaml') {
            hasPubspec = true;
            try {
              final content = String.fromCharCodes(_readEntryBytes(entry));
              final lines = content.split('\n');
              for (final line in lines) {
                if (line.startsWith('name:')) {
                  pubspecName = line.replaceFirst('name:', '').trim();
                }
                if (line.startsWith('version:')) {
                  pubspecVersion = line.replaceFirst('version:', '').trim();
                }
              }
            } catch (_) {}
          }

          if (path.contains('lib/main.dart')) {
            hasMain = true;
          }

          if (path.contains('android/')) {
            hasAndroid = true;
          }
        } else {
          dirCount++;
          if (path.contains('lib/') || path.endsWith('lib')) {
            hasLib = true;
          }
        }
      }

      final isValid = hasPubspec && hasMain;

      final analysis = ZipAnalysis(
        hasPubspec: hasPubspec,
        hasMainDart: hasMain,
        hasAndroid: hasAndroid,
        hasLib: hasLib,
        pubspecName: pubspecName,
        pubspecVersion: pubspecVersion,
        fileCount: fileCount,
        dirCount: dirCount,
        isValidFlutterProject: isValid,
      );

      if (!mounted) return;
      setState(() => _analysis = analysis);

      _addLog('');
      _addLog('━━━ HASIL ANALISIS ━━━');
      _addLog('${hasPubspec ? "✅" : "❌"} pubspec.yaml');
      if (pubspecName != null) _addLog('   → Project: $pubspecName');
      if (pubspecVersion != null) _addLog('   → Version: $pubspecVersion');
      _addLog('${hasMain ? "✅" : "❌"} lib/main.dart');
      _addLog('${hasAndroid ? "✅" : "⚠️"} android/ folder');
      _addLog('${hasLib ? "✅" : "⚠️"} lib/ folder');
      _addLog('📊 Total: $fileCount files, $dirCount folders');
      _addLog('');

      if (isValid) {
        _addLog('🎉 ZIP VALID! Siap untuk build.');
        if (!mounted) return;
        setState(() {
          _stage = BuildStage.ready;
          _statusText = 'Siap untuk build';
          _progress = 0.0;
        });
      } else {
        _addLog('❌ ZIP TIDAK VALID!');
        if (!hasPubspec) {
          _addLog('   → pubspec.yaml tidak ditemukan');
        }
        if (!hasMain) {
          _addLog('   → lib/main.dart tidak ditemukan');
        }
        if (!mounted) return;
        setState(() {
          _stage = BuildStage.error;
          _statusText = 'ZIP tidak valid — bukan project Flutter';
        });
        _snack('❌ ZIP bukan project Flutter valid', isError: true);
      }
    } catch (e) {
      _addLog('❌ Gagal membaca ZIP: $e');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.error;
        _statusText = 'Gagal menganalisis ZIP';
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // START BUILD
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _startBuild() async {
    if (GITHUB_TOKEN.contains('GANTI_') || GITHUB_TOKEN.isEmpty) {
      _snack('❌ GitHub Token belum di-set di code', isError: true);
      return;
    }

    if (_zipFile == null) {
      _snack('❌ Pilih file ZIP dulu', isError: true);
      return;
    }

    if (_analysis == null || !_analysis!.isValidFlutterProject) {
      _snack('❌ ZIP tidak valid', isError: true);
      return;
    }

    final tag = _tagController.text.trim();
    if (tag.isEmpty) {
      _snack('❌ Tag tidak boleh kosong', isError: true);
      return;
    }

    setState(() {
      _stage = BuildStage.uploading;
      _statusText = 'Upload ZIP ke CDN...';
      _progress = 0.0;
    });

    _addLog('');
    _addLog('━━━ MULAI BUILD ━━━');

    try {
      _addLog('📤 Upload ZIP ke CDN...');
      final zipUrl = await _uploadZipToCdn();
      _zipPublicUrl = zipUrl;

      if (!mounted) return;
      setState(() {
        _stage = BuildStage.triggering;
        _statusText = 'Trigger workflow GitHub...';
        _progress = 0.3;
      });

      _addLog('✅ ZIP uploaded: $zipUrl');
      _addLog('🚀 Trigger GitHub Actions...');

      await _triggerWorkflow(zipUrl, tag);

      if (!mounted) return;
      setState(() {
        _stage = BuildStage.waiting;
        _statusText = 'Menunggu runner...';
        _progress = 0.5;
      });

      _addLog('⏳ Menunggu workflow mulai...');

      await Future.delayed(const Duration(seconds: 6));
      await _findAndPollRun(tag);
    } catch (e) {
      _addLog('❌ Error: $e');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.error;
        _statusText = e.toString();
      });
      _snack('❌ $e', isError: true);
      _addHistory(BuildHistoryItem(
        tag: tag,
        buildType: _buildType,
        status: 'error',
        createdAt: DateTime.now(),
        errorMessage: e.toString(),
      ));
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // UPLOAD ZIP TO CDN
  // ═══════════════════════════════════════════════════════════════════
  Future<String> _uploadZipToCdn() async {
    if (_zipFile == null) throw 'ZIP tidak ada';

    final request = http.MultipartRequest('POST', Uri.parse(CDN_UPLOAD));
    request.files.add(
      await http.MultipartFile.fromPath('file', _zipFile!.path),
    );

    final streamedResponse = await request.send().timeout(
      const Duration(minutes: 5),
      onTimeout: () => throw 'Upload timeout (>5 menit)',
    );

    final response = await http.Response.fromStream(streamedResponse);

    debugPrint('CDN upload: ${response.statusCode} → ${response.body}');

    if (response.statusCode != 200) {
      throw 'Upload gagal (${response.statusCode}): ${response.body}';
    }

    final data = jsonDecode(response.body);
    if (data['success'] != true || data['url'] == null) {
      throw 'Response CDN tidak valid: ${response.body}';
    }

    return data['url'] as String;
  }

  // ═══════════════════════════════════════════════════════════════════
  // TRIGGER WORKFLOW
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _triggerWorkflow(String zipUrl, String tag) async {
    final url = Uri.parse(
      '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/workflows/$WORKFLOW_FILE/dispatches',
    );

    final body = {
      'ref': WORKFLOW_REF,
      'inputs': {
        'zip_url': zipUrl,
        'tag': tag,
        'build_type': _buildType,
        'only_analyze': _onlyAnalyze ? 'true' : 'false',
      },
    };

    final res = await http
        .post(
          url,
          headers: {
            'Authorization': 'Bearer $GITHUB_TOKEN',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28',
            'Content-Type': 'application/json',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 20));

    if (res.statusCode != 204) {
      throw 'Trigger gagal (${res.statusCode}): ${res.body}';
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // FIND RUN + POLL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _findAndPollRun(String tag) async {
    try {
      final url = Uri.parse(
        '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/workflows/$WORKFLOW_FILE/runs?per_page=5',
      );

      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $GITHUB_TOKEN',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        throw 'List runs gagal (${res.statusCode})';
      }

      final data = jsonDecode(res.body);
      final runs = (data['workflow_runs'] as List? ?? []);
      if (runs.isEmpty) throw 'Tidak ada workflow run';

      final latest = runs[0];
      _runId = latest['id'] as int?;
      _runUrl = latest['html_url'] as String?;

      if (_runId == null) throw 'Run ID invalid';

      if (!mounted) return;
      setState(() {
        _stage = BuildStage.running;
        _statusText = 'Build sedang berjalan...';
        _progress = 0.55;
      });

      _addLog('✅ Workflow run ditemukan: $_runId');
      if (_runUrl != null) _addLog('🔗 $_runUrl');

      _startPolling(tag);
    } catch (e) {
      _addLog('❌ $e');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.error;
        _statusText = e.toString();
      });
    }
  }

  void _startPolling(String tag) {
    _logPollTimer?.cancel();
    _logPollAttempts = 0;

    _logPollTimer = Timer.periodic(const Duration(seconds: 8), (t) async {
      if (_runId == null || !mounted) return;
      _logPollAttempts++;

      try {
        final url = Uri.parse(
          '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/runs/$_runId',
        );
        final res = await http.get(
          url,
          headers: {
            'Authorization': 'Bearer $GITHUB_TOKEN',
            'Accept': 'application/vnd.github+json',
          },
        ).timeout(const Duration(seconds: 15));

        if (res.statusCode != 200) return;

        final data = jsonDecode(res.body);
        final status = data['status'] as String? ?? 'queued';
        final conclusion = data['conclusion'] as String?;

        if (!mounted) return;

        if (status == 'completed') {
          t.cancel();
          await _onBuildCompleted(tag, conclusion);
        } else {
          if (status == 'in_progress') {
            final newProgress = 0.55 + (_logPollAttempts * 0.02).clamp(0.0, 0.35);
            setState(() {
              _stage = BuildStage.running;
              _statusText = 'Building... (${_logPollAttempts * 8}s)';
              _progress = newProgress;
            });

            if (_logPollAttempts % 3 == 0) {
              await _fetchLiveLog();
            }
          } else {
            setState(() {
              _statusText = 'Antrian...';
              _progress = 0.5;
            });
          }
        }
      } catch (e) {
        debugPrint('Poll error: $e');
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // FETCH LIVE LOG
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchLiveLog() async {
    if (_runId == null) return;

    try {
      final jobsUrl = Uri.parse(
        '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/runs/$_runId/jobs',
      );
      final jobsRes = await http.get(
        jobsUrl,
        headers: {
          'Authorization': 'Bearer $GITHUB_TOKEN',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 15));

      if (jobsRes.statusCode != 200) return;

      final jobsData = jsonDecode(jobsRes.body);
      final jobs = (jobsData['jobs'] as List? ?? []);
      if (jobs.isEmpty) return;

      final jobId = jobs[0]['id'] as int?;
      if (jobId == null) return;

      final logUrl = Uri.parse(
        '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/jobs/$jobId/logs',
      );
      final logRes = await http.get(
        logUrl,
        headers: {
          'Authorization': 'Bearer $GITHUB_TOKEN',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 20));

      if (logRes.statusCode != 200) return;

      final logText = logRes.body;
      if (logText.isEmpty) return;

      final lines = logText.split('\n');
      final recentLines = lines.length > 15
          ? lines.sublist(lines.length - 15)
          : lines;

      if (!mounted) return;
      setState(() {
        final localLogs = _logs
            .where((l) =>
                l.contains('📤') ||
                l.contains('🚀') ||
                l.contains('✅') ||
                l.contains('⏳') ||
                l.contains('━━━') ||
                l.contains('📦') ||
                l.contains('📂') ||
                l.contains('📊') ||
                l.contains('🎉') ||
                l.contains('❌') ||
                l.contains('🔗') ||
                l.contains('→') ||
                l.contains('   '))
            .toList();
        _logs.clear();
        _logs.addAll(localLogs);
        _logs.add('');
        _logs.add('━━━ GITHUB ACTIONS LOG ━━━');
        _logs.addAll(recentLines.where((l) => l.trim().isNotEmpty));
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollController.hasClients) {
          _logScrollController.animateTo(
            _logScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut,
          );
        }
      });
    } catch (e) {
      debugPrint('Fetch log error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // ON BUILD COMPLETED
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _onBuildCompleted(String tag, String? conclusion) async {
    _addLog('');
    _addLog('━━━ BUILD SELESAI ━━━');

    await _fetchLiveLog();

    if (conclusion == 'success') {
      _addLog('✅ Build SUKSES!');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.success;
        _statusText = 'Build sukses! Ambil artifact...';
        _progress = 0.95;
      });

      await Future.delayed(const Duration(seconds: 2));
      await _fetchArtifact(tag);
    } else {
      _addLog('❌ Build GAGAL ($conclusion)');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.failed;
        _statusText = 'Build gagal: $conclusion';
        _progress = 1.0;
      });
      _snack('❌ Build gagal', isError: true);
      _addHistory(BuildHistoryItem(
        tag: tag,
        buildType: _buildType,
        status: 'failed',
        createdAt: DateTime.now(),
        runUrl: _runUrl,
        errorMessage: 'Conclusion: $conclusion',
      ));
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // FETCH ARTIFACT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchArtifact(String tag) async {
    try {
      final url = Uri.parse(
        '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/runs/$_runId/artifacts',
      );

      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $GITHUB_TOKEN',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        throw 'Fetch artifact gagal (${res.statusCode})';
      }

      final data = jsonDecode(res.body);
      final artifacts = (data['artifacts'] as List? ?? []);
      if (artifacts.isEmpty) throw 'Tidak ada artifact';

      final first = artifacts[0];
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.success;
        _artifactName = first['name'] as String?;
        _artifactId = first['id'] as int?;
        _artifactSize = first['size_in_bytes'] as int?;
        _progress = 1.0;
        _statusText = 'Build sukses! Siap download.';
      });

      _addLog('📦 Artifact: $_artifactName');
      _addLog('📊 Size: ${_formatBytes(_artifactSize)}');
      _snack('🎉 APK siap di-download!');

      _addHistory(BuildHistoryItem(
        tag: tag,
        buildType: _buildType,
        status: 'success',
        createdAt: DateTime.now(),
        runUrl: _runUrl,
        artifactName: _artifactName,
        artifactId: _artifactId,
        artifactSize: _artifactSize,
      ));
    } catch (e) {
      _addLog('❌ $e');
      if (!mounted) return;
      setState(() {
        _stage = BuildStage.error;
        _statusText = e.toString();
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // DOWNLOAD ARTIFACT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _downloadArtifact() async {
    if (_artifactId == null || _artifactName == null) {
      _snack('❌ Tidak ada artifact', isError: true);
      return;
    }

    setState(() => _downloadProgress = 0.0);

    try {
      final url = Uri.parse(
        '$GH_API/repos/$GITHUB_OWNER/$GITHUB_REPO/actions/artifacts/$_artifactId/zip',
      );

      _addLog('⬇️ Download artifact...');

      final client = http.Client();
      final request = http.Request('GET', url);
      request.headers.addAll({
        'Authorization': 'Bearer $GITHUB_TOKEN',
        'Accept': 'application/vnd.github+json',
      });

      final response = await client.send(request);
      if (response.statusCode != 200 && response.statusCode != 302) {
        throw 'Download gagal (${response.statusCode})';
      }

      final totalBytes = response.contentLength ?? 0;
      final chunks = <int>[];

      await for (final chunk in response.stream) {
        chunks.addAll(chunk);
        if (totalBytes > 0 && mounted) {
          setState(() => _downloadProgress = chunks.length / totalBytes);
        }
      }

      client.close();

      Directory? dir;
      if (Platform.isAndroid) {
        dir = Directory('/storage/emulated/0/Download');
        if (!await dir.exists()) {
          dir = await getExternalStorageDirectory();
        }
      } else {
        dir = await getApplicationDocumentsDirectory();
      }

      if (dir == null) {
        throw 'Tidak bisa mengakses folder Download';
      }

      final fileName = '${_artifactName ?? "flutter-apk"}.zip';
      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(chunks);

      if (!mounted) return;
      setState(() {
        _savedApkPath = file.path;
        _downloadProgress = 1.0;
      });

      _addLog('✅ Tersimpan: ${file.path}');
      _snack('✅ Disimpan: ${file.path}');

      await _extractApkFromZip(file);
    } catch (e) {
      _addLog('❌ $e');
      _snack('❌ $e', isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // EXTRACT APK FROM ARTIFACT ZIP
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _extractApkFromZip(File zipFile) async {
    try {
      _addLog('📂 Extract APK dari ZIP...');

      final bytes = await zipFile.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);

      final apks = <dynamic>[];
      for (final f in archive) {
        if (f.isFile && f.name.endsWith('.apk')) apks.add(f);
      }

      if (apks.isEmpty) {
        _addLog('⚠️ Tidak ada APK di dalam ZIP');
        return;
      }

      _addLog('📱 Ditemukan ${apks.length} APK:');
      for (final apk in apks) {
        _addLog('   → ${apk.name} (${_formatBytes(apk.size as int?)})');
      }

      Directory? dir;
      if (Platform.isAndroid) {
        dir = Directory('/storage/emulated/0/Download');
        if (!await dir.exists()) {
          dir = await getExternalStorageDirectory();
        }
      } else {
        dir = await getApplicationDocumentsDirectory();
      }

      if (dir == null) {
        _addLog('⚠️ Tidak bisa mengakses folder Download');
        return;
      }

      final extractDir =
          Directory('${dir.path}/atlas_apk_${DateTime.now().millisecondsSinceEpoch}');
      await extractDir.create(recursive: true);

      for (final apk in apks) {
        final apkFileName = (apk.name as String).split('/').last;
        final apkFile = File('${extractDir.path}/$apkFileName');
        await apkFile.writeAsBytes(_readEntryBytes(apk));
        _addLog('✅ Extracted: $apkFileName');
      }

      _addLog('📁 APK tersimpan di: ${extractDir.path}');
      _snack('✅ APK tersimpan di folder atlas_apk');
    } catch (e) {
      _addLog('⚠️ Gagal extract APK: $e');
    }
  }

  Future<void> _shareArtifact() async {
    if (_savedApkPath == null) return;
    try {
      await Share.shareXFiles(
        [XFile(_savedApkPath!)],
        subject: 'Flutter APK Build',
      );
    } catch (e) {
      debugPrint('Share error: $e');
      _snack('Share tidak tersedia di perangkat ini', isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════
  void _reset() {
    setState(() {
      _zipFile = null;
      _zipFileName = null;
      _zipFileSize = null;
      _analysis = null;
      _stage = BuildStage.idle;
      _progress = 0.0;
      _statusText = '';
      _runId = null;
      _runUrl = null;
      _zipPublicUrl = null;
      _artifactName = null;
      _artifactId = null;
      _artifactSize = null;
      _savedApkPath = null;
      _downloadProgress = 0.0;
      _logs.clear();
    });
    _logPollTimer?.cancel();
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: fbTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        backgroundColor: isError ? fbRed : fbGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: fbBorderDark, width: 2),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  String _formatBytes(int? bytes) {
    if (bytes == null) return '-';
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  Future<void> _copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _snack('📋 Disalin!');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          fbTextMain.withOpacity(0.20),
          fbRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? fbGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [fbBgCard, fbBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  Widget _sectionHeader({
    required String title,
    required IconData icon,
    Widget? trailing,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [fbGold, Color.lerp(fbGold, Colors.black, 0.4)!],
            ),
            shape: BoxShape.circle,
            border: Border.all(color: fbBorderDark, width: 1.5),
            boxShadow: [
              BoxShadow(color: fbGold.withOpacity(0.5), blurRadius: 8),
            ],
          ),
          child: Icon(icon, color: fbRedDark, size: 12),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            color: fbTextMain,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        if (trailing != null) ...[
          const Spacer(),
          trailing,
        ],
      ],
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: onPressed != null
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    fbTextSub.withOpacity(0.2),
                    fbTextSub.withOpacity(0.08),
                  ],
                ),
          boxShadow: onPressed != null
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(
                color: onPressed != null
                    ? fbBorderDark
                    : fbTextSub.withOpacity(0.3),
                width: 2.5,
              ),
            ),
          ),
          child: loading
              ? const Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon,
                        size: 18,
                        color: onPressed != null
                            ? Colors.white
                            : fbTextSub.withOpacity(0.5)),
                    const SizedBox(width: 8),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        color: onPressed != null
                            ? Colors.white
                            : fbTextSub.withOpacity(0.5),
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildSmallBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: fbBorderDark, width: 2),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 13),
            const SizedBox(width: 5),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: fbBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(fbBgMain, fbRed, 0.25)!,
                  fbBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  _buildProgressBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 14),
                          _buildPickZipSection(),
                          if (_analysis != null) ...[
                            const SizedBox(height: 14),
                            _buildAnalysisCard(),
                          ],
                          if (_stage != BuildStage.idle &&
                              _stage != BuildStage.analyzing) ...[
                            const SizedBox(height: 14),
                            _buildConfigCard(),
                          ],
                          const SizedBox(height: 14),
                          _buildBuildButton(),
                          if (_logs.isNotEmpty) ...[
                            const SizedBox(height: 14),
                            _buildLogSection(),
                          ],
                          if (_artifactId != null) ...[
                            const SizedBox(height: 14),
                            _buildArtifactCard(),
                          ],
                          const SizedBox(height: 14),
                          _buildHistorySection(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── APP BAR ─────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 12, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [fbBgSurface, fbBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: fbGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: fbGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [fbRed, fbRedDark]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: fbBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [fbRed, fbRedDark]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: fbBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: fbGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.precision_manufacturing_rounded,
                      color: fbGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'FLUTTER BUILDER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (_stage != BuildStage.idle)
            GestureDetector(
              onTap: _reset,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [fbRed, fbRedDark]),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: fbBorderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                  ],
                ),
                child: Icon(Icons.refresh_rounded,
                    color: fbGold, size: 18),
              ),
            ),
        ],
      ),
    );
  }

  // ─── PROGRESS BAR ────────────────────────────────────────────
  Widget _buildProgressBar() {
    if (_stage == BuildStage.idle || _stage == BuildStage.analyzing) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                _statusText,
                style: TextStyle(
                  color: fbTextSub,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const Spacer(),
              Text(
                '${(_progress * 100).toStringAsFixed(0)}%',
                style: TextStyle(
                  color: fbGold,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _progress,
              minHeight: 5,
              backgroundColor: fbBgMain,
              valueColor: AlwaysStoppedAnimation(
                _stage == BuildStage.success
                    ? fbGreen
                    : (_stage == BuildStage.failed || _stage == BuildStage.error)
                        ? fbRed
                        : fbBlue,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO CARD ───────────────────────────────────────────────
  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: fbGold,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [fbGold, Color.lerp(fbGold, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: fbBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: fbGold.withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.precision_manufacturing_rounded,
                  size: 28, color: fbRedDark),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'FLUTTER BUILDER',
                    style: TextStyle(
                      color: fbTextMain,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Upload ZIP → Auto Analyze → Build APK',
                    style: TextStyle(
                      color: fbTextSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: fbBlue.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: fbBlue.withOpacity(0.4), width: 1),
                    ),
                    child: Text(
                      '$GITHUB_OWNER/$GITHUB_REPO',
                      style: TextStyle(
                        color: fbBlue,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PICK ZIP SECTION ────────────────────────────────────────
  Widget _buildPickZipSection() {
    final isDisabled = _stage == BuildStage.uploading ||
        _stage == BuildStage.triggering ||
        _stage == BuildStage.waiting ||
        _stage == BuildStage.running;

    return _bevelBox(
      radius: 18,
      glow: _zipFile == null ? fbGold : fbGreen,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'PILIH FILE ZIP',
              icon: Icons.folder_zip_rounded,
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: isDisabled ? null : _pickZip,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [fbBgSurface, fbBgMain],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _zipFile == null
                        ? fbGold.withOpacity(0.4)
                        : fbGreen.withOpacity(0.5),
                    width: 2,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: _zipFile == null
                              ? [fbGold, Color.lerp(fbGold, Colors.black, 0.4)!]
                              : [fbGreen, Color.lerp(fbGreen, Colors.black, 0.4)!],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: fbBorderDark, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: (_zipFile == null ? fbGold : fbGreen)
                                .withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Icon(
                        _zipFile == null
                            ? Icons.add_rounded
                            : Icons.check_rounded,
                        color: _zipFile == null ? fbRedDark : Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _zipFileName ?? 'Pilih ZIP project Flutter',
                            style: TextStyle(
                              color: fbTextMain,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 0.5,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _zipFile == null
                                ? 'Tap untuk pilih dari file manager'
                                : '${_formatBytes(_zipFileSize)} • ${_zipFile!.path.split("/").last}',
                            style: TextStyle(
                              color: fbTextSub,
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    if (_zipFile != null && !isDisabled)
                      GestureDetector(
                        onTap: _pickZip,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                fbBlue,
                                Color.lerp(fbBlue, Colors.black, 0.4)!
                              ],
                            ),
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: fbBorderDark, width: 1.5),
                          ),
                          child: Icon(Icons.refresh_rounded,
                              color: Colors.white, size: 14),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── ANALYSIS CARD ───────────────────────────────────────────
  Widget _buildAnalysisCard() {
    final a = _analysis!;
    final color = a.isValidFlutterProject ? fbGreen : fbRed;

    return _bevelBox(
      radius: 18,
      glow: color,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border:
                        Border.all(color: color.withOpacity(0.5), width: 1.5),
                  ),
                  child: Icon(
                    a.isValidFlutterProject
                        ? Icons.check_rounded
                        : Icons.close_rounded,
                    color: color,
                    size: 14,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  a.isValidFlutterProject ? 'ZIP VALID' : 'ZIP TIDAK VALID',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildAnalysisRow(
              ok: a.hasPubspec,
              label: 'pubspec.yaml',
              detail: a.pubspecName != null ? 'Project: ${a.pubspecName}' : null,
            ),
            _buildAnalysisRow(
              ok: a.hasMainDart,
              label: 'lib/main.dart',
            ),
            _buildAnalysisRow(
              ok: a.hasAndroid,
              label: 'android/ folder',
              optional: true,
            ),
            _buildAnalysisRow(
              ok: a.hasLib,
              label: 'lib/ folder',
              optional: true,
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: fbBgSurface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: fbGold.withOpacity(0.3), width: 1),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_rounded, color: fbGold, size: 12),
                  const SizedBox(width: 6),
                  Text(
                    '${a.fileCount} files, ${a.dirCount} folders',
                    style: TextStyle(
                      color: fbTextSub,
                      fontSize: 10,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalysisRow({
    required bool ok,
    required String label,
    String? detail,
    bool optional = false,
  }) {
    Color color;
    IconData icon;
    if (ok) {
      color = fbGreen;
      icon = Icons.check_circle_rounded;
    } else if (optional) {
      color = fbYellow;
      icon = Icons.warning_amber_rounded;
    } else {
      color = fbRed;
      icon = Icons.cancel_rounded;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: fbTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                if (detail != null)
                  Text(
                    detail,
                    style: TextStyle(
                      color: fbTextSub,
                      fontSize: 9,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── CONFIG CARD ─────────────────────────────────────────────
  Widget _buildConfigCard() {
    final isDisabled = _stage == BuildStage.uploading ||
        _stage == BuildStage.triggering ||
        _stage == BuildStage.waiting ||
        _stage == BuildStage.running;

    return _bevelBox(
      radius: 18,
      glow: fbGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'KONFIGURASI BUILD',
              icon: Icons.tune_rounded,
            ),
            const SizedBox(height: 12),
            Text(
              'TAG BUILD',
              style: TextStyle(
                color: fbTextSub,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 6),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [fbBgSurface, fbBgMain]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: fbGold.withOpacity(0.5), width: 2),
              ),
              child: TextField(
                controller: _tagController,
                enabled: !isDisabled,
                style: TextStyle(
                  color: fbTextMain,
                  fontSize: 12,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: fbGold,
                decoration: InputDecoration(
                  hintText: 'build-001',
                  hintStyle: TextStyle(
                    color: fbTextSub.withOpacity(0.5),
                    fontSize: 11,
                  ),
                  prefixIcon: Icon(Icons.label_rounded, color: fbGold, size: 16),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'BUILD TYPE',
              style: TextStyle(
                color: fbTextSub,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildToggleChip(
                    label: 'RELEASE',
                    icon: Icons.rocket_launch_rounded,
                    active: _buildType == 'release',
                    onTap: isDisabled
                        ? null
                        : () => setState(() => _buildType = 'release'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildToggleChip(
                    label: 'DEBUG',
                    icon: Icons.bug_report_rounded,
                    active: _buildType == 'debug',
                    onTap: isDisabled
                        ? null
                        : () => setState(() => _buildType = 'debug'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToggleChip({
    required String label,
    required IconData icon,
    required bool active,
    required VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(colors: [fbRed, fbRedDark])
              : LinearGradient(colors: [fbBgSurface, fbBgMain]),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: active ? fbGold : fbGold.withOpacity(0.3),
            width: active ? 2.5 : 1.5,
          ),
          boxShadow: active
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: fbRed.withOpacity(0.5),
                    blurRadius: 10,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: active ? fbGold : fbTextSub, size: 14),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: active ? Colors.white : fbTextSub,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUILD BUTTON ────────────────────────────────────────────
  Widget _buildBuildButton() {
    final canBuild = _stage == BuildStage.ready &&
        _zipFile != null &&
        _analysis != null &&
        _analysis!.isValidFlutterProject;

    return _build3DButton(
      label: _stage == BuildStage.running
          ? 'BUILDING...'
          : _stage == BuildStage.uploading
              ? 'UPLOADING...'
              : _stage == BuildStage.success
                  ? 'BUILD SUKSES ✓'
                  : _stage == BuildStage.failed || _stage == BuildStage.error
                      ? 'BUILD GAGAL'
                      : 'MULAI BUILD',
      icon: _stage == BuildStage.running
          ? Icons.hourglass_top_rounded
          : Icons.precision_manufacturing_rounded,
      onPressed: canBuild ? _startBuild : null,
      color: canBuild ? fbRed : fbGreen,
      loading: _stage == BuildStage.running || _stage == BuildStage.uploading,
    );
  }

  // ─── LOG SECTION ─────────────────────────────────────────────
  Widget _buildLogSection() {
    return _bevelBox(
      radius: 18,
      glow: fbGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [fbGold, Color.lerp(fbGold, Colors.black, 0.4)!],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: fbBorderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(color: fbGold.withOpacity(0.5), blurRadius: 8),
                    ],
                  ),
                  child: Icon(Icons.terminal_rounded,
                      color: fbRedDark, size: 12),
                ),
                const SizedBox(width: 8),
                Text(
                  'LIVE LOG',
                  style: TextStyle(
                    color: fbTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _copyToClipboard(_logs.join('\n')),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: fbBlue.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border:
                          Border.all(color: fbBlue.withOpacity(0.5), width: 1),
                    ),
                    child:
                        Icon(Icons.copy_rounded, color: fbBlue, size: 11),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: _clearLogs,
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: fbRed.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border:
                          Border.all(color: fbRed.withOpacity(0.5), width: 1),
                    ),
                    child: Icon(Icons.delete_outline_rounded,
                        color: fbRed, size: 11),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              height: 280,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: fbGold.withOpacity(0.3), width: 1.5),
              ),
              child: ListView.builder(
                controller: _logScrollController,
                padding: const EdgeInsets.all(10),
                itemCount: _logs.length,
                itemBuilder: (context, i) {
                  final line = _logs[i];
                  Color color = fbTextMain;
                  if (line.contains('✅') || line.contains('🎉')) {
                    color = fbGreen;
                  } else if (line.contains('❌') || line.contains('Error')) {
                    color = fbRed;
                  } else if (line.contains('⚠️') || line.contains('→')) {
                    color = fbYellow;
                  } else if (line.contains('━━━')) {
                    color = fbGold;
                  } else if (line.contains('🚀') || line.contains('📤')) {
                    color = fbBlue;
                  }

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1),
                    child: Text(
                      line,
                      style: TextStyle(
                        color: color,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: line.contains('━━━')
                            ? FontWeight.w900
                            : FontWeight.w500,
                        height: 1.4,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── ARTIFACT CARD ───────────────────────────────────────────
  Widget _buildArtifactCard() {
    return _bevelBox(
      radius: 18,
      glow: fbGreen,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'DOWNLOAD APK',
              icon: Icons.download_rounded,
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [fbBgSurface, fbBgMain]),
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: fbGreen.withOpacity(0.4), width: 1.5),
              ),
              child: Row(
                children: [
                  Icon(Icons.android_rounded, color: fbGreen, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _artifactName ?? '-',
                          style: TextStyle(
                            color: fbTextMain,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _formatBytes(_artifactSize),
                          style: TextStyle(
                            color: fbTextSub,
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            if (_downloadProgress > 0 && _downloadProgress < 1) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _downloadProgress,
                  minHeight: 6,
                  backgroundColor: fbBgMain,
                  valueColor: AlwaysStoppedAnimation(fbGreen),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Mengunduh... ${(_downloadProgress * 100).toStringAsFixed(0)}%',
                style: TextStyle(
                  color: fbGreen,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 10),
            ],
            Row(
              children: [
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.download_rounded,
                    label: 'DOWNLOAD APK',
                    color: fbGreen,
                    onTap: _downloadArtifact,
                  ),
                ),
                if (_savedApkPath != null) ...[
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildSmallBtn(
                      icon: Icons.share_rounded,
                      label: 'SHARE',
                      color: fbPurple,
                      onTap: _shareArtifact,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── HISTORY SECTION ─────────────────────────────────────────
  Widget _buildHistorySection() {
    return _bevelBox(
      radius: 18,
      glow: fbGold,
      glowOpacity: 0.25,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'HISTORY BUILD (${_history.length})',
              icon: Icons.history_rounded,
            ),
            const SizedBox(height: 10),
            if (_history.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Center(
                  child: Text(
                    'Belum ada riwayat build',
                    style: TextStyle(
                      color: fbTextSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              )
            else
              ..._history.map((item) => _buildHistoryItem(item)),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryItem(BuildHistoryItem item) {
    final isSuccess = item.status == 'success';
    final color = isSuccess ? fbGreen : fbRed;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [fbBgSurface, fbBgMain]),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.3), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.4), width: 1),
            ),
            child: Icon(
              isSuccess ? Icons.check_rounded : Icons.error_rounded,
              color: color,
              size: 12,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.tag,
                  style: TextStyle(
                    color: fbTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  '${item.buildType} • ${_formatTime(item.createdAt)}',
                  style: TextStyle(
                    color: fbTextSub,
                    fontSize: 9,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          if (item.runUrl != null)
            GestureDetector(
              onTap: () async {
                try {
                  final uri = Uri.parse(item.runUrl!);
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                } catch (_) {}
              },
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [fbBlue, Color.lerp(fbBlue, Colors.black, 0.4)!],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: fbBorderDark, width: 1.5),
                ),
                child: Icon(Icons.open_in_new_rounded,
                    color: Colors.white, size: 11),
              ),
            ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes}m lalu';
    if (diff.inDays < 1) return '${diff.inHours}j lalu';
    return '${diff.inDays}h lalu';
  }
}

// ═══════════════════════════════════════════════════════════════════
// ─── MODELS ───────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
enum BuildStage {
  idle,
  analyzing,
  ready,
  uploading,
  triggering,
  waiting,
  running,
  success,
  failed,
  error,
}

class ZipAnalysis {
  final bool hasPubspec;
  final bool hasMainDart;
  final bool hasAndroid;
  final bool hasLib;
  final String? pubspecName;
  final String? pubspecVersion;
  final int fileCount;
  final int dirCount;
  final bool isValidFlutterProject;

  ZipAnalysis({
    required this.hasPubspec,
    required this.hasMainDart,
    required this.hasAndroid,
    required this.hasLib,
    this.pubspecName,
    this.pubspecVersion,
    required this.fileCount,
    required this.dirCount,
    required this.isValidFlutterProject,
  });
}

class BuildHistoryItem {
  final String tag;
  final String buildType;
  final String status;
  final DateTime createdAt;
  final String? runUrl;
  final String? artifactName;
  final int? artifactId;
  final int? artifactSize;
  final String? errorMessage;

  BuildHistoryItem({
    required this.tag,
    required this.buildType,
    required this.status,
    required this.createdAt,
    this.runUrl,
    this.artifactName,
    this.artifactId,
    this.artifactSize,
    this.errorMessage,
  });

  Map<String, dynamic> toJson() => {
        'tag': tag,
        'buildType': buildType,
        'status': status,
        'createdAt': createdAt.toIso8601String(),
        'runUrl': runUrl,
        'artifactName': artifactName,
        'artifactId': artifactId,
        'artifactSize': artifactSize,
        'errorMessage': errorMessage,
      };

  factory BuildHistoryItem.fromJson(Map<String, dynamic> json) =>
      BuildHistoryItem(
        tag: json['tag'] ?? '',
        buildType: json['buildType'] ?? 'release',
        status: json['status'] ?? 'unknown',
        createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
        runUrl: json['runUrl'],
        artifactName: json['artifactName'],
        artifactId: json['artifactId'],
        artifactSize: json['artifactSize'],
        errorMessage: json['errorMessage'],
      );
}