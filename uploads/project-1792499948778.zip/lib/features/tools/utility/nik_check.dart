// lib/features/tools/utility/nik_check.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color nkBgMain = const Color(0xFF160A07);
Color nkBgSurface = const Color(0xFF2A140E);
Color nkBgCard = const Color(0xFF3A1E15);
Color nkTextMain = const Color(0xFFF3E6DD);
Color nkTextSub = const Color(0xFFC9913F);
Color nkGold = const Color(0xFFD4A853);
Color nkRed = const Color(0xFFB71C1C);
Color nkRedDark = const Color(0xFF7F0000);
Color nkRedDeep = const Color(0xFF4A0000);
Color nkGreen = const Color(0xFF4CAF50);
Color nkBlue = const Color(0xFF2196F3);
Color nkBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  nkBgMain     = theme.brownDark;
  nkBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  nkBgCard     = theme.brownMid;
  nkTextMain   = theme.bgCreamLight;
  nkTextSub    = theme.gold;
  nkGold       = theme.gold;
  nkRed        = theme.redMain;
  nkRedDark    = theme.redDark;
  nkRedDeep    = theme.redDeep;
  nkGreen      = theme.accentGreen;
  nkBlue       = theme.accentBlue;
  nkBorderDark = theme.borderDark;
}

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  final XThemeController _themeController = XThemeController();

  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnimation =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _nikController.dispose();
    _animController.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      setState(() {
        _errorMessage = "NIK tidak boleh kosong.";
        _data = null;
      });
      return;
    }

    if (!RegExp(r'^\d{16}$').hasMatch(nik)) {
      setState(() {
        _errorMessage = "NIK harus 16 digit angka.";
        _data = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    try {
      final response = await http
          .get(Uri.parse('$apiBaseUrl/api/nik/check?nik=$nik'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() {
            _data = json['data'];
            _errorMessage = null;
          });
          _animController.forward(from: 0);
        } else {
          setState(() {
            _errorMessage = json['message'] ?? "Data tidak ditemukan.";
          });
        }
      } else {
        setState(() => _errorMessage = "Gagal mengambil data dari server.");
      }
    } catch (e) {
      setState(() => _errorMessage = "Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '📋 $label disalin!',
          style: TextStyle(
            color: nkTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: nkGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: nkBorderDark, width: 2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          nkTextMain.withOpacity(0.20),
          nkRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? nkGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [nkBgCard, nkBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: nkBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(nkBgMain, nkRed, 0.25)!,
                  nkBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          if (_data != null) ...[
                            const SizedBox(height: 16),
                            _buildResults(),
                          ],
                          if (_data == null &&
                              !_isLoading &&
                              _errorMessage == null)
                            _buildPlaceholder(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [nkBgSurface, nkBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: nkGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: nkGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nkRed, nkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: nkBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nkRed, nkRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: nkBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: nkGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.badge_rounded, color: nkGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'NIK CHECKER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: nkGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [nkGold, Color.lerp(nkGold, Colors.black, 0.4)!],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: nkBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.credit_card_rounded,
                      color: nkRedDark, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MASUKKAN NIK',
                  style: TextStyle(
                    color: nkTextMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nkBgSurface, nkBgMain],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: nkGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: nkGold.withOpacity(0.3), blurRadius: 12),
                ],
              ),
              child: TextField(
                controller: _nikController,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                ],
                style: TextStyle(
                  color: nkTextMain,
                  fontSize: 15,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
                cursorColor: nkGold,
                decoration: InputDecoration(
                  hintText: '16 digit NIK...',
                  hintStyle: TextStyle(
                    color: nkTextSub.withOpacity(0.5),
                    fontSize: 13,
                    letterSpacing: 1,
                  ),
                  prefixIcon: Icon(Icons.tag, color: nkGold, size: 18),
                  suffixIcon: _nikController.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: nkTextSub, size: 18),
                          onPressed: () {
                            _nikController.clear();
                            setState(() {});
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                ),
                onChanged: (_) => setState(() {}),
                onSubmitted: (_) => _checkNik(),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [nkRed, Color.lerp(nkRed, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: nkRed.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isLoading ? null : _checkNik,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: nkBorderDark, width: 2.5),
                  ),
                ),
                child: _isLoading
                    ? const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: Colors.white,
                          ),
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.search_rounded,
                              color: Colors.white, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'CEK DATA NIK',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: nkRed,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: nkGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: nkGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: nkTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULTS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResults() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        children: [
          _buildCategoryCard(
            title: "IDENTITAS DIRI",
            icon: Icons.person_rounded,
            children: [
              _buildInfoRow(
                label: "NIK",
                value: _data!["nik"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["nik"]?.toString() ?? "", "NIK"),
              ),
              _buildInfoRow(
                label: "Nama Lengkap",
                value: _data!["data"]?["nama"]?.toString() ?? '',
                note: 'Data nama tidak tersedia public',
              ),
              _buildInfoRow(
                label: "Jenis Kelamin",
                value: _data!["data"]?["kelamin"]?.toString(),
              ),
              _buildInfoRow(
                label: "Tempat Lahir",
                value: _data!["data"]?["tempat_lahir"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["data"]?["tempat_lahir"]?.toString() ?? "",
                    "Tempat Lahir"),
              ),
              _buildInfoRow(
                label: "Tanggal Lahir",
                value: _data!["data"]?["tanggal_lahir"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["data"]?["tanggal_lahir"]?.toString() ?? "",
                    "Tanggal Lahir"),
              ),
              _buildInfoRow(
                label: "Usia",
                value: _data!["data"]?["usia"]?.toString(),
              ),
            ],
          ),
          _buildCategoryCard(
            title: "DATA DOMISILI",
            icon: Icons.location_on_rounded,
            children: [
              _buildInfoRow(
                label: "Provinsi",
                value: _data!["data"]?["provinsi"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["data"]?["provinsi"]?.toString() ?? "",
                    "Provinsi"),
              ),
              _buildInfoRow(
                label: "Kabupaten/Kota",
                value: _data!["data"]?["kabupaten"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["data"]?["kabupaten"]?.toString() ?? "",
                    "Kabupaten"),
              ),
              _buildInfoRow(
                label: "Kecamatan",
                value: _data!["data"]?["kecamatan"]?.toString(),
                onCopy: () => _copyToClipboard(
                    _data!["data"]?["kecamatan"]?.toString() ?? "",
                    "Kecamatan"),
              ),
              _buildInfoRow(
                label: "Kelurahan/Desa",
                value: _data!["data"]?["kelurahan"]?.toString() ?? '',
                note: 'Data Dukcapil — tidak tersedia',
              ),
            ],
          ),
          _buildCategoryCard(
            title: "INFORMASI TAMBAHAN",
            icon: Icons.auto_awesome_rounded,
            children: [
              _buildInfoRow(
                label: "Zodiak",
                value: _data!["data"]?["zodiak"]?.toString(),
              ),
              _buildInfoRow(
                label: "Pasaran",
                value: _data!["data"]?["pasaran"]?.toString(),
              ),
              _buildInfoRow(
                label: "Ultah Mendatang",
                value: _data!["data"]?["ultah_mendatang"]?.toString(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    // Filter out widget yang kosong
    final validChildren =
        children.where((w) => w is! SizedBox).toList();

    return _bevelBox(
      radius: 18,
      glow: nkGold,
      glowOpacity: 0.25,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [nkRed, nkRedDark],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(17),
                  topRight: Radius.circular(17),
                ),
                border: Border(
                  bottom: BorderSide(color: nkGold, width: 2),
                ),
                boxShadow: [
                  BoxShadow(
                    color: nkGold.withOpacity(0.3),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(color: nkGold, width: 1.5),
                    ),
                    child: Icon(icon, color: nkGold, size: 14),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Content
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(children: validChildren),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow({
    required String label,
    String? value,
    String? note,
    VoidCallback? onCopy,
  }) {
    final isEmpty = value == null || value.isEmpty;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            nkBgSurface,
            nkBgMain,
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: nkGold.withOpacity(0.3), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: nkTextSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  isEmpty ? (note ?? '—') : value,
                  style: TextStyle(
                    color: isEmpty
                        ? nkTextSub.withOpacity(0.5)
                        : nkTextMain,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                    fontStyle: isEmpty && note != null
                        ? FontStyle.italic
                        : FontStyle.normal,
                  ),
                ),
              ],
            ),
          ),
          if (onCopy != null && !isEmpty)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [nkGold, Color.lerp(nkGold, Colors.black, 0.4)!],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: nkBorderDark, width: 1.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(Icons.copy_rounded,
                    color: nkRedDark, size: 12),
              ),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PLACEHOLDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPlaceholder() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          _bevelBox(
            radius: 100,
            glow: nkGold,
            glowOpacity: 0.4,
            child: Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                Icons.badge_rounded,
                size: 56,
                color: nkGold,
                shadows: [
                  Shadow(
                    color: nkGold.withOpacity(0.7),
                    blurRadius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'NIK Checker',
            style: TextStyle(
              color: nkTextMain,
              fontSize: 20,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: nkGold.withOpacity(0.6),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Masukkan NIK 16 digit untuk cek informasi identitas & domisili',
              style: TextStyle(
                color: nkTextSub,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _buildFeatureChip(Icons.person, 'Identitas'),
              _buildFeatureChip(Icons.location_on, 'Domisili'),
              _buildFeatureChip(Icons.calendar_today, 'Usia'),
              _buildFeatureChip(Icons.auto_awesome, 'Zodiak'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [nkBgCard, nkBgMain]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: nkGold.withOpacity(0.4), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: nkGold, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: nkTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}