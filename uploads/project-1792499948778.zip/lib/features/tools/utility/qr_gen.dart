// lib/features/tools/utility/qr_gen.dart
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color qrBgMain = const Color(0xFF160A07);
Color qrBgSurface = const Color(0xFF2A140E);
Color qrBgCard = const Color(0xFF3A1E15);
Color qrTextMain = const Color(0xFFF3E6DD);
Color qrTextSub = const Color(0xFFC9913F);
Color qrAccent = const Color(0xFFE0763F);
Color qrAccentDeep = const Color(0xFF9C3B22);
Color qrRed = const Color(0xFFB71C1C);
Color qrRedDark = const Color(0xFF7F0000);
Color qrRedDeep = const Color(0xFF4A0000);
Color qrGold = const Color(0xFFD4A853);
Color qrGreen = const Color(0xFF4CAF50);
Color qrBlue = const Color(0xFF2196F3);
Color qrBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  qrBgMain     = theme.brownDark;
  qrBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  qrBgCard     = theme.brownMid;
  qrTextMain   = theme.bgCreamLight;
  qrTextSub    = theme.gold;
  qrAccent     = theme.gold;
  qrAccentDeep = theme.goldDark;
  qrRed        = theme.redMain;
  qrRedDark    = theme.redDark;
  qrRedDeep    = theme.redDeep;
  qrGold       = theme.gold;
  qrGreen      = theme.accentGreen;
  qrBlue       = theme.accentBlue;
  qrBorderDark = theme.borderDark;
}

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  bool _isSaving = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // GENERATE QR
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _errorMessage = "Text tidak boleh kosong.";
        _qrImage = null;
      });
      return;
    }

    if (text.length > 2000) {
      setState(() {
        _errorMessage = "Text terlalu panjang (max 2000 karakter).";
        _qrImage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse('$apiBaseUrl/api/qr/generate'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'text': text,
              'size': 512,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        setState(() {
          _qrImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        String msg = "Gagal generate QR Code.";
        try {
          final err = jsonDecode(response.body);
          msg = err['message'] ?? msg;
        } catch (_) {}
        setState(() => _errorMessage = msg);
      }
    } catch (e) {
      setState(() => _errorMessage = "Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SAVE QR TO STORAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _saveQR() async {
    if (_qrImage == null) return;

    setState(() => _isSaving = true);

    try {
      Directory? directory;
      if (Platform.isAndroid) {
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        directory = await getApplicationDocumentsDirectory();
      }

      final fileName = 'qr_code_${DateTime.now().millisecondsSinceEpoch}.png';
      final file = File('${directory!.path}/$fileName');
      await file.writeAsBytes(_qrImage!);

      _showSnack("✅ Disimpan di: ${file.path}", isError: false);
    } catch (e) {
      _showSnack("❌ Gagal menyimpan: $e", isError: true);
    } finally {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) setState(() => _isSaving = false);
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SHARE QR
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _shareQR() async {
    if (_qrImage == null) return;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/qr_code_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_qrImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'QR Code dari: ${_textController.text}',
      );
    } catch (e) {
      _showSnack("❌ Error sharing: $e", isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // COPY TEXT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _copyText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    _showSnack("📋 Text disalin!", isError: false);
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: qrTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? qrRed : qrGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: qrBorderDark, width: 2),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          qrTextMain.withOpacity(0.20),
          qrRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? qrGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [qrBgCard, qrBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          colors: [
            color,
            Color.lerp(color, Colors.black, 0.5)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: color.withOpacity(0.5),
            blurRadius: 16,
            spreadRadius: -3,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: qrBorderDark, width: 2.5),
          ),
        ),
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 18, color: Colors.white),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: qrBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(qrBgMain, qrRed, 0.25)!,
                  qrBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          if (_qrImage != null) ...[
                            const SizedBox(height: 16),
                            _buildResultCard(),
                          ],
                          if (_qrImage == null &&
                              !_isLoading &&
                              _errorMessage == null)
                            _buildPlaceholder(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [qrBgSurface, qrBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: qrGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(
            color: qrGold.withOpacity(0.25),
            blurRadius: 18,
          ),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [qrRed, qrRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: qrBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [qrRed, qrRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: qrBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: qrGold.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.qr_code_rounded, color: qrGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'QR GENERATOR',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: qrGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [qrGold, qrAccentDeep],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: qrBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.text_fields_rounded,
                      color: qrRedDark, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MASUKKAN TEXT / URL',
                  style: TextStyle(
                    color: qrTextMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [qrBgSurface, qrBgMain],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: qrGold, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: qrGold.withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: TextField(
                controller: _textController,
                style: TextStyle(
                  color: qrTextMain,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: qrGold,
                maxLines: 3,
                minLines: 2,
                decoration: InputDecoration(
                  hintText: 'https://google.com atau text apapun...',
                  hintStyle: TextStyle(
                    color: qrTextSub.withOpacity(0.5),
                    fontSize: 13,
                  ),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.only(bottom: 30),
                    child: Icon(Icons.link, color: qrGold, size: 18),
                  ),
                  suffixIcon: _textController.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.copy_rounded,
                              color: qrTextSub, size: 18),
                          onPressed: _copyText,
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                ),
                onChanged: (_) => setState(() {}),
                onSubmitted: (_) => _generateQR(),
              ),
            ),
            const SizedBox(height: 14),
            _build3DButton(
              label: _isLoading ? 'GENERATING...' : 'GENERATE QR',
              icon: _isLoading
                  ? Icons.hourglass_top_rounded
                  : Icons.qr_code_2_rounded,
              onPressed: _isLoading ? null : _generateQR,
              color: qrRed,
              loading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: qrRed,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: qrGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: qrGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: qrTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULT CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResultCard() {
    return Column(
      children: [
        // QR Preview
        _bevelBox(
          radius: 20,
          glow: qrGold,
          glowOpacity: 0.4,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [qrRed, qrRedDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: qrBorderDark, width: 2),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.qr_code_rounded,
                              color: qrGold, size: 14),
                          const SizedBox(width: 6),
                          const Text(
                            "QR CODE READY",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // QR Image
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: qrGold, width: 3),
                    boxShadow: [
                      const BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(4, 4),
                      ),
                      BoxShadow(
                        color: qrGold.withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: -4,
                      ),
                    ],
                  ),
                  child: Image.memory(
                    _qrImage!,
                    width: 260,
                    height: 260,
                    fit: BoxFit.contain,
                  ),
                ),

                const SizedBox(height: 16),

                // Info text
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: qrGreen.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border:
                        Border.all(color: qrGreen.withOpacity(0.5), width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.check_circle_rounded,
                          color: qrGreen, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'QR Code berhasil digenerate!',
                          style: TextStyle(
                            color: qrGreen,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 14),

        // Action buttons
        Row(
          children: [
            Expanded(
              child: _build3DButton(
                label: 'SIMPAN',
                icon: Icons.save_alt_rounded,
                onPressed: _isSaving ? null : _saveQR,
                color: qrGreen,
                loading: _isSaving,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _build3DButton(
                label: 'SHARE',
                icon: Icons.share_rounded,
                onPressed: _shareQR,
                color: qrBlue,
              ),
            ),
          ],
        ),

        const SizedBox(height: 10),

        // Regenerate + Reset
        Row(
          children: [
            Expanded(
              child: _build3DButton(
                label: 'REGENERATE',
                icon: Icons.refresh_rounded,
                onPressed: _generateQR,
                color: qrRed,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _build3DButton(
                label: 'CLEAR',
                icon: Icons.delete_outline_rounded,
                onPressed: () {
                  setState(() {
                    _qrImage = null;
                    _errorMessage = null;
                    _textController.clear();
                  });
                },
                color: qrRedDeep,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PLACEHOLDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPlaceholder() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          _bevelBox(
            radius: 100,
            glow: qrGold,
            glowOpacity: 0.4,
            child: Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                Icons.qr_code_scanner_rounded,
                size: 56,
                color: qrGold,
                shadows: [
                  Shadow(
                    color: qrGold.withOpacity(0.7),
                    blurRadius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'QR Code Generator',
            style: TextStyle(
              color: qrTextMain,
              fontSize: 20,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: qrGold.withOpacity(0.6),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Masukkan text atau URL untuk membuat QR Code',
              style: TextStyle(
                color: qrTextSub,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _buildFeatureChip(Icons.link, 'URL'),
              _buildFeatureChip(Icons.text_fields, 'Text'),
              _buildFeatureChip(Icons.wifi, 'WiFi'),
              _buildFeatureChip(Icons.person, 'Contact'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [qrBgCard, qrBgMain],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: qrGold.withOpacity(0.4), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: qrGold, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: qrTextSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}