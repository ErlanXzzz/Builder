// lib/features/tools/utility/obfuscator_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// ─── XTHEME-DRIVEN COLORS ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
Color obBgMain = const Color(0xFF160A07);
Color obBgSurface = const Color(0xFF2A140E);
Color obBgCard = const Color(0xFF3A1E15);
Color obTextMain = const Color(0xFFF3E6DD);
Color obTextSub = const Color(0xFFC9913F);
Color obGold = const Color(0xFFD4A853);
Color obRed = const Color(0xFFB71C1C);
Color obRedDark = const Color(0xFF7F0000);
Color obGreen = const Color(0xFF4CAF50);
Color obBlue = const Color(0xFF2196F3);
Color obPurple = const Color(0xFFAB47BC);
Color obYellow = const Color(0xFFFFC107);
Color obBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  obBgMain     = theme.brownDark;
  obBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  obBgCard     = theme.brownMid;
  obTextMain   = theme.bgCreamLight;
  obTextSub    = theme.gold;
  obGold       = theme.gold;
  obRed        = theme.redMain;
  obRedDark    = theme.redDark;
  obGreen      = theme.accentGreen;
  obBlue       = theme.accentBlue;
  obPurple     = theme.accentBlue;
  obYellow     = theme.accentYellow;
  obBorderDark = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// ─── HELPERS: BASE64 / BASE62 (NEW) ───────────────────────────────
// ═══════════════════════════════════════════════════════════════════

const String _base62Alphabet =
    '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

/// Base62 encode dari bytes (bigint style).
String base62Encode(List<int> bytes) {
  if (bytes.isEmpty) return '';
  BigInt num = BigInt.zero;
  for (final b in bytes) {
    num = (num << 8) | BigInt.from(b);
  }
  final base = BigInt.from(62);
  final buf = <String>[];
  while (num > BigInt.zero) {
    final rem = (num % base).toInt();
    buf.add(_base62Alphabet[rem]);
    num = num ~/ base;
  }
  return buf.reversed.join();
}

/// Base62 decode ke bytes.
List<int> base62Decode(String input) {
  if (input.isEmpty) return <int>[];
  BigInt num = BigInt.zero;
  final base = BigInt.from(62);
  for (int i = 0; i < input.length; i++) {
    final idx = _base62Alphabet.indexOf(input[i]);
    if (idx < 0) {
      throw 'Karakter base62 tidak valid: "${input[i]}"';
    }
    num = num * base + BigInt.from(idx);
  }
  final bytes = <int>[];
  final mask = BigInt.from(0xFF);
  while (num > BigInt.zero) {
    bytes.add((num & mask).toInt());
    num = num >> 8;
  }
  return bytes.reversed.toList();
}

/// Plain base64 encode (tanpa wrapper).
String plainBase64Encode(String text) => base64Encode(utf8.encode(text));

/// Plain base64 decode.
String plainBase64Decode(String b64) {
  final cleaned = b64.replaceAll(RegExp(r'\s'), '');
  return utf8.decode(base64Decode(cleaned));
}

/// Plain base62 encode dari String (UTF-8).
String plainBase62Encode(String text) => base62Encode(utf8.encode(text));

/// Plain base62 decode ke String.
String plainBase62Decode(String encoded) {
  final cleaned = encoded.replaceAll(RegExp(r'\s'), '');
  return utf8.decode(base62Decode(cleaned));
}

/// Cek apakah hasil decode mayoritas printable (untuk heuristik auto-detect).
bool _isMostlyPrintable(String s) {
  if (s.isEmpty) return false;
  int printable = 0;
  for (final r in s.runes) {
    if (r == 9 || r == 10 || r == 13 || (r >= 32 && r < 127) || r > 0x7F) {
      printable++;
    }
  }
  return printable / s.runes.length > 0.85;
}

// ═══════════════════════════════════════════════════════════════════
// ─── HELPERS: OBFUSCATE ───────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════

/// JS: Escape semua karakter jadi `\xNN`.
String jsHexEscape(String code) {
  final buf = StringBuffer();
  for (int i = 0; i < code.length; i++) {
    final c = code.codeUnitAt(i);
    if (c == 10) {
      buf.write('\\n');
    } else if (c == 13) {
      buf.write('\\r');
    } else if (c == 9) {
      buf.write('\\t');
    } else {
      buf.write('\\x${c.toRadixString(16).padLeft(2, '0')}');
    }
  }
  return buf.toString();
}

/// JS: Escape semua karakter jadi `\uNNNN`.
String jsUnicodeEscape(String code) {
  final buf = StringBuffer();
  for (int i = 0; i < code.length; i++) {
    final c = code.codeUnitAt(i);
    buf.write('\\u${c.toRadixString(16).padLeft(4, '0')}');
  }
  return buf.toString();
}

/// JS: Base64 + eval wrapper.
String jsBase64Eval(String code) {
  final b64 = base64Encode(utf8.encode(code));
  return 'eval(atob("$b64"));';
}

/// JS: Base62 + decode eval wrapper (custom decoder inline).
String jsBase62Eval(String code) {
  final b62 = base62Encode(utf8.encode(code));
  return 'eval((function(){'
      'var A="$_base62Alphabet",s="$b62",n=0n,B=62n;'
      'for(var i=0;i<s.length;i++)n=n*B+BigInt(A.indexOf(s[i]));'
      'var b=[],m=255n;while(n>0n){b.unshift(Number(n&m));n>>=8n;}'
      'return new TextDecoder().decode(new Uint8Array(b));'
      '})());';
}

/// JS: Char code + eval wrapper.
String jsCharCodeEval(String code) {
  final codes = <String>[];
  for (int i = 0; i < code.length; i++) {
    codes.add(code.codeUnitAt(i).toString());
  }
  return 'eval(String.fromCharCode(${codes.join(',')}));';
}

/// JS: String array + hex variable rename (light obfuscation).
String jsStringArray(String code) {
  final stringRe = RegExp(r'''(['"])((?:\\.|(?!\1).)*)\1''');
  final strings = <String>[];
  final seen = <String, int>{};

  final modified = code.replaceAllMapped(stringRe, (m) {
    final content = m.group(2)!;
    final key = m.group(1)! + content;
    if (seen.containsKey(key)) {
      return '_S[${seen[key]}]';
    }
    final idx = strings.length;
    strings.add(content);
    seen[key] = idx;
    return '_S[$idx]';
  });

  final renamed = modified.replaceAllMapped(
    RegExp(r'\b(var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]{2,})\b'),
    (m) => '${m.group(1)} _0x${_hexHash(m.group(2)!)}',
  );

  final arrayDecl = '_S=${strings.map((s) => jsonEncode(s)).toList()};';
  return arrayDecl + renamed;
}

String _hexHash(String s) {
  int hash = 0;
  for (int i = 0; i < s.length; i++) {
    hash = ((hash * 31) + s.codeUnitAt(i)) & 0xFFFFFF;
  }
  return hash.toRadixString(16).padLeft(6, '0').substring(0, 6);
}

/// JS: Minify.
String jsMinify(String code) {
  var result = code;
  result = result.replaceAll(RegExp(r'//[^\n]*'), '');
  result = result.replaceAll(RegExp(r'/\*[\s\S]*?\*/'), '');
  result = result.replaceAll(RegExp(r'\s+'), ' ');
  result = result.replaceAll(
      RegExp(r'\s*([{}\(\)\[\];,:+\-*/%=<>!&|^~?])\s*'), r'$1');
  return result.trim();
}

/// HTML: Encode numeric entities.
String htmlEntitiesDecimal(String html) {
  final buf = StringBuffer();
  for (int i = 0; i < html.length; i++) {
    buf.write('&#${html.codeUnitAt(i)};');
  }
  return buf.toString();
}

/// HTML: Encode hex entities.
String htmlEntitiesHex(String html) {
  final buf = StringBuffer();
  for (int i = 0; i < html.length; i++) {
    buf.write('&#x${html.codeUnitAt(i).toRadixString(16)};');
  }
  return buf.toString();
}

/// HTML: Base64 + document.write.
String htmlBase64DocWrite(String html) {
  final b64 = base64Encode(utf8.encode(html));
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>'
      '<script>document.write(atob("$b64"));</script>'
      '</body></html>';
}

/// HTML: Base62 + document.write.
String htmlBase62DocWrite(String html) {
  final b62 = base62Encode(utf8.encode(html));
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>'
      '<script>(function(){'
      'var A="$_base62Alphabet",s="$b62",n=0n,B=62n;'
      'for(var i=0;i<s.length;i++)n=n*B+BigInt(A.indexOf(s[i]));'
      'var b=[],m=255n;while(n>0n){b.unshift(Number(n&m));n>>=8n;}'
      'document.write(new TextDecoder().decode(new Uint8Array(b)));'
      '})();</script></body></html>';
}

/// HTML: Char code + document.write.
String htmlCharCodeDocWrite(String html) {
  final codes = <String>[];
  for (int i = 0; i < html.length; i++) {
    codes.add(html.codeUnitAt(i).toString());
  }
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>'
      '<script>document.write(String.fromCharCode(${codes.join(',')}));</script>'
      '</body></html>';
}

/// HTML: URL encode.
String htmlUrlEncode(String html) {
  return Uri.encodeFull(html).replaceAll('%20', ' ');
}

// ═══════════════════════════════════════════════════════════════════
// ─── HELPERS: DEOBFUSCATE ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════

String beautifyJs(String code) {
  final buf = StringBuffer();
  int indent = 0;
  const indentStr = '  ';
  bool inString = false;
  String? stringChar;
  bool inLineComment = false;
  bool inBlockComment = false;

  void writeIndent() {
    for (int i = 0; i < indent; i++) {
      buf.write(indentStr);
    }
  }

  for (int i = 0; i < code.length; i++) {
    final c = code[i];
    final next = i + 1 < code.length ? code[i + 1] : '';

    if (inString) {
      buf.write(c);
      if (c == '\\' && i + 1 < code.length) {
        buf.write(next);
        i++;
      } else if (c == stringChar) {
        inString = false;
        stringChar = null;
      }
      continue;
    }

    if (inLineComment) {
      if (c == '\n') {
        inLineComment = false;
        buf.writeln();
        writeIndent();
      } else {
        buf.write(c);
      }
      continue;
    }

    if (inBlockComment) {
      if (c == '*' && next == '/') {
        buf.write('*/');
        i++;
        inBlockComment = false;
      } else {
        buf.write(c);
      }
      continue;
    }

    if (c == '"' || c == "'" || c == '`') {
      inString = true;
      stringChar = c;
      buf.write(c);
      continue;
    }

    if (c == '/' && next == '/') {
      inLineComment = true;
      buf.write('//');
      i++;
      continue;
    }
    if (c == '/' && next == '*') {
      inBlockComment = true;
      buf.write('/*');
      i++;
      continue;
    }

    if (c == '{') {
      buf.writeln(' {');
      indent++;
      writeIndent();
    } else if (c == '}') {
      indent = math.max(0, indent - 1);
      buf.writeln();
      writeIndent();
      buf.write('}');
      if (next != ';' && next != ',' && next != ')' && next != '}') {
        buf.writeln();
        writeIndent();
      }
    } else if (c == ';') {
      buf.write(';');
      if (next != '}') {
        buf.writeln();
        writeIndent();
      }
    } else if (c == '\n') {
      continue;
    } else {
      buf.write(c);
    }
  }

  var result = buf.toString();
  result = result.replaceAll(RegExp(r'\n{3,}'), '\n\n');
  result = result.replaceAll(RegExp(r'[ \t]+\n'), '\n');
  return result.trim();
}

String beautifyHtml(String code) {
  var result = code;
  result = result.replaceAllMapped(
    RegExp(r'(</[a-zA-Z0-9]+>)'),
    (m) => '${m.group(1)}\n',
  );
  result = result.replaceAllMapped(
    RegExp(r'(<(?!\/?(?:span|a|b|i|em|strong|br|img|input)\b)[a-zA-Z0-9]+)'),
    (m) => '\n${m.group(1)}',
  );
  result = result.replaceAll(RegExp(r'\n{3,}'), '\n\n');
  return result.trim();
}

String jsUnescape(String code) {
  var result = code;
  result = result.replaceAllMapped(
    RegExp(r'\\u([0-9a-fA-F]{4})'),
    (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)),
  );
  result = result.replaceAllMapped(
    RegExp(r'\\x([0-9a-fA-F]{2})'),
    (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)),
  );
  return result;
}

String htmlEntityDecode(String code) {
  var result = code;
  result = result.replaceAllMapped(
    RegExp(r'&#x([0-9a-fA-F]+);'),
    (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)),
  );
  result = result.replaceAllMapped(
    RegExp(r'&#(\d+);'),
    (m) => String.fromCharCode(int.parse(m.group(1)!)),
  );
  const named = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&apos;': "'",
    '&nbsp;': ' ',
  };
  named.forEach((k, v) {
    result = result.replaceAll(k, v);
  });
  return result;
}

/// Extract base64 dari `eval(atob("..."))`.
String? extractBase64Eval(String code) {
  final re = RegExp(
      r'''eval\s*\(\s*(?:window\.)?atob\s*\(\s*["']([A-Za-z0-9+/=\s]+)["']\s*\)\s*\)''');
  final m = re.firstMatch(code);
  if (m == null) return null;
  return m.group(1)!.replaceAll(RegExp(r'\s'), '');
}

/// Extract base62 dari wrapper `var A="...62",s="..."`.
String? extractBase62Wrapper(String code) {
  final re = RegExp(r'''["']([0-9A-Za-z]{4,})["']\s*,\s*n\s*=\s*0n''');
  final m = re.firstMatch(code);
  if (m == null) return null;
  // Deteksi keberadaan decoder base62
  if (!code.contains('B=62n') && !code.contains('B = 62n')) return null;
  return m.group(1);
}

/// Extract char code dari wrapper `String.fromCharCode(...)`.
String? extractCharCode(String code) {
  final re = RegExp(
      r'''(?:eval|document\.write)\s*\(\s*String\.fromCharCode\s*\(([\d,\s]+)\)\s*\)''');
  final m = re.firstMatch(code);
  if (m == null) return null;

  final codes = m
      .group(1)!
      .split(',')
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .map((e) => int.tryParse(e) ?? 0)
      .toList();

  final buf = StringBuffer();
  for (final c in codes) {
    buf.writeCharCode(c);
  }
  return buf.toString();
}

class DeobfuscateResult {
  final String output;
  final String method;
  final bool success;
  DeobfuscateResult({
    required this.output,
    required this.method,
    required this.success,
  });
}

DeobfuscateResult autoDeobfuscate(String input) {
  final trimmed = input.trim();
  if (trimmed.isEmpty) {
    return DeobfuscateResult(output: '', method: 'Kosong', success: false);
  }

  // 1. Base64 + eval(atob)
  final b64 = extractBase64Eval(trimmed);
  if (b64 != null) {
    try {
      final decoded = utf8.decode(base64Decode(b64));
      return DeobfuscateResult(
        output: beautifyJs(decoded),
        method: 'Base64 + eval(atob)',
        success: true,
      );
    } catch (_) {}
  }

  // 2. Base62 wrapper
  final b62 = extractBase62Wrapper(trimmed);
  if (b62 != null) {
    try {
      final decoded = utf8.decode(base62Decode(b62));
      final looksHtml = decoded.contains('<html') ||
          decoded.contains('<!DOCTYPE') ||
          decoded.contains('<body');
      return DeobfuscateResult(
        output: looksHtml ? beautifyHtml(decoded) : beautifyJs(decoded),
        method: 'Base62 wrapper',
        success: true,
      );
    } catch (_) {}
  }

  // 3. Char code
  final charCode = extractCharCode(trimmed);
  if (charCode != null) {
    final isHtml = charCode.contains('<') &&
        charCode.contains('>') &&
        !charCode.contains('function');
    return DeobfuscateResult(
      output: isHtml ? beautifyHtml(charCode) : beautifyJs(charCode),
      method: 'String.fromCharCode',
      success: true,
    );
  }

  // 4. HTML entities
  if (RegExp(r'&#x?[0-9a-fA-F]+;').hasMatch(trimmed)) {
    final decoded = htmlEntityDecode(trimmed);
    if (decoded != trimmed) {
      return DeobfuscateResult(
        output: decoded.contains('<') && decoded.contains('>')
            ? beautifyHtml(decoded)
            : beautifyJs(decoded),
        method: 'HTML Entities',
        success: true,
      );
    }
  }

  // 5. JS escapes
  if (RegExp(r'\\x[0-9a-fA-F]{2}|\\u[0-9a-fA-F]{4}').hasMatch(trimmed)) {
    final decoded = jsUnescape(trimmed);
    if (decoded != trimmed) {
      final looksHtml = decoded.contains('<html') ||
          decoded.contains('<!DOCTYPE') ||
          decoded.contains('<body');
      return DeobfuscateResult(
        output: looksHtml ? beautifyHtml(decoded) : beautifyJs(decoded),
        method: 'JS Hex/Unicode Escape',
        success: true,
      );
    }
  }

  // 6. Plain Base64 (tanpa wrapper) — hanya kalau shape-nya cocok
  final b64Clean = trimmed.replaceAll(RegExp(r'\s'), '');
  if (b64Clean.length >= 4 &&
      b64Clean.length % 4 == 0 &&
      RegExp(r'^[A-Za-z0-9+/]+={0,2}$').hasMatch(b64Clean)) {
    try {
      final decoded = utf8.decode(base64Decode(b64Clean));
      if (_isMostlyPrintable(decoded)) {
        final looksHtml = decoded.contains('<html') ||
            decoded.contains('<!DOCTYPE') ||
            decoded.contains('<body');
        return DeobfuscateResult(
          output: looksHtml ? beautifyHtml(decoded) : beautifyJs(decoded),
          method: 'Plain Base64',
          success: true,
        );
      }
    } catch (_) {}
  }

  // 7. Plain Base62 — hanya kalau alfanumerik murni
  if (trimmed.length >= 4 && RegExp(r'^[A-Za-z0-9]+$').hasMatch(trimmed)) {
    try {
      final bytes = base62Decode(trimmed);
      if (bytes.isNotEmpty) {
        final decoded = utf8.decode(bytes);
        if (_isMostlyPrintable(decoded) &&
            decoded.contains(RegExp(r'[a-zA-Z]'))) {
          final looksHtml = decoded.contains('<html') ||
              decoded.contains('<!DOCTYPE') ||
              decoded.contains('<body');
          return DeobfuscateResult(
            output: looksHtml ? beautifyHtml(decoded) : beautifyJs(decoded),
            method: 'Plain Base62',
            success: true,
          );
        }
      }
    } catch (_) {}
  }

  // 8. Fallback: beautify saja
  final looksHtml = trimmed.contains('<html') ||
      trimmed.contains('<!DOCTYPE') ||
      trimmed.contains('<body') ||
      (trimmed.startsWith('<') && trimmed.endsWith('>'));
  return DeobfuscateResult(
    output: looksHtml ? beautifyHtml(trimmed) : beautifyJs(trimmed),
    method: 'Beautify saja (tidak terdeteksi obfuscation)',
    success: true,
  );
}

// ═══════════════════════════════════════════════════════════════════
// ─── MAIN PAGE ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
enum ObfMode { obfuscate, deobfuscate }
enum LangMode { js, html, text }

class ObfuscatorPage extends StatefulWidget {
  const ObfuscatorPage({super.key});

  @override
  State<ObfuscatorPage> createState() => _ObfuscatorPageState();
}

class _ObfuscatorPageState extends State<ObfuscatorPage> {
  final XThemeController _themeController = XThemeController();

  final TextEditingController _inputCtrl = TextEditingController();
  final TextEditingController _outputCtrl = TextEditingController();

  ObfMode _mode = ObfMode.obfuscate;
  LangMode _lang = LangMode.js;
  String _method = 'hex';

  bool _isProcessing = false;
  String? _status;

  static const Map<LangMode, List<MapEntry<String, String>>> _methods = {
    LangMode.js: [
      MapEntry('hex', 'Hex Escape (\\xNN)'),
      MapEntry('unicode', 'Unicode Escape (\\uNNNN)'),
      MapEntry('base64', 'Base64 + eval(atob)'),
      MapEntry('base62', 'Base62 + eval'),
      MapEntry('charcode', 'Char Code + eval'),
      MapEntry('stringarray', 'String Array + Rename'),
      MapEntry('minify', 'Minify Only'),
    ],
    LangMode.html: [
      MapEntry('entities_dec', 'HTML Entities Desimal (&#NN;)'),
      MapEntry('entities_hex', 'HTML Entities Hex (&#xNN;)'),
      MapEntry('base64', 'Base64 + document.write'),
      MapEntry('base62', 'Base62 + document.write'),
      MapEntry('charcode', 'Char Code + document.write'),
      MapEntry('url', 'URL Encode'),
    ],
    LangMode.text: [
      MapEntry('b64_enc', 'Base64 Encode'),
      MapEntry('b64_dec', 'Base64 Decode'),
      MapEntry('b62_enc', 'Base62 Encode'),
      MapEntry('b62_dec', 'Base62 Decode'),
    ],
  };

  @override
  void initState() {
    super.initState();
    _method = _methods[_lang]!.first.key;
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _outputCtrl.dispose();
    super.dispose();
  }

  void _onLangChanged(LangMode lang) {
    setState(() {
      _lang = lang;
      _method = _methods[lang]!.first.key;
      _outputCtrl.clear();
      _status = null;
    });
  }

  void _onModeChanged(ObfMode mode) {
    setState(() {
      _mode = mode;
      _outputCtrl.clear();
      _status = null;
    });
  }

  Future<void> _process() async {
    final input = _inputCtrl.text;
    if (input.trim().isEmpty) {
      _snack('⚠️ Masukkan code terlebih dahulu', isError: true);
      return;
    }

    setState(() {
      _isProcessing = true;
      _status = null;
    });

    await Future.delayed(const Duration(milliseconds: 100));

    try {
      if (_mode == ObfMode.obfuscate) {
        _doObfuscate(input);
      } else {
        _doDeobfuscate(input);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isProcessing = false;
        _status = '❌ Error: $e';
      });
      _snack('❌ $e', isError: true);
    }
  }

  void _doObfuscate(String input) {
    String output;
    String label;

    if (_lang == LangMode.js) {
      switch (_method) {
        case 'hex':
          output = jsHexEscape(input);
          label = 'Hex Escape';
          break;
        case 'unicode':
          output = jsUnicodeEscape(input);
          label = 'Unicode Escape';
          break;
        case 'base64':
          output = jsBase64Eval(input);
          label = 'Base64 + eval';
          break;
        case 'base62':
          output = jsBase62Eval(input);
          label = 'Base62 + eval';
          break;
        case 'charcode':
          output = jsCharCodeEval(input);
          label = 'Char Code + eval';
          break;
        case 'stringarray':
          output = jsStringArray(input);
          label = 'String Array + Rename';
          break;
        case 'minify':
          output = jsMinify(input);
          label = 'Minify';
          break;
        default:
          throw 'Metode tidak dikenal';
      }
    } else if (_lang == LangMode.html) {
      switch (_method) {
        case 'entities_dec':
          output = htmlEntitiesDecimal(input);
          label = 'HTML Entities Desimal';
          break;
        case 'entities_hex':
          output = htmlEntitiesHex(input);
          label = 'HTML Entities Hex';
          break;
        case 'base64':
          output = htmlBase64DocWrite(input);
          label = 'Base64 + document.write';
          break;
        case 'base62':
          output = htmlBase62DocWrite(input);
          label = 'Base62 + document.write';
          break;
        case 'charcode':
          output = htmlCharCodeDocWrite(input);
          label = 'Char Code + document.write';
          break;
        case 'url':
          output = htmlUrlEncode(input);
          label = 'URL Encode';
          break;
        default:
          throw 'Metode tidak dikenal';
      }
    } else {
      // ── RAW / TEXT: Base64 & Base62 (encode/decode) ──
      switch (_method) {
        case 'b64_enc':
          output = plainBase64Encode(input);
          label = 'Base64 Encode';
          break;
        case 'b64_dec':
          output = plainBase64Decode(input);
          label = 'Base64 Decode';
          break;
        case 'b62_enc':
          output = plainBase62Encode(input);
          label = 'Base62 Encode';
          break;
        case 'b62_dec':
          output = plainBase62Decode(input);
          label = 'Base62 Decode';
          break;
        default:
          throw 'Metode tidak dikenal';
      }
    }

    if (!mounted) return;
    setState(() {
      _outputCtrl.text = output;
      _isProcessing = false;
      _status =
          '✅ Obfuscate sukses ($label) • ${input.length} → ${output.length} chars';
    });
    _snack('✅ Berhasil!');
  }

  void _doDeobfuscate(String input) {
    final result = autoDeobfuscate(input);

    if (!mounted) return;
    setState(() {
      _outputCtrl.text = result.output;
      _isProcessing = false;
      _status = result.success
          ? '✅ Deobfuscate sukses • Metode: ${result.method}'
          : '⚠️ ${result.method}';
    });
    _snack(result.success ? '✅ Berhasil deobfuscate!' : '⚠️ Gagal detect');
  }

  void _copyOutput() {
    final text = _outputCtrl.text;
    if (text.isEmpty) {
      _snack('⚠️ Tidak ada output untuk disalin', isError: true);
      return;
    }
    Clipboard.setData(ClipboardData(text: text));
    _snack('📋 Output disalin ke clipboard!');
  }

  void _copyInput() {
    final text = _inputCtrl.text;
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    _snack('📋 Input disalin!');
  }

  void _pasteInput() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null && data!.text!.isNotEmpty) {
      setState(() => _inputCtrl.text = data.text!);
      _snack('📥 Berhasil paste');
    } else {
      _snack('⚠️ Clipboard kosong', isError: true);
    }
  }

  void _swapIO() {
    final input = _inputCtrl.text;
    final output = _outputCtrl.text;
    setState(() {
      _inputCtrl.text = output;
      _outputCtrl.text = input;
      _status = null;
    });
  }

  void _clearAll() {
    setState(() {
      _inputCtrl.clear();
      _outputCtrl.clear();
      _status = null;
    });
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: obTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        backgroundColor: isError ? obRed : obGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: obBorderDark, width: 2),
        ),
      ),
    );
  }

  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          obTextMain.withOpacity(0.20),
          obRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? obGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [obBgCard, obBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  Widget _sectionHeader({
    required String title,
    required IconData icon,
    Widget? trailing,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [obGold, Color.lerp(obGold, Colors.black, 0.4)!],
            ),
            shape: BoxShape.circle,
            border: Border.all(color: obBorderDark, width: 1.5),
            boxShadow: [
              BoxShadow(color: obGold.withOpacity(0.5), blurRadius: 8),
            ],
          ),
          child: Icon(icon, color: obRedDark, size: 12),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            color: obTextMain,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        if (trailing != null) ...[
          const Spacer(),
          trailing,
        ],
      ],
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: onPressed != null
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    obTextSub.withOpacity(0.2),
                    obTextSub.withOpacity(0.08),
                  ],
                ),
          boxShadow: onPressed != null
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(
                color: onPressed != null
                    ? obBorderDark
                    : obTextSub.withOpacity(0.3),
                width: 2.5,
              ),
            ),
          ),
          child: loading
              ? const Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon,
                        size: 18,
                        color: onPressed != null
                            ? Colors.white
                            : obTextSub.withOpacity(0.5)),
                    const SizedBox(width: 8),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        color: onPressed != null
                            ? Colors.white
                            : obTextSub.withOpacity(0.5),
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildSmallBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: obBorderDark, width: 2),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 13),
            const SizedBox(width: 5),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: obBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(obBgMain, obRed, 0.25)!,
                  obBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 14),
                          _buildModeToggle(),
                          const SizedBox(height: 14),
                          if (_mode == ObfMode.obfuscate) ...[
                            _buildLanguageToggle(),
                            const SizedBox(height: 14),
                            _buildMethodPicker(),
                            const SizedBox(height: 14),
                          ],
                          _buildInputSection(),
                          const SizedBox(height: 14),
                          _buildProcessButton(),
                          const SizedBox(height: 14),
                          if (_status != null) ...[
                            _buildStatusCard(),
                            const SizedBox(height: 14),
                          ],
                          if (_outputCtrl.text.isNotEmpty) ...[
                            _buildOutputSection(),
                            const SizedBox(height: 14),
                          ],
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 12, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [obBgSurface, obBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: obGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: obGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [obRed, obRedDark]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: obBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [obRed, obRedDark]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: obBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: obGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.enhanced_encryption_rounded,
                      color: obGold, size: 16),
                  const SizedBox(width: 8),
                  const Flexible(
                    child: Text(
                      'OBFUSCATOR',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _clearAll,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [obRed, obRedDark]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: obBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.delete_sweep_rounded,
                  color: obGold, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: obGold,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [obGold, Color.lerp(obGold, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: obBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: obGold.withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.enhanced_encryption_rounded,
                  size: 28, color: obRedDark),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'OBFUSCATOR',
                    style: TextStyle(
                      color: obTextMain,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(
                          color: obGold.withOpacity(0.7),
                          blurRadius: 12,
                        ),
                        const Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Obfuscate • Deobfuscate • Base64/62',
                    style: TextStyle(
                      color: obTextSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeToggle() {
    return _bevelBox(
      radius: 16,
      glow: obGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Expanded(
              child: _buildToggleChip(
                icon: Icons.lock_rounded,
                label: 'OBFUSCATE',
                color: obRed,
                active: _mode == ObfMode.obfuscate,
                onTap: () => _onModeChanged(ObfMode.obfuscate),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildToggleChip(
                icon: Icons.lock_open_rounded,
                label: 'DEOBFUSCATE',
                color: obGreen,
                active: _mode == ObfMode.deobfuscate,
                onTap: () => _onModeChanged(ObfMode.deobfuscate),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToggleChip({
    required IconData icon,
    required String label,
    required Color color,
    required bool active,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!])
              : LinearGradient(colors: [obBgSurface, obBgMain]),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: active ? obGold : obGold.withOpacity(0.3),
            width: active ? 2.5 : 1.5,
          ),
          boxShadow: active
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: active ? Colors.white : obTextSub, size: 15),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  color: active ? Colors.white : obTextSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageToggle() {
    return _bevelBox(
      radius: 16,
      glow: obGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'PILIH MODE',
              icon: Icons.code_rounded,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildLangChip(
                    icon: Icons.javascript_rounded,
                    label: 'JS',
                    color: obYellow,
                    active: _lang == LangMode.js,
                    onTap: () => _onLangChanged(LangMode.js),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildLangChip(
                    icon: Icons.html_rounded,
                    label: 'HTML',
                    color: obBlue,
                    active: _lang == LangMode.html,
                    onTap: () => _onLangChanged(LangMode.html),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildLangChip(
                    icon: Icons.text_fields_rounded,
                    label: 'RAW',
                    color: obPurple,
                    active: _lang == LangMode.text,
                    onTap: () => _onLangChanged(LangMode.text),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLangChip({
    required IconData icon,
    required String label,
    required Color color,
    required bool active,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(
                  colors: [color, Color.lerp(color, Colors.black, 0.5)!])
              : LinearGradient(colors: [obBgSurface, obBgMain]),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: active ? obGold : obGold.withOpacity(0.3),
            width: active ? 2.5 : 1.5,
          ),
          boxShadow: active
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: active ? obRedDark : obTextSub, size: 16),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: active ? obRedDark : obTextSub,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMethodPicker() {
    final methods = _methods[_lang]!;
    return _bevelBox(
      radius: 16,
      glow: obGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'PILIH METODE',
              icon: Icons.auto_fix_high_rounded,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: methods.map((m) {
                final active = _method == m.key;
                // Warna khusus untuk decode = hijau
                final isDecode = m.key.endsWith('_dec');
                final chipColor =
                    isDecode ? obGreen : obRed;
                return GestureDetector(
                  onTap: () => setState(() => _method = m.key),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: active
                          ? LinearGradient(
                              colors: [
                                chipColor,
                                Color.lerp(chipColor, Colors.black, 0.5)!
                              ])
                          : LinearGradient(
                              colors: [obBgSurface, obBgMain]),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: active ? obGold : obGold.withOpacity(0.3),
                        width: active ? 2.5 : 1.5,
                      ),
                      boxShadow: active
                          ? [
                              const BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(2, 2),
                              ),
                              BoxShadow(
                                color: chipColor.withOpacity(0.5),
                                blurRadius: 10,
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      m.value,
                      style: TextStyle(
                        color: active ? Colors.white : obTextSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputSection() {
    String hint;
    if (_mode == ObfMode.obfuscate) {
      if (_lang == LangMode.js) {
        hint =
            '// Paste JavaScript code di sini...\n\nfunction hello() {\n  console.log("Hello World");\n}';
      } else if (_lang == LangMode.html) {
        hint =
            '<!-- Paste HTML code di sini... -->\n\n<div class="box">\n  <h1>Hello</h1>\n</div>';
      } else {
        if (_method.endsWith('_dec')) {
          hint = '// Paste encoded text (base64/base62) di sini...\n// Contoh: SGVsbG8gV29ybGQ=';
        } else {
          hint = '// Ketik text biasa di sini...\n// Contoh: Hello World';
        }
      }
    } else {
      hint =
          '// Paste obfuscated code di sini...\n// Sistem auto-detect: Base64 / Base62 / eval / charcode / entities';
    }

    return _bevelBox(
      radius: 16,
      glow: obGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: _mode == ObfMode.obfuscate
                  ? 'INPUT'
                  : 'INPUT OBFUSCATED CODE',
              icon: Icons.input_rounded,
              trailing: Row(
                children: [
                  GestureDetector(
                    onTap: _pasteInput,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      margin: const EdgeInsets.only(right: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            obBlue,
                            Color.lerp(obBlue, Colors.black, 0.4)!
                          ],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: obBorderDark, width: 1.5),
                      ),
                      child: const Icon(Icons.content_paste_rounded,
                          color: Colors.white, size: 11),
                    ),
                  ),
                  if (_inputCtrl.text.isNotEmpty)
                    GestureDetector(
                      onTap: _copyInput,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              obGold,
                              Color.lerp(obGold, Colors.black, 0.4)!
                            ],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(color: obBorderDark, width: 1.5),
                        ),
                        child: Icon(Icons.copy_rounded,
                            color: obRedDark, size: 11),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Container(
              constraints:
                  const BoxConstraints(minHeight: 180, maxHeight: 320),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [obBgSurface, obBgMain]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: obGold.withOpacity(0.4), width: 2),
              ),
              child: TextField(
                controller: _inputCtrl,
                maxLines: null,
                style: TextStyle(
                  color: obTextMain,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                  height: 1.4,
                ),
                cursorColor: obGold,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(
                    color: obTextSub.withOpacity(0.4),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(12),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.info_outline_rounded, color: obTextSub, size: 11),
                const SizedBox(width: 4),
                Text(
                  '${_inputCtrl.text.length} characters',
                  style: TextStyle(
                    color: obTextSub.withOpacity(0.7),
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProcessButton() {
    final isObf = _mode == ObfMode.obfuscate;
    final isDecode = _method.endsWith('_dec');

    String label;
    if (_isProcessing) {
      label = 'PROCESSING...';
    } else if (isObf) {
      label = isDecode ? 'MULAI DECODE' : 'MULAI OBFUSCATE';
    } else {
      label = 'MULAI DEOBFUSCATE';
    }

    IconData icon;
    if (_isProcessing) {
      icon = Icons.hourglass_top_rounded;
    } else if (isObf) {
      icon = isDecode
          ? Icons.lock_open_rounded
          : Icons.enhanced_encryption_rounded;
    } else {
      icon = Icons.lock_open_rounded;
    }

    return _build3DButton(
      label: label,
      icon: icon,
      onPressed: _isProcessing ? null : _process,
      color: isObf ? (isDecode ? obGreen : obRed) : obGreen,
      loading: _isProcessing,
    );
  }

  Widget _buildStatusCard() {
    final isSuccess = _status!.startsWith('✅');
    final isError = _status!.startsWith('❌') || _status!.startsWith('⚠️');
    final color = isSuccess ? obGreen : (isError ? obRed : obGold);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          color.withOpacity(0.15),
          color.withOpacity(0.05),
        ]),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.5), width: 1.5),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess
                ? Icons.check_circle_rounded
                : (isError ? Icons.error_rounded : Icons.info_rounded),
            color: color,
            size: 14,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _status!,
              style: TextStyle(
                color: obTextMain,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutputSection() {
    return _bevelBox(
      radius: 16,
      glow: obGreen,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(
              title: 'OUTPUT RESULT',
              icon: Icons.output_rounded,
              trailing: Row(
                children: [
                  GestureDetector(
                    onTap: _swapIO,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      margin: const EdgeInsets.only(right: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            obPurple,
                            Color.lerp(obPurple, Colors.black, 0.4)!
                          ],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: obBorderDark, width: 1.5),
                      ),
                      child: const Icon(Icons.swap_vert_rounded,
                          color: Colors.white, size: 11),
                    ),
                  ),
                  GestureDetector(
                    onTap: _copyOutput,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            obGreen,
                            Color.lerp(obGreen, Colors.black, 0.4)!
                          ],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: obBorderDark, width: 1.5),
                      ),
                      child: const Icon(Icons.copy_rounded,
                          color: Colors.white, size: 11),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Container(
              constraints:
                  const BoxConstraints(minHeight: 180, maxHeight: 400),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [obBgSurface, obBgMain]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: obGreen.withOpacity(0.4), width: 2),
              ),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: SelectableText(
                    _outputCtrl.text,
                    style: TextStyle(
                      color: obTextMain,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      height: 1.4,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.check_circle_outline_rounded,
                    color: obGreen, size: 11),
                const SizedBox(width: 4),
                Text(
                  '${_outputCtrl.text.length} characters',
                  style: TextStyle(
                    color: obGreen.withOpacity(0.8),
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.copy_all_rounded,
                    label: 'COPY OUTPUT',
                    color: obGreen,
                    onTap: _copyOutput,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildSmallBtn(
                    icon: Icons.delete_outline_rounded,
                    label: 'CLEAR',
                    color: obRed,
                    onTap: () => setState(() {
                      _outputCtrl.clear();
                      _status = null;
                    }),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}