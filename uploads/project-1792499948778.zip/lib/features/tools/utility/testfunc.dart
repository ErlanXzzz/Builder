// lib/features/tools/utility/testfunc.dart
import 'dart:convert';
import 'dart:ui';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/apiBaseUrl.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS (mutable) ──────────────────────────────────
Color tfBgMain = const Color(0xFF0B1014);
Color tfBgSurface = const Color(0xFF171C22);
Color tfBgCard = const Color(0xFF151A20);
Color tfTextMain = const Color(0xFFE9EEF2);
Color tfTextSub = const Color(0xFF9BA4AA);
Color tfAccent = const Color(0xFF03BCD4);
Color tfAccentDark = const Color(0xFF002E34);
Color tfBorder = const Color(0xFF2A323A);
Color tfDanger = const Color(0xFFE65353);
Color tfGreen = const Color(0xFF4CAF50);
Color tfBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  tfBgMain     = theme.brownDark;
  tfBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  tfBgCard     = theme.brownMid;
  tfTextMain   = theme.bgCreamLight;
  tfTextSub    = theme.gold;
  tfAccent     = theme.gold;
  tfAccentDark = theme.goldDark;
  tfBorder     = theme.redDeep;
  tfDanger     = theme.accentRed;
  tfGreen      = theme.accentGreen;
  tfBorderDark = theme.borderDark;
}

class TestFunctionPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final String expiredDate;

  const TestFunctionPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.expiredDate,
  }) : super(key: key);

  @override
  State<TestFunctionPage> createState() => _TestFunctionPageState();
}

class _TestFunctionPageState extends State<TestFunctionPage> {
  final TextEditingController targetController = TextEditingController();
  final TextEditingController functionController = TextEditingController();
  final TextEditingController delayController =
      TextEditingController(text: '1000');
  final TextEditingController jumlahController =
      TextEditingController(text: '1');

  bool _isTesting = false;
  String? _testResponseMessage;
  int _successCount = 0;
  int _failCount = 0;
  final List<String> _errorMessages = <String>[];
  String _currentStatus = '';
  String? _pickedFileName;

  final XThemeController _themeController = XThemeController();

  @override
  void dispose() {
    targetController.dispose();
    functionController.dispose();
    delayController.dispose();
    jumlahController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final String cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.startsWith('+') && cleaned.length >= 8) return cleaned;
    if (cleaned.startsWith('62') && cleaned.length >= 8) return '+$cleaned';
    return null;
  }

  Future<void> _pickJsFile() async {
    try {
      const XTypeGroup jsGroup = XTypeGroup(
        label: 'JavaScript / Text',
        extensions: <String>['js', 'txt'],
      );

      final XFile? file = await openFile(
        acceptedTypeGroups: <XTypeGroup>[jsGroup],
      );

      if (file == null) return;

      final List<int> bytes = await file.readAsBytes();
      final String content = utf8.decode(bytes, allowMalformed: true);

      if (!mounted) return;
      setState(() {
        _pickedFileName = file.name;
        functionController.text = content;
      });
    } catch (e) {
      _showAlert('File Error', 'Gagal memilih file: $e');
    }
  }

  Future<void> _testFunction() async {
    final String rawInput = targetController.text.trim();
    final String? target = formatPhoneNumber(rawInput);
    final int jumlah = int.tryParse(jumlahController.text) ?? 1;
    final int delay = int.tryParse(delayController.text) ?? 1000;

    if (target == null) {
      _showAlert('Invalid Number',
          'Gunakan format nomor internasional, contoh: 62xxxxxxxxxx');
      return;
    }

    if (functionController.text.trim().isEmpty) {
      _showAlert('No Function',
          'Paste function atau pilih file .js terlebih dahulu.');
      return;
    }

    if (delay < 0) {
      _showAlert('Invalid Delay', 'Delay tidak boleh minus.');
      return;
    }

    if (jumlah <= 0 || jumlah > 1000) {
      _showAlert('Invalid Loops', 'Jumlah loops harus antara 1 - 1000.');
      return;
    }

    setState(() {
      _isTesting = true;
      _testResponseMessage = null;
      _successCount = 0;
      _failCount = 0;
      _errorMessages.clear();
      _currentStatus = 'Mengirim...';
    });

    try {
      final http.Response response = await http.post(
        Uri.parse('$apiBaseUrl/testFunction'),
        headers: <String, String>{'Content-Type': 'application/json'},
        body: jsonEncode(<String, dynamic>{
          'key': widget.sessionKey,
          'target': target,
          'jumlah': jumlah,
          'delay': delay,
          'functionCode': functionController.text,
          'username': widget.username,
          'role': widget.role,
        }),
      );

      final Map<String, dynamic> data =
          jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;
      setState(() {
        if (data['success'] == true) {
          _successCount = data['successCount'] as int? ?? 0;
          _failCount = data['failCount'] as int? ?? 0;
          if (data['errors'] != null) {
            _errorMessages.addAll(List<String>.from(data['errors'] as List));
          }
          _testResponseMessage =
              data['message'] as String? ?? 'Function selesai dikirim';
          _currentStatus =
              _failCount == 0 ? 'Berhasil' : 'Selesai dengan error';
        } else {
          _testResponseMessage =
              data['message'] as String? ?? 'Gagal menjalankan function';
          _currentStatus = 'Gagal';
        }
        _isTesting = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _testResponseMessage = 'Error: $e';
        _currentStatus = 'Error';
        _isTesting = false;
      });
    }
  }

  void _clearFunction() {
    setState(() {
      functionController.clear();
      _pickedFileName = null;
    });
  }

  void _resetAll() {
    setState(() {
      targetController.clear();
      functionController.clear();
      delayController.text = '1000';
      jumlahController.text = '1';
      _pickedFileName = null;
      _testResponseMessage = null;
      _successCount = 0;
      _failCount = 0;
      _errorMessages.clear();
      _currentStatus = '';
    });
  }

  void _showAlert(String title, String msg) {
    showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: AlertDialog(
            backgroundColor: tfBgSurface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: BorderSide(color: tfBorder, width: 2),
            ),
            title: Text(title,
                style: TextStyle(
                    color: tfTextMain, fontWeight: FontWeight.w700)),
            content: Text(msg, style: TextStyle(color: tfTextSub)),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK', style: TextStyle(color: tfAccent)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          tfTextMain.withOpacity(0.20),
          tfAccent.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? tfAccent).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [tfBgCard, tfBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _topBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 12, 0, 22),
      child: Row(
        children: <Widget>[
          GestureDetector(
            onTap: () => Navigator.maybePop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [tfAccent, tfAccentDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tfBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back,
                  color: Colors.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'TES FUNC',
              style: TextStyle(
                color: tfTextMain,
                fontSize: 19,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.1,
                shadows: [
                  Shadow(
                    color: tfAccent.withOpacity(0.6),
                    blurRadius: 14,
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [tfAccent, tfAccentDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: tfBorderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
              ],
            ),
            child: Icon(Icons.history,
                color: Colors.white, size: 20),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HERO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _heroCard() {
    return _bevelBox(
      radius: 20,
      glow: tfAccent,
      glowOpacity: 0.35,
      child: Container(
        height: 115,
        padding: const EdgeInsets.all(24),
        child: Row(
          children: <Widget>[
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [tfAccent, tfAccentDark],
                ),
                border: Border.all(color: tfBorderDark, width: 2.5),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                      color: tfAccent.withOpacity(0.55),
                      blurRadius: 25,
                      spreadRadius: 3),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.code, color: Colors.white, size: 31),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Test Function',
                    style: TextStyle(
                        color: tfTextMain,
                        fontSize: 19,
                        fontWeight: FontWeight.w800,
                        shadows: [
                          Shadow(
                            color: tfAccent.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ]),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Kirim function custom dengan delay & loops',
                    style:
                        TextStyle(color: tfTextSub, fontSize: 13.5, height: 1.2),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _label(String label) {
    return Padding(
      padding: const EdgeInsets.only(top: 26, bottom: 12),
      child: Text(
        label,
        style: TextStyle(
            color: tfTextMain, fontSize: 16.5, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _inputBox({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    int minLines = 1,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [tfBgCard, tfBgMain],
        ),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: tfAccent, width: 2.5),
        boxShadow: [
          const BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: tfAccent.withOpacity(0.3),
            blurRadius: 12,
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        minLines: minLines,
        maxLines: maxLines,
        keyboardType: keyboardType,
        cursorColor: tfAccent,
        style: TextStyle(
            color: tfTextMain, fontSize: 15.5, letterSpacing: 0.3),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: tfTextSub.withOpacity(0.6), fontSize: 15),
          prefixIcon: Padding(
            padding: EdgeInsets.only(top: maxLines > 1 ? 16 : 0),
            child: Icon(icon, color: tfAccent, size: 23),
          ),
          prefixIconConstraints: const BoxConstraints(minWidth: 58),
          contentPadding: EdgeInsets.fromLTRB(
              0, maxLines > 1 ? 22 : 20, 18, maxLines > 1 ? 22 : 20),
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _fileRow() {
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Row(
        children: <Widget>[
          Expanded(
            child: GestureDetector(
              onTap: _pickJsFile,
              child: Container(
                height: 55,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [tfBgCard, tfBgMain],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: tfAccent, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.upload_file_outlined,
                        color: tfAccent, size: 21),
                    const SizedBox(width: 9),
                    Flexible(
                      child: Text(
                        _pickedFileName == null
                            ? 'Pilih file js'
                            : _pickedFileName!,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: tfAccent,
                            fontSize: 15.5,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          GestureDetector(
            onTap: _clearFunction,
            child: Container(
              width: 78,
              height: 55,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    tfDanger.withOpacity(0.3),
                    tfDanger.withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tfDanger, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Text('Clear',
                  style: TextStyle(
                      color: tfDanger,
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _smallInput({
    required String title,
    required TextEditingController controller,
    required IconData icon,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title,
              style: TextStyle(
                  color: tfTextMain,
                  fontSize: 15.8,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [tfBgCard, tfBgMain],
              ),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: tfAccent, width: 2.5),
              boxShadow: [
                const BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: tfAccent.withOpacity(0.25),
                  blurRadius: 10,
                ),
              ],
            ),
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              cursorColor: tfAccent,
              style: TextStyle(color: tfTextMain, fontSize: 15.5),
              decoration: InputDecoration(
                prefixIcon: Icon(icon, color: tfAccent, size: 23),
                prefixIconConstraints: const BoxConstraints(minWidth: 58),
                contentPadding: const EdgeInsets.symmetric(vertical: 20),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sendRow() {
    return Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              height: 66,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [tfAccent, tfAccentDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: tfBorderDark, width: 3),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: tfAccent.withOpacity(0.5),
                    blurRadius: 20,
                    spreadRadius: -4,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isTesting ? null : _testFunction,
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                child: _isTesting
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2.6),
                          ),
                          const SizedBox(width: 12),
                          Text(_currentStatus,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800)),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(Icons.send_rounded,
                              color: Colors.white, size: 22),
                          SizedBox(width: 12),
                          Text(
                            'KIRIM FUNCTION',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 15.5,
                                letterSpacing: 1.1,
                                shadows: [
                                  Shadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 3,
                                    offset: Offset(1, 1),
                                  ),
                                ]),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(width: 20),
          GestureDetector(
            onTap: _resetAll,
            child: Container(
              width: 74,
              height: 74,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    tfDanger.withOpacity(0.3),
                    tfDanger.withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: tfDanger, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child:
                  Icon(Icons.refresh_rounded, color: tfDanger, size: 28),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoCard() {
    return _bevelBox(
      radius: 18,
      glow: tfAccent,
      glowOpacity: 0.2,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 36),
        padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(Icons.info_outline, color: tfAccent, size: 22),
                const SizedBox(width: 14),
                Text('informasi',
                    style: TextStyle(
                        color: tfTextMain,
                        fontSize: 16,
                        fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 20),
            Text('• Gunakan format nomor internasional (62xxx)',
                style: TextStyle(
                    color: tfTextSub, fontSize: 13.4, height: 1.55)),
            Text('• File .js akan dibaca sebagai plain text',
                style: TextStyle(
                    color: tfTextSub, fontSize: 13.4, height: 1.55)),
            Text('• Delay dalam milidetik (ms)',
                style: TextStyle(
                    color: tfTextSub, fontSize: 13.4, height: 1.55)),
            Text('• Loops menentukan jumlah pengiriman',
                style: TextStyle(
                    color: tfTextSub, fontSize: 13.4, height: 1.55)),
            Text('• Function akan dikirim sebagai payload',
                style: TextStyle(
                    color: tfTextSub, fontSize: 13.4, height: 1.55)),
          ],
        ),
      ),
    );
  }

  Widget _resultCard() {
    if (_testResponseMessage == null && !_isTesting) {
      return const SizedBox.shrink();
    }

    final bool ok = _failCount == 0;
    final Color resultColor = ok ? tfGreen : tfDanger;

    return _bevelBox(
      radius: 16,
      glow: resultColor,
      glowOpacity: 0.4,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 22),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(ok ? Icons.check_circle_outline : Icons.error_outline,
                    color: resultColor),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _testResponseMessage ?? _currentStatus,
                    style: TextStyle(
                        color: resultColor, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            if (_successCount > 0 || _failCount > 0) ...<Widget>[
              const SizedBox(height: 10),
              Text('Sukses: $_successCount   Gagal: $_failCount',
                  style: TextStyle(color: tfTextSub)),
            ],
            if (_errorMessages.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              ..._errorMessages
                  .map((String e) => Text('• $e',
                      style: TextStyle(color: tfDanger, fontSize: 12)))
                  .toList(),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: tfBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(tfBgMain, tfAccent, 0.15)!,
                  tfBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(25, 0, 25, 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _topBar(context),
                    _heroCard(),
                    _label('Nomor Target'),
                    _inputBox(
                      controller: targetController,
                      hint: '62xxx (contoh: 6281234567890)',
                      icon: Icons.phone,
                      keyboardType: TextInputType.phone,
                    ),
                    _label('Function / Message'),
                    _inputBox(
                      controller: functionController,
                      hint: 'Paste function atau message di sini...',
                      icon: Icons.code_rounded,
                      minLines: 8,
                      maxLines: 10,
                      keyboardType: TextInputType.multiline,
                    ),
                    _fileRow(),
                    const SizedBox(height: 44),
                    Row(
                      children: <Widget>[
                        _smallInput(
                            title: 'Delay (ms)',
                            controller: delayController,
                            icon: Icons.timer_rounded),
                        const SizedBox(width: 20),
                        _smallInput(
                            title: 'jumlah Loops',
                            controller: jumlahController,
                            icon: Icons.repeat_rounded),
                      ],
                    ),
                    _sendRow(),
                    _resultCard(),
                    _infoCard(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}