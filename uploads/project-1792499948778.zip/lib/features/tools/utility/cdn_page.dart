// lib/features/tools/utility/upload_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../dashboard/xtheme.dart';

// ═══════════════════════════════════════════════════════════════════
// ─── XTHEME-DRIVEN COLORS ─────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
Color upBgMain = const Color(0xFF160A07);
Color upBgSurface = const Color(0xFF2A140E);
Color upBgCard = const Color(0xFF3A1E15);
Color upBgElevated = const Color(0xFF4A2818);
Color upTextMain = const Color(0xFFF3E6DD);
Color upTextSub = const Color(0xFFC9913F);
Color upGold = const Color(0xFFD4A853);
Color upRed = const Color(0xFFB71C1C);
Color upRedDark = const Color(0xFF7F0000);
Color upRedDeep = const Color(0xFF4A0000);
Color upGreen = const Color(0xFF4CAF50);
Color upBlue = const Color(0xFF2196F3);
Color upPurple = const Color(0xFFAB47BC);
Color upBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  upBgMain     = theme.brownDark;
  upBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  upBgCard     = theme.brownMid;
  upBgElevated = Color.lerp(theme.brownMid, theme.bgCreamLight, 0.15)!;
  upTextMain   = theme.bgCreamLight;
  upTextSub    = theme.gold;
  upGold       = theme.gold;
  upRed        = theme.redMain;
  upRedDark    = theme.redDark;
  upRedDeep    = theme.redDeep;
  upGreen      = theme.accentGreen;
  upBlue       = theme.accentBlue;
  upPurple     = theme.accentBlue;
  upBorderDark = theme.borderDark;
}

// ═══════════════════════════════════════════════════════════════════
// ─── UPLOAD ENDPOINT ──────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
const String UPLOAD_ENDPOINT = 'https://cdn.atlas-by-erlan.com/api/upload';

// ═══════════════════════════════════════════════════════════════════
// ─── UPLOAD MODEL ─────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class UploadItem {
  final String fileName;
  final String filePath;
  final int fileSize;
  String? url;
  DateTime? uploadedAt;
  double progress;
  String? error;
  UploadStatus status;

  UploadItem({
    required this.fileName,
    required this.filePath,
    required this.fileSize,
    this.url,
    this.uploadedAt,
    this.progress = 0.0,
    this.error,
    this.status = UploadStatus.pending,
  });

  Map<String, dynamic> toJson() => {
        'fileName': fileName,
        'filePath': filePath,
        'fileSize': fileSize,
        'url': url,
        'uploadedAt': uploadedAt?.toIso8601String(),
        'status': status.name,
      };

  factory UploadItem.fromJson(Map<String, dynamic> j) => UploadItem(
        fileName: j['fileName'] ?? '',
        filePath: j['filePath'] ?? '',
        fileSize: j['fileSize'] ?? 0,
        url: j['url'],
        uploadedAt: j['uploadedAt'] != null
            ? DateTime.tryParse(j['uploadedAt'])
            : null,
        status: UploadStatus.values.firstWhere(
          (e) => e.name == j['status'],
          orElse: () => UploadStatus.success,
        ),
      );
}

enum UploadStatus { pending, uploading, success, error }

// ═══════════════════════════════════════════════════════════════════
// ─── MAIN PAGE ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
class UploadPage extends StatefulWidget {
  const UploadPage({super.key});

  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  final XThemeController _themeController = XThemeController();
  final ImagePicker _imagePicker = ImagePicker();

  // Queue file yang mau di-upload
  final List<UploadItem> _queue = [];

  // History file yang sudah di-upload
  final List<UploadItem> _history = [];

  bool _isUploading = false;
  bool _isLoadingHistory = true;

  static const String _historyKey = 'upload_history_v1';

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // ═══════════════════════════════════════════════════════════════════
  // HISTORY PERSISTENCE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_historyKey);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        if (!mounted) return;
        setState(() {
          _history.clear();
          _history.addAll(list
              .map((e) => UploadItem.fromJson(Map<String, dynamic>.from(e)))
              .toList());
        });
      }
    } catch (e) {
      debugPrint('Load history error: $e');
    } finally {
      if (mounted) setState(() => _isLoadingHistory = false);
    }
  }

  Future<void> _saveHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = jsonEncode(_history.map((e) => e.toJson()).toList());
      await prefs.setString(_historyKey, raw);
    } catch (e) {
      debugPrint('Save history error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // PICK FILE / IMAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _pickFiles() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        withData: false,
      );

      if (result == null || result.files.isEmpty) return;

      if (!mounted) return;

      setState(() {
        for (final f in result.files) {
          if (f.path == null) continue;
          // Cek duplikat
          final exists = _queue.any((q) => q.filePath == f.path);
          if (exists) continue;
          _queue.add(UploadItem(
            fileName: f.name,
            filePath: f.path!,
            fileSize: f.size,
          ));
        }
      });

      _showSnack('${result.files.length} file ditambahkan');
    } catch (e) {
      _showSnack('❌ Gagal pilih file: $e', isError: true);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? picked = await _imagePicker.pickImage(
        source: source,
        imageQuality: 90,
      );
      if (picked == null) return;

      if (!mounted) return;

      final file = File(picked.path);
      final size = await file.length();

      setState(() {
        final exists = _queue.any((q) => q.filePath == picked.path);
        if (exists) return;
        _queue.add(UploadItem(
          fileName: picked.name,
          filePath: picked.path,
          fileSize: size,
        ));
      });

      _showSnack('📸 Gambar ditambahkan');
    } catch (e) {
      _showSnack('❌ Gagal pilih gambar: $e', isError: true);
    }
  }

  void _showSourcePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => AnimatedBuilder(
        animation: _themeController,
        builder: (context, _) {
          applyXTheme(_themeController.currentTheme);

          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [upBgSurface, upBgMain],
              ),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(
                top: BorderSide(color: upGold, width: 3),
                left: BorderSide(color: upBorderDark, width: 2),
                right: BorderSide(color: upBorderDark, width: 2),
              ),
            ),
            child: SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: upGold.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'PILIH SUMBER GAMBAR',
                    style: TextStyle(
                      color: upTextMain,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: _buildSourceOption(
                          icon: Icons.camera_alt_rounded,
                          label: 'KAMERA',
                          color: upRed,
                          onTap: () {
                            Navigator.pop(context);
                            _pickImage(ImageSource.camera);
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildSourceOption(
                          icon: Icons.photo_library_rounded,
                          label: 'GALERI',
                          color: upBlue,
                          onTap: () {
                            Navigator.pop(context);
                            _pickImage(ImageSource.gallery);
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSourceOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.5)!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: upBorderDark, width: 2.5),
          boxShadow: [
            const BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(4, 4),
            ),
            BoxShadow(
              color: color.withOpacity(0.5),
              blurRadius: 14,
              spreadRadius: -3,
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white, size: 32),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                fontSize: 12,
                letterSpacing: 1.5,
                shadows: [
                  Shadow(
                    color: Color(0xCC000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // UPLOAD ALL
  // ═══════════════════════════════════════════════════════════════════
Future<void> _uploadAll() async {
  if (_queue.isEmpty) {
    _showSnack('Tidak ada file untuk diupload', isError: true);
    return;
  }

  setState(() => _isUploading = true);

  for (int i = 0; i < _queue.length; i++) {
    final item = _queue[i];
    if (item.status == UploadStatus.success) continue;

    setState(() {
      item.status = UploadStatus.uploading;
      item.progress = 0.0;
      item.error = null;
    });

    try {
      final file = File(item.filePath);
      if (!await file.exists()) {
        throw 'File tidak ditemukan';
      }

      // LANGKAH 1: Minta Presigned Upload URL dari Express Vercel
      final getUrlResponse = await http.post(
        Uri.parse('https://cdn.atlas-by-erlan.com/api/get-upload-url'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'originalName': item.fileName}),
      );

      if (getUrlResponse.statusCode != 200) {
        throw 'Gagal mendapatkan izin upload dari server.';
      }

      final urlData = jsonDecode(getUrlResponse.body);
      if (urlData['success'] != true) {
        throw urlData['message'] ?? 'Izin upload ditolak.';
      }

      final String uploadUrl = urlData['uploadUrl'];
      final String publicUrl = urlData['publicUrl'];

      // LANGKAH 2: Upload File LANGSUNG ke Supabase Storage (Bypass Vercel limit ~4.5MB!)
      final fileBytes = await file.readAsBytes();
      final uploadResponse = await http.put(
        Uri.parse(uploadUrl),
        headers: {
          'Content-Type': 'application/octet-stream',
        },
        body: fileBytes,
      );

      if (uploadResponse.statusCode == 200 || uploadResponse.statusCode == 201) {
        setState(() {
          item.url = publicUrl;
          item.status = UploadStatus.success;
          item.progress = 1.0;
          item.uploadedAt = DateTime.now();
        });

        // Tambah ke history
        _history.insert(0, UploadItem(
          fileName: item.fileName,
          filePath: item.filePath,
          fileSize: item.fileSize,
          url: publicUrl,
          uploadedAt: DateTime.now(),
          status: UploadStatus.success,
          progress: 1.0,
        ));
      } else {
        throw 'Upload direct ke storage gagal (${uploadResponse.statusCode})';
      }
    } catch (e) {
      setState(() {
        item.status = UploadStatus.error;
        item.error = e.toString();
      });
    }
  }

  setState(() => _isUploading = false);
  await _saveHistory();

  final successCount = _queue.where((e) => e.status == UploadStatus.success).length;
  final failCount = _queue.where((e) => e.status == UploadStatus.error).length;

  if (failCount == 0) {
    _showSnack('✅ $successCount file berhasil diupload');
  } else {
    _showSnack('⚠️ $successCount sukses, $failCount gagal', isError: true);
  }
}

  // ═══════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════
  void _removeFromQueue(int index) {
    setState(() => _queue.removeAt(index));
  }

  void _clearQueue() {
    setState(() => _queue.clear());
  }

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: upBgSurface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: upBorderDark, width: 2.5),
        ),
        title: Text(
          'Hapus History?',
          style: TextStyle(
            color: upTextMain,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
          ),
        ),
        content: Text(
          'Semua riwayat upload akan dihapus.',
          style: TextStyle(color: upTextSub, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('BATAL', style: TextStyle(color: upTextSub)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('HAPUS', style: TextStyle(color: upRed)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _history.clear());
      await _saveHistory();
      _showSnack('🗑️ History dihapus');
    }
  }

  Future<void> _copyUrl(String url) async {
    await Clipboard.setData(ClipboardData(text: url));
    _showSnack('📋 URL disalin!');
  }

  Future<void> _openUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showSnack('❌ Gagal buka URL', isError: true);
    }
  }

  Future<void> _shareUrl(String url, String fileName) async {
    try {
      await Share.share(
        '$fileName\n$url',
        subject: 'File dari ATLAS CDN',
      );
    } catch (e) {
      _showSnack('❌ Gagal share', isError: true);
    }
  }

  Future<void> _downloadToLocal(UploadItem item) async {
    if (item.url == null) return;

    try {
      _showSnack('⏳ Mengunduh...');

      final response = await http.get(Uri.parse(item.url!));
      final bytes = response.bodyBytes;

      Directory? directory;
      if (Platform.isAndroid) {
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        directory = await getApplicationDocumentsDirectory();
      }

      final file = File('${directory!.path}/${item.fileName}');
      await file.writeAsBytes(bytes);

      _showSnack('✅ Disimpan: ${file.path}');
    } catch (e) {
      _showSnack('❌ Gagal download: $e', isError: true);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            color: upTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: isError ? upRed : upGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: upBorderDark, width: 2),
        ),
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  IconData _iconForFile(String fileName) {
    final ext = fileName.split('.').last.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].contains(ext)) {
      return Icons.image_rounded;
    }
    if (['mp4', 'mov', 'avi', 'mkv', 'webm'].contains(ext)) {
      return Icons.videocam_rounded;
    }
    if (['mp3', 'wav', 'ogg', 'm4a'].contains(ext)) {
      return Icons.music_note_rounded;
    }
    if (['pdf'].contains(ext)) return Icons.picture_as_pdf_rounded;
    if (['zip', 'rar', '7z', 'tar'].contains(ext)) return Icons.folder_zip_rounded;
    if (['doc', 'docx'].contains(ext)) return Icons.description_rounded;
    if (['xls', 'xlsx'].contains(ext)) return Icons.table_chart_rounded;
    if (['txt', 'md'].contains(ext)) return Icons.text_snippet_rounded;
    return Icons.insert_drive_file_rounded;
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          upTextMain.withOpacity(0.20),
          upRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? upGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [upBgCard, upBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  Widget _build3DButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool loading = false,
    bool fullWidth = true,
  }) {
    final button = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: onPressed != null
            ? LinearGradient(
                colors: [color, Color.lerp(color, Colors.black, 0.5)!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : LinearGradient(
                colors: [
                  upTextSub.withOpacity(0.2),
                  upTextSub.withOpacity(0.08),
                ],
              ),
        boxShadow: onPressed != null
            ? [
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(4, 4),
                ),
                BoxShadow(
                  color: color.withOpacity(0.5),
                  blurRadius: 16,
                  spreadRadius: -3,
                ),
              ]
            : null,
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(
              color: onPressed != null
                  ? upBorderDark
                  : upTextSub.withOpacity(0.3),
              width: 2.5,
            ),
          ),
        ),
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon,
                      size: 18,
                      color: onPressed != null
                          ? Colors.white
                          : upTextSub.withOpacity(0.5)),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      color: onPressed != null
                          ? Colors.white
                          : upTextSub.withOpacity(0.5),
                      letterSpacing: 1.2,
                      shadows: onPressed != null
                          ? const [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ]
                          : null,
                    ),
                  ),
                ],
              ),
      ),
    );

    return fullWidth ? button : button;
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: upBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(upBgMain, upRed, 0.25)!,
                  upBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 14),
                          _buildPickerButtons(),
                          const SizedBox(height: 14),
                          if (_queue.isNotEmpty) _buildQueueSection(),
                          if (_queue.isNotEmpty) const SizedBox(height: 14),
                          _buildHistorySection(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── APP BAR ────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [upBgSurface, upBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: upGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: upGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [upRed, upRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: upBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [upRed, upRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: upBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: upGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.cloud_upload_rounded,
                      color: upGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'FILE UPLOADER',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _isLoadingHistory ? null : _clearHistory,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [upRed, upRedDark],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: upBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(Icons.delete_sweep_rounded,
                  color: upGold, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO CARD ──────────────────────────────────────────────
  Widget _buildHeroCard() {
    return _bevelBox(
      radius: 20,
      glow: upGold,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [upGold, Color.lerp(upGold, Colors.black, 0.5)!],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: upBorderDark, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: upGold.withOpacity(0.65),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: Icon(
                Icons.cloud_upload_rounded,
                size: 28,
                color: upRedDark,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ATLAS CDN',
                    style: TextStyle(
                      color: upTextMain,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(
                          color: upGold.withOpacity(0.7),
                          blurRadius: 12,
                        ),
                        const Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Upload file ke server, dapat link publik',
                    style: TextStyle(
                      color: upTextSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PICKER BUTTONS ─────────────────────────────────────────
  Widget _buildPickerButtons() {
    return _bevelBox(
      radius: 20,
      glow: upGold,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [upGold, Color.lerp(upGold, Colors.black, 0.4)!],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: upBorderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.add_circle_rounded,
                      color: upRedDark, size: 14),
                ),
                const SizedBox(width: 10),
                Text(
                  'PILIH FILE',
                  style: TextStyle(
                    color: upTextMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _buildPickCard(
                    icon: Icons.attach_file_rounded,
                    label: 'FILE',
                    sub: 'Multi format',
                    color: upBlue,
                    onTap: _isUploading ? null : _pickFiles,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildPickCard(
                    icon: Icons.image_rounded,
                    label: 'GAMBAR',
                    sub: 'Kamera / Galeri',
                    color: upPurple,
                    onTap: _isUploading ? null : _showSourcePicker,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Upload button
            _build3DButton(
              label: _isUploading
                  ? 'MENGUPLOAD...'
                  : 'UPLOAD ${_queue.length} FILE',
              icon: _isUploading
                  ? Icons.hourglass_top_rounded
                  : Icons.cloud_upload_rounded,
              onPressed: _isUploading || _queue.isEmpty ? null : _uploadAll,
              color: upRed,
              loading: _isUploading,
            ),
            const SizedBox(height: 10),

            // Clear queue
            if (_queue.isNotEmpty)
              GestureDetector(
                onTap: _isUploading ? null : _clearQueue,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        upTextSub.withOpacity(0.2),
                        upTextSub.withOpacity(0.08),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: upTextSub.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.clear_all_rounded,
                          color: upTextSub, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        'KOSONGKAN QUEUE',
                        style: TextStyle(
                          color: upTextSub,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPickCard({
    required IconData icon,
    required String label,
    required String sub,
    required Color color,
    required VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: onTap != null
              ? LinearGradient(
                  colors: [
                    color,
                    Color.lerp(color, Colors.black, 0.5)!,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    upTextSub.withOpacity(0.2),
                    upTextSub.withOpacity(0.08),
                  ],
                ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: onTap != null
                ? upBorderDark
                : upTextSub.withOpacity(0.3),
            width: 2.5,
          ),
          boxShadow: onTap != null
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.5),
                    blurRadius: 14,
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: onTap != null
                  ? Colors.white
                  : upTextSub.withOpacity(0.5),
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: onTap != null
                    ? Colors.white
                    : upTextSub.withOpacity(0.5),
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                fontSize: 12,
                letterSpacing: 1.2,
                shadows: onTap != null
                    ? const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              sub,
              style: TextStyle(
                color: onTap != null
                    ? Colors.white70
                    : upTextSub.withOpacity(0.4),
                fontSize: 9,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── QUEUE SECTION ──────────────────────────────────────────
  Widget _buildQueueSection() {
    return _bevelBox(
      radius: 18,
      glow: upBlue,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [upBlue, Color.lerp(upBlue, Colors.black, 0.4)!],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: upBorderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: upBlue.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Icon(Icons.inbox_rounded,
                      color: Colors.white, size: 12),
                ),
                const SizedBox(width: 8),
                Text(
                  'QUEUE (${_queue.length})',
                  style: TextStyle(
                    color: upTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ..._queue.asMap().entries.map((entry) {
              return _buildQueueItem(entry.key, entry.value);
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildQueueItem(int index, UploadItem item) {
    Color statusColor;
    IconData statusIcon;
    switch (item.status) {
      case UploadStatus.pending:
        statusColor = upTextSub;
        statusIcon = Icons.schedule_rounded;
        break;
      case UploadStatus.uploading:
        statusColor = upBlue;
        statusIcon = Icons.cloud_upload_rounded;
        break;
      case UploadStatus.success:
        statusColor = upGreen;
        statusIcon = Icons.check_circle_rounded;
        break;
      case UploadStatus.error:
        statusColor = upRed;
        statusIcon = Icons.error_rounded;
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [upBgSurface, upBgMain],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: statusColor.withOpacity(0.4),
          width: 1.5,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: statusColor.withOpacity(0.5), width: 1),
                ),
                child: Icon(
                  _iconForFile(item.fileName),
                  color: statusColor,
                  size: 14,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.fileName,
                      style: TextStyle(
                        color: upTextMain,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _formatBytes(item.fileSize),
                      style: TextStyle(
                        color: upTextSub,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              Icon(statusIcon, color: statusColor, size: 18),
              const SizedBox(width: 6),
              if (item.status == UploadStatus.pending ||
                  item.status == UploadStatus.error)
                GestureDetector(
                  onTap: () => _removeFromQueue(index),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: upRed.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.close_rounded,
                        color: upRed, size: 14),
                  ),
                ),
            ],
          ),
          if (item.status == UploadStatus.uploading) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: item.progress,
                minHeight: 4,
                backgroundColor: upBgMain,
                valueColor: AlwaysStoppedAnimation(upBlue),
              ),
            ),
          ],
          if (item.status == UploadStatus.error && item.error != null) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: upRed.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '❌ ${item.error}',
                style: TextStyle(
                  color: upRed,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
          if (item.status == UploadStatus.success && item.url != null) ...[
            const SizedBox(height: 10),
            _buildUrlActions(item.url!, item.fileName),
          ],
        ],
      ),
    );
  }

  // ─── URL ACTIONS (copy, open, share) ────────────────────────
  Widget _buildUrlActions(String url, String fileName) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: upGreen.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: upGreen.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.link_rounded, color: upGreen, size: 12),
              const SizedBox(width: 6),
              Expanded(
                child: SelectableText(
                  url,
                  style: TextStyle(
                    color: upGreen,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: _buildSmallBtn(
                  icon: Icons.copy_rounded,
                  label: 'COPY',
                  color: upBlue,
                  onTap: () => _copyUrl(url),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _buildSmallBtn(
                  icon: Icons.open_in_new_rounded,
                  label: 'BUKA',
                  color: upGold,
                  onTap: () => _openUrl(url),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _buildSmallBtn(
                  icon: Icons.share_rounded,
                  label: 'SHARE',
                  color: upPurple,
                  onTap: () => _shareUrl(url, fileName),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSmallBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
          ),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: upBorderDark, width: 1.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 11),
            const SizedBox(width: 3),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── HISTORY SECTION ────────────────────────────────────────
  Widget _buildHistorySection() {
    return _bevelBox(
      radius: 18,
      glow: upGreen,
      glowOpacity: 0.3,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        upGreen,
                        Color.lerp(upGreen, Colors.black, 0.4)!,
                      ],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: upBorderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: upGreen.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Icon(Icons.history_rounded,
                      color: Colors.white, size: 12),
                ),
                const SizedBox(width: 8),
                Text(
                  'HISTORY (${_history.length})',
                  style: TextStyle(
                    color: upTextMain,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (_isLoadingHistory)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Center(
                  child: CircularProgressIndicator(color: upGold),
                ),
              )
            else if (_history.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: upGold.withOpacity(0.1),
                        border: Border.all(
                          color: upGold.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        Icons.inbox_rounded,
                        size: 32,
                        color: upGold.withOpacity(0.7),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Belum ada history',
                      style: TextStyle(
                        color: upTextMain,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Upload file untuk mulai',
                      style: TextStyle(
                        color: upTextSub,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              )
            else
              ..._history.take(20).map((item) => _buildHistoryItem(item)),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryItem(UploadItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [upBgSurface, upBgMain],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: upGreen.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: upGreen.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: upGreen.withOpacity(0.4), width: 1),
                ),
                child: Icon(
                  _iconForFile(item.fileName),
                  color: upGreen,
                  size: 12,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.fileName,
                      style: TextStyle(
                        color: upTextMain,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          _formatBytes(item.fileSize),
                          style: TextStyle(
                            color: upTextSub,
                            fontSize: 9,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(width: 6),
                        if (item.uploadedAt != null)
                          Text(
                            '• ${_formatTime(item.uploadedAt!)}',
                            style: TextStyle(
                              color: upTextSub.withOpacity(0.7),
                              fontSize: 9,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              if (item.url != null) ...[
                GestureDetector(
                  onTap: () => _copyUrl(item.url!),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    margin: const EdgeInsets.only(left: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [upBlue, Color.lerp(upBlue, Colors.black, 0.4)!],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: upBorderDark, width: 1.5),
                    ),
                    child: Icon(Icons.copy_rounded,
                        color: Colors.white, size: 11),
                  ),
                ),
                GestureDetector(
                  onTap: () => _openUrl(item.url!),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    margin: const EdgeInsets.only(left: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [upGold, Color.lerp(upGold, Colors.black, 0.4)!],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: upBorderDark, width: 1.5),
                    ),
                    child: Icon(Icons.open_in_new_rounded,
                        color: upRedDark, size: 11),
                  ),
                ),
                GestureDetector(
                  onTap: () => _downloadToLocal(item),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    margin: const EdgeInsets.only(left: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          upGreen,
                          Color.lerp(upGreen, Colors.black, 0.4)!,
                        ],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: upBorderDark, width: 1.5),
                    ),
                    child: Icon(Icons.download_rounded,
                        color: Colors.white, size: 11),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes}m lalu';
    if (diff.inDays < 1) return '${diff.inHours}j lalu';
    if (diff.inDays < 7) return '${diff.inDays}h lalu';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}