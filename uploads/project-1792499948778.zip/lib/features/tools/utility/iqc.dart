// lib/features/tools/utility/iqc.dart
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import '../../dashboard/xtheme.dart';

// ─── XTHEME-DRIVEN COLORS ────────────────────────────────────────────
Color iqcBgMain = const Color(0xFF160A07);
Color iqcBgSurface = const Color(0xFF2A140E);
Color iqcBgCard = const Color(0xFF3A1E15);
Color iqcTextMain = const Color(0xFFF3E6DD);
Color iqcTextSub = const Color(0xFFC9913F);
Color iqcGold = const Color(0xFFD4A853);
Color iqcRed = const Color(0xFFB71C1C);
Color iqcRedDark = const Color(0xFF7F0000);
Color iqcRedDeep = const Color(0xFF4A0000);
Color iqcGreen = const Color(0xFF4CAF50);
Color iqcBlue = const Color(0xFF2196F3);
Color iqcBorderDark = const Color(0xFF1A0505);

void applyXTheme(XThemeData theme) {
  iqcBgMain     = theme.brownDark;
  iqcBgSurface  = Color.lerp(theme.brownMid, theme.brownDark, 0.55)!;
  iqcBgCard     = theme.brownMid;
  iqcTextMain   = theme.bgCreamLight;
  iqcTextSub    = theme.gold;
  iqcGold       = theme.gold;
  iqcRed        = theme.redMain;
  iqcRedDark    = theme.redDark;
  iqcRedDeep    = theme.redDeep;
  iqcGreen      = theme.accentGreen;
  iqcBlue       = theme.accentBlue;
  iqcBorderDark = theme.borderDark;
}

class IQCScreen extends StatefulWidget {
  const IQCScreen({super.key});

  @override
  State<IQCScreen> createState() => _IQCScreenState();
}

class _IQCScreenState extends State<IQCScreen> {
  // ── Controllers ────────────────────────────────────────────────
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _chatTimeController = TextEditingController();
  final TextEditingController _statusBarTimeController =
      TextEditingController();
  final TextEditingController _carrierController =
      TextEditingController(text: 'Telkomsel');
  final TextEditingController _batteryController =
      TextEditingController(text: '87');

  // ── GlobalKey untuk capture ────────────────────────────────────
  final GlobalKey _previewKey = GlobalKey();

  // ── State ──────────────────────────────────────────────────────
  Uint8List? _generatedImage;
  bool _isGenerating = false;
  bool _isSaving = false;
  bool _isSharing = false;
  String? _errorMessage;
  bool _bubbleOnRight = false;
  bool _showCarrier = true;

  final XThemeController _themeController = XThemeController();

  @override
  void initState() {
    super.initState();
    final timeFormat = DateFormat('HH:mm');
    final now = DateTime.now();
    _chatTimeController.text = timeFormat.format(now);
    _statusBarTimeController.text = timeFormat.format(now);
    _textController.text = 'ERLAN OFFICIAL';
  }

  @override
  void dispose() {
    _textController.dispose();
    _chatTimeController.dispose();
    _statusBarTimeController.dispose();
    _carrierController.dispose();
    _batteryController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // VALIDASI
  // ═══════════════════════════════════════════════════════════════════
  bool _isValidTime(String time) {
    return RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$').hasMatch(time);
  }

  // ═══════════════════════════════════════════════════════════════════
  // GENERATE — capture widget jadi PNG
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _generateIQCImage() async {
    if (_textController.text.trim().isEmpty) {
      _showError('Masukkan teks chat terlebih dahulu');
      return;
    }
    if (!_isValidTime(_chatTimeController.text)) {
      _showError('Format waktu chat salah (HH:mm)');
      return;
    }
    if (!_isValidTime(_statusBarTimeController.text)) {
      _showError('Format waktu status bar salah (HH:mm)');
      return;
    }

    setState(() {
      _isGenerating = true;
      _errorMessage = null;
      _generatedImage = null;
    });

    await Future.delayed(const Duration(milliseconds: 300));

    try {
      final boundary = _previewKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) throw 'Preview belum siap';

      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw 'Gagal capture gambar';

      setState(() {
        _generatedImage = byteData.buffer.asUint8List();
      });
      _showSuccess('✅ Screenshot berhasil dibuat!');
    } catch (e) {
      setState(() => _errorMessage = 'Gagal generate: $e');
      _showError(_errorMessage!);
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SAVE TO STORAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _saveImage() async {
    if (_generatedImage == null) {
      _showError('Tidak ada gambar untuk disimpan');
      return;
    }

    setState(() => _isSaving = true);

    try {
      Directory? directory;
      if (Platform.isAndroid) {
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        directory = await getApplicationDocumentsDirectory();
      }

      if (directory == null) throw 'Tidak bisa akses folder';

      final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final safeText = _textController.text
          .replaceAll(RegExp(r'[^\w\s]'), '')
          .replaceAll(' ', '_');
      final fileName = 'iqc_${safeText}_$timestamp.png';
      final file = File('${directory.path}/$fileName');

      await file.writeAsBytes(_generatedImage!);

      _showSuccess('✅ Disimpan: ${file.path}');
      if (mounted) _showSaveSuccessDialog(file.path, fileName);
    } catch (e) {
      _showError('❌ Gagal menyimpan: $e');
    } finally {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) setState(() => _isSaving = false);
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SHARE IMAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _shareImage() async {
    if (_generatedImage == null) return;

    setState(() => _isSharing = true);

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/iqc_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Screenshot Chat iPhone',
      );
    } catch (e) {
      _showError('❌ Error sharing: $e');
    } finally {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) setState(() => _isSharing = false);
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // COPY TO CLIPBOARD
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _showSuccess('📋 Disalin!');
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(
            color: iqcTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: iqcGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: iqcBorderDark, width: 2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(
            color: iqcTextMain,
            fontWeight: FontWeight.w700,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: iqcRed,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: iqcBorderDark, width: 2),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSaveSuccessDialog(String filePath, String fileName) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: _bevelBox(
          radius: 20,
          glow: iqcGreen,
          glowOpacity: 0.4,
          child: Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [iqcGreen, Color.lerp(iqcGreen, Colors.black, 0.4)!],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: iqcBorderDark, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: iqcGreen.withOpacity(0.5),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.check_rounded,
                          color: Colors.white, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Gambar Disimpan!',
                      style: TextStyle(
                        color: iqcTextMain,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        shadows: const [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Lokasi file:',
                  style: TextStyle(
                    color: iqcTextSub,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [iqcBgSurface, iqcBgMain],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: iqcGold.withOpacity(0.5), width: 1.5),
                  ),
                  child: Text(
                    fileName,
                    style: TextStyle(
                      color: iqcGold,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          _copyToClipboard(filePath);
                          Navigator.pop(context);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [iqcBlue, Color.lerp(iqcBlue, Colors.black, 0.4)!],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: iqcBorderDark, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              'COPY PATH',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [iqcRed, iqcRedDark],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: iqcBorderDark, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              'OK',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D HELPERS
  // ═══════════════════════════════════════════════════════════════════
  BoxDecoration _bevelDecoration({
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          iqcTextMain.withOpacity(0.20),
          iqcRed.withOpacity(0.15),
          Colors.black.withOpacity(0.55),
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.75),
          blurRadius: 22,
          spreadRadius: -6,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
        BoxShadow(
          color: (glow ?? iqcGold).withOpacity(glowOpacity),
          blurRadius: 26,
          spreadRadius: -8,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _bevelBox({
    required Widget child,
    double radius = 18,
    Color? glow,
    double glowOpacity = 0.25,
  }) {
    return Container(
      decoration: _bevelDecoration(
          radius: radius, glow: glow, glowOpacity: glowOpacity),
      padding: const EdgeInsets.all(1.6),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 1),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [iqcBgCard, iqcBgMain],
          ),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        applyXTheme(_themeController.currentTheme);

        return Scaffold(
          backgroundColor: iqcBgMain,
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.5, -0.8),
                radius: 1.4,
                colors: [
                  Color.lerp(iqcBgMain, iqcRed, 0.25)!,
                  iqcBgMain,
                  Colors.black,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInputSection(),
                          const SizedBox(height: 16),
                          if (_errorMessage != null) _buildErrorCard(),
                          const SizedBox(height: 16),
                          _buildPreviewSection(),
                          const SizedBox(height: 16),
                          if (_generatedImage != null) _buildResultSection(),
                          const SizedBox(height: 16),
                          _buildExamplesSection(),
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // APP BAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 12, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [iqcBgSurface, iqcBgMain],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: iqcGold.withOpacity(0.4), width: 2),
        ),
        boxShadow: [
          const BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 4),
          ),
          BoxShadow(color: iqcGold.withOpacity(0.25), blurRadius: 18),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [iqcRed, iqcRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: iqcBorderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [iqcRed, iqcRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: iqcBorderDark, width: 2.5),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(color: iqcGold.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.phone_iphone_rounded,
                      color: iqcGold, size: 16),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'IQC SCREENSHOT',
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 3,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Tombol Info
          GestureDetector(
            onTap: () => _showInfoDialog(),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [iqcRed, iqcRedDark],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: iqcBorderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.info_outline,
                  color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: _bevelBox(
          radius: 20,
          glow: iqcGold,
          glowOpacity: 0.4,
          child: Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [iqcGold, Color.lerp(iqcGold, Colors.black, 0.4)!],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: iqcBorderDark, width: 2.5),
                    boxShadow: [
                      BoxShadow(
                        color: iqcGold.withOpacity(0.5),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: Icon(Icons.info_outline_rounded,
                      color: iqcRedDark, size: 26),
                ),
                const SizedBox(height: 16),
                Text(
                  'TENTANG',
                  style: TextStyle(
                    color: iqcTextMain,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 3,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Screen Shot WhatsApp iPhone\n\n'
                  'Mode OFFLINE — semua gambar dirender di HP sendiri.\n\n'
                  'Tidak butuh internet.\n'
                  'Hasil PNG kualitas tinggi (3x pixel ratio).',
                  style: TextStyle(
                    color: iqcTextSub,
                    fontSize: 12,
                    height: 1.6,
                    fontFamily: 'ShareTechMono',
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [iqcRed, iqcRedDark],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: iqcBorderDark, width: 2),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: const Text(
                      'TUTUP',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT SECTION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputSection() {
    return _bevelBox(
      radius: 20,
      glow: iqcGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('KONFIGURASI CHAT', Icons.tune_rounded),
            const SizedBox(height: 16),

            // ── Text Chat ──
            _buildInputField(
              label: 'Teks Chat',
              controller: _textController,
              hint: 'Masukkan teks chat...',
              maxLines: 3,
              icon: Icons.chat_bubble_outline_rounded,
            ),
            const SizedBox(height: 14),

            // ── Waktu chat & status bar ──
            Row(
              children: [
                Expanded(
                  child: _buildInputField(
                    label: 'Waktu Chat',
                    controller: _chatTimeController,
                    hint: 'HH:mm',
                    icon: Icons.schedule_rounded,
                    isTime: true,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildInputField(
                    label: 'Status Bar',
                    controller: _statusBarTimeController,
                    hint: 'HH:mm',
                    icon: Icons.access_time_rounded,
                    isTime: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // ── Carrier & Battery ──
            if (_showCarrier) ...[
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: _buildInputField(
                      label: 'Operator',
                      controller: _carrierController,
                      hint: 'Telkomsel',
                      icon: Icons.signal_cellular_alt_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 1,
                    child: _buildInputField(
                      label: 'Baterai %',
                      controller: _batteryController,
                      hint: '87',
                      icon: Icons.battery_full_rounded,
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
            ],

            // ── Bubble position toggle ──
            Row(
              children: [
                Expanded(
                  child: _buildToggleChip(
                    label: 'Bubble Kiri',
                    icon: Icons.format_align_left_rounded,
                    isActive: !_bubbleOnRight,
                    onTap: () => setState(() => _bubbleOnRight = false),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildToggleChip(
                    label: 'Bubble Kanan',
                    icon: Icons.format_align_right_rounded,
                    isActive: _bubbleOnRight,
                    onTap: () => setState(() => _bubbleOnRight = true),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // ── Carrier toggle ──
            Row(
              children: [
                Expanded(
                  child: _buildToggleChip(
                    label: 'Tampilkan Operator',
                    icon: _showCarrier
                        ? Icons.visibility_rounded
                        : Icons.visibility_off_rounded,
                    isActive: _showCarrier,
                    onTap: () => setState(() => _showCarrier = !_showCarrier),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // ── Generate button ──
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [iqcRed, Color.lerp(iqcRed, Colors.black, 0.5)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: iqcRed.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isGenerating ? null : _generateIQCImage,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: iqcBorderDark, width: 2.5),
                  ),
                ),
                child: _isGenerating
                    ? const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: Colors.white,
                          ),
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.auto_awesome_rounded,
                              color: Colors.white, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'BUAT SCREENSHOT',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [iqcGold, Color.lerp(iqcGold, Colors.black, 0.4)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: iqcBorderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: iqcRedDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: TextStyle(
            color: iqcTextMain,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 3,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    String hint = '',
    IconData? icon,
    bool isTime = false,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: iqcTextSub,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [iqcBgSurface, iqcBgMain],
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: iqcGold.withOpacity(0.5), width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: TextField(
            controller: controller,
            onChanged: (_) => setState(() {}),
            keyboardType: keyboardType,
            maxLines: maxLines,
            style: TextStyle(
              color: iqcTextMain,
              fontSize: 13,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w600,
            ),
            cursorColor: iqcGold,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle:
                  TextStyle(color: iqcTextSub.withOpacity(0.5), fontSize: 12),
              prefixIcon: icon != null
                  ? Icon(icon, color: iqcGold, size: 16)
                  : null,
              suffixIcon: isTime
                  ? GestureDetector(
                      onTap: () {
                        final now = DateTime.now();
                        controller.text = DateFormat('HH:mm').format(now);
                        setState(() {});
                      },
                      child: Container(
                        margin: const EdgeInsets.all(6),
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [iqcGold, Color.lerp(iqcGold, Colors.black, 0.4)!],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(color: iqcBorderDark, width: 1.5),
                        ),
                        child: Icon(Icons.refresh_rounded,
                            color: iqcRedDark, size: 12),
                      ),
                    )
                  : null,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildToggleChip({
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          gradient: isActive
              ? LinearGradient(
                  colors: [iqcRed, iqcRedDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [iqcBgSurface, iqcBgMain],
                ),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isActive ? iqcGold : iqcGold.withOpacity(0.3),
            width: isActive ? 2.5 : 1.5,
          ),
          boxShadow: isActive
              ? [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: iqcGold.withOpacity(0.4),
                    blurRadius: 10,
                  ),
                ]
              : const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? iqcGold : iqcTextSub,
              size: 14,
            ),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  color: isActive ? Colors.white : iqcTextSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ERROR CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return _bevelBox(
      radius: 16,
      glow: iqcRed,
      glowOpacity: 0.4,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: iqcGold, width: 1.5),
              ),
              child: Icon(Icons.error_outline_rounded,
                  color: iqcGold, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _errorMessage!,
                style: TextStyle(
                  color: iqcTextMain,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PREVIEW SECTION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPreviewSection() {
    return _bevelBox(
      radius: 20,
      glow: iqcGold,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _buildSectionLabel('PREVIEW LIVE', Icons.preview_rounded),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        iqcGreen.withOpacity(0.3),
                        iqcGreen.withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: iqcGreen.withOpacity(0.5)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: iqcGreen,
                          boxShadow: [
                            BoxShadow(
                              color: iqcGreen,
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 5),
                      Text(
                        'LIVE',
                        style: TextStyle(
                          color: iqcGreen,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Center(
              child: RepaintBoundary(
                key: _previewKey,
                child: _buildIphonePreview(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // iPhone PREVIEW WIDGET (yang di-capture)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildIphonePreview() {
    final bubbleAlignment =
        _bubbleOnRight ? Alignment.centerRight : Alignment.centerLeft;

    return Container(
      width: 340,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Status Bar ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              children: [
                Text(
                  _statusBarTimeController.text,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                ),
                if (_showCarrier && _carrierController.text.isNotEmpty) ...[
                  const SizedBox(width: 6),
                  Text(
                    _carrierController.text,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
                const Spacer(),
                // Signal bars
                Row(
                  children: List.generate(
                    4,
                    (i) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 0.7),
                      width: 3,
                      height: 4.0 + (i * 2.5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(1),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 5),
                const Icon(Icons.wifi, color: Colors.white, size: 12),
                const SizedBox(width: 5),
                // Battery with percentage
                Row(
                  children: [
                    if (_batteryController.text.isNotEmpty)
                      Text(
                        '${_batteryController.text}%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    const SizedBox(width: 3),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 2, vertical: 1),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white70, width: 1),
                        borderRadius: BorderRadius.circular(3),
                      ),
                      child: Container(
                        width: 18,
                        height: 8,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(1),
                        ),
                      ),
                    ),
                    const SizedBox(width: 1),
                    Container(
                      width: 1.5,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white70,
                        borderRadius: BorderRadius.circular(1),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ── Chat bubble ──
          Align(
            alignment: bubbleAlignment,
            child: Container(
              constraints: const BoxConstraints(maxWidth: 240),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: _bubbleOnRight
                    ? const BorderRadius.only(
                        topLeft: Radius.circular(18),
                        topRight: Radius.circular(18),
                        bottomRight: Radius.circular(4),
                        bottomLeft: Radius.circular(18),
                      )
                    : const BorderRadius.only(
                        topLeft: Radius.circular(18),
                        topRight: Radius.circular(18),
                        bottomRight: Radius.circular(18),
                        bottomLeft: Radius.circular(4),
                      ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 4,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: Text(
                _textController.text.isEmpty
                    ? 'ERLAN OFFICIAL'
                    : _textController.text,
                style: const TextStyle(
                  color: Color(0xFF1A1A1A),
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  height: 1.3,
                ),
              ),
            ),
          ),

          // ── Chat time ──
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 8, right: 8),
            child: Align(
              alignment: bubbleAlignment,
              child: Text(
                _chatTimeController.text,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 10,
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ── Fake input bar ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF1C1C1E),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: Colors.white.withOpacity(0.15), width: 0.5),
            ),
            child: Row(
              children: [
                Icon(Icons.add_circle_outline,
                    color: Colors.white.withOpacity(0.4), size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      'Pesan',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Icon(Icons.mic_none_rounded,
                    color: Colors.white.withOpacity(0.4), size: 18),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // ── Home indicator ──
          Center(
            child: Container(
              width: 110,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.6),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULT SECTION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResultSection() {
    return _bevelBox(
      radius: 20,
      glow: iqcGreen,
      glowOpacity: 0.35,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('HASIL SCREENSHOT', Icons.image_rounded),
            const SizedBox(height: 14),

            // Result image
            Container(
              width: double.infinity,
              constraints: const BoxConstraints(maxHeight: 400),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: iqcGold, width: 2),
                boxShadow: [
                  const BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: iqcGold.withOpacity(0.4),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.memory(
                  _generatedImage!,
                  fit: BoxFit.contain,
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Info
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '📦 ${(_generatedImage!.lengthInBytes / 1024).toStringAsFixed(1)} KB',
                  style: TextStyle(
                    color: iqcTextSub,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  '🕐 ${DateFormat('HH:mm:ss').format(DateTime.now())}',
                  style: TextStyle(
                    color: iqcTextSub,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Action buttons
            Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    label: 'SIMPAN',
                    icon: Icons.save_alt_rounded,
                    color: iqcGreen,
                    onTap: _isSaving ? null : _saveImage,
                    loading: _isSaving,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildActionButton(
                    label: 'SHARE',
                    icon: Icons.share_rounded,
                    color: iqcBlue,
                    onTap: _isSharing ? null : _shareImage,
                    loading: _isSharing,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    label: 'REGENERATE',
                    icon: Icons.refresh_rounded,
                    color: iqcRed,
                    onTap: _generateIQCImage,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildActionButton(
                    label: 'CLEAR',
                    icon: Icons.delete_outline_rounded,
                    color: iqcRedDeep,
                    onTap: () {
                      setState(() {
                        _generatedImage = null;
                        _errorMessage = null;
                      });
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback? onTap,
    bool loading = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.5)!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: iqcBorderDark, width: 2),
          boxShadow: [
            const BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(3, 3),
            ),
            BoxShadow(
              color: color.withOpacity(0.4),
              blurRadius: 10,
            ),
          ],
        ),
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.8,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // EXAMPLES SECTION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildExamplesSection() {
    return _bevelBox(
      radius: 18,
      glow: iqcGold,
      glowOpacity: 0.25,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionLabel('CONTOH CEPAT', Icons.bolt_rounded),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildExampleChip('Malam minggu yuk', '20:00', '20:05'),
                _buildExampleChip('Besok ketemuan dimana?', '15:30', '15:45'),
                _buildExampleChip('Lagi apa?', '21:15', '21:20'),
                _buildExampleChip('Udah makan belum?', '12:00', '12:10'),
                _buildExampleChip('Iya nanti aku kabari', '18:22', '18:30'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExampleChip(
      String text, String chatTime, String statusBarTime) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _textController.text = text;
          _chatTimeController.text = chatTime;
          _statusBarTimeController.text = statusBarTime;
        });
        _showSuccess('✅ Contoh diterapkan');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [iqcBgSurface, iqcBgMain],
          ),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: iqcGold.withOpacity(0.4), width: 1.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text.length > 22 ? '${text.substring(0, 22)}...' : text,
              style: TextStyle(
                color: iqcTextMain,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$chatTime | $statusBarTime',
              style: TextStyle(
                color: iqcTextSub,
                fontSize: 9,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }
}