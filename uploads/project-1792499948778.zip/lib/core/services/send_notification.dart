// lib/core/services/send_notification.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config/apiBaseUrl.dart';

// Sesuaikan path ini dengan lokasi xtheme.dart kamu
import '../../features/dashboard/xtheme.dart';

class SendNotificationPage extends StatefulWidget {
  final String sessionKey;

  const SendNotificationPage({super.key, required this.sessionKey});

  @override
  State<SendNotificationPage> createState() => _SendNotificationPageState();
}

class _SendNotificationPageState extends State<SendNotificationPage> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  bool _isLoading = false;

  // Controller tema (singleton)
  final XThemeController _themeController = XThemeController();

Future<void> _sendBroadcastNotification() async {
  final title = _titleController.text.trim();
  final message = _messageController.text.trim();

  if (title.isEmpty || message.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Judul dan pesan tidak boleh kosong!")),
    );
    return;
  }

  setState(() => _isLoading = true);

  try {
    // Kirim pesan ke API backend untuk disimpan di DB/Memory Server
    final response = await http.post(
      Uri.parse('$apiBaseUrl/api/postNotification'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'key': widget.sessionKey,
        'title': title,
        'body': message,
      }),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['status'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("🚀 Notifikasi broadcast berhasil diterbitkan!")),
      );
      _titleController.clear();
      _messageController.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("⚠️ Gagal: ${data['message'] ?? 'Server Error'}")),
      );
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("❌ Terjadi kesalahan koneksi: $e")),
    );
  } finally {
    setState(() => _isLoading = false);
  }
}

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final theme = _themeController.currentTheme;

        return Scaffold(
          backgroundColor: theme.brownDark,
          extendBodyBehindAppBar: true,

          // ─── APP BAR 3D ───
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(70),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.redMain, theme.redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border(
                  bottom: BorderSide(color: theme.borderDark, width: 3),
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 12,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: SafeArea(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Tombol back 3D
                    Positioned(
                      left: 8,
                      child: Builder(
                        builder: (ctx) => GestureDetector(
                          onTap: () => Navigator.of(ctx).maybePop(),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.redMain, theme.redDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: theme.borderDark, width: 2),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(2, 2),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Judul 3D
                    Positioned(
                      left: 56,
                      right: 56,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [theme.redMain, theme.redDark],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: theme.borderDark, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.campaign_rounded,
                              color: theme.gold,
                              size: 16,
                              shadows: const [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 3,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                            const SizedBox(width: 6),
                            const Flexible(
                              child: Text(
                                "BROADCAST NOTIF",
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5,
                                  shadows: [
                                    Shadow(
                                      color: Color(0x99000000),
                                      blurRadius: 2,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Ikon kanan
                    Positioned(
                      right: 16,
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [theme.goldLight, theme.gold, theme.goldDark],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: theme.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                            BoxShadow(
                              color: Color(0x66000000),
                              blurRadius: 8,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.notifications_active_rounded,
                          color: theme.redDark,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [theme.brownDark, theme.redDeep, theme.brownDark],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: Stack(
              children: [
                // Radial glow atas
                Positioned(
                  top: -100,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 350,
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.topCenter,
                        radius: 1.0,
                        colors: [
                          theme.redMain.withOpacity(0.18),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                SafeArea(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // ─── HEADER CARD ───
                        _buildHeaderCard(theme),
                        const SizedBox(height: 24),

                        // ─── JUDUL FIELD ───
                        _buildFieldLabel(
                          theme: theme,
                          icon: Icons.title_rounded,
                          label: "JUDUL NOTIFIKASI",
                        ),
                        const SizedBox(height: 8),
                        _buildInputField(
                          theme: theme,
                          controller: _titleController,
                          hintText: "Contoh: Halo Pengguna ATLAS!",
                          icon: Icons.edit_rounded,
                          maxLines: 1,
                        ),
                        const SizedBox(height: 20),

                        // ─── PESAN FIELD ───
                        _buildFieldLabel(
                          theme: theme,
                          icon: Icons.message_rounded,
                          label: "PESAN NOTIFIKASI",
                        ),
                        const SizedBox(height: 8),
                        _buildInputField(
                          theme: theme,
                          controller: _messageController,
                          hintText: "Contoh: Hai, ada fitur baru nih di aplikasi...",
                          icon: Icons.article_rounded,
                          maxLines: 5,
                        ),
                        const SizedBox(height: 28),

                        // ─── TOMBOL KIRIM 3D ───
                        _buildSendButton(theme),
                        const SizedBox(height: 16),

                        // ─── INFO CARD ───
                        _buildInfoCard(theme),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎯 HEADER CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeaderCard(XThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.redMain, theme.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: theme.borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Color(0x66000000),
                  blurRadius: 10,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Icon(
              Icons.campaign_rounded,
              color: theme.gold,
              size: 30,
              shadows: const [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 4,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "BROADCAST PUSH",
                  style: TextStyle(
                    color: theme.redDark,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Color(0x33000000),
                        blurRadius: 3,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Kirim notifikasi ke semua pengguna ATLAS secara instan.",
                  style: TextStyle(
                    color: theme.brownMid,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📝 FIELD LABEL
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFieldLabel({
    required XThemeData theme,
    required IconData icon,
    required String label,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.redMain, theme.redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: theme.borderDark, width: 1.8),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: theme.gold, size: 13),
        ),
        const SizedBox(width: 10),
        Text(
          label,
          style: TextStyle(
            color: theme.bgCreamLight,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: const [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 3,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ⌨️ INPUT FIELD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputField({
    required XThemeData theme,
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    required int maxLines,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: TextStyle(
          color: theme.textDark,
          fontSize: 14,
          fontWeight: FontWeight.w700,
          fontFamily: 'ShareTechMono',
        ),
        cursorColor: theme.redMain,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(
            color: theme.brownMid.withOpacity(0.5),
            fontSize: 13,
            fontFamily: 'ShareTechMono',
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.redMain, theme.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: theme.borderDark, width: 1.8),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Icon(icon, color: theme.gold, size: 16),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🚀 TOMBOL KIRIM 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSendButton(XThemeData theme) {
    return GestureDetector(
      onTap: _isLoading ? null : _sendBroadcastNotification,
      child: Container(
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.redMain, theme.redDark, theme.redDeep],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(5, 5),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 16,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Center(
          child: _isLoading
              ? SizedBox(
                  height: 24,
                  width: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation<Color>(theme.gold),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.send_rounded,
                      color: theme.gold,
                      size: 20,
                      shadows: const [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      "KIRIM KE SEMUA USER",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 4,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ℹ️ INFO CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard(XThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.bgCreamLight, theme.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.goldLight, theme.gold, theme.goldDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: theme.borderDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Icon(
              Icons.info_outline_rounded,
              color: theme.redDark,
              size: 16,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              "Notifikasi akan langsung diterbitkan dan disinkronkan ke semua pengguna ATLAS.",
              style: TextStyle(
                color: theme.brownMid,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}