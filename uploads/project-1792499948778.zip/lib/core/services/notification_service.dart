import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/apiBaseUrl.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  // Inisialisasi Notifikasi Lokal
  static Future<void> init() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
    );

    await _localNotifications.initialize(initSettings);

    // Buat Notification Channel untuk Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'atlas_broadcast_channel',
      'Informasi ATLAS',
      description: 'Channel notifikasi update dan informasi ATLAS',
      importance: Importance.max,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    debugPrint("🟢 NotificationService (Local) Berhasil Diinisialisasi");
  }

  // Fungsi Tampilkan Notifikasi Langsung
  static Future<void> showNotification({
    required int id,
    required String title,
    required String body,
  }) async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'atlas_broadcast_channel',
      'Informasi ATLAS',
      channelDescription: 'Channel notifikasi update dan informasi ATLAS',
      importance: Importance.max,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
    );

    await _localNotifications.show(id, title, body, details);
  }

  // Fungsi Pengecekan Notifikasi Terbaru ke Server (Polling)
  static Future<void> checkServerNotification() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/latestNotification'),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is Map<String, dynamic> && data['status'] == true) {
          final int notifId = data['id'] ?? 1;
          final String title = data['title'] ?? 'Info ATLAS';
          final String body = data['body'] ?? '';

          final prefs = await SharedPreferences.getInstance();
          final int lastSeenId = prefs.getInt('last_notif_id') ?? 0;

          // Jika ada notifikasi ID baru yang belum pernah muncul di HP ini
          if (notifId > lastSeenId && body.isNotEmpty) {
            await showNotification(
              id: notifId,
              title: title,
              body: body,
            );

            // Simpan ID agar tidak memunculkan notifikasi berulang
            await prefs.setInt('last_notif_id', notifId);
            debugPrint("🔔 Notifikasi Baru Ditampilkan: $title");
          }
        }
      }
    } catch (e) {
      debugPrint("⚠️ Gagal mengecek notifikasi dari server: $e");
    }
  }
}
