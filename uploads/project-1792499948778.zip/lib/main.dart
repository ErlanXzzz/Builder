import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:app_links/app_links.dart';
import 'package:video_player/video_player.dart';

import 'features/landing/landing_page.dart';
import 'features/landing/login_page.dart';
import 'features/dashboard/dashboard_page.dart';
import 'features/dashboard/xtheme.dart';
import 'features/dashboard/home_page.dart';
import 'features/dashboard/seller_page.dart';
import 'features/dashboard/admin_page.dart';
import 'features/dashboard/owner_page.dart';
import 'features/dashboard/control_panel.dart';

import 'core/profiders/theme_provider.dart';
import 'core/services/notification_service.dart';
import 'core/config/apiBaseUrl.dart';

import 'features/system/maintance_page.dart';
import 'features/system/update_page.dart';

import 'features/tools/islamic/jadwal_sholat_page.dart';
import 'features/tools/language/kamus_jepang_page.dart';
import 'features/tools/game/dino_game.dart';


// ================================================================
// GLOBAL NAVIGATOR KEY
// ================================================================

final GlobalKey<NavigatorState> navigatorKey =
    GlobalKey<NavigatorState>();


// ================================================================
// MAIN
// ================================================================

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  XThemeController();
  try {
    await NotificationService.init();
  } catch (e, stack) {
    debugPrint(
      "❌ Gagal menginisialisasi NotificationService: $e",
    );
    debugPrint("$stack");
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => ThemeProvider(),
        ),
      ],
      child: const MyApp(),
    ),
  );
}


// ================================================================
// INTRO SPLASH SCREEN
//
// HANYA bertugas:
// 1. Menampilkan video
// 2. Melakukan pengecekan awal
// 3. Setelah itu menyerahkan halaman ke StartupGatePage
//
// TIDAK ADA REALTIME MONITOR DI SINI.
// ================================================================

class IntroSplashScreen extends StatefulWidget {
  const IntroSplashScreen({super.key});

  @override
  State<IntroSplashScreen> createState() =>
      _IntroSplashScreenState();
}

class _IntroSplashScreenState
    extends State<IntroSplashScreen> {

  late VideoPlayerController _controller;

  bool _isNavigated = false;

  Widget? _targetScreen;

  bool _isChecking = false;


  @override
  void initState() {
    super.initState();

    _initVideoAndCheckScreen();
  }


  // ==============================================================
  // INIT VIDEO + CEK SCREEN
  // ==============================================================

  Future<void> _initVideoAndCheckScreen() async {
    _controller = VideoPlayerController.asset(
      'assets/videos/door_intro.mp4',
    );

    try {
      await _controller.initialize();

      if (mounted) {
        setState(() {});
      }

      await _controller.play();
    } catch (e) {
      debugPrint(
        '⚠️ Gagal memuat/memutar video intro: $e',
      );
    }


    // ============================================================
    // CEK KONDISI APLIKASI
    // ============================================================

    await _checkScreen();


    if (!mounted) return;


    // ============================================================
    // LISTENER VIDEO
    // ============================================================

    if (_controller.value.isInitialized) {
      _controller.addListener(
        _videoListener,
      );
    }


    // ============================================================
    // JIKA VIDEO SUDAH SELESAI
    // ============================================================

    if (_controller.value.isInitialized &&
        _controller.value.position >=
            _controller.value.duration) {

      _navigateToNext();
    }


    // ============================================================
    // FALLBACK
    //
    // Kalau video error / terlalu lama,
    // tetap lanjut.
    // ============================================================

    Future.delayed(
      const Duration(seconds: 3),
      () {
        if (!mounted) return;

        if (!_isNavigated) {
          _navigateToNext();
        }
      },
    );
  }


  // ==============================================================
  // VIDEO LISTENER
  // ==============================================================

  void _videoListener() {
    if (!mounted) return;

    if (!_controller.value.isInitialized) {
      return;
    }

    if (_controller.value.position >=
            _controller.value.duration &&
        !_isNavigated) {

      _navigateToNext();
    }
  }


  // ==============================================================
  // CEK SCREEN
  // ==============================================================

  Future<void> _checkScreen() async {
    if (_isChecking) return;

    _isChecking = true;

    try {
      debugPrint(
        '🔍 Melakukan pengecekan awal aplikasi...',
      );

      final screen = await checkInitialScreen();

      if (!mounted) return;

      _targetScreen = screen;

      debugPrint(
        '🔎 Hasil pengecekan: ${screen.runtimeType}',
      );
    } catch (e) {
      debugPrint(
        '❌ Error checkInitialScreen: $e',
      );
    } finally {
      _isChecking = false;
    }
  }


  // ==============================================================
  // NAVIGASI
  // ==============================================================

  void _navigateToNext() {
    if (_isNavigated) return;


    // ------------------------------------------------------------
    // Kalau pengecekan belum selesai,
    // tunggu sampai selesai.
    // ------------------------------------------------------------

    if (_targetScreen == null) {
      _checkScreen().then(
        (_) {
          if (!mounted) return;

          if (_targetScreen != null) {
            _executeNavigation();
          }
        },
      );

      return;
    }


    _executeNavigation();
  }


  // ==============================================================
  // EXECUTE NAVIGATION
  // ==============================================================

  void _executeNavigation() {
    if (_isNavigated) return;

    if (_targetScreen == null) return;

    _isNavigated = true;


    // Stop video
    try {
      _controller.pause();
    } catch (_) {}


    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => StartupGatePage(
          initialScreen: _targetScreen!,
        ),
      ),
    );
  }


  // ==============================================================
  // DISPOSE
  // ==============================================================

  @override
  void dispose() {
    try {
      _controller.removeListener(
        _videoListener,
      );
    } catch (_) {}

    _controller.dispose();

    super.dispose();
  }


  // ==============================================================
  // UI
  // ==============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: GestureDetector(
        behavior: HitTestBehavior.opaque,

        onTap: _navigateToNext,

        child: Center(
          child: _controller.value.isInitialized
              ? AspectRatio(
                  aspectRatio:
                      _controller.value.aspectRatio,

                  child: VideoPlayer(
                    _controller,
                  ),
                )
              : const CircularProgressIndicator(
                  color: Color(0xFF4F46E5),
                ),
        ),
      ),
    );
  }
}


// ================================================================
// STARTUP GATE PAGE
//
// INI SATU-SATUNYA TEMPAT REALTIME MONITOR BERJALAN.
//
// Monitor:
// - Dino
// - Maintenance
// - Update
//
// Setiap kondisi berubah, aplikasi akan mengecek ulang otomatis.
// ================================================================

class StartupGatePage extends StatefulWidget {

  final Widget initialScreen;

  const StartupGatePage({
    super.key,
    required this.initialScreen,
  });

  @override
  State<StartupGatePage> createState() =>
      _StartupGatePageState();
}


class _StartupGatePageState
    extends State<StartupGatePage> {

  late Widget _currentScreen;


  Timer? _retryTimer;

  StreamSubscription<List<ConnectivityResult>>?
      _connectivitySubscription;


  bool _checking = false;


  @override
  void initState() {
    super.initState();

    _currentScreen = widget.initialScreen;

    _startRealtimeMonitor();
  }


  // ==============================================================
  // REALTIME MONITOR
  // ==============================================================

  void _startRealtimeMonitor() {

    // ============================================================
    // 1. DETEKSI PERUBAHAN KONEKSI
    // ============================================================

    _connectivitySubscription =
        Connectivity()
            .onConnectivityChanged
            .listen(
      (results) {

        final bool hasNetwork =
            results.any(
          (result) =>
              result != ConnectivityResult.none,
        );


        if (hasNetwork) {

          debugPrint(
            '🌐 Koneksi terdeteksi kembali.',
          );

          _checkAgain();
        } else {

          debugPrint(
            '📴 Koneksi internet terputus.',
          );
        }
      },
      onError: (error) {
        debugPrint(
          '❌ Connectivity error: $error',
        );
      },
    );


    // ============================================================
    // 2. FALLBACK POLLING
    //
    // Tetap cek setiap 4 detik.
    //
    // Ini penting karena:
    //
    // WiFi tersambung
    // tidak selalu berarti
    // internet/API sudah bisa digunakan.
    // ============================================================

    _retryTimer = Timer.periodic(
      const Duration(seconds: 10), // Cek notifikasi & status setiap 10 detik
      (_) {
      _checkAgain();
      NotificationService.checkServerNotification(); // 👈 Tambahkan baris ini
      },
    );
  }


  // ==============================================================
  // CEK ULANG
  // ==============================================================

  Future<void> _checkAgain() async {

    if (!mounted) return;

    if (_checking) return;


    // ============================================================
    // HANYA MONITOR HALAMAN YANG MEMBUTUHKAN RECOVERY
    // ============================================================

    final bool shouldMonitor =
        _currentScreen is DinoGameApp ||
        _currentScreen is MaintenancePage ||
        _currentScreen is UpdatePage;


    if (!shouldMonitor) {
      return;
    }


    _checking = true;


    try {

      debugPrint(
        '🔄 Realtime: mengecek kondisi aplikasi...',
      );


      final Widget newScreen =
          await checkInitialScreen();


      if (!mounted) return;


      // ==========================================================
      // OFFLINE
      // ==========================================================

      if (newScreen is DinoGameApp) {

        if (_currentScreen is! DinoGameApp) {

          setState(() {
            _currentScreen =
                newScreen;
          });
        }

        debugPrint(
          '🦖 Masih offline.',
        );

        return;
      }


      // ==========================================================
      // MAINTENANCE
      // ==========================================================

      if (newScreen is MaintenancePage) {

        if (_currentScreen is!
            MaintenancePage) {

          setState(() {
            _currentScreen =
                newScreen;
          });
        }

        debugPrint(
          '🚧 Server masih maintenance.',
        );

        return;
      }


      // ==========================================================
      // UPDATE
      // ==========================================================

      if (newScreen is UpdatePage) {

        if (_currentScreen is!
            UpdatePage) {

          setState(() {
            _currentScreen =
                newScreen;
          });
        }

        debugPrint(
          '⬆️ Update masih diperlukan.',
        );

        return;
      }


      // ==========================================================
      // KONDISI SUDAH NORMAL
      // ==========================================================

      debugPrint(
        '✅ Kondisi normal.',
      );

      debugPrint(
        '🚀 Melanjutkan ke ${newScreen.runtimeType}',
      );


      setState(() {
        _currentScreen =
            newScreen;
      });


      // ==========================================================
      // Setelah masuk halaman normal,
      // monitor akan berhenti pada pengecekan berikutnya.
      // ==========================================================

    } catch (e) {

      debugPrint(
        '❌ Error realtime checker: $e',
      );

    } finally {

      _checking = false;
    }
  }


  // ==============================================================
  // DISPOSE
  // ==============================================================

  @override
  void dispose() {

    _retryTimer?.cancel();

    _retryTimer = null;


    _connectivitySubscription?.cancel();

    _connectivitySubscription = null;


    super.dispose();
  }


  // ==============================================================
  // UI
  // ==============================================================

  @override
  Widget build(BuildContext context) {

    return _currentScreen;
  }
}


// ================================================================
// CEK VERSI
// ================================================================

bool isUpdateRequired(
  String currentVersion,
  String serverVersion,
) {

  try {

    final currentParts =
        currentVersion
            .trim()
            .split('.')
            .map(
              (e) => int.parse(e),
            )
            .toList();


    final serverParts =
        serverVersion
            .trim()
            .split('.')
            .map(
              (e) => int.parse(e),
            )
            .toList();


    final maxLength =
        currentParts.length >
                serverParts.length
            ? currentParts.length
            : serverParts.length;


    for (int i = 0; i < maxLength; i++) {

      final current =
          i < currentParts.length
              ? currentParts[i]
              : 0;


      final server =
          i < serverParts.length
              ? serverParts[i]
              : 0;


      if (server > current) {
        return true;
      }


      if (server < current) {
        return false;
      }
    }


    return false;

  } catch (e) {

    debugPrint(
      '❌ Error parsing version: $e',
    );

    return false;
  }
}


// ================================================================
// CHECK INITIAL SCREEN
//
// ALUR:
//
// Tidak ada internet
//      ↓
// Dino
//
// Internet ada
//      ↓
// Cek Maintenance
//
// Maintenance TRUE
//      ↓
// Maintenance Page
//
// Maintenance FALSE
//      ↓
// Cek Update
//
// Update diperlukan
//      ↓
// Update Page
//
// Update tidak diperlukan
//      ↓
// Cek Auto Login
//
// Auto Login berhasil
//      ↓
// Dashboard
//
// Tidak login
//      ↓
// AppEntryPage
// ================================================================

Future<Widget> checkInitialScreen() async {

  // ==============================================================
  // 1. CEK INTERNET
  // ==============================================================

  try {

    debugPrint(
      '🌐 Mengecek koneksi internet...',
    );


    final internetCheck =
        await InternetAddress.lookup(
      'google.com',
    ).timeout(
      const Duration(
        seconds: 4,
      ),
    );


    if (internetCheck.isEmpty ||
        internetCheck[0]
            .rawAddress
            .isEmpty) {

      debugPrint(
        '🦖 Tidak ada akses internet.',
      );

      return const DinoGameApp();
    }


    debugPrint(
      '🟢 Internet tersedia.',
    );

  } on SocketException {

    debugPrint(
      '🦖 Offline / SocketException.',
    );

    return const DinoGameApp();

  } on TimeoutException {

    debugPrint(
      '🦖 Internet timeout.',
    );

    return const DinoGameApp();

  } catch (e) {

    debugPrint(
      '🦖 Error koneksi: $e',
    );

    return const DinoGameApp();
  }


  // ==============================================================
  // 2. CEK MAINTENANCE
  // ==============================================================

  try {

    debugPrint(
      '🔍 Mengecek maintenance server...',
    );


    final maintenanceUri =
        Uri.parse(
      '$apiBaseUrl/api/maintenance',
    );


    final response =
        await http.get(
      maintenanceUri,
    ).timeout(
      const Duration(
        seconds: 6,
      ),
    );


    // ------------------------------------------------------------
    // HTTP ERROR
    // ------------------------------------------------------------

    if (response.statusCode != 200) {

      debugPrint(
        '🚧 Server maintenance HTTP ${response.statusCode}',
      );

      return const MaintenancePage();
    }


    // ------------------------------------------------------------
    // PARSE JSON
    // ------------------------------------------------------------

    dynamic data;

    try {

      data = jsonDecode(
        response.body,
      );

    } catch (e) {

      debugPrint(
        '🚧 Response maintenance bukan JSON: $e',
      );

      return const MaintenancePage();
    }


    if (data is! Map<String, dynamic>) {

      debugPrint(
        '🚧 Format response maintenance tidak valid.',
      );

      return const MaintenancePage();
    }


    final status =
        data['status'];


    // ------------------------------------------------------------
    // MAINTENANCE TRUE
    // ------------------------------------------------------------

    if (status == true) {

      debugPrint(
        '🚧 Maintenance TRUE.',
      );

      return const MaintenancePage();
    }


    // ------------------------------------------------------------
    // STATUS HARUS FALSE
    // ------------------------------------------------------------

    if (status != false) {

      debugPrint(
        '🚧 Field status maintenance tidak valid.',
      );

      return const MaintenancePage();
    }


    debugPrint(
      '🟢 Maintenance FALSE.',
    );

  } on SocketException catch (e) {

    debugPrint(
      '🚧 Server API tidak dapat dijangkau: $e',
    );

    return const MaintenancePage();

  } on http.ClientException catch (e) {

    debugPrint(
      '🚧 HTTP Client Error: $e',
    );

    return const MaintenancePage();

  } on TimeoutException {

    debugPrint(
      '🚧 Server API timeout.',
    );

    return const MaintenancePage();

  } catch (e) {

    debugPrint(
      '🚧 Error maintenance: $e',
    );

    return const MaintenancePage();
  }


  // ==============================================================
  // 3. CEK UPDATE
  // ==============================================================

  try {

    debugPrint(
      '🔍 Mengecek update aplikasi...',
    );


    final packageInfo =
        await PackageInfo.fromPlatform();


    final String currentAppVersion =
        packageInfo.version;


    final updateUri =
        Uri.parse(
      '$apiBaseUrl/api/update',
    );


    final response =
        await http.get(
      updateUri,
    ).timeout(
      const Duration(
        seconds: 5,
      ),
    );


    if (response.statusCode == 200) {

      dynamic data;


      try {

        data = jsonDecode(
          response.body,
        );

      } catch (_) {

        data = null;
      }


      if (data is Map<String, dynamic>) {

        final String latestVersion =
            (data['version'] ?? '')
                .toString()
                .trim();


        if (latestVersion.isNotEmpty) {

          final bool needUpdate =
              isUpdateRequired(
            currentAppVersion,
            latestVersion,
          );


          if (needUpdate) {

            debugPrint(
              '⬆️ Update diperlukan: '
              '$currentAppVersion → '
              '$latestVersion',
            );


            return UpdatePage(
              currentVersion:
                  currentAppVersion,
              latestVersion:
                  latestVersion,
            );
          }
        }
      }
    }


    debugPrint(
      '🟢 Tidak ada update wajib.',
    );

  } catch (e) {

    // ------------------------------------------------------------
    // Kalau endpoint update error,
    // jangan langsung blok aplikasi.
    // ------------------------------------------------------------

    debugPrint(
      '⚠️ Error pengecekan update: $e',
    );
  }


  // ==============================================================
  // 4. CEK AUTO LOGIN
  // ==============================================================

  try {

    debugPrint(
      '🔍 Mengecek session login...',
    );


    final prefs =
        await SharedPreferences.getInstance();


    final String? savedUser =
        prefs.getString(
      'username',
    );


    final String? savedPass =
        prefs.getString(
      'password',
    );


    final String? savedKey =
        prefs.getString(
      'key',
    );


    // ------------------------------------------------------------
    // TIDAK ADA SESSION
    // ------------------------------------------------------------

    if (savedUser == null ||
        savedUser.isEmpty ||
        savedPass == null ||
        savedPass.isEmpty ||
        savedKey == null ||
        savedKey.isEmpty) {

      debugPrint(
        'ℹ️ Tidak ada session login.',
      );

      return const AppEntryPage();
    }


    // ------------------------------------------------------------
    // AUTO LOGIN
    // ------------------------------------------------------------

    debugPrint(
      '🔄 Mencoba auto-login...',
    );


    String androidId =
        'unknown_device';


    try {

      final deviceInfo =
          DeviceInfoPlugin();


      final android =
          await deviceInfo.androidInfo;


      androidId =
          android.id.isEmpty
              ? 'unknown_device'
              : android.id;

    } catch (e) {

      debugPrint(
        '⚠️ Gagal mendapatkan Android ID: $e',
      );
    }


    final uri =
        Uri.parse(
      '$apiBaseUrl/api/accountDetails',
    ).replace(
      queryParameters: {

        'username':
            savedUser,

        'password':
            savedPass,

        'androidId':
            androidId,

        'key':
            savedKey,
      },
    );


    final response =
        await http.get(
      uri,
    ).timeout(
      const Duration(
        seconds: 7,
      ),
    );


    // ------------------------------------------------------------
    // RESPONSE 200
    // ------------------------------------------------------------

    if (response.statusCode == 200) {

      dynamic data;


      try {

        data = jsonDecode(
          response.body,
        );

      } catch (e) {

        debugPrint(
          '⚠️ Response accountDetails bukan JSON: $e',
        );

        data = null;
      }


      if (data is Map<String, dynamic>) {


        // ========================================================
        // LOGIN VALID
        // ========================================================

        if (data['valid'] == true) {

          debugPrint(
            '🟢 Auto-login berhasil.',
          );


          return DashboardPage(

            username:
                savedUser,

            password:
                savedPass,

            role:
                data['role'],

            sessionKey:
                data['key'] ?? savedKey,

            expiredDate:
                data['expiredDate'],
                
            balance:
                data['balance'],
                
            apiKeyQris:
                data['apiKeyQris'],


            listBug:
                (data['listBug']
                        as List? ??
                    [])
                    .map(
                      (e) =>
                          Map<String, dynamic>.from(
                        e as Map,
                      ),
                    )
                    .toList(),


            listBugGroup:
                (data['listBugGroup']
                        as List? ??
                    [])
                    .map(
                      (e) =>
                          Map<String, dynamic>.from(
                        e as Map,
                      ),
                    )
                    .toList(),


            listBugCh:
                (data['listBugCh']
                        as List? ??
                    [])
                    .map(
                      (e) =>
                          Map<String, dynamic>.from(
                        e as Map,
                      ),
                    )
                    .toList(),


            news:
                (data['news']
                        as List? ??
                    [])
                    .map(
                      (e) =>
                          Map<String, dynamic>.from(
                        e as Map,
                      ),
                    )
                    .toList(),


            uid:
                data['uid'],
          );
        }


        // ========================================================
        // SESSION TIDAK VALID
        // ========================================================

        debugPrint(
          '⚠️ Session tidak valid. Menghapus session.',
        );


        await prefs.remove(
          'username',
        );

        await prefs.remove(
          'password',
        );

        await prefs.remove(
          'key',
        );
      }
    }

  } catch (e) {

    debugPrint(
      '❌ Error auto-login: $e',
    );
  }


  // ==============================================================
  // 5. BELUM LOGIN
  // ==============================================================

  debugPrint(
    '➡️ Masuk AppEntryPage.',
  );


  return const AppEntryPage();
}


// ================================================================
// MY APP
// ================================================================

class MyApp extends StatefulWidget {

  const MyApp({
    super.key,
  });

  @override
  State<MyApp> createState() =>
      _MyAppState();
}


class _MyAppState
    extends State<MyApp> {

  late final AppLinks _appLinks;


  @override
  void initState() {
    super.initState();

    initDeepLinks();
  }


  // ==============================================================
  // DEEP LINK
  // ==============================================================

  Future<void> initDeepLinks() async {

    _appLinks = AppLinks();


    try {

      final initialUri =
          await _appLinks.getInitialAppLink();


      if (initialUri != null) {

        handleIncomingUri(
          initialUri,
        );
      }

    } catch (e) {

      debugPrint(
        '❌ Error getInitialAppLink: $e',
      );
    }


    _appLinks.uriLinkStream.listen(
      (uri) {

        handleIncomingUri(
          uri,
        );
      },

      onError: (err) {

        debugPrint(
          '❌ Error uriLinkStream: $err',
        );
      },
    );
  }


  // ==============================================================
  // HANDLE DEEP LINK
  // ==============================================================

  void handleIncomingUri(
    Uri uri,
  ) {

    debugPrint(
      '🌐 Deep link diterima: $uri',
    );


    if (uri.pathSegments.isNotEmpty) {

      final targetRoute =
          '/${uri.pathSegments.first}';


      navigatorKey.currentState
          ?.pushNamed(
        targetRoute,
      );
    }
  }


  // ==============================================================
  // BUILD
  // ==============================================================

  @override
  Widget build(
    BuildContext context,
  ) {

    return MaterialApp(

      navigatorKey:
          navigatorKey,

      debugShowCheckedModeBanner:
          false,

      title:
          'atlas',


      theme:
          ThemeData(

        brightness:
            Brightness.dark,

        fontFamily:
            'ShareTechMono',

        scaffoldBackgroundColor:
            const Color(
          0xFFCED4DA,
        ),


        colorScheme:
            const ColorScheme.dark().copyWith(

          primary:
              const Color(
            0xFF4F46E5,
          ),

          secondary:
              const Color(
            0xFF6366F1,
          ),

          tertiary:
              const Color(
            0xFFA5B4FC,
          ),

          background:
              const Color(
            0xFF1E1B2E,
          ),

          surface:
              const Color(
            0xFF2A2744,
          ),
        ),


        primaryColor:
            const Color(
          0xFF4F46E5,
        ),


        appBarTheme:
            const AppBarTheme(

          backgroundColor:
              Colors.black,

          foregroundColor:
              Colors.black87,

          iconTheme:
              IconThemeData(
            color:
                Colors.black87,
          ),
        ),


        iconTheme:
            const IconThemeData(
          color:
              Colors.black87,
        ),


        elevatedButtonTheme:
            ElevatedButtonThemeData(

          style:
              ElevatedButton.styleFrom(

            backgroundColor:
                const Color(
              0xFF4F46E5,
            ),

            foregroundColor:
                Colors.black87,

            shape:
                RoundedRectangleBorder(
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),
          ),
        ),


        textButtonTheme:
            TextButtonThemeData(

          style:
              TextButton.styleFrom(
            foregroundColor:
                Colors.grey.shade800,
          ),
        ),


        outlinedButtonTheme:
            OutlinedButtonThemeData(

          style:
              OutlinedButton.styleFrom(

            foregroundColor:
                Colors.grey.shade800,

            side:
                const BorderSide(
              color:
                  Colors.grey,
            ),
          ),
        ),


        floatingActionButtonTheme:
            const FloatingActionButtonThemeData(

          backgroundColor:
              Colors.grey,
        ),


        inputDecorationTheme:
            InputDecorationTheme(

          filled:
              true,

          fillColor:
              Colors.black.withOpacity(
            0.3,
          ),


          focusedBorder:
              OutlineInputBorder(

            borderSide:
                const BorderSide(
              color:
                  Colors.grey,
            ),

            borderRadius:
                BorderRadius.circular(
              12,
            ),
          ),


          enabledBorder:
              OutlineInputBorder(

            borderSide:
                BorderSide(
              color:
                  Colors.grey.withOpacity(
                0.6,
              ),
            ),

            borderRadius:
                BorderRadius.circular(
              12,
            ),
          ),
        ),


        snackBarTheme:
            SnackBarThemeData(

          backgroundColor:
              Colors.grey.shade800,

          contentTextStyle:
              const TextStyle(
            color:
                Colors.black87,
          ),
        ),
      ),


      // ==========================================================
      // HOME
      // ==========================================================

      home:
          const IntroSplashScreen(),


      // ==========================================================
      // ROUTES
      // ==========================================================

      onGenerateRoute:
          (settings) {

        switch (settings.name) {

          // ------------------------------------------------------
          // ROOT
          // ------------------------------------------------------

          case '/':
            return MaterialPageRoute(
              builder: (_) =>
                  const AppEntryPage(),
            );


          // ------------------------------------------------------
          // LANDING
          // ------------------------------------------------------

          case '/landing':
            return MaterialPageRoute(
              builder: (_) =>
                  const LandingPage(),
            );


          // ------------------------------------------------------
          // LOGIN
          // ------------------------------------------------------

          case '/login':
            return MaterialPageRoute(
              builder: (_) =>
                  const LoginPage(),
            );


          // ------------------------------------------------------
          // MAINTENANCE
          // ------------------------------------------------------

          case '/maintenance':
            return MaterialPageRoute(
              builder: (_) =>
                  const MaintenancePage(),
            );


          // ------------------------------------------------------
          // UPDATE
          // ------------------------------------------------------

          case '/update':
            return MaterialPageRoute(
              builder: (_) =>
                  const UpdatePage(),
            );


          // ------------------------------------------------------
          // DINO
          // ------------------------------------------------------

          case '/dino':
            return MaterialPageRoute(
              builder: (_) =>
                  const DinoGameApp(),
            );


          // ------------------------------------------------------
          // DASHBOARD
          // ------------------------------------------------------

          case '/dashboard':

            final args =
                settings.arguments
                    as Map<String, dynamic>;


            return MaterialPageRoute(

              builder: (_) =>
                  DashboardPage(

                username:
                    args['username'],

                password:
                    args['password'],

                role:
                    args['role'],

                sessionKey:
                    args['key'],

                expiredDate:
                    args['expiredDate'],
                    
                balance:
                    args['balance'],
                    
                apiKeyQris:
                    args['apiKeyQris'],
                    

                listBug:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBug'] ?? [],
                ),


                listBugGroup:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBugGroup'] ?? [],
                ),


                listBugCh:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBugCh'] ?? [],
                ),


                news:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['news'] ?? [],
                ),


                uid:
                    args['uid'],
              ),
            );


          // ------------------------------------------------------
          // HOME
          // ------------------------------------------------------

          case '/home':

            final args =
                settings.arguments
                    as Map<String, dynamic>;


            return MaterialPageRoute(

              builder: (_) =>
                  HomePage(

                username:
                    args['username'],

                password:
                    args['password'],


                listBug:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBug'] ?? [],
                ),


                listBugGroup:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBugGroup'] ?? [],
                ),


                listBugCh:
                    List<
                      Map<String, dynamic>
                    >.from(
                  args['listBugCh'] ?? [],
                ),


                role:
                    args['role'],

                expiredDate:
                    args['expiredDate'],

                sessionKey:
                    args['sessionKey'],
              ),
            );


          // ------------------------------------------------------
          // SELLER
          // ------------------------------------------------------

          case '/seller':

            final args =
                settings.arguments
                    as Map<String, dynamic>;


            return MaterialPageRoute(

              builder: (_) =>
                  SellerPage(
                keyToken:
                    args['keyToken'],
              ),
            );


          // ------------------------------------------------------
          // ADMIN
          // ------------------------------------------------------

          case '/admin':

            final args =
                settings.arguments
                    as Map<String, dynamic>;


            return MaterialPageRoute(

              builder: (_) =>
                  AdminPage(
                sessionKey:
                    args['sessionKey'],
              ),
            );


          // ------------------------------------------------------
          // OWNER
          // ------------------------------------------------------

          case '/owner':

            final args =
                settings.arguments
                    as Map<String, dynamic>;


            return MaterialPageRoute(

              builder: (_) =>
                  OwnerPage(

                sessionKey:
                    args['sessionKey'],

                username:
                    args['username'],
              ),
            );


          // ------------------------------------------------------
          // CONTROL PANEL
          // ------------------------------------------------------

          case '/control_panel':

            return MaterialPageRoute(
              builder: (_) =>
                  const ControlPanelPage(),
            );


          // ------------------------------------------------------
          // JADWAL SHOLAT
          // ------------------------------------------------------

          case '/jadwal_sholat':

            return MaterialPageRoute(
              builder: (_) =>
                  const JadwalSholatPage(),
            );


          // ------------------------------------------------------
          // KAMUS JEPANG
          // ------------------------------------------------------

          case '/kamus_jepang':

            return MaterialPageRoute(
              builder: (_) =>
                  const KamusJepangPage(),
            );


          // ------------------------------------------------------
          // 404
          // ------------------------------------------------------

          default:

            return MaterialPageRoute(

              builder: (_) =>
                  const Scaffold(

                body:
                    Center(

                  child:
                      Text(
                    "404 - Not Found",
                  ),
                ),
              ),
            );
        }
      },
    );
  }
}